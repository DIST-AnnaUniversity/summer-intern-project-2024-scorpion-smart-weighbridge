import sys
import os
import cv2
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PyQt5.QtGui import QPixmap, QImage, QPainter, QColor, QFont
from PyQt5.QtCore import QTimer, Qt, QTime, QDate
from PyQt5 import uic
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtMultimediaWidgets import QVideoWidget
from PyQt5.QtCore import QUrl
from Presentation.Py.SplashScreen import SplashScreen

# Directory containing slideshow images
IMAGE_DIR = 'Add images'

# Placeholder RTSP URLs for the cameras
rtsp_url_cam1 = 'k'
rtsp_url_cam2 = 'k'
rtsp_url_cam3 = 'k'
rtsp_url_cam4 = 'k'

class SlideshowWindow(QWidget):
    def __init__(self, image_folder, parent=None):
        super(SlideshowWindow, self).__init__(parent)
        self.image_folder = image_folder
        self.image_files = [os.path.join(image_folder, f) for f in os.listdir(image_folder) if f.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.mp4'))]
        self.current_index = 0
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.label)
        self.layout.setAlignment(Qt.AlignCenter)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.show_next_media)

        self.media_player = QMediaPlayer(None, QMediaPlayer.VideoSurface)
        self.video_widget = QVideoWidget(self)
        self.video_widget.setFixedSize(400, 500)
        self.layout.addWidget(self.video_widget)
        self.media_player.setVideoOutput(self.video_widget)

        self.show_next_media()

    def show_next_media(self):
        # Stop any active timers
        self.timer.stop()
        self.media_player.stop()

        if self.image_files:
            current_file = self.image_files[self.current_index]
            if current_file.endswith('.mp4'):
                self.show_video(current_file)
            else:
                self.show_image(current_file)

            self.current_index = (self.current_index + 1) % len(self.image_files)

    def show_image(self, image_path):
        pixmap = QPixmap(image_path)
        pixmap = pixmap.scaled(400, 500, Qt.KeepAspectRatio)  # Resize pixmap to 400x300 with aspect ratio
        self.label.setPixmap(pixmap)
        self.label.show()
        self.video_widget.hide()
        self.timer.start(2000)  # Change image every 2 seconds

    def show_video(self, video_path):
        self.label.hide()
        self.video_widget.show()
        self.media_player.setMedia(QMediaContent(QUrl.fromLocalFile(video_path)))
        self.media_player.play()

class CameraFeed(QWidget):
    def __init__(self, label, rtsp_url, parent=None):
        super(CameraFeed, self).__init__(parent)
        self.label = label
        self.rtsp_url = rtsp_url
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)  # Update frame every 30 ms
        self.no_feed_pixmap = self.create_no_feed_pixmap()

        # Create timestamp label
        self.timestamp_label = QLabel(self.label)
        self.timestamp_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.timestamp_label.setStyleSheet("color: white; background-color: black; padding: 5px;")
        self.timestamp_label.setFont(QFont('Arial', 29))
        self.timestamp_label.move(10, 29)  # Adjust position as needed

    def create_no_feed_pixmap(self):
        pixmap = QPixmap(self.label.size())
        pixmap.fill(Qt.black)
        painter = QPainter(pixmap)
        painter.setPen(QColor(Qt.white))
        painter.setFont(QFont('Arial', 20))
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "No camera feed")
        painter.end()
        return pixmap

    def update_frame(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = QImage(frame, frame.shape[1], frame.shape[0], QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(image)

            # Update timestamp
            current_time = QTime.currentTime().toString('hh:mm:ss')
            current_date = QDate.currentDate().toString('dd-MM-yyyy')
            timestamp_text = f"{current_time} {current_date}"
            self.timestamp_label.setText(timestamp_text)
        else:
            pixmap = self.no_feed_pixmap

        self.label.setPixmap(pixmap)

    def close(self):
        self.timer.stop()
        self.cap.release()

def main():
    try:
        os.system('sudo ifconfig eth0 192.168.10.100 netmask 255.255.255.0 up')
        scorpion_wb_application = QApplication(sys.argv)

        # Get the primary and secondary screens
        screens = scorpion_wb_application.screens()
        primary_screen = screens[0]
        secondary_screen = screens[1] if len(screens) > 1 else None

        # Show splash screen on primary screen (laptop)
        load_splash_screen = SplashScreen()
        load_splash_screen.show()

        if secondary_screen:
            # Set up main window (camera UI) on secondary screen
            main_window = QMainWindow()
            ui_path = os.path.join('Presentation', 'UI', 'mainscreen_cam.ui')
            main_window_widget = QWidget()
            uic.loadUi(ui_path, main_window_widget)
            main_window.setCentralWidget(main_window_widget)

            # Set up slideshow window on secondary screen
            slideshow_window = SlideshowWindow(IMAGE_DIR)

            # Layout for main window and slideshow
            main_layout = QHBoxLayout()
            main_layout.addWidget(main_window_widget, 3)  # Camera UI takes 3/4 of the space
            main_layout.addWidget(slideshow_window, 1)   # Slideshow takes 1/4 of the space

            # Create a central widget for main_window to hold both main window and slideshow
            central_widget = QWidget()
            central_widget.setLayout(main_layout)
            main_window.setCentralWidget(central_widget)

            main_window.setGeometry(secondary_screen.geometry())
            main_window.show()

            # Create camera feed instances for each label
            cam1_label = main_window_widget.findChild(QLabel, 'cam1')
            cam2_label = main_window_widget.findChild(QLabel, 'cam2')
            cam3_label = main_window_widget.findChild(QLabel, 'cam3')
            cam4_label = main_window_widget.findChild(QLabel, 'cam4')

            cam1_feed = CameraFeed(cam1_label, rtsp_url_cam1)
            cam2_feed = CameraFeed(cam2_label, rtsp_url_cam2)
            cam3_feed = CameraFeed(cam3_label, rtsp_url_cam3)
            cam4_feed = CameraFeed(cam4_label, rtsp_url_cam4)

        scorpion_wb_application.exec_()
    except Exception as e:
        print(f"Exception occurred: {e}")
    finally:
        print("Application closed.")
        sys.exit()

if __name__ == '__main__':
    main()
