import platform
import sys
import os

from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QDialog, QMessageBox, QGridLayout
from PyQt5.QtCore import QTime, pyqtSlot, QEvent
from PyQt5 import uic
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtGui import QPixmap, QFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView
from PyQt5.QtCore import pyqtSignal

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Py.SystemConfig import SystemConfig
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable
import cv2

class CameraScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        ui_file = os.path.join(ROOT_PATH, 'UI', 'camera.ui')

        # Load the UI file
        uic.loadUi(ui_file, self)

        self.setWindowTitle("Camera Feed")

        self.setGeometry(0, 2, 900, 480)

        # Initialize camera labels and buttons from UI
        self.camera_1 = self.findChild(QLabel, 'camera_1')
        self.camera_2 = self.findChild(QLabel, 'camera_2')
        self.camera_3 = self.findChild(QLabel, 'camera_3')
        self.camera_4 = self.findChild(QLabel, 'camera_4')


        self.capture_button_1 = self.findChild(QPushButton, 'capture_button')
        self.capture_button_2 = self.findChild(QPushButton, 'capture_button_2')
        self.capture_button_3 = self.findChild(QPushButton, 'capture_button_3')
        self.capture_button_4 = self.findChild(QPushButton, 'capture_button_4')
        self.print_button = self.findChild(QPushButton, 'print_button')
        self.close_camera_button = self.findChild(QPushButton, 'close_camera_button')

        self.camera_labels = {
            "camera_1": self.camera_1,
            "camera_2": self.camera_2,
            "camera_3": self.camera_3,
            "camera_4": self.camera_4,
        }
        self.captured_images = {
            "camera_1": [],
            "camera_2": [],
            "camera_3": [],
            "camera_4": [],
        }
        self.full_screen_dialogs = {}


        # Mouse Press
        self.camera_1.mousePressEvent = lambda event: self.display_full_screen(self.camera_1)
        self.camera_2.mousePressEvent = lambda event: self.display_full_screen(self.camera_2)
        self.camera_3.mousePressEvent = lambda event: self.display_full_screen(self.camera_3)
        self.camera_4.mousePressEvent = lambda event: self.display_full_screen(self.camera_4)

        # Shortcut Key
        self.key_actions = {
            Qt.Key_Escape: lambda: self.go_home(),
            Qt.Key_1: lambda: self.display_full_screen(self.camera_1),
            Qt.Key_2: lambda: self.display_full_screen(self.camera_2),
            Qt.Key_3: lambda: self.display_full_screen(self.camera_3),
            Qt.Key_4: lambda: self.display_full_screen(self.camera_4),
            Qt.Key_QuoteLeft: lambda: self.close_full_screen(),
            Qt.Key_Q: lambda: self.capture_image("camera_1"),
            Qt.Key_W: lambda: self.capture_image("camera_2"),
            Qt.Key_E: lambda: self.capture_image("camera_3"),
            Qt.Key_R: lambda: self.capture_image("camera_4"),
            Qt.Key_P: lambda: self.print_pdf()
        }

        # Connect capture buttons
        self.capture_button_1.clicked.connect(lambda: self.capture_image("camera_1"))
        self.capture_button_2.clicked.connect(lambda: self.capture_image("camera_2"))
        self.capture_button_3.clicked.connect(lambda: self.capture_image("camera_3"))
        self.capture_button_4.clicked.connect(lambda: self.capture_image("camera_4"))

        self.print_button.clicked.connect(self.print_pdf)
        self.print_button.setEnabled(False)  # Initially disabled

        self.close_camera_button.clicked.connect(self.go_home)

        self.rtsp_url_1 = SystemConfig.on_loading_URL1(self)
        self.rtsp_url_2 = SystemConfig.on_loading_URL2(self)
        self.rtsp_url_3 = SystemConfig.on_loading_URL3(self)
        self.rtsp_url_4 = SystemConfig.on_loading_URL4(self)

        print(self.rtsp_url_1,self.rtsp_url_2,self.rtsp_url_3,self.rtsp_url_4)

        self.cap_1 = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.cap_2 = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.cap_3 = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.cap_4 = cv2.VideoCapture(0, cv2.CAP_DSHOW)


        # self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.datetime_timer = QTimer(self)
        self.datetime_timer.timeout.connect(self.update_datetime)
        self.datetime_timer.start(1000)

        self.current_datetime = ""

        #Focus Policy to enable key events
        self.setFocusPolicy(Qt.StrongFocus)
        self.setFocus()


    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def close_full_screen(self):
        for dialog in self.full_screen_dialogs.values():
            dialog.close()

    def go_home(self):
        # Release the camera resources
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        if self.cap_3 is not None:
            self.cap_3.release()
        if self.cap_4 is not None:
            self.cap_4.release()
        # Stop the timer
        self.timer.stop()
        # Close the window
        self.close()

    def closeEvent(self, event):
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        if self.cap_3 is not None:
            self.cap_3.release()
        if self.cap_4 is not None:
            self.cap_4.release()
        self.timer.stop()
        event.accept()

    def show_camera_boxes(self):
        self.camera_screen = CameraScreen(self)
        self.camera_screen.show()

    def update_camera_feed(self):
        camera_caps = [self.cap_1, self.cap_2, self.cap_3, self.cap_4]
        for idx, (camera_name, camera_label) in enumerate(self.camera_labels.items()):
            cap = camera_caps[idx]
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                height, width, channel = frame.shape
                bytesPerLine = 3 * width
                qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

                painter = QPainter(qImg)
                painter.setPen(QColor(Qt.white))
                painter.setFont(QFont("Arial", 12))
                painter.drawText(10, 20, self.current_datetime)
                painter.end()

                pixmap = QPixmap.fromImage(qImg)
                camera_label.setPixmap(pixmap)
            else:
                self.show_no_camera_feed(camera_label)

    def show_no_camera_feed(self, camera_label):
        camera_label.setText("No Camera Feed")
        camera_label.setAlignment(Qt.AlignCenter)
        camera_label.setStyleSheet("color: white; background-color: black;")

    def update_datetime(self):
        self.current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")

    def display_full_screen(self, label):
        if isinstance(label, QLabel) and label.pixmap():
            camera_name = next(key for key, value in self.camera_labels.items() if value is label)
            cap = getattr(self, f"cap_{camera_name[-1]}")
            if camera_name not in self.full_screen_dialogs:
                self.full_screen_dialogs[camera_name] = FullScreenDialog(cap, camera_name, self)
            self.full_screen_dialogs[camera_name].showFullScreen()

    def capture_image(self, camera_name):
        # Get the current date and time
        current_datetime = QDateTime.currentDateTime()
        year = current_datetime.toString("yyyy")
        month = current_datetime.toString("MMMM")  # Full month name
        date = current_datetime.toString("dd-MM-yyyy")  # Full date
        time = current_datetime.toString("HH.mm.ss")  # Time with periods instead of colons

        # Determine which capture object to use based on camera_name
        if camera_name == "camera_1":
            cap = self.cap_1
        elif camera_name == "camera_2":
            cap = self.cap_2
        elif camera_name == "camera_3":
            cap = self.cap_3
        elif camera_name == "camera_4":
            cap = self.cap_4
        else:
            return  # Handle unknown camera_name if needed

        # Create the directory structure: captured_images/year/month/date
        base_dir = os.path.join("captured_images", year, month, date)
        if not os.path.exists(base_dir):
            os.makedirs(base_dir)

        # Save the image in the created directory with the updated timestamp format in the filename
        image_path = os.path.join(base_dir, f"{camera_name}_{time}.jpg")
        ret, frame = cap.read()
        if ret:
            cv2.imwrite(image_path, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

            # Append the image path to the captured images dictionary
            if camera_name not in self.captured_images:
                self.captured_images[camera_name] = []
            self.captured_images[camera_name].append(image_path)

            # Show a message box to inform the user about the captured image
            QMessageBox.information(self, "Capture", f"Image captured and saved at {image_path}.")

            # Check if any two cameras have captured at least one image each, then enable the print button
            cameras_with_images = [camera for camera, images in self.captured_images.items() if len(images) >= 1]
            if len(cameras_with_images) >= 2:
                self.print_button.setEnabled(True)
            else:
                self.print_button.setEnabled(False)
        else:
            QMessageBox.warning(self, "Capture Error", "Failed to capture image from selected camera.")

    def print_pdf(self):
        # Find cameras with at least one captured image
        cameras_with_images = [camera_name for camera_name, images in self.captured_images.items() if len(images) >= 1]

        if len(cameras_with_images) < 1:
            QMessageBox.warning(self, "Print Error", "Need at least one image from any camera to print.")
            return

        # Prepare PDF
        current_datetime = QDateTime.currentDateTime()
        year = current_datetime.toString("yyyy")
        month = current_datetime.toString("MMMM")  # Full month name
        date = current_datetime.toString("dd-MM-yyyy")  # Full date
        time = current_datetime.toString("HH.mm.ss")  # Time with periods instead of colons

        # Create the directory structure: captured_images/year/month/date
        base_dir = os.path.join("pdf_reports", year, month, date)
        if not os.path.exists(base_dir):
            os.makedirs(base_dir)

        pdf_path = os.path.join(base_dir, f"bill_{time}.pdf")


        c = canvas.Canvas(pdf_path, pagesize=A4)
        width, height = A4

        margin = 20
        space_between_images = 20
        vertical_offset = 50

        # Draw the title
        title = "WEIGHMENT CERTIFICATE"
        c.setFont("Helvetica-Bold", 16)
        title_width = c.stringWidth(title)
        title_x = (width - title_width) / 2
        title_y = height - margin - 20
        c.drawString(title_x, title_y, title)

        # Underline the title
        c.line(title_x, title_y - 5, title_x + title_width, title_y - 5)

        # Adjust the text_y value to increase or decrease the space below the title
        text_y = height - margin - 120  # Adjust this value for spacing

        # Dashed lines
        c.setStrokeColor(colors.black)
        c.setDash(6, 3)
        c.line(margin, text_y + 60, width - margin, text_y + 60)
        c.line(margin, text_y - 250, width - margin, text_y - 250)
        c.setDash(1, 0)

        left_details = [
            f"BILL NO                      : ",
            f"MATERIAL                  : ",
            f"AGENT NAME            : ",
            f"PLACE OF LOADING : ",
            f"MOISTURE VALUE    : ",
            f"SIZE                            : ",
            f"GROSS Wt (Kg)          : ",
            f"TARE  Wt (Kg)            : ",
            f"NETT  Wt (Kg)            : "
        ]

        right_details = [
            f"VEHICLE                            : ",
            f"SUPERVISOR NAME        : ",
            f"COUNT                              : ",
            f"MSEZ DELIVERY NO        : ",
            f"SUPPLIER CHALLAN NO : ",
            f"AMOUNT (RS)                   : ",
            f"TIME                                   : ",
            f"DATE                                  : "
        ]

        line_spacing = 25

        c.setFont("Helvetica", 11)
        for i, label in enumerate(left_details):
            c.drawString(margin + 20, text_y - (i * line_spacing), label)

        for i, label in enumerate(right_details):
            c.drawString(margin + 320, text_y - (i * line_spacing), label)

        text_y -= max(len(left_details), len(right_details)) * line_spacing + 20

        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        text_y -= 20

        c.setFont("Helvetica", 10)
        additional_text = "LCS - For All Your Weighing Needs"
        additional_text_width = c.stringWidth(additional_text)
        additional_text_x = (width - additional_text_width) / 2
        c.drawString(additional_text_x, text_y - 2, additional_text)

        # Adjust image dimensions and placement
        # Adjust image dimensions and placement
        # Adjust image dimensions and placement
        img_width = 180  # Set a fixed width for images
        img_height = 120  # Set a fixed height for images
        space_between_images = 20  # Set spacing between images horizontally
        second_image_offset = 240  # Set the offset for the second image

        for camera_idx, camera_name in enumerate(cameras_with_images):
            images_to_print = self.captured_images[camera_name][:2]  # Limit to two images per camera

            # Draw camera header
            text_cam = f"Camera {camera_name[-1]}"
            text_cam = f"Camera {camera_name[-1]}"
            c.setFont("Helvetica-Bold", 12)
            c.drawString(margin, text_y, text_cam)
            text_y -= 20

            x_pos = margin  # Starting position for the first image

            for idx, image_path in enumerate(images_to_print):
                if idx >= 2:
                    break  # Limit to two images per camera

                image = cv2.imread(image_path)
                image_height, image_width, _ = image.shape
                aspect_ratio = image_width / image_height

                if idx == 1:
                    # Adjust x_pos for the second image
                    x_pos += second_image_offset

                # Calculate position for each image
                c.drawImage(image_path, x_pos, text_y - img_height, width=img_width, height=img_height)

                # Move x_pos for the next image to be drawn next to the current one
                x_pos += img_width + space_between_images

            text_y -= img_height + 20  # Adjust vertical position for the next camera section

        # Add signatures
        c.setFont("Helvetica", 12)
        text_operator = "Signature of the Operator"
        text_width_operator = c.stringWidth(text_operator, "Helvetica", 12)
        c.drawString(margin + 20, margin + 5, text_operator)
        c.line(margin + 20, margin + 20, margin + 220, margin + 20)

        text_supervisor = "Signature of the Supervisor"
        text_width_supervisor = c.stringWidth(text_supervisor, "Helvetica", 12)
        c.drawString(width - margin - text_width_supervisor - 20, margin + 5, text_supervisor)
        c.line(width - margin - 220, margin + 20, width - margin - 20, margin + 20)

        c.save()

        # Clear captured images
        for camera_name in cameras_with_images:
            self.captured_images[camera_name].clear()

        QMessageBox.information(self, "PDF", f"PDF generated at {pdf_path}.")





class FullScreenDialog(QWidget):
    def __init__(self, cap, camera_name, parent=None):
        super(FullScreenDialog, self).__init__(parent)
        self.setWindowModality(Qt.ApplicationModal)
        self.cap = cap
        self.camera_name = camera_name

        self.setGeometry(-15, -85, 1000, 700)  # Adjust the geometry as needed

        self.layout = QVBoxLayout(self)

        self.close_button = QPushButton("back", self)
        self.close_button.setFixedSize(840, 10)
        font = QFont()
        font.setPointSize(24)  # Set font size
        self.close_button.setFont(font)
        self.close_button.clicked.connect(self.close)
        self.layout.addWidget(self.close_button)

        self.camera_label = QLabel(self)
        self.layout.addWidget(self.camera_label)

        self.setLayout(self.layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.captured_images = []

    def keyPressEvent(self, event):
        self.close()

    def update_camera_feed(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

            painter = QPainter(qImg)
            painter.setPen(QColor(Qt.white))
            painter.setFont(QFont("Arial", 12))
            current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")
            painter.drawText(10, 20, current_datetime)
            painter.end()

            qImg_scaled = qImg.scaled(self.camera_label.size(), Qt.KeepAspectRatio)
            pixmap = QPixmap.fromImage(qImg_scaled)
            self.camera_label.setPixmap(pixmap)

    def mousePressEvent(self, event):
        self.close()


class MainScreen(QMainWindow):
    def __init__(self, parent=None):
        super(MainScreen, self).__init__(parent)
        self.setWindowTitle("Main Screen")
        self.setGeometry(100, 100, 800, 600)

        self.btn_camera = QPushButton("Open Camera", self)
        self.btn_camera.clicked.connect(self.show_camera_boxes)

        self.voice_button = self.findChild(QPushButton, 'voice_button')
        self.voice_button.clicked.connect(self.activate_voice_command)

        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.btn_camera)
        self.layout.addWidget(self.voice_button)

        central_widget = QWidget()
        central_widget.setLayout(self.layout)
        self.setCentralWidget(central_widget)

        self.cap = None  # Placeholder for camera capture object

    def show_camera_boxes(self):
        camera_screen = CameraScreen(self, self.cap)
        camera_screen.show()

    def activate_voice_command(self):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            QMessageBox.information(self, "Voice Command", "Speak now...")
            audio = recognizer.listen(source)

        try:
            command = recognizer.recognize_google(audio)
            if "open camera" in command.lower():
                self.show_camera_boxes()
            else:
                QMessageBox.warning(self, "Voice Command", f"Command '{command}' not recognized.")
        except sr.UnknownValueError:
            QMessageBox.warning(self, "Voice Command", "Sorry, I didn't catch that.")
        except sr.RequestError:
            QMessageBox.warning(self, "Voice Command", "Speech recognition service is unavailable.")

# Create an instance of the MainScreen class and run the application
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainScreen()
    window.show()
    sys.exit(app.exec_())
