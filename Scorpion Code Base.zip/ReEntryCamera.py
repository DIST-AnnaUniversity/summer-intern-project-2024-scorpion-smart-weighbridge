import platform
import sys
import os
import cv2
import subprocess
import shutil


from PyQt5.QtCore import Qt, QTimer, QDateTime, QDate
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QDialog, QMessageBox, QGridLayout
from PyQt5.QtCore import QTime, pyqtSlot, QEvent
from PyQt5 import uic
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtGui import QPixmap, QFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView
from PyQt5.QtCore import pyqtSignal

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from BusinessLogic.MainScreenBL import MainScreenBL
from Presentation.Py.SystemConfig import SystemConfig
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable


import platform
import sys
import os
import cv2

from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QDialog, QMessageBox, QGridLayout
from PyQt5.QtCore import QTime, pyqtSlot, QEvent
from PyQt5 import uic
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtGui import QPixmap, QFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView
from PyQt5.QtCore import pyqtSignal

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Py.SystemConfig import SystemConfig
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable

class Preview(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        ui_file = os.path.join(ROOT_PATH, 'UI', 'ReEntryCamera.ui')

        # Load the UI file
        uic.loadUi(ui_file, self)

        self.setWindowTitle("Camera Feed")
        self.setGeometry(0, 2, 810, 484)  # Adjusted geometry to match the UI

        # Initialize camera labels from UI
        self.camera_1 = self.findChild(QLabel, 'camera_1')
        self.camera_2 = self.findChild(QLabel, 'camera_2')

        self.camera_labels = {
            "camera_1": self.camera_1,
            "camera_2": self.camera_2,
        }
        self.captured_images = {
            "camera_1": [],
            "camera_2": [],
        }

        # Shortcut Key
        self.key_actions = {
            Qt.Key_Escape: lambda: self.go_home(),
            Qt.Key_Q: lambda: self.capture_image("camera_1"),
            Qt.Key_W: lambda: self.capture_image("camera_2"),
            Qt.Key_P: lambda: self.print_pdf()
        }

        # Connect confirm button
        self.confirm_button = self.findChild(QPushButton, 'confirm_button')
        self.confirm_button.clicked.connect(self.confirm_action)

        self.cap_1 = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.cap_2 = cv2.VideoCapture(0, cv2.CAP_DSHOW)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.datetime_timer = QTimer(self)
        self.datetime_timer.timeout.connect(self.update_datetime)
        self.datetime_timer.start(1000)

        self.current_datetime = ""

        # Focus Policy to enable key events
        self.setFocusPolicy(Qt.StrongFocus)
        self.setFocus()

        self.selected_filter = ""

        self.bill_data = ""

    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def go_home(self):
        # Release the camera resources
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        # Stop the timer
        self.timer.stop()
        # Close the window
        self.close()

    def closeEvent(self, event):
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        self.timer.stop()
        event.accept()

    def update_camera_feed(self):
        camera_caps = [self.cap_1, self.cap_2]
        for idx, (camera_name, camera_label) in enumerate(self.camera_labels.items()):
            cap = camera_caps[idx]
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                height, width, channel = frame.shape
                bytesPerLine = 3 * width
                qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

                painter = QPainter(qImg)
                painter.setPen(QColor(Qt.white))
                painter.setFont(QFont("Arial", 12))
                painter.drawText(10, 20, self.current_datetime)
                painter.end()

                pixmap = QPixmap.fromImage(qImg)
                camera_label.setPixmap(pixmap)
            else:
                self.show_no_camera_feed(camera_label)

    def show_no_camera_feed(self, camera_label):
        camera_label.setText("No Camera Feed")
        camera_label.setAlignment(Qt.AlignCenter)
        camera_label.setStyleSheet("color: white; background-color: black;")

    def update_datetime(self):
        self.current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")

    def capture_image(self, camera_name):
        # Get the current date and time
        current_datetime = QDateTime.currentDateTime()
        year = current_datetime.toString("yyyy")
        month = current_datetime.toString("MMMM")  # Full month name
        date = current_datetime.toString("dd-MM-yyyy")  # Full date
        time = current_datetime.toString("HH.mm.ss")  # Time with periods instead of colons

        # Determine which capture object to use based on camera_name
        if camera_name == "camera_1":
            cap = self.cap_1
        elif camera_name == "camera_2":
            cap = self.cap_2
        else:
            return  # Handle unknown camera_name if needed

        # Create the directory structure: captured_images/year/month/date
        base_dir = os.path.join("captured_images", year, month, date)
        if not os.path.exists(base_dir):
            os.makedirs(base_dir)

        # Save the image in the created directory with the updated timestamp format in the filename
        image_path = os.path.join(base_dir, f"{camera_name}_{time}.jpg")
        ret, frame = cap.read()
        if ret:
            cv2.imwrite(image_path, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

            # Append the image path to the captured images dictionary
            if camera_name not in self.captured_images:
                self.captured_images[camera_name] = []
            self.captured_images[camera_name].append(image_path)
        else:
            QMessageBox.warning(self, "Capture Error", "Failed to capture image from selected camera.")

    def print_pdf(self, index):
        # Find cameras with at least one captured image
        cameras_with_images = [camera_name for camera_name, images in self.captured_images.items() if len(images) >= 1]

        if len(cameras_with_images) < 1:
            QMessageBox.warning(self, "Print Error", "Need at least one image from any camera to print.")
            return

        # Prepare PDF
        current_datetime = QDateTime.currentDateTime()
        year = current_datetime.toString("yyyy")
        month = current_datetime.toString("MMMM")  # Full month name
        date = current_datetime.toString("dd-MM-yyyy")  # Full date
        time = current_datetime.toString("HH.mm.ss")  # Time with periods instead of colons

        # Create the directory structure: pdf_reports/year/month/date
        base_dir = os.path.join("pdf_reports", year, month, date)
        if not os.path.exists(base_dir):
            os.makedirs(base_dir)

        pdf_path = os.path.join(base_dir, f"bill_{time}.pdf")

        # Create the print_reports directory if it doesn't exist
        print_reports_dir = "print_reports"
        if not os.path.exists(print_reports_dir):
            os.makedirs(print_reports_dir)

        # Path for saving the PDF directly in print_reports
        print_pdf_path = os.path.join(print_reports_dir, f"bill_{time}.pdf")

        # Initialize the canvas
        c = canvas.Canvas(pdf_path, pagesize=A4)

        width, height = A4

        margin = 20
        space_between_images = 20

        # Draw the title
        title = "WEIGHMENT CERTIFICATE"
        c.setFont("Helvetica-Bold", 16)
        title_width = c.stringWidth(title)
        title_x = (width - title_width) / 2
        title_y = height - margin - 20
        c.drawString(title_x, title_y, title)

        # Underline the title
        c.line(title_x, title_y - 5, title_x + title_width, title_y - 5)

        # Adjust the text_y value to increase or decrease the space below the title
        text_y = height - margin - 120  # Adjust this value for spacing

        # Dashed lines
        c.setStrokeColor(colors.black)
        c.setDash(6, 3)
        c.line(margin, text_y + 60, width - margin, text_y + 60)
        c.line(margin, text_y - 250, width - margin, text_y - 250)
        c.setDash(1, 0)

        self.bill_data = MainScreenBL().get_bill_data(index)
        print(self.bill_data)

        left_details = [
            f" BILL NO                      : {self.bill_data[0]}",
            f" LINE NO                     : {self.bill_data[4]}",
            f" SERIAL NAME           : {self.bill_data[6]}",
            f" AMOUNT                    : {self.bill_data[14]}",
            f" REGION                     : {self.bill_data[7]}",
            f" GROSS UNIT             : {self.bill_data[15]}",
            f" AGENT                       : {self.bill_data[8]}",
            f" GROSS Wt (Kg)         : {self.bill_data[11]}",
            f" TARE  Wt (Kg)           : {self.bill_data[12]}",
            f" NETT  Wt (Kg)           : {self.bill_data[13]}"
        ]

        right_details = [
            f"VEHICLE                              : {self.bill_data[1]}    ",
            f"SUPERVISOR NAME          : {self.bill_data[5]}    ",
            f"COUNT                                : {self.bill_data[9]}    ",
            f"SUPPLIER NAME                : {self.bill_data[10]}    ",
            f"SUPPLIER CHALLAN NO   : {self.bill_data[3]}    ",
            f"AMOUNT (RS)                     : {self.bill_data[2]}    ",
            f"RE-ENTRY AMOUNT (RS)  : {self.bill_data[18]}  ",
            f"FIRST ENTRY                      : {self.bill_data[19]}  ",
            f"GROSS DATE                      : {self.bill_data[16]}  ",
            f"TARE DATE                         : {self.bill_data[17]}  "
        ]

        line_spacing = 25

        c.setFont("Helvetica", 11)
        for i, label in enumerate(left_details):
            c.drawString(margin + 20, text_y - (i * line_spacing), label)

        for i, label in enumerate(right_details):
            c.drawString(margin + 320, text_y - (i * line_spacing), label)

        text_y -= max(len(left_details), len(right_details)) * line_spacing + 20

        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        text_y -= 20

        c.setFont("Helvetica", 10)
        additional_text = "LCS - For All Your Weighing Needs"
        additional_text_width = c.stringWidth(additional_text)
        additional_text_x = (width - additional_text_width) / 2
        c.drawString(additional_text_x, text_y - 2, additional_text)

        img_width = 230
        img_height = 160
        space_between_images = 40

        # Calculate the starting y position for images
        img_y_start = text_y - img_height - 90

        # Track the current x position
        img_x_position = margin + 17

        for camera_name in cameras_with_images:
            images_to_print = self.captured_images[camera_name][:2]  # Limit to two images per camera

            # Draw camera header
            text_cam = f"Camera {camera_name[-1]}"
            c.setFont("Helvetica-Bold", 12)
            c.drawString(img_x_position, img_y_start + img_height + 10, text_cam)

            # Calculate position for each image and draw them side by side
            for idx, image_path in enumerate(images_to_print):
                x_pos = img_x_position + idx * (img_width + space_between_images)
                c.drawImage(image_path, x_pos, img_y_start, width=img_width, height=img_height)

            # Update the x position for the next set of images
            img_x_position += (img_width + space_between_images) * len(images_to_print) + margin

        # Add signatures
        c.setFont("Helvetica", 12)
        text_operator = "          Signature of the Operator"
        text_width_operator = c.stringWidth(text_operator, "Helvetica", 12)
        c.drawString(margin + 20, margin + 5, text_operator)
        c.line(margin + 20, margin + 20, margin + 220, margin + 20)

        text_supervisor = "Signature of the Supervisor        "
        text_width_supervisor = c.stringWidth(text_supervisor, "Helvetica", 12)
        c.drawString(width - margin - text_width_supervisor - 20, margin + 5, text_supervisor)
        c.line(width - margin - 220, margin + 20, width - margin - 20, margin + 20)

        c.save()

        # Copy the saved PDF to the print_reports directory
        shutil.copy(pdf_path, print_pdf_path)

        # Clear captured images
        for camera_name in cameras_with_images:
            self.captured_images[camera_name].clear()

        QMessageBox.information(self, "Bill Generation", "Successful")

        list_of_files = os.listdir(print_reports_dir)
        full_path = [os.path.join(print_reports_dir, file) for file in list_of_files if file.endswith('.pdf')]
        if full_path:
            latest_pdf = max(full_path, key=os.path.getctime)
            # Open the most recent PDF file
            try:
                os.startfile(latest_pdf)
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not open PDF: {str(e)}")




    def confirm_action(self):

        index = 13
        self.capture_image("camera_1")
        self.capture_image("camera_2")
        self.print_pdf(index)
        self.go_home()
