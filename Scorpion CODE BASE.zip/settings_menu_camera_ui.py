from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QLabel, QLineEdit, QFrame, QComboBox, QVBoxLayout, \
    QHBoxLayout, QWidget, QStackedWidget, QSpacerItem, QSizePolicy

from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsEthernetUi:
    def __init__(self):
        super().__init__()

    def init_ui(self):
        self.HorizontalLyt = QVBoxLayout(self)
        self.stackedWidget = QStackedWidget(self)
        self.HorizontalLyt.addWidget(self.stackedWidget)
        self.create_ethernet_ui()

    def create_ethernet_ui(self):
        try:
            # Clear the layout
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmEthernet = QFrame(self)
            self.frmEthernet.resize(521, 429)

            # Ethernet Background Label
            self.lblEthernetBg = QLabel(self.frmEthernet)
            self.lblEthernetBg.resize(521, 429)
            self.lblEthernetBg.setParent(self.frmEthernet)

            # Header Label
            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["ethernet_components"]["ethernet_header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left; border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(10, 10)
            self.lblHeader.setParent(self.frmEthernet)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            # Ethernet Edit Button
            self.btnEthernetEdit = QPushButton()
            self.btnEthernetEdit.resize(42, 42)
            self.btnEthernetEdit.move(360, 10)
            self.btnEthernetEdit.clicked.connect(self.on_click_ethernet_edit)
            self.btnEthernetEdit.setParent(self.frmEthernet)
            self.btnEthernetEdit.setStyleSheet(
                f"QPushButton {{ background-image: url({ROOT_PATH}Images/MainScreenImages/Edit.png); border: none; }}"
                f"QPushButton::hover {{ background-image: url({ROOT_PATH}Images/MainScreenImages/EditHover.png); }}"
                f"QPushButton::disabled {{ background-image: url({ROOT_PATH}Images/MainScreenImages/EditDisable.png); }}")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnEthernetEdit.setGraphicsEffect(shadow)

            # Ethernet Save Button
            self.btnEthernetSave = QPushButton()
            self.btnEthernetSave.resize(42, 42)
            self.btnEthernetSave.move(420, 10)
            self.btnEthernetSave.clicked.connect(self.on_click_ethernet_save)
            self.btnEthernetSave.setParent(self.frmEthernet)
            self.btnEthernetSave.setStyleSheet(
                f"QPushButton {{ background-image: url({ROOT_PATH}Images/SettingScreenImages/Save.png); border: none; }}"
                f"QPushButton::hover {{ background-image: url({ROOT_PATH}Images/SettingScreenImages/SaveHover.png); }}"
                f"QPushButton::disabled {{ background-image: url({ROOT_PATH}Images/SettingScreenImages/SaveDisable.png); }}")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnEthernetSave.setGraphicsEffect(shadow)

            self.verticalLayout = QVBoxLayout(self.frmEthernet)
            self.verticalLayout.setContentsMargins(10, 75, 10, 10)

            self.comboLayout = QHBoxLayout()

            # Camera Quantity QComboBox
            self.lblCameraQuantity = QLabel()
            self.lblCameraQuantity.setText("Camera Quantity")
            self.lblCameraQuantity.setStyleSheet(
                "border:0px solid lightgrey; font: 20px Regular Inter; color:#696667; text-align:left;")
            self.lblCameraQuantity.setParent(self.frmEthernet)
            self.comboLayout.addWidget(self.lblCameraQuantity)

            self.cmbCameraQuantity = QComboBox()
            self.cmbCameraQuantity.setFont(QFont('Inter', 15))
            self.cmbCameraQuantity.setParent(self.frmEthernet)
            self.cmbCameraQuantity.addItem("")  # Adding an empty item as placeholder
            self.cmbCameraQuantity.addItems(["1", "2", "3", "4"])  # Adding items to the combobox
            self.cmbCameraQuantity.currentIndexChanged.connect(self.update_camera_buttons)
            self.comboLayout.addWidget(self.cmbCameraQuantity)

            self.verticalLayout.addLayout(self.comboLayout)

            spacerItem = QSpacerItem(20, 17, QSizePolicy.Minimum, QSizePolicy.Minimum)
            self.verticalLayout.addItem(spacerItem)

            # Horizontal Push Buttons for Camera Selection
            self.buttonLayout = QHBoxLayout()
            # Creating the buttons and connecting them
            self.buttonLayout = QHBoxLayout()

            # Create buttons with specific actions
            self.btn1 = QPushButton('1')
            self.btn1.setFont(QFont('Inter', 15))
            self.btn1.setFixedSize(50, 30)
            self.btn1.setObjectName("btn1")
            self.btn1.clicked.connect(self.on_click_cam)
            self.buttonLayout.addWidget(self.btn1)

            self.btn2 = QPushButton('2')
            self.btn2.setFont(QFont('Inter', 15))
            self.btn2.setFixedSize(50, 30)
            self.btn2.setObjectName("btn2")
            self.btn2.clicked.connect(self.on_click_cam)
            self.buttonLayout.addWidget(self.btn2)

            self.btn3 = QPushButton('3')
            self.btn3.setFont(QFont('Inter', 15))
            self.btn3.setFixedSize(50, 30)
            self.btn3.setObjectName("btn3")
            self.btn3.clicked.connect(self.on_click_cam)
            self.buttonLayout.addWidget(self.btn3)

            self.btn4 = QPushButton('4')
            self.btn4.setFont(QFont('Inter', 15))
            self.btn4.setFixedSize(50, 30)
            self.btn4.setObjectName("btn4")
            self.btn4.clicked.connect(self.on_click_cam)
            self.buttonLayout.addWidget(self.btn4)

            self.verticalLayout.addLayout(self.buttonLayout)

            # IP Address and Port Number Layout
            self.ipPortLayout = QHBoxLayout()

            self.ipLayout = QVBoxLayout()
            self.lblEthernetIpAddress = QLabel()
            self.lblEthernetIpAddress.setText(
                GlobalVariable.language_setting_items["ethernet_components"]["ethernet_header_1"])
            self.lblEthernetIpAddress.setStyleSheet(
                "border:0px solid lightgrey; font: 20px Regular Inter; color:#696667; text-align:left;")
            self.ipLayout.addWidget(self.lblEthernetIpAddress)

            self.txtEthernetIpAddress = QLineEdit()
            self.txtEthernetIpAddress.setMaxLength(15)
            self.txtEthernetIpAddress.setInputMask("000.000.000.000")
            self.txtEthernetIpAddress.setFont(QFont('Inter', 15))
            self.ipLayout.addWidget(self.txtEthernetIpAddress)

            self.ipPortLayout.addLayout(self.ipLayout)

            self.portLayout = QVBoxLayout()
            self.lblEthernetPortNumber = QLabel()
            self.lblEthernetPortNumber.setText(
                GlobalVariable.language_setting_items["ethernet_components"]["ethernet_header_2"])
            self.lblEthernetPortNumber.setStyleSheet(
                "border:0px solid lightgrey; font: 20px Regular Inter; color:#696667; text-align:left;")
            self.portLayout.addWidget(self.lblEthernetPortNumber)

            self.txtEthernetPortNumber = QLineEdit()
            self.txtEthernetPortNumber.setMaxLength(4)
            self.txtEthernetPortNumber.setFont(QFont('Inter', 15))
            self.txtEthernetPortNumber.setInputMask("0000")
            self.portLayout.addWidget(self.txtEthernetPortNumber)

            self.ipPortLayout.addLayout(self.portLayout)

            self.verticalLayout.addLayout(self.ipPortLayout)

            # Username and Password Layout
            self.userPassLayout = QHBoxLayout()

            self.userLayout = QVBoxLayout()
            self.lblUsername = QLabel()
            self.lblUsername.setText("Username")
            self.lblUsername.setStyleSheet(
                "border:0px solid lightgrey; font: 20px Regular Inter; color:#696667; text-align:left;")
            self.userLayout.addWidget(self.lblUsername)

            self.txtUsername = QLineEdit()
            self.txtUsername.setFont(QFont('Inter', 15))
            self.userLayout.addWidget(self.txtUsername)

            self.userPassLayout.addLayout(self.userLayout)

            self.passLayout = QVBoxLayout()
            self.lblPassword = QLabel()
            self.lblPassword.setText("Password")
            self.lblPassword.setStyleSheet(
                "border:0px solid lightgrey; font: 20px Regular Inter; color:#696667; text-align:left;")
            self.passLayout.addWidget(self.lblPassword)

            self.txtPassword = QLineEdit()
            self.txtPassword.setFont(QFont('Inter', 15))
            self.txtPassword.setEchoMode(QLineEdit.Password)
            self.passLayout.addWidget(self.txtPassword)

            self.userPassLayout.addLayout(self.passLayout)

            self.verticalLayout.addLayout(self.userPassLayout)

            # Add labels for status ticks
            self.lblEthernetIpAddressStatus = QLabel(self.frmEthernet)
            self.lblEthernetIpAddressStatus.resize(21, 21)
            self.lblEthernetIpAddressStatus.move(200, 195)  # Adjust position as needed
            self.lblEthernetIpAddressStatus.setStyleSheet(f"background-image: url({ROOT_PATH}Images/tick_icon.png);")

            self.lblEthernetPortNumberStatus = QLabel(self.frmEthernet)
            self.lblEthernetPortNumberStatus.resize(21, 21)
            self.lblEthernetPortNumberStatus.move(450, 195)  # Adjust position as needed
            self.lblEthernetPortNumberStatus.setStyleSheet(f"background-image: url({ROOT_PATH}Images/tick_icon.png);")

            self.lblUsernameStatus = QLabel(self.frmEthernet)
            self.lblUsernameStatus.resize(21, 21)
            self.lblUsernameStatus.move(200, 305)  # Adjust position as needed
            self.lblUsernameStatus.setStyleSheet(f"background-image: url({ROOT_PATH}Images/tick_icon.png);")

            self.lblPasswordStatus = QLabel(self.frmEthernet)
            self.lblPasswordStatus.resize(21, 21)
            self.lblPasswordStatus.move(450, 305)  # Adjust position as needed
            self.lblPasswordStatus.setStyleSheet(f"background-image: url({ROOT_PATH}Images/tick_icon.png);")

            # Add the status labels to a list if needed
            self.label_status = []
            self.label_status.append(self.lblEthernetIpAddressStatus)
            self.label_status.append(self.lblEthernetPortNumberStatus)
            self.label_status.append(self.lblUsernameStatus)
            self.label_status.append(self.lblPasswordStatus)

            self.frmEthernet.show()
            self.HorizontalLyt.addWidget(self.frmEthernet)
        except Exception as e:
            print(e)
