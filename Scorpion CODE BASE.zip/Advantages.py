from BusinessLogic.AppFeaturesBL import AppFeaturesBL
class Advantages:
    def __init__(self):
        super().__init__()

    def save_app_features(self, feature_name, status):
        try:
            self.feature_count = AppFeaturesBL().get_app_feature_count(feature_name)
            self.features_list = [feature_name, status]
            if self.feature_count == "0":
                self.result = AppFeaturesBL().insert_app_fetaures(self.features_list)
            else:
                self.result = AppFeaturesBL().update_app_fetaures(self.features_list)
            pass
        except Exception as e:
            print(e)

    def fetch_app_features(self):
        try:
            self.result = AppFeaturesBL().fetch_app_features()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    Advantages.display_app_status(self, row_data[0], str(row_data[1]))
                    status = str(row_data[1])

                    pass
            pass
        except Exception as e:
            print(e)

    def display_app_status(self, feature_name, status):
        try:
            if feature_name == "CloudStorage":
                if status == "1":
                    self.btnCloudStorageON.raise_()
                    self.btnCloudStorageOFF.lower()
                elif status == "0":
                    self.btnCloudStorageON.lower()
                    self.btnCloudStorageOFF.raise_()

            if feature_name == "RemoteConfig":
                if status == "1":
                    self.btnRemoteConfigON.raise_()
                    self.btnRemoteConfigOFF.lower()
                elif status == "0":
                    self.btnRemoteConfigON.lower()
                    self.btnRemoteConfigOFF.raise_()
            if feature_name == "MobileNotification":
                if status == "1":
                    self.btnMobileNotifON.raise_()
                    self.btnMobileNotifOFF.lower()
                elif status == "0":
                    self.btnMobileNotifON.lower()
                    self.btnMobileNotifOFF.raise_()
            if feature_name == "VoiceAssistance":
                if status == "1":
                    self.btn_voice_on.raise_()
                    self.btn_voice_off.lower()
                elif status == "0":
                    self.btn_voice_on.lower()
                    self.btn_voice_off.raise_()
            if feature_name == "CameraSettings":
                if status == "1":
                    self.btnCameraSetON.raise_()
                    self.btnCameraSetOFF.lower()
                elif status == "0":
                    self.btnCameraSetON.lower()
                    self.btnCameraSetOFF.raise_()


        except Exception as e:
            print(e)


