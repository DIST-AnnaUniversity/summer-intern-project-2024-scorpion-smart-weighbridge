import glob
import json
import os
import platform
import shutil
import time
from datetime import datetime

import serial
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, QTimer, QTime, pyqtSlot
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QMainWindow, QFileDialog, QLineEdit, QApplication, QPushButton, QGraphicsDropShadowEffect

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.UiConfiguration import RESOLUTION_PATH, DB_BACKUP_PATH, ROOT_PATH, PathConfig, USB_PATH
from Presentation.Py.Advantages import Advantages
from Presentation.Py.AppConfig import AppConfig
from Presentation.Py.CalibrationSettings import CalibrationSettings
from Presentation.Py.GeneralSettings import GeneralSettings
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Py.ParameterSettings import ParameterSettings
from Presentation.Py.ProfileInfo import ProfileInfo
from Presentation.Py.SettingImports import *
from Presentation.Py.SystemConfig import SystemConfig
from Presentation.Py.Webhooks import Webhooks
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.UI.settings_footer_config_ui import SettingsGeneralFooter
from Presentation.UI.settings_header_config_ui import SettingsGeneralHeader
from Presentation.UI.settings_menu_advantages_ui import SettingAdvantagesUi
from Presentation.UI.settings_menu_assign_role_ui import SettingsAssignRole
from Presentation.UI.settings_menu_cloud_ui import SettingsCloudUi
from Presentation.UI.settings_menu_code_entry_ui import SettingsCodeParameterUi
from Presentation.UI.settings_menu_com_selection_ui import SettingsComSelectionUi
from Presentation.UI.settings_menu_create_user_ui import SettingsCreateUserUi
from Presentation.UI.settings_menu_date_time_ui import SettingsGeneralMenu
from Presentation.UI.settings_menu_db_backup_ui import SettingsDbBackupUi
from Presentation.UI.settings_menu_device_info_ui import SettingsDeviceInfoUi
from Presentation.UI.settings_menu_diagnostics_ui import SettingsDiagnosticsUi
from Presentation.UI.settings_menu_domain_ui import SettingsDomainUi
from Presentation.UI.settings_menu_email_ui import SettingsEmailUi
from Presentation.UI.settings_menu_header_ui import SettingsHeaderParameterUi
from Presentation.UI.settings_menu_mobile_notification_ui import SettingsMobileNotification
from Presentation.UI.settings_menu_other_param_ui import SettingsOtherParameterUi
from Presentation.UI.settings_menu_profile_ui import SettingsProfileDetailsUi
from Presentation.UI.settings_menu_stampingdue_ui import SettingsStampingDueUi
from Presentation.UI.settings_menu_support_ui import SettingsSupportUi
from Presentation.UI.settings_system_diagnostics_ui import SettingsSystemDiagnosticsUi
from Presentation.UI.settings_user_permission_ui import SettingsUserPermissionUi
from Presentation.UI.settings_wifi_ui import SettingsWifiUi
from Presentation.Utilities.GlobalEntities import GlobalEntities
from models.USBDevices import USBDevices


def setup_timer(timer, interval, slot=None, singleshot=False):
    try:
        if slot:
            timer.timeout.connect(slot)
        timer.start(interval)
        if singleshot:
            timer.setSingleShot(True)
    except Exception as e:
        print(e)


class SettingScreen(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.objMainScreen = None
        """ Setting the Window frameless """
        self.setWindowFlag(Qt.FramelessWindowHint)

        """ Setting the Height and Width for QMainWindow """
        with open(RESOLUTION_PATH, 'r') as file:
            dict_resolution = json.load(file)

        width = int(dict_resolution['width'])
        height = int(dict_resolution['height'])
        self.setFixedWidth(width)
        self.setFixedHeight(height)

        self.label_status = []
        self.code_label_status = []

        self.index = 1

        SettingsMenuUi.create_main_window(self)
        UiComponents.update_header_logo(self, self.lbl_logo, "Logo.png", 71, 35)
        SettingsMenuUi.main_menu(self)
        SettingsMenuUi.sub_menu(self)

        SettingsMenuUi.create_sub_widget(self)
        SettingsMenuUi.create_main_widget(self)
        SettingsMenuUi.access_denied(self)
        SettingsMenuUi.no_network_found(self)
        SettingsMenuUi.setting_msg_popup(self)
        self.wgt_main.lower()

        self.Popuptimer = QTimer()
        self.Popuptimer.setSingleShot(True)
        self.Popuptimer.setInterval(2000)

        self.tmr_msg_popup = QTimer()
        self.tmr_msg_popup.setSingleShot(True)
        self.tmr_msg_popup.setInterval(2000)  # set the time interval to 2 seconds

        self.timerWriteRawAdc = QTimer(self)
        self.timerWriteData = QTimer(self)
        self.timerReadData = QTimer(self)
        '''system diagnostics timers'''
        self.tmr_read_com_config = QTimer(self)
        self.tmr_write_com_config = QTimer(self)
        self.tmr_display_com_config = QTimer(self)

        self.timer_read_app_config = QTimer(self)
        self.timer_write_app_config = QTimer(self)
        self.timer_display_app_config = QTimer(self)
        self.timer_update_status = QTimer(self)
        self.timer_write_all_app_config = QTimer(self)

        self.timerShowData = QTimer(self)
        self.timerReadRawAdc = QTimer(self)
        self.timerShowRawAdc = QTimer(self)
        self.timerWriteAllData = QTimer(self)
        self.timerUpdateSuccessfully = QTimer(self)
        self.timerWriteData1 = QTimer(self)

        self.timerWriteCurrentLoad = QTimer(self)
        self.timerReadCurrentLoad = QTimer(self)

        self.timerShowCurrentLoad = QTimer(self)
        with open(PathConfig.JSONPath.wifi_commands_path, 'r') as file:
            wifi_commands = json.load(file)

        self.turn_on_wifi = (wifi_commands['turn_wifi_on'])
        self.turn_off_wifi = (wifi_commands['turn_wifi_off'])
        self.cmd_connect_network = (wifi_commands['connect_network'])
        self.cmd_connect_protected_network = (wifi_commands['protected_network_password'])
        self.cmd_scan_wifi_network = (wifi_commands['scan_wifi'])

        ''' Fetch applications languages '''
        app_settings_json = open("" + DB_BACKUP_PATH + "settings.json")
        app_settings_language = json.load(app_settings_json)
        app_settings_json.close()
        language = app_settings_language["language"]

        with open("" + ROOT_PATH + "Languages/" + language + ".json", "r", encoding='utf-8') as json_file_reader:
            GlobalVariable.language_setting_items = json.loads(json_file_reader.read())

        SettingsMenuUi.display_menu_buttons_from_json(self)
        if GlobalVariable.super_admin_login:
            self.dict_main_menu = {"Com1": self.SystemConfig,
                                   "Com2": self.Parameters,
                                   "Com3": self.AppConfig,
                                   "Com4": self.General,
                                   "Com5": self.Webhooks,
                                   "Com6": self.Profile,
                                   "Com8": self.Notification,
                                   "Com9": self.Advantages}
        else:
            self.dict_main_menu = {"Com1": self.SystemConfig,
                                   "Com2": self.Parameters,
                                   "Com3": self.AppConfig,
                                   "Com4": self.General,
                                   "Com5": self.Webhooks,
                                   "Com6": self.Profile
                                   }
        self.wifi_thread = None
        self.lst_user_access = []
        self.dict_user_permission = {
            "SysConfigRead": "1",
            "SysConfigWrite": "0",
            "SysConfigVisible": "0",
            "AppConfigRead": "1",
            "AppConfigWrite": "0",
            "AppConfigVisible": "0",
            "GeneralRead": "1",
            "GeneralWrite": "0",
            "GeneralVisible": "0",
            "WebhooksRead": "1",
            "WebhooksWrite": "0",
            "WebhooksVisible": "0",
            "ParameterRead": "1",
            "ParameterWrite": "0",
            "ParameterVisible": "0",
            "ProfileRead": "1",
            "ProfileWrite": "0",
            "ProfileVisible": "0",
            "NotificationRead": "0",
            "NotificationWrite": "0",
            "NotificationVisible": "1",
            "AdvantagesRead": "1",
            "AdvantagesWrite": "0",
            "AdvantagesVisible": "0"
        }
        self.set_label_values()
        self.fetch_active_user_access_state()
        SettingsMenuUi.sys_config_sub_menu(self)
        self.on_click_system_config()
        self.fetch_header_settings()
        self.timerdatetime = QTimer(self)
        setup_timer(self.timerdatetime, 100, self.date_time)
        if not platform.system() == "Windows":
            WifiConfiguration.start_thread_for_wifi_status(self)

    def date_time(self):
        try:
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_time.setText(formatted_datetime)
        except Exception as e:
            print(e)

    def on_click_main_menu(self):
        try:
            CalibrationSettings.disable_calibration_timers(self)
            AppConfig.disable_app_config_timers(self)
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "system_config":
                    self.on_click_system_config()
                elif button_name == "parameters":
                    self.on_click_parameters()
                elif button_name == "general":
                    self.on_click_general()
                elif button_name == "app_config":
                    self.on_click_app_config()
                elif button_name == "webhooks":
                    self.on_click_webhooks()
                elif button_name == "notification":
                    self.on_click_notification()
                elif button_name == "profile":
                    self.on_click_profile()
                elif button_name == "advantages":
                    self.on_click_advantages()
                elif button_name == "stampingdue":
                    self.on_click_stamping()
                elif button_name == "home":
                    self.on_click_home()
            pass
        except Exception as e:
            print(e)

    def on_click_system_config(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.sys_config_sub_menu(self)
            if GlobalVariable.super_admin_login:
                self.dict_sub_menu = {"Menu1": self.RS232,
                                      "Menu2": self.Calibration,
                                      "Menu3": self.PrinterConfig, "Menu4": self.Peripherals, "Menu5": self.Ethernet,
                                      "Menu6": self.Diagnostics,
                                      "Menu7": self.InputSettings,
                                      "Menu8": self.OutputSettings}
            else:
                self.dict_sub_menu = {"Menu1": self.RS232,
                                      "Menu3": self.PrinterConfig,
                                      "Menu4": self.Peripherals}
            # if GlobalVariable.super_admin_login:
            #     self.dict_sub_menu = {"Menu1": self.RS232,
            #                           "Menu2": self.Calibration,
            #                           "Menu3": self.PrinterConfig, "Menu4": self.Peripherals, "Menu5": self.Ethernet,
            #                           "Menu6": self.Diagnostics, "Menu7": self.SystemDiagnostics,
            #                           "Menu8": self.InputSettings,
            #                           "Menu9": self.OutputSettings}
            # else:
            #     self.dict_sub_menu = {"Menu1": self.RS232,
            #                           "Menu3": self.PrinterConfig, "Menu4": self.SystemDiagnostics,
            #                           "Menu5": self.Peripherals}
            UiComponents.SystemConfigButton(self)
            self.on_click_rs_232()
            pass
        except Exception as e:
            print(e)

    def on_click_rs_232(self):
        try:
            UiComponents.update_sub_menu_components(self, self.RS232)
            if not self.dict_user_permission["SysConfigVisible"] == "1":
                SettingsRs232Ui.create_rs_232_ui(self)
                SystemConfig.init_rs_232_settings(self)
                if self.dict_user_permission["SysConfigRead"] == "1":
                    self.menu_access(False, self.frmRS232Comm)
                else:
                    self.menu_access(True, self.frmRS232Comm)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 50)
        except Exception as e:
            print(e)

    def menu_access(self, state, panel):
        try:
            panel.setEnabled(state)
        except Exception as e:
            print(e)

    def on_click_calibration(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Calibration)
            if not self.dict_user_permission["SysConfigVisible"] == "1":
                CalibrationMenuUI.create_calibration_ui(self)
                self.initialize_com_port()
                CalibrationSettings.Get_DateTime_fromDB(self)
                CalibrationSettings.init_calibration(self)
                CalibrationSettings.update_calibration_controls_state(self, False)
                if self.dict_user_permission["SysConfigRead"] == "1":
                    self.menu_access(False, self.frmCalibration)
                else:
                    self.menu_access(True, self.frmCalibration)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                # self.setToolTipMessage(490, 455)
                pass
        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.on_click_home()
        elif event.key() == Qt.Key_Return:
            self.enable_textbox_focus()
        elif event.key() == Qt.Key_Y:
            GlobalEntities.parameter_active_screen_events["yes"]()
        elif event.key() == Qt.Key_N:
            GlobalEntities.parameter_active_screen_events["no"]()

    def enable_textbox_focus(self):
        try:
            focused_widget = QApplication.focusWidget()
            if focused_widget is not None and len(
                    GlobalEntities.text_box_contents) > 0 and focused_widget in GlobalEntities.text_box_contents:
                GlobalEntities.text_box_entry_count = GlobalEntities.text_box_contents.index(focused_widget) + 1
            if not GlobalEntities.text_box_entry_count < 0 and not len(GlobalEntities.text_box_contents) <= 0 and len(
                    GlobalEntities.text_box_contents) > GlobalEntities.text_box_entry_count:
                GlobalEntities.text_box_contents[GlobalEntities.text_box_entry_count].setFocus()
                GlobalEntities.text_box_entry_count += 1
            elif GlobalEntities.text_box_entry_count == len(GlobalEntities.text_box_contents):
                ''' For enabling save functions after all text box entries'''
                GlobalEntities.parameter_active_screen_events["save"]()
                pass
            pass
        except Exception as e:
            print(e)

    def on_click_sys_config_menu(self):
        try:
            CalibrationSettings.disable_calibration_timers(self)
            AppConfig.disable_app_config_timers(self)
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "rs232":
                    self.on_click_rs_232()
                    pass
                elif button_name == "ethernet":
                    index = 1
                    self.on_click_ethernet_communication(index)
                elif button_name == "calibration":
                    self.on_click_calibration()
                    pass
                elif button_name == "system_diagnostics":
                    if not self.dict_user_permission["SysConfigVisible"] == "1":
                        SettingsSystemDiagnosticsUi.SystemDiagnostics_Ui(self)
                        UiComponents.update_sub_menu_components(self, self.SystemDiagnostics)
                        self.initialize_system_diagnostics()
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.menu_access(False, self.frm_system_diagnostics)
                        else:
                            self.menu_access(True, self.frm_system_diagnostics)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        #   SettingsMenuUi.sys_config_sub_menu(self)
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
                elif button_name == "input_settings":
                    if not self.dict_user_permission["SysConfigVisible"] == "1":
                        UiComponents.update_sub_menu_components(self, self.InputSettings)
                        SettingsMenuInputUi.create_input_settings_ui(self)
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.menu_access(False, self.frmInputSettings)
                        else:
                            self.menu_access(True, self.frmInputSettings)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        SettingsMenuUi.sys_config_sub_menu(self)
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
                        pass
                elif button_name == "output_settings":
                    if not self.dict_user_permission["SysConfigVisible"] == "1":
                        UiComponents.update_sub_menu_components(self, self.OutputSettings)
                        SettingsMenuOutputUi.create_output_settings_ui(self)
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.sysconfig_menu_access(False, self.frmOutputSettings)
                        else:
                            self.sysconfig_menu_access(True, self.frmOutputSettings)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        SettingsMenuUi.sys_config_sub_menu(self)
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
                        pass
                        pass
                elif button_name == "printer_config":
                    UiComponents.update_sub_menu_components(self, self.PrinterConfig)
                    if not self.dict_user_permission["SysConfigVisible"] == "1":

                        PrinterConfigUI.create_printer_ui(self)
                        SystemConfig.init_print_config(self)
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.menu_access(False, self.frmPrinter)
                        else:
                            self.menu_access(True, self.frmPrinter)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        # SettingsMenuUi.sys_config_sub_menu(self)
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
                        pass
                elif button_name == "peripherals":
                    UiComponents.update_sub_menu_components(self, self.Peripherals)
                    if not self.dict_user_permission["SysConfigVisible"] == "1":
                        SettingsComSelectionUi.create_com_selection_ui(self)
                        SystemConfig.init_peripherals_settings(self)
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.menu_access(False, self.frmPeripherals)
                        else:
                            self.menu_access(True, self.frmPeripherals)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
                        pass
                elif button_name == "diagnostics":
                    UiComponents.update_sub_menu_components(self, self.Diagnostics)
                    if not self.dict_user_permission["SysConfigVisible"] == "1":
                        SettingsDiagnosticsUi.create_diagnostics_ui(self)
                        if self.dict_user_permission["SysConfigRead"] == "1":
                            self.menu_access(False, self.diagnostics_base_frame)
                        else:
                            self.menu_access(True, self.diagnostics_base_frame)
                    else:
                        self.wgt.raise_()
                        self.wgt_main.lower()
                        SettingsAccessDeniedUi.sub_layout_Ui(self)
                        self.setToolTipMessage(135, 50)
        except Exception as e:
            print(e)

    def setToolTipMessage(self, x_axis, y_axis):
        try:
            self.ToolTip.setVisible(True)
            self.ToolTip.raise_()
            self.ToolTip.setGeometry(x_axis, y_axis, 169, 54)
            self.Popuptimer.start()
            self.Popuptimer.timeout.connect(self.ToolTip.hide)
        except Exception as e:
            print(e)

    def on_click_parameters(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.parameters_sub_menu(self)
            self.dict_sub_menu = {"Menu1": self.HeaderSettings, "Menu2": self.CodeSettings, "Menu3": self.OtherSettings}
            UiComponents.ParametersButton(self)
            self.on_click_header_settings()
        except Exception as e:
            print(e)

    def on_click_parameters_menu(self):
        try:
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "header_settings":
                    self.on_click_header_settings()
                    pass
                elif button_name == "code_settings":
                    self.on_click_code_settings()
                    pass
                elif button_name == "other_settings":
                    self.on_click_other_settings()
                    pass


        except Exception as e:
            print(e)

    '''Header settings menu access and logic'''

    def on_click_header_settings(self):
        try:
            UiComponents.update_sub_menu_components(self, self.HeaderSettings)
            if not self.dict_user_permission["ParameterVisible"] == "1":
                SettingsHeaderParameterUi.create_header_parameter(self)

                ParameterSettings.on_loading_parameter_settings(self)
                if self.dict_user_permission["ParameterRead"] == "1":
                    self.menu_access(False, self.frmHeaderSettings)
                else:
                    self.menu_access(True, self.frmHeaderSettings)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 50)
                pass
        except Exception as e:
            print(e)

    def on_click_header_entry(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_entry, self.btn_re_entry)
            for index in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[index].raise_()
                GlobalEntities.header_checkbox_names[index].setVisible(True)

            for index in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[index].lower()
                GlobalEntities.re_header_checkbox_names[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def on_click_header_reentry(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_re_entry, self.btn_entry)
            for index in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[index].lower()
                GlobalEntities.header_checkbox_names[index].setVisible(False)

            for index in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[index].raise_()
                GlobalEntities.re_header_checkbox_names[index].setVisible(True)
            pass
        except Exception as e:
            print(e)

    def on_click_header_edit(self):
        try:
            ParameterSettings.update_controls_state(self, True)
            ParameterSettings.disable_verified_status(self)
            self.on_click_header_entry()
            self.lbl_header1.setFocus()
            GlobalEntities.text_box_entry_count = 1
            pass
        except Exception as e:
            print(e)

    def on_click_header_save(self):
        try:
            self.pnl_header_save.setVisible(True)
            self.pnl_header_save.move(50, 80)
            self.pnl_header_save.setFocus()
            pass
        except Exception as e:
            print(e)

    def on_click_header_hide(self):
        try:
            self.pnl_header_save.move(500000, 80000)
            self.lbl_header1.setFocus()
            GlobalEntities.text_box_entry_count = 1
            pass
        except Exception as e:
            print(e)

    def on_click_header_save_ok(self):
        try:
            ParameterSettings.save_header_parameters(self)
            self.pnl_header_save.move(500000, 80000)
            pass
        except Exception as e:
            print(e)

    def on_click_code_settings(self):
        try:
            UiComponents.update_sub_menu_components(self, self.CodeSettings)
            if not self.dict_user_permission["ParameterVisible"] == "1":
                SettingsCodeParameterUi.create_code_parameter(self)
                ParameterSettings.on_loading_code_parameter_settings(self)
                ParameterSettings.assign_code_params_entry_events(self)
                if self.dict_user_permission["ParameterRead"] == "1":
                    self.menu_access(False, self.frmCodeSettings)
                else:
                    self.menu_access(True, self.frmCodeSettings)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 85)
                pass
        except Exception as e:
            print(e)

    def on_click_add_code(self):
        try:
            self.prev_code = ""
            self.flg_code_edit = False
            self.txt_code_name.setText("")
            self.txt_code_value.setText("")
            self.txt_code_name.setEnabled(True)
            self.txt_code_value.setEnabled(True)
            self.btn_code_details_save.setEnabled(True)
            self.btn_code_details_edit.setEnabled(False)
            self.btn_add_code.setEnabled(False)
            ParameterSettings.assign_entry_details_params_events(self)
            pass
        except Exception as e:
            print(e)

    def on_click_code_details_save(self):
        try:
            ParameterSettings.save_code_details(self, GlobalEntities.selected_code_no, self.flg_code_edit,
                                                self.prev_code)
            ParameterSettings.fill_code_details(self, GlobalEntities.selected_code_no)
            self.lbl_edit_msg.setVisible(False)
            self.dgv_code_details.setEnabled(False)
            if not self.flg_code_edit:
                self.on_click_add_code()

            pass
        except Exception as e:
            print(e)

    def on_click_code_details_edit(self):
        try:
            self.flg_code_edit = True
            self.btn_code_details_save.setEnabled(True)
            self.btn_add_code.setEnabled(False)
            self.lbl_edit_msg.setVisible(True)
            self.dgv_code_details.setEnabled(True)
            self.lbl_codeno_status.setVisible(False)
            self.lbl_code_name_status.setVisible(False)
            pass
        except Exception as e:
            print(e)

    def on_code_details_selected(self):
        try:
            row = self.dgv_code_details.currentRow()
            if not row == -1:
                self.code1No = self.dgv_code_details.item(row, 0).text()
                self.Code1name = self.dgv_code_details.item(row, 1).text()
                self.txt_code_name.setText(self.code1No)
                self.txt_code_value.setText(self.Code1name)
                self.prev_code = self.txt_code_name.text()
                self.txt_code_name.setEnabled(True)
                self.txt_code_value.setEnabled(True)
                ParameterSettings.assign_entry_details_params_events(self)
            pass
        except Exception as e:
            print(e)

    def on_click_code_scroll_down(self):
        try:
            scroll_value = 1
            current_scroll_position = self.dgv_code_details.verticalScrollBar().value()
            new_scroll_position = current_scroll_position + scroll_value
            self.dgv_code_details.verticalScrollBar().setValue(new_scroll_position)
            pass
        except Exception as e:
            print(e)

    def on_click_code_scroll_up(self):
        try:
            scroll_value = 1
            current_scroll_position = self.dgv_code_details.verticalScrollBar().value()
            new_scroll_position = current_scroll_position - scroll_value
            self.dgv_code_details.verticalScrollBar().setValue(new_scroll_position)
            pass
        except Exception as e:
            print(e)

    def on_click_code_edit(self):
        try:
            ParameterSettings.update_code_controls_state(self, True)
            ParameterSettings.disable_verified_status(self)
            self.on_click_code_entry()
            GlobalEntities.text_box_entry_count = 1
            self.lbl_code1.setFocus()
            pass
        except Exception as e:
            print(e)

    def on_click_code_save(self):
        try:
            self.pnl_code_save.move(50, 80)
            self.pnl_code_save.raise_()
            self.pnl_code_save.setFocus()
            pass
        except Exception as e:
            print(e)

    def on_click_code_hide(self):
        try:
            self.pnl_code_save.move(500000, 80000)
            self.lbl_code1.setFocus()
            GlobalEntities.text_box_entry_count = 1
            pass
        except Exception as e:
            print(e)

    def on_click_code_save_ok(self):
        try:
            ParameterSettings.save_code_parameters(self)
            self.pnl_code_save.move(500000, 80000)
            pass
        except Exception as e:
            print(e)

    def on_click_return_code(self):
        try:
            self.frm_code_details.move(500000, 100000)
            self.frm_code_entered_details.move(0, 0)
            ParameterSettings.assign_code_params_entry_events(self)
            pass
        except Exception as e:
            print(e)

    def on_click_code_details_entry(self):
        try:
            self.frm_code_details.move(0, 0)
            self.frm_code_entered_details.move(500000, 100000)
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "code1details":
                    GlobalEntities.selected_code_no = "1"
                    pass
                elif button_name == "code2details":
                    GlobalEntities.selected_code_no = "2"
                    pass
                elif button_name == "code3details":
                    GlobalEntities.selected_code_no = "3"
                    pass
                elif button_name == "code4details":
                    GlobalEntities.selected_code_no = "4"
                    pass
                elif button_name == "code5details":
                    GlobalEntities.selected_code_no = "5"
                    pass
                ParameterSettings.fill_code_details(self, GlobalEntities.selected_code_no)
                ParameterSettings.assign_entry_details_params_events(self)
            pass
        except Exception as e:
            print(e)

    def on_click_code_entry(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_entry, self.btn_re_entry)
            for index in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[index].raise_()
                GlobalEntities.header_checkbox_names[index].setVisible(True)

            for index in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[index].lower()
                GlobalEntities.re_header_checkbox_names[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def on_click_code_reentry(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_re_entry, self.btn_entry)
            for index in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[index].lower()
                GlobalEntities.header_checkbox_names[index].setVisible(False)

            for index in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[index].raise_()
                GlobalEntities.re_header_checkbox_names[index].setVisible(True)
            pass
        except Exception as e:
            print(e)

    def on_click_other_settings(self):
        try:
            UiComponents.update_sub_menu_components(self, self.OtherSettings)
            if not self.dict_user_permission["ParameterVisible"] == "1":

                SettingsOtherParameterUi.create_other_parameter_ui(self)
                self.init_other_settings_params()
                if self.dict_user_permission["ParameterRead"] == "1":
                    self.menu_access(False, self.frm_other_settings)
                else:
                    self.menu_access(True, self.frm_other_settings)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                # SettingsMenuUi.parameters_sub_menu(self)
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 120)
                pass
        except Exception as e:
            print(e)

    def init_other_settings_params(self):
        try:
            self.btn_manual.setVisible(False)
            self.btn_auto.setVisible(False)
            self.amount_status = ""
            self.date_time_status = ""
            self.gunny_status = ""
            self.unit_value = ""
            self.manual_status = ""
            self.manual_mode = ""
            ParameterSettings.get_other_settings_status(self)
            pass
        except Exception as e:
            print(e)

    def on_click_other_param_edit(self):
        try:
            ParameterSettings.update_other_settings_controls_state(self, True)
            pass
        except Exception as e:
            print(e)

    def on_click_other_param_save(self):
        try:
            ParameterSettings.save_other_settings(self)
            pass
        except Exception as e:
            print(e)

    def on_click_other_params_status(self):
        try:
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "amount_enable":
                    self.amount_status = "0"
                    self.btn_amount_enable.lower()
                    self.btn_amount_disable.raise_()
                    pass
                elif button_name == "amount_disable":
                    self.amount_status = "1"
                    self.btn_amount_enable.raise_()
                    self.btn_amount_disable.lower()
                    pass
                elif button_name == "date_enable":
                    self.date_time_status = "0"
                    self.btn_date_enable.lower()
                    self.btn_date_disable.raise_()
                    pass
                elif button_name == "date_disable":
                    self.date_time_status = "1"
                    self.btn_date_enable.raise_()
                    self.btn_date_disable.lower()
                    pass
                elif button_name == "gunny_enable":
                    self.gunny_status = "0"
                    self.btn_gunny_enable.lower()
                    self.btn_gunny_disable.raise_()
                elif button_name == "gunny_disable":
                    self.gunny_status = "1"
                    self.btn_gunny_enable.raise_()
                    self.btn_gunny_disable.lower()
                    pass
                elif button_name == "manual_enable":
                    self.manual_status = "0"
                    self.btn_manual.setVisible(False)
                    self.btn_auto.setVisible(False)
                    self.btn_manual_enable.lower()
                    self.btn_manual_disable.raise_()
                    pass
                elif button_name == "manual_disable":
                    self.manual_status = "1"
                    self.btn_manual.setVisible(True)
                    self.btn_auto.setVisible(True)
                    self.btn_manual_enable.raise_()
                    self.btn_manual_disable.lower()
                elif button_name == "unit_kg":
                    self.unit_value = "Kg"
                    UiComponents.update_toggle_style_sheet(self, self.btn_unit_1, self.btn_unit_2)
                    pass
                elif button_name == "unit_tonnes":
                    self.unit_value = "Ton"
                    UiComponents.update_toggle_style_sheet(self, self.btn_unit_2, self.btn_unit_1)
                elif button_name == "auto":
                    self.manual_mode = "1"
                    UiComponents.update_toggle_style_sheet(self, self.btn_auto, self.btn_manual)
                elif button_name == "manual":
                    self.manual_mode = "0"
                    UiComponents.update_toggle_style_sheet(self, self.btn_manual, self.btn_auto)

            pass
        except Exception as e:
            print(e)

    def on_click_general(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.general_sub_menu(self)
            SettingsGeneralMenu.create_date_time_ui(self)
            self.dict_sub_menu = {"Menu1": self.DateTime, "Menu2": self.Wifi, "Menu3": self.Header,
                                  "Menu4": self.Footer}

            UiComponents.General(self)
            self.on_click_datetime()
            pass
        except Exception as e:
            print(e)

    def on_click_general_menu(self):
        try:

            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "datetime":
                    self.on_click_datetime()
                elif button_name == "wifi":
                    self.on_click_wifi()
                elif button_name == "header":
                    self.on_click_header_config()
                    pass
                elif button_name == "footer":
                    self.on_click_footer_config()
                    pass
        except Exception as e:
            print(e)

    def on_click_wifi(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Wifi)
            if not self.dict_user_permission["GeneralVisible"] == "1":
                SettingsWifiUi.wifi_ui(self)
                self.lst_temp_wifi = []
                self.frmWifiPanel.move(25657, 677)
                self.frmMsgpanel.move(9000, 200)
                UiComponents.WifiSettingsUiComponents(self)
                if not platform.system == "Windows":
                    if WifiConfiguration.is_wifi_enabled(self):
                        self.btnWifiON.raise_()
                        self.btnWifiOFF.lower()
                        WifiConfiguration.start_wifi_thread(self)

                    else:
                        self.btnWifiOFF.raise_()
                        self.btnWifiON.lower()
                        UiComponents.pnl_turn_ON_wifi(self)
                        self.frmMsgpanel.move(7, 60)
                self.init_dgv_wifi()
                if self.dict_user_permission["GeneralRead"] == "1":
                    self.menu_access(False, self.frmWifi)
                else:
                    self.menu_access(True, self.frmWifi)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 80)
                pass
        except Exception as e:
            print(e)

    def on_click_wifi_ON(self):
        try:

            """While clicking turn on button the ON button will be lowered
            and the OFF button will be Raised 
            """
            self.btnWifiOFF.raise_()
            self.btnWifiON.lower()
            self.frmMsgpanel.move(7, 60)
            os.system(self.turn_off_wifi)
            self.dgvWifiList.setRowCount(0)
        except Exception as e:
            print(e)

    # For turning ON Wi-Fi

    def on_click_wifi_OFF(self):
        try:
            """While clicking turn on button the OFF button will be lowered
                and the ON button will be Raised. 
            """
            self.hide_msg_panel()
            self.btnWifiOFF.lower()
            self.btnWifiON.raise_()
            os.system(self.turn_on_wifi)
        except Exception as e:
            print(e)

    def hide_msg_panel(self):
        try:
            self.frmMsgpanel.move(9000, 200)
        except Exception as e:
            print(e)

    def hide_wifi_panel(self):
        try:
            self.frmWifiPanel.move(17000, 138)
        except Exception as e:
            print(e)

    def init_dgv_wifi(self):
        try:
            self.dgvWifiList.setColumnCount(1)
            self.dgvWifiList.setRowCount(0)
            self.dgvWifiList.setHorizontalHeaderLabels(
                ['Scan for Available Networks'])
            self.dgvWifiList.setColumnWidth(0, 450)
            self.dgvWifiList.cellClicked.connect(self.show_wifi_panel)
            self.dgvWifiList.cellClicked.connect(self.get_selected_cell_value)
            self.dgvWifiList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        except Exception as e:
            print(e)

    def get_selected_cell_value(self):
        try:
            rowcount = self.dgvWifiList.currentRow()
            self.list_data = []
            for index in range(self.dgvWifiList.columnCount()):
                item = self.dgvWifiList.item(rowcount, index)
                self.ID = item.text()
                self.list_data.append(self.ID)
            self.SSID = self.list_data[0].replace('CONNECTED', '')
            self.SSID = self.SSID.strip()

            self.txtWifiName.setText(self.SSID)
        except Exception as e:
            print(e)

    def show_wifi_panel(self):
        try:
            self.frmWifiPanel.move(100, 100)
            self.txtWifiPassword.clear()
        except Exception as e:
            print(e)

    def connect_wifi(self):
        try:
            if not self.txtWifiPassword.text() == "":
                self.wifi_name = self.txtWifiName.text()
                self.Wifi_Password = self.txtWifiPassword.text()
                WifiConfiguration.configure_wifi(self, self.wifi_name, self.cmd_connect_network,
                                                 self.cmd_connect_protected_network, self.Wifi_Password)
                self.hide_wifi_panel()
            else:
                # Wi-Fi Password for open network
                self.wifi_name = self.txtWifiName.text()
                WifiConfiguration.configure_wifi(self, self.wifi_name, self.cmd_connect_network, None, None)
                self.hide_wifi_panel()
        except Exception as e:
            print(e)

    # The values emitted from the thread will be received and processed
    @pyqtSlot(list, int, str)
    def update_live_wifi(self, lstAvailableWifi, status_code, connected_ssid):
        try:
            self.wifi_status_code = status_code
            if not len(lstAvailableWifi) == 0:
                self.dgvWifiList.setRowCount(0)
                # Duplicate values in the list can be removed using the set.
                unique_wifi = list(set(self.lst_temp_wifi + lstAvailableWifi))

                #  the list is sent to the function for displaying
                WifiConfiguration.DisplayAvailableWifi(self, unique_wifi, connected_ssid)
            elif self.wifi_status_code == 0:
                self.dgvWifiList.setRowCount(0)

        except Exception as e:
            print(e)

    @pyqtSlot(int)
    def update_wifi_status(self, status_code):
        try:
            self.wifi_status_code = status_code
            if self.wifi_status_code == 1:
                UiComponents.wifi_status_on(self)
                GlobalVariable.wifi_status = True
            elif self.wifi_status_code == 0:
                UiComponents.wifi_status_off(self)
                GlobalVariable.wifi_status = False
        except Exception as e:
            print(e)

    def on_click_datetime(self):
        try:
            UiComponents.update_sub_menu_components(self, self.DateTime)
            if not self.dict_user_permission["GeneralVisible"] == "1":
                SettingsGeneralMenu.create_date_time_ui(self)
                GeneralSettings.init_date_time_configuration(self)
                self.cmbContinent.setEditable(True)
                self.cmbContinent.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
                self.cmbContinent.completer().setCompletionMode(QtWidgets.QCompleter.PopupCompletion)

                self.cmbRegion.setEditable(True)
                self.cmbRegion.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
                self.cmbRegion.completer().setCompletionMode(QtWidgets.QCompleter.PopupCompletion)
                if self.dict_user_permission["GeneralRead"] == "1":
                    self.menu_access(False, self.frmDateTime)
                else:
                    self.menu_access(True, self.frmDateTime)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 50)
                pass
        except Exception as e:
            print(e)

    def updateregioncmb(self, index):
        try:
            self.cmbRegion.clear()

            time_region = self.cmbContinent.itemData(index)
            if time_region:
                self.cmbRegion.addItems(time_region)
        except Exception as e:
            print(e)

    def on_click_date_time_save(self):
        try:
            GeneralSettings.save_date_time_configurations(self)
            pass
        except Exception as e:
            print(e)

    def get_date_time_manual_entries(self):
        try:
            self.date_format = "DD-MM-YYYY"
            '''sub string time frm text box '''
            self.time = self.txt_time.text()
            self.time = self.time.replace(':', '')
            time_text = self.time.strip()
            self.hour = time_text[:2]  # 12
            self.minute = time_text[2:4]  # 30
            # self.second = int(time_text[4:6])  # 00

            '''sub string date frm text box '''
            self.date = self.txt_date.text()
            self.date = self.date.replace('-', '')
            date_text = self.date.strip()

            if self.date_format == "DD-MM-YYYY":
                self.day = date_text[:2]  # 28
                self.month = date_text[2:4]  # 06
                self.year = date_text[4:8]  # 2001
            elif self.date_format == "YYYY-MM-DD":
                self.year = int(date_text[:4])  # 2001
                self.month = int(date_text[4:6])  # 06
                self.day = int(date_text[6:8])  # 28
            elif self.date_format == "MM-DD-YYYY":
                self.day = int(date_text[:2])  # 06
                self.month = int(date_text[2:4])  # 28
                self.year = int(date_text[4:8])  # 2001
        except Exception as e:
            print(e)

    def on_click_date_time_edit(self):
        try:
            GeneralSettings.update_date_time_controls_state(self, True)
            GeneralSettings.disable_verified_status(self)
            pass
        except Exception as e:
            print(e)

    def on_click_header_config(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Header)
            if not self.dict_user_permission["GeneralVisible"] == "1":
                SettingsGeneralHeader.create_header_config_ui(self)
                GeneralSettings.init_header_config(self)
                if self.dict_user_permission["GeneralRead"] == "1":
                    self.menu_access(False, self.frmHeader)
                else:
                    self.menu_access(True, self.frmHeader)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 120)
                pass
        except Exception as e:
            print(e)

    def on_click_logo(self):
        try:
            device_list = os.listdir(USB_PATH)
            if device_list:
                for i, drive_name in enumerate(device_list):
                    if drive_name:
                        GetDevice_name = drive_name
                self.filename = QFileDialog.getOpenFileName(self, 'Select a file',
                                                            USB_PATH + GetDevice_name,
                                                            "Image files (*.png *.jpg *.gif)")
                image_path = self.filename[0]
                if not image_path == "":
                    ImageName = os.path.basename(image_path).split('/')[-1]
                    GlobalVariable.Logo = ImageName
                    shutil.copy(image_path, PathConfig.Logo.LOGO_PATH)
                    UiComponents.update_header_logo(self, self.lbl_logo, ImageName, 111, 111)
            else:
                MessagePopup.setting_msg_popup(self, "error", "No Device Found !! ")
        except OSError as e:
            MessagePopup.setting_msg_popup(self, "error", "No Device Found !! ")

    def on_click_header_config_edit(self):
        try:
            GeneralSettings.update_header_config_controls_state(self, True)
            GeneralSettings.disable_verified_status(self)
            pass
        except Exception as e:
            print(e)

    def on_click_header_config_save(self):
        try:
            GeneralSettings.save_Header_values(self)
            pass
        except Exception as e:
            print(e)

    def on_click_footer_config(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Footer)
            if not self.dict_user_permission["GeneralVisible"] == "1":
                SettingsGeneralFooter.create_footer_config_ui(self)
                GeneralSettings.init_footer_config(self)
                if self.dict_user_permission["GeneralRead"] == "1":
                    self.menu_access(False, self.frmFooter)
                else:
                    self.menu_access(True, self.frmFooter)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 160)
                pass
        except Exception as e:
            print(e)

    def on_click_footer_config_edit(self):
        try:
            GeneralSettings.update_footer_config_controls_state(self, True)
            GeneralSettings.disable_verified_status(self)
            pass
        except Exception as e:
            print(e)

    def on_click_footer_config_save(self):
        try:
            GeneralSettings.save_Footer_values(self)
            pass
        except Exception as e:
            print(e)

    def on_click_app_config(self):
        try:
            SettingsAppConfigUi.create_app_config_ui(self)
            UiComponents.AppConfigButtonStyles(self)
            if self.dict_user_permission["AppConfigVisible"] != "1":
                self.wgt.lower()
                self.wgt_main.raise_()
                self.initialize_com_port()
                AppConfig.init_app_config_menu(self)
                if self.dict_user_permission["AppConfigRead"] == "1":
                    self.frm_app_config.setEnabled(False)
                else:
                    self.frm_app_config.setEnabled(True)
            else:
                self.wgt.lower()
                self.wgt_main.raise_()
                SettingsAccessDeniedUi.main_layout_Ui(self)
                self.setToolTipMessage(135, 80)
        except Exception as e:
            print(e)

    '''App Config Menu control access and logic'''

    def on_click_app_edit(self):
        try:
            AppConfig.update_app_config_control_state(self, True)
            AppConfig.disable_verified_status(self)
            UiComponents.ComboBox_Style(self, self.cmb_adc_filter)
            pass
        except Exception as e:
            print(e)

    def on_click_app_save(self):
        try:
            AppConfig.save_app_configuration(self)
            UiComponents.ComboBox_Style(self, self.cmb_adc_filter)
            pass
        except Exception as e:
            print(e)

    def on_click_webhooks(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.weebhooks_sub_menu(self)
            self.dict_sub_menu = {"Menu1": self.Cloud, "Menu2": self.Domain, "Menu3": self.DbBackup}
            self.on_click_cloud_storage()
            UiComponents.Webhooks(self)
            pass
        except Exception as e:
            print(e)

    def on_click_webhooks_menu(self):
        try:

            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "cloud":
                    self.on_click_cloud_storage()
                    pass
                elif button_name == "domain":
                    self.on_click_domain_settings()
                    pass
                elif button_name == "dbbackup":
                    self.on_click_db_backup()
                    pass

        except Exception as e:
            print(e)

    def on_click_cloud_storage(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Cloud)
            if self.dict_user_permission["WebhooksVisible"] != "1":
                SettingsCloudUi.create_cloud_storage_ui(self)
                Webhooks.init_cloud_settings(self)
                if self.dict_user_permission["WebhooksRead"] == "1":
                    self.frm_cloud_settings.setEnabled(False)
                else:
                    self.frm_cloud_settings.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 50)
                pass

        except Exception as e:
            print(e)

    def on_click_cloud_edit(self):
        try:
            Webhooks.update_cloud_controls_state(self, True)
            Webhooks.disable_verified_status(self)
            pass
        except Exception as e:
            print(e)

    def on_click_cloud_save(self):
        try:
            Webhooks.save_cloud_storage_to_db(self)
            pass
        except Exception as e:
            print(e)

    def chk_show_server_password(self):
        try:
            if self.chkShowPassword.isChecked():
                self.chkShowPassword.setText("Hide Password")
                self.txt_server_password.setEchoMode(QLineEdit.Normal)
            else:
                self.chkShowPassword.setText("Show Password")
                self.txt_server_password.setEchoMode(QLineEdit.Password)
            pass
        except Exception as e:
            print(e)

    def on_click_domain_settings(self):
        try:
            UiComponents.update_sub_menu_components(self, self.Domain)
            if self.dict_user_permission["WebhooksVisible"] != "1":
                SettingsDomainUi.create_domain_ui(self)
                if self.dict_user_permission["WebhooksRead"] == "1":
                    self.frm_domain_settings.setEnabled(False)
                else:
                    self.frm_domain_settings.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 80)
                pass
        except Exception as e:
            print(e)

    def on_click_domain_edit(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_domain_save(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_db_backup(self):
        try:
            UiComponents.update_sub_menu_components(self, self.DbBackup)
            if self.dict_user_permission["WebhooksVisible"] != "1":
                SettingsDbBackupUi.create_db_backup_ui(self)

                if self.dict_user_permission["WebhooksRead"] == "1":
                    self.frmDbBackup.setEnabled(False)

                else:
                    self.frmDbBackup.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 120)
                pass
        except Exception as e:
            print(e)

    def on_click_get_db_backup(self):
        try:
            self.pnl_db_alert.setVisible(True)
            self.pnl_db_alert.move(50, 80)
            pass
        except Exception as e:
            print(e)

    def on_click_no_backup(self):
        try:
            self.pnl_db_alert.move(50000, 800000)
            pass
        except Exception as e:
            print(e)

    def on_click_yes_backup(self):
        try:
            Webhooks.export_db_backup_usb(self)
            pass
        except Exception as e:
            print(e)

    def on_click_db_msg_ok(self):
        try:
            self.pnl_db_msg.move(500000, 800000)
            pass
        except Exception as e:
            print(e)

    def on_click_user_information(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.user_info_sub_menu(self)
            # SettingsRS232CommunicationUi.RS232_Ui(self)
            # self.dict_sub_menu = {"Menu1": self.AssignRole, "Menu2": self.UserPermission}
            #
            # UiComponents.UserInfoButtons(self)
            pass
        except Exception as e:
            print(e)

    def set_label_values(self):
        try:
            self.get_type_details("DateTime", self.lbl_time, self.lbl_time)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:

            type_row = VehicleReEntryBL().get_other_settings(type)
            lbldisplay.setText(type_row[0][0])
            isVisible = True if int(type_row[0][1]) else False
            lbldisplay.setVisible(isVisible)
            valdisplay.setVisible(isVisible)
        except Exception as e:
            print(e)

    def on_click_user_info_menu(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_notification_menu(self):
        try:
            if self.dict_user_permission["NotificationVisible"] != "1":
                sender = self.sender()
                if sender is not None:
                    button_name = sender.objectName()
                    if button_name == "email":
                        self.on_click_email()
                        pass
                    elif button_name == "support":
                        self.on_click_support()
                        pass
                    elif button_name == "device_info":
                        self.on_click_mobile_notification()
                        pass
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsMenuUi.noification_sub_menu(self)
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(135, 320)
                pass
        except Exception as e:
            print(e)

    def on_click_notification(self):
        try:

            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.noification_sub_menu(self)
            self.dict_sub_menu = {"Menu1": self.Email, "Menu2": self.Support, "Menu3": self.DeviceInfo}
            UiComponents.NotificationButtonStyles(self)
            self.on_click_email()
            pass
        except Exception as e:
            print(e)

    def on_click_email(self):
        try:
            if self.dict_user_permission["NotificationVisible"] != "1":
                SettingsEmailUi.create_email_ui(self)
                UiComponents.update_sub_menu_components(self, self.Email)
                if self.dict_user_permission["NotificationRead"] == "1":
                    self.frm_email_config.setEnabled(False)

                else:
                    self.frm_email_config.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsMenuUi.noification_sub_menu(self)
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(135, 320)
                pass
        except Exception as e:
            print(e)

    def on_click_delete_email(self):
        try:

            pass
        except Exception as e:
            print(e)

    def on_click_add_email(self):
        try:

            pass
        except Exception as e:
            print(e)

    def on_click_edit_email(self):
        try:

            pass
        except Exception as e:
            print(e)

    def on_click_save_email(self):
        try:

            pass
        except Exception as e:
            print(e)

    def on_click_support(self):
        try:
            if self.dict_user_permission["NotificationVisible"] != "1":
                SettingsSupportUi.create_support_ui(self)
                UiComponents.update_sub_menu_components(self, self.Support)
                if self.dict_user_permission["NotificationRead"] == "1":
                    self.frmSupport.setEnabled(False)

                else:
                    self.frmSupport.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsMenuUi.noification_sub_menu(self)
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(135, 320)
                pass
        except Exception as e:
            print(e)

    def on_click_support_submit(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_device_info(self):
        try:
            SettingsDeviceInfoUi.create_device_info_ui(self)
            UiComponents.update_sub_menu_components(self, self.DeviceInfo)
            pass
        except Exception as e:
            print(e)

    def on_click_mobile_notification(self):
        try:
            if self.dict_user_permission["NotificationVisible"] != "1":
                SettingsMobileNotification.create_mob_notification_ui(self)
                UiComponents.update_sub_menu_components(self, self.DeviceInfo)
                if self.dict_user_permission["NotificationRead"] == "1":
                    self.frmAppNotification.setEnabled(False)

                else:
                    self.frmAppNotification.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsMenuUi.noification_sub_menu(self)
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(135, 320)
                pass
        except Exception as e:
            print(e)

    def On_Click_mob_notification_status(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_profile(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.profile_sub_menu(self)
            self.dict_sub_menu = {"Menu1": self.UserProfile, "Menu2": self.CreateNewUser, "Menu3": self.AssignRole,
                                  "Menu4": self.UserPermission}
            UiComponents.ProfileButtonStyles(self)
            self.on_click_profile_menu()
        except Exception as e:
            print(e)

    def on_click_profile_menu(self):
        try:
            UiComponents.update_sub_menu_components(self, self.UserProfile)
            if self.dict_user_permission["ProfileVisible"] != "1":
                SettingsProfileDetailsUi.create_profile_details_ui(self)
                ProfileInfo.init_profile_info(self)
                if self.dict_user_permission["ProfileRead"] == "1":
                    self.frmProfileDetails.setEnabled(False)

                else:
                    self.frmProfileDetails.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 50)
        except Exception as e:
            print(e)

    def on_click_profile_sub_menu(self):
        try:
            self.dict_sub_menu = {"Menu1": self.UserProfile, "Menu2": self.CreateNewUser, "Menu3": self.AssignRole,
                                  "Menu4": self.UserPermission}
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "user_profile":
                    self.on_click_profile_menu()
                elif button_name == "new_user":
                    self.on_click_create_user()
                elif button_name == "assign_role":
                    self.on_click_assign_role()
                elif button_name == "user_permission":
                    self.on_click_user_permission()
        except Exception as e:
            print(e)

    def on_click_profile_edit(self):
        try:
            ProfileInfo.update_profile_controls_state(self, True)
            self.btnProfileDetailsEdit.setEnabled(True)
            pass
        except Exception as e:
            print(e)

    def on_click_profile_save(self):
        try:
            ProfileInfo.save_profile_info(self)
            pass
        except Exception as e:
            print(e)

    def on_click_profile_picture_edit(self):
        try:
            ProfileInfo.ProfilePictureEdit(self)
            pass
        except Exception as e:
            print(e)

    def on_click_preferences(self):
        try:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsMenuUi.preference_sub_menu(self)
            self.dict_sub_menu = {"Menu1": self.Language}
            UiComponents.PreferencesButtonStyles(self)
            pass
        except Exception as e:
            print(e)

    def on_click_create_user(self):
        try:
            UiComponents.update_sub_menu_components(self, self.CreateNewUser)
            if self.dict_user_permission["ProfileVisible"] != "1":
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsCreateUserUi.create_new_user_ui(self)
                ProfileInfo.init_create_user(self)
                if self.dict_user_permission["ProfileRead"] == "1":
                    self.frmCreateNewUser.setEnabled(False)

                else:
                    self.frmCreateNewUser.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 85)
                UiComponents.update_sub_menu_components(self, self.CreateNewUser)
                pass
        except Exception as e:
            print(e)

    def chk_show_password(self):
        try:
            if self.chkShowPassword.isChecked():
                self.chkShowPassword.setText("Hide Password")
                self.txtCreatePassword.setEchoMode(QLineEdit.Normal)
            else:
                self.chkShowPassword.setText("Show Password")
                self.txtCreatePassword.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def on_click_show_password(self):
        try:
            if self.chk_show_password.isChecked():
                self.chk_show_password.setText("Hide Password")
                self.txt_password.setEchoMode(QLineEdit.Normal)
            else:
                self.chk_show_password.setText("Show Password")
                self.txt_password.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def chk_show_re_password(self):
        try:
            if self.chkShowRePassword.isChecked():
                self.chkShowRePassword.setText("Hide Password")
                self.txtConformPassword.setEchoMode(QLineEdit.Normal)
            else:
                self.chkShowRePassword.setText("Show Password")
                self.txtConformPassword.setEchoMode(QLineEdit.Password)
            pass
        except Exception as e:
            print(e)

    def on_click_create_user_edit(self):
        try:
            ProfileInfo.update_create_user_controls_state(self, True)
            pass
        except Exception as e:
            print(e)

    def on_click_create_user_save(self):
        try:
            ProfileInfo.CreateNewUser(self)
            ProfileInfo.ProfileSave(self)
            ProfileInfo.update_create_user_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def on_click_user_picture_edit(self):
        try:
            ProfileInfo.Browse_ProfilePicture(self)
            pass
        except Exception as e:
            print(e)

    def on_click_assign_role(self):
        try:
            UiComponents.update_sub_menu_components(self, self.AssignRole)
            if self.dict_user_permission["ProfileVisible"] != "1":
                SettingsAssignRole.create_assign_role_ui(self)
                ProfileInfo.fill_Roles(self)
                if self.dict_user_permission["ProfileRead"] == "1":
                    self.frmAssignRole.setEnabled(False)
                else:
                    self.frmAssignRole.setEnabled(True)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 120)
                pass
        except Exception as e:
            print(e)

    def on_click_user_permission(self):
        try:
            SettingsUserPermissionUi.UserPermission_Ui(self)
            UiComponents.update_sub_menu_components(self, self.UserPermission)
            UiComponents.UserPermissionControls(self)
            UiComponents.UserPermissionAccessControls(self)
            self.btnCreateRoles.setEnabled(True)
            self.SelectedRoleName = ""
            self.FetchAvailableRoles()
            self.InitalizeUserPermissionVariables()
            self.btnCreateRoles.setEnabled(True)
            ProfileInfo.fill_Roles(self)
            self.btnCreateRoles.setEnabled(True)
        except Exception as e:
            print(e)

    def FetchAvailableRoles(self):
        try:
            self.button_dict = {}
            self.lstAvailableRoles = []
            self.RoleCount = 0
            self.lstAvailableRoles = UserPermissionSettings.FetchAvailableRoles(
                self)
            for i in reversed(range(self.pnlCustomRoles.count())):
                item = self.pnlCustomRoles.itemAt(i)
                widget = item.widget()
                self.pnlCustomRoles.removeWidget(widget)
            if not len(self.lstAvailableRoles) <= 0:
                for i, RoleName in enumerate(self.lstAvailableRoles):
                    if not RoleName == "Admin" and not RoleName == "Supervisor" and not RoleName == "Operator":
                        self.btnRoles = QPushButton(str(RoleName))
                        self.btnRoles.setMaximumSize(100, 40)
                        self.btnRoles.setStyleSheet("QPushButton "
                                                    "{"
                                                    "border-radius:7px;"
                                                    "font: 18px Regular Inter;"
                                                    "color: black;"
                                                    "background-color: white;"
                                                    "border: 1px solid lightgrey;"
                                                    "}"
                                                    "QPushButton:hover "
                                                    "{"
                                                    "border-radius:7px;"
                                                    "font: 18px Regular Inter;"
                                                    "color: white;"
                                                    "background-color: black;"
                                                    "}"
                                                    )
                        shadow = QGraphicsDropShadowEffect()
                        shadow.setBlurRadius(13)
                        self.btnRoles.setGraphicsEffect(shadow)

                        self.button_dict[str(self.RoleCount)] = self.btnRoles
                        self.pnlCustomRoles.addWidget(self.btnRoles)
                        self.btnRoles.raise_()
                        self.RoleCount = self.RoleCount + 1
                    else:
                        self.btnCreateRoles.setEnabled(True)
            for i, button in enumerate(self.button_dict.values()):
                button.clicked.connect(
                    lambda checked,
                           i=i: self.on_click_DynamicButton(
                        str(i)))
        except Exception as e:
            print(e)

    def on_click_DynamicButton(self, i):
        try:
            self.btnRoleDelete.setVisible(True)
            self.SelectedButton = self.button_dict[i]
            self.SelectedRoleName = self.SelectedButton.text()
            self.FetchSelectedRoleStatus(self.SelectedRoleName)
        except Exception as e:
            print(e)

    def FetchSelectedRoleStatus(self, SelectedRoleName):
        try:
            self.groupBox.setEnabled(True)
            self.lstSelectedRoleInfo = []
            self.lstSelectedRoleStatus = []
            if not SelectedRoleName == "":
                self.SelectedRoleName = SelectedRoleName
                self.lstSelectedRoleInfo = UserPermissionSettings.FetchStatusofSelectedRole(
                    self, SelectedRoleName)
                if not len(self.lstSelectedRoleInfo) <= 0:
                    self.txtRoleName.setText(str(self.lstSelectedRoleInfo[0]))
                    for i, Status in enumerate(self.lstSelectedRoleInfo):
                        if not i == 0:
                            self.lstSelectedRoleStatus.append(
                                self.lstSelectedRoleInfo[i])
                    self.UpdateUserPermissionStatus()
                    self.UpdateUserPermissionStatusValue()
                    self.flgEditUserPermission = True
                    self.txtRoleName.setEnabled(False)
                    self.pnlCreateNewRole.move(1, 1)
                    self.pnlCreateNewRole.raise_()
                    self.pnlAssignAccess.move(16000000, 5)
        except Exception as e:
            print(e)

    def UpdateUserPermissionStatus(self):
        try:
            if not len(self.lstSelectedRoleStatus) <= 0:
                for i, status in enumerate(self.lstSelectedRoleStatus):
                    for count, buttons in enumerate(
                            self.dictAccessStatusButtons.items()):
                        if i == count:
                            self.SelectedType = str(buttons[0])
                            if self.SelectedType.__contains__("Read"):
                                UiComponents.UpdateReadSelectedUserPermissionStatus(
                                    self, buttons[1], str(status))
                            elif self.SelectedType.__contains__("Write"):
                                UiComponents.UpdateWriteSelectedUserPermissionStatus(
                                    self, buttons[1], str(status))
                            else:
                                UiComponents.UpdateVisibleSelectedUserPermissionStatus(
                                    self, buttons[1], str(status))
            pass
        except Exception as e:
            print(e)

    def UpdateUserPermissionStatusValue(self):
        try:
            if not len(self.lstSelectedRoleStatus) <= 0:
                self.RowCount = 0
                for i, key in enumerate(self.dictUserAccess):
                    if i >= 2:
                        self.dictUserAccess.update(
                            {key: self.lstSelectedRoleStatus[self.RowCount]})
                        self.RowCount = self.RowCount + 1
            pass
        except Exception as e:
            print(e)

    def on_click_delete_role(self):
        try:
            self.user_name = str(self.txtRoleName.text())
            UserPermissionSettings.delete_selected_role(self, self.user_name)
            self.pnlCreateNewRole.move(1600000, 20)
            self.pnlAssignAccess.move(1600000, 5)
            # self.FetchAvailableRoles()
            for i in reversed(range(self.pnlCustomRoles.count())):
                item = self.pnlCustomRoles.itemAt(i)
                item.widget().setParent(None)
            self.FetchAvailableRoles()
        except Exception as e:
            print(e)

    def On_Click_AssignRoleEdit(self):
        try:
            self.dgvDisplayUserDetails.setEnabled(True)
            pass
        except Exception as e:
            print(e)

    def on_click_CreateRoles(self):
        try:
            self.btnRoleDelete.setVisible(False)
            self.SelectedRoleName = ""
            self.CustomRoleCount = UserPermissionSettings.FetchMaximumRoleCount(self)
            if not self.CustomRoleCount >= 7:
                self.flgEditUserPermission = False
                self.pnlCreateNewRole.move(1, 1)
                self.pnlCreateNewRole.raise_()
                self.pnlAssignAccess.move(16000000, 5)
                self.txtRoleName.setText("")
                self.txtRoleName.setEnabled(True)
                for child in self.pnlAssignAccess.children():
                    child.setEnabled(True)

            else:
                MessagePopup.setting_msg_popup(self, "error", "max limit exits !! ")
        except Exception as e:
            print(e)

    def on_click_Next(self):
        try:
            if not self.txtRoleName.text() == "":
                if self.SelectedRoleName == "":
                    UiComponents.UserPermissionAccessControls(self)
                self.pnlCreateNewRole.move(1600000, 20)
                self.pnlAssignAccess.move(1, 1)
                self.pnlAssignAccess.raise_()
                self.dictUserAccess.update(
                    {"UserName": str(self.txtRoleName.text())})
                if self.rbAdmin.isChecked():
                    self.dictUserAccess.update({"UserRole": "Admin"})
                elif self.rbSupervisor.isChecked():
                    self.dictUserAccess.update({"UserRole": "Supervisor"})
                elif self.rbOperator.isChecked():
                    self.dictUserAccess.update({"UserRole": "Operator"})
            else:
                pass
        except Exception as e:
            print(e)

    def InitalizeUserPermissionVariables(self):
        try:
            self.flgEditUserPermission = False
            self.dictUserAccess = {
                "UserName": "",
                "UserRole": "",
                "SysConfigRead": "1",
                "SysConfigWrite": "0",
                "SysConfigVisible": "0",
                "AppConfigRead": "1",
                "AppConfigWrite": "0",
                "AppConfigVisible": "0",
                "GeneralRead": "1",
                "GeneralWrite": "0",
                "GeneralVisible": "0",
                "WebhooksRead": "1",
                "WebhooksWrite": "0",
                "WebhooksVisible": "0",
                "ParameterRead": "1",
                "ParameterWrite": "0",
                "ParameterVisible": "0",
                "ProfileRead": "1",
                "ProfileWrite": "0",
                "ProfileVisible": "0",
                "NotificationRead": "1",
                "NotificationWrite": "0",
                "NotificationVisible": "0",
                "AdvantagesRead": "1",
                "AdvantagesWrite": "0",
                "AdvantagesVisible": "0"

            }

            self.dictAccessStatusButtons = {
                "Read1": self.btnReadSysConfig,
                "Write1": self.btnWriteSysConfig,
                "Visible1": self.btnVisibleSysConfig,
                "Read2": self.btnReadAppConfig,
                "Write2": self.btnWriteAppConfig,
                "Visible2": self.btnVisibleAppConfig,
                "Read3": self.btnReadGeneral,
                "Write3": self.btnWriteGeneral,
                "Visible3": self.btnVisibleGeneral,
                "Read4": self.btnReadWebhooks,
                "Write4": self.btnWriteWebhooks,
                "Visible4": self.btnVisibleWebhooks,
                "Read5": self.btnReadParameter,
                "Write5": self.btnWriteParameter,
                "Visible5": self.btnVisibleParameter,
                "Read6": self.btnReadProfile,
                "Write6": self.btnWriteProfile,
                "Visible6": self.btnVisibleProfile,
                "Read7": self.btnReadNotification,
                "Write7": self.btnWriteNotification,
                "Visible7": self.btnVisibleNotification,
                "Read8": self.btnReadAdvantages,
                "Write8": self.btnWriteAdvantages,
                "Visible8": self.btnVisibleAdvantages}
        except Exception as e:
            print(e)

    def on_click_Admin(self):
        try:
            self.btnRoleDelete.setVisible(False)
            self.FetchSelectedRoleStatus("Admin")
            # self.groupBox.setEnabled(False)
            for child in self.pnlAssignAccess.children():
                # Enable the specific button and disable others
                if child == self.btnAccessCancel:
                    child.setEnabled(True)
                else:
                    child.setEnabled(False)
        except Exception as e:
            print(e)

    def on_click_Supervisor(self):
        try:
            self.btnRoleDelete.setVisible(False)
            self.FetchSelectedRoleStatus("Supervisor")
            for child in self.pnlAssignAccess.children():
                if child == self.btnAccessCancel:
                    child.setEnabled(True)
                else:
                    child.setEnabled(False)
        except OSError as e:
            print(e)

    def on_click_Operator(self):
        try:
            self.btnRoleDelete.setVisible(False)
            self.FetchSelectedRoleStatus("Operator")
            for child in self.pnlAssignAccess.children():
                if child == self.btnAccessCancel:
                    child.setEnabled(True)
                else:
                    child.setEnabled(False)
        except Exception as e:
            print(e)

    def on_click_ReadSysConfig(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self,
                self.btnReadSysConfig,
                self.btnWriteSysConfig,
                self.btnVisibleSysConfig)
            self.dictUserAccess.update(
                {"SysConfigRead": "1", "SysConfigWrite": "0", "SysConfigVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteSysConfig(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self, self.btnReadSysConfig, self.btnWriteSysConfig, self.btnVisibleSysConfig)
            self.dictUserAccess.update(
                {"SysConfigRead": "0", "SysConfigWrite": "1", "SysConfigVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleSysConfig(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self, self.btnReadSysConfig, self.btnWriteSysConfig, self.btnVisibleSysConfig)
            self.dictUserAccess.update(
                {"SysConfigRead": "0", "SysConfigWrite": "0", "SysConfigVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadAppConfig(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self, self.btnReadAppConfig, self.btnWriteAppConfig, self.btnVisibleAppConfig)
            self.dictUserAccess.update(
                {"AppConfigRead": "1", "AppConfigWrite": "0", "AppConfigVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteAppConfig(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self, self.btnReadAppConfig, self.btnWriteAppConfig, self.btnVisibleAppConfig)
            self.dictUserAccess.update(
                {"AppConfigRead": "0", "AppConfigWrite": "1", "AppConfigVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleAppConfig(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self, self.btnReadAppConfig, self.btnWriteAppConfig, self.btnVisibleAppConfig)
            self.dictUserAccess.update(
                {"AppConfigRead": "0", "AppConfigWrite": "0", "AppConfigVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadGeneral(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self, self.btnReadGeneral, self.btnWriteGeneral, self.btnVisibleGeneral)
            self.dictUserAccess.update(
                {"GeneralRead": "1", "GeneralWrite": "0", "GeneralVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteGeneral(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self, self.btnReadGeneral, self.btnWriteGeneral, self.btnVisibleGeneral)
            self.dictUserAccess.update(
                {"GeneralRead": "0", "GeneralWrite": "1", "GeneralVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleGeneral(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self, self.btnReadGeneral, self.btnWriteGeneral, self.btnVisibleGeneral)
            self.dictUserAccess.update(
                {"GeneralRead": "0", "GeneralWrite": "0", "GeneralVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadWebhooks(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self, self.btnReadWebhooks, self.btnWriteWebhooks, self.btnVisibleWebhooks)
            self.dictUserAccess.update(
                {"WebhooksRead": "1", "WebhooksWrite": "0", "WebhooksVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteWebhooks(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self, self.btnReadWebhooks, self.btnWriteWebhooks, self.btnVisibleWebhooks)
            self.dictUserAccess.update(
                {"WebhooksRead": "0", "WebhooksWrite": "1", "WebhooksVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleWebhooks(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self, self.btnReadWebhooks, self.btnWriteWebhooks, self.btnVisibleWebhooks)
            self.dictUserAccess.update(
                {"WebhooksRead": "0", "WebhooksWrite": "0", "WebhooksVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadParameter(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self,
                self.btnReadParameter,
                self.btnWriteParameter,
                self.btnVisibleParameter)
            self.dictUserAccess.update(
                {"ParameterRead": "1", "ParameterWrite": "0", "ParameterVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteParameter(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self,
                self.btnReadParameter,
                self.btnWriteParameter,
                self.btnVisibleParameter)
            self.dictUserAccess.update(
                {"ParameterRead": "0", "ParameterWrite": "1", "ParameterVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleParameter(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self,
                self.btnReadParameter,
                self.btnWriteParameter,
                self.btnVisibleParameter)
            self.dictUserAccess.update(
                {"ParameterRead": "0", "ParameterWrite": "0", "ParameterVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadProfile(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self, self.btnReadProfile, self.btnWriteProfile, self.btnVisibleProfile)
            self.dictUserAccess.update(
                {"ProfileRead": "1", "ProfileWrite": "0", "ProfileVisible": "0"})

        except Exception as e:
            print(e)

    def on_click_WriteProfile(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self, self.btnReadProfile, self.btnWriteProfile, self.btnVisibleProfile)
            self.dictUserAccess.update(
                {"ProfileRead": "0", "ProfileWrite": "1", "ProfileVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleProfile(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self, self.btnReadProfile, self.btnWriteProfile, self.btnVisibleProfile)
            self.dictUserAccess.update(
                {"ProfileRead": "0", "ProfileWrite": "0", "ProfileVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadNotification(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self,
                self.btnReadNotification,
                self.btnWriteNotification,
                self.btnVisibleNotification)
            self.dictUserAccess.update(
                {"NotificationRead": "1", "NotificationWrite": "0", "NotificationVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteNotification(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self,
                self.btnReadNotification,
                self.btnWriteNotification,
                self.btnVisibleNotification)
            self.dictUserAccess.update(
                {"NotificationRead": "0", "NotificationWrite": "1", "NotificationVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleNotification(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self,
                self.btnReadNotification,
                self.btnWriteNotification,
                self.btnVisibleNotification)
            self.dictUserAccess.update(
                {"NotificationRead": "0", "NotificationWrite": "0", "NotificationVisible": "1"})
        except Exception as e:
            print(e)

    def on_click_ReadAdvantages(self):
        try:
            UiComponents.UpdateSelectedReadAccessButton(
                self,
                self.btnReadAdvantages,
                self.btnWriteAdvantages,
                self.btnVisibleAdvantages)
            self.dictUserAccess.update(
                {"AdvantagesRead": "1", "AdvantagesWrite": "0", "AdvantagesVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_WriteAdvantages(self):
        try:
            UiComponents.UpdateSelectedWriteAccessButton(
                self,
                self.btnReadAdvantages,
                self.btnWriteAdvantages,
                self.btnVisibleAdvantages)
            self.dictUserAccess.update(
                {"AdvantagesRead": "0", "AdvantagesWrite": "1", "AdvantagesVisible": "0"})
        except Exception as e:
            print(e)

    def on_click_VisibleAdvantages(self):
        try:
            UiComponents.UpdateSelectedVisibleAccessButton(
                self,
                self.btnReadAdvantages,
                self.btnWriteAdvantages,
                self.btnVisibleAdvantages)
            self.dictUserAccess.update(
                {"AdvantagesRead": "0", "AdvantagesWrite": "0", "AdvantagesVisible": "1"})
            print(self.dictUserAccess)
        except Exception as e:
            print(e)

    def fetch_active_user_access_state(self):
        try:
            self.lst_user_access = UserPermissionSettings.FetchActiveUserDetails(self)
            for count, data in enumerate(self.lst_user_access):
                for item_count, key in enumerate(self.dict_user_permission):
                    if count == item_count:
                        self.dict_user_permission.update({key: str(data)})
            pass
        except Exception as e:
            print(e)

    def on_click_Cancel(self):
        try:
            self.pnlCreateNewRole.move(1600000, 20)
            self.pnlAssignAccess.move(1600000, 5)
        except Exception as e:
            print(e)

    def on_click_CancelAccess(self):
        try:
            self.pnlCreateNewRole.move(1600000, 20)
            self.pnlAssignAccess.move(1600000, 5)
        except Exception as e:
            print(e)

    def on_click_SaveAccess(self):
        try:
            self.pnlCreateNewRole.move(1600000, 20)
            self.pnlAssignAccess.move(1600000, 5)
            UserPermissionSettings.SaveUserPermissionSettings(
                self, self.dictUserAccess, self.flgEditUserPermission)
            for i in reversed(range(self.pnlCustomRoles.count())):
                item = self.pnlCustomRoles.itemAt(i)
                item.widget().setParent(None)
            self.FetchAvailableRoles()
        except Exception as e:
            print(e)

    def combo_box_changed(self, text):
        try:
            ProfileInfo.assign_user_roles(self, text)
            pass
        except Exception as e:
            print(e)

    def on_click_advantages(self):
        try:
            self.wgt.lower()
            self.wgt_main.raise_()
            UiComponents.AdvantagesButtonStyles(self)
            SettingAdvantagesUi.create_advantages_ui(self)
            Advantages.fetch_app_features(self)
        except Exception as e:
            print(e)

    def on_click_stamping(self):
        try:
            self.wgt.lower()
            self.wgt_main.raise_()
            UiComponents.StampingDue(self)
            SettingsStampingDueUi.create_stamping_due_ui(self)
            self.init_stamping_due()
        except Exception as e:
            print(e)

    def init_stamping_due(self):
        try:
            self.txt_password.setEchoMode(QLineEdit.Password)
            self.pnl_password.setVisible(False)
            self.get_stamping_details()
        except Exception as e:
            print(e)

    def on_click_browse_stamping_image(self):
        try:
            usb_device = USBDevices.fetch_usb_devices()
            if not len(usb_device) == 0:
                for device in usb_device:
                    for count, path_name in enumerate(glob.glob(device)):
                        self.selected_file_name = QFileDialog.getOpenFileName(self, 'Select a file',
                                                                              path_name,
                                                                              "Image files (*.png *.jpg *.gif)")
                        usb_image_path = self.selected_file_name[0]
                        if not usb_image_path == "":
                            stamping_image_name = os.path.basename(usb_image_path).split('/')[-1]
                            GlobalVariable.stamping_image = stamping_image_name
                            shutil.copy(usb_image_path, PathConfig.Logo.STAMPING_IMAGE_PATH)
                            self.lbl_stamping_image.setText('')
                            UiComponents.update_stamping_image(self, self.lbl_stamping_image, stamping_image_name, 550,
                                                               200)
            else:
                MessagePopup.setting_msg_popup(self, "error", "No Device Found !! ")
        except Exception as e:
            print(e)
            MessagePopup.setting_msg_popup(self, "error", "No Device Found !! ")

    def on_click_stamping_due(self):
        try:
            self.txt_password.setText("")
            self.txt_password.setFocus()
            self.pnl_password.setVisible(True)
        except Exception as e:
            print(e)

    def on_click_password_ok(self):
        try:
            # GlobalVariable.stamping_image = "Logo.png"
            self.password = self.txt_password.text()
            self.list_stamping_details = []
            if self.password:
                if self.password == GlobalVariable.active_user_password:
                    self.list_stamping_details.append(GlobalVariable.ActiveUser)
                    current_date = datetime.now()
                    self.stamping_date = (current_date.strftime("%d-%m-%Y"))
                    current_time = QTime.currentTime()
                    self.stamping_time = (current_time.toString("hh:mm:ss AP"))
                    self.list_stamping_details.append(self.stamping_date)
                    self.list_stamping_details.append(self.stamping_time)
                    if not GlobalVariable.stamping_image == "":
                        self.list_stamping_details.append(GlobalVariable.stamping_image)
                        if len(self.list_stamping_details) > 0:
                            GeneralSettingsBL().update_stamping_details(self.list_stamping_details)
                            MessagePopup.setting_msg_popup(self, "correct", "updated successfully")
                            self.pnl_password.setVisible(False)
                            self.get_stamping_details()
                    else:
                        self.pnl_password.setVisible(False)
                        MessagePopup.setting_msg_popup(self, "error", "Browse Image")
                else:
                    self.pnl_password.setVisible(False)
                    MessagePopup.setting_msg_popup(self, "error", "Incorrect Password")
            else:
                self.pnl_password.setVisible(False)
                MessagePopup.setting_msg_popup(self, "error", "Enter Password")
        except Exception as e:
            print(e)

    def get_stamping_details(self):
        try:
            self.return_stamping_details = GeneralSettingsBL().get_stamping_details()
            if len(self.return_stamping_details) > 0:
                if self.return_stamping_details[4] == '1' and not GlobalVariable.super_admin_login:
                    self.lbl_user_name.setText(str(self.return_stamping_details[0]))
                    self.lbl_stamping_date.setText(str(self.return_stamping_details[1]))
                    self.lbl_stamping_time.setText(str(self.return_stamping_details[2]))
                    UiComponents.update_stamping_image(self, self.lbl_stamping_image,
                                                       str(self.return_stamping_details[3]), 550, 200)
                    self.btn_browse.setEnabled(False)
                    self.btn_stamping_due.setEnabled(False)
                else:
                    if self.return_stamping_details[4] == '1':
                        self.lbl_user_name.setText(str(self.return_stamping_details[0]))
                        self.lbl_stamping_date.setText(str(self.return_stamping_details[1]))
                        self.lbl_stamping_time.setText(str(self.return_stamping_details[2]))
                        UiComponents.update_stamping_image(self, self.lbl_stamping_image,
                                                           str(self.return_stamping_details[3]), 550, 200)
                    self.btn_browse.setEnabled(True)
                    self.btn_stamping_due.setEnabled(True)
        except Exception as e:
            print(e)

    def on_click_password_cancel(self):
        try:
            self.pnl_password.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_show_password(self):
        try:
            if self.chk_show_password.isChecked():
                self.chk_show_password.setText("Hide Password")
                self.txt_password.setEchoMode(QLineEdit.Normal)
            else:
                self.chk_show_password.setText("Show Password")
                self.txt_password.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def on_click_advantages_menu_status(self):
        try:
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "CloudStorageON":
                    self.cloud_storage_status("0")
                    self.btnCloudStorageON.lower()
                    self.btnCloudStorageOFF.raise_()
                    pass
                elif button_name == "CloudStorageOFF":
                    self.cloud_storage_status("1")
                    self.btnCloudStorageON.raise_()
                    self.btnCloudStorageOFF.lower()
                    pass
                elif button_name == "RemoteConfigON":
                    self.remote_config_status("0")
                    self.btnRemoteConfigOFF.raise_()
                    self.btnRemoteConfigON.lower()
                    pass
                elif button_name == "RemoteConfigOFF":
                    self.remote_config_status("1")
                    self.btnRemoteConfigOFF.lower()
                    self.btnRemoteConfigON.raise_()
                    pass
                elif button_name == "MobileON":
                    self.mobile_notification_status("0")
                    self.btnMobileNotifON.lower()
                    self.btnMobileNotifOFF.raise_()
                    pass
                elif button_name == "MobileOFF":
                    self.mobile_notification_status("1")
                    self.btnMobileNotifOFF.lower()
                    self.btnMobileNotifON.raise_()
                    pass
                elif button_name == "VoiceON":
                    self.voice_assistance_status("0")
                    self.btn_voice_on.lower()
                    self.btn_voice_off.raise_()
                    pass
                elif button_name == "VoiceOFF":
                    self.voice_assistance_status("1")
                    self.btn_voice_off.lower()
                    self.btn_voice_on.raise_()
                    pass
                elif button_name == "CameraON":
                    self.camera_settings_status("0")
                    self.btnCameraSetON.lower()
                    self.btnCameraSetOFF.raise_()
                    pass
                elif button_name == "CameraOFF":
                    self.camera_settings_status("1")
                    self.btnCameraSetOFF.lower()
                    self.btnCameraSetON.raise_()

                    pass
        except Exception as e:
            print(e)

    def cloud_storage_status(self, status):
        try:
            Advantages.save_app_features(self, "CloudStorage", status)
            pass
        except Exception as e:
            print(e)

    def camera_settings_status(self, status):
        try:
            Advantages.save_app_features(self, "CameraSettings", status)
            pass
        except Exception as e:
            print(e)

    def remote_config_status(self, status):
        try:
            Advantages.save_app_features(self, "RemoteConfig", status)
            pass
        except Exception as e:
            print(e)

    def mobile_notification_status(self, status):
        try:
            Advantages.save_app_features(self, "MobileNotification", status)
            pass
        except Exception as e:
            print(e)

    def voice_assistance_status(self, status):
        try:
            Advantages.save_app_features(self, "VoiceAssistance", status)
            pass
        except Exception as e:
            print(e)

    def on_click_home(self):
        try:
            WifiConfiguration.stop_wifi_thread(self)
            WifiConfiguration.terminate_thread(self)
            if self.objMainScreen is None:
                from Presentation.Py.MainScreen import MainScreen
                self.objMainScreen = MainScreen(self)
                self.objMainScreen.show()
                self.hide()
        except Exception as e:
            print(e)

    '''System config Ui component access and logic'''

    def initialize_com_port(self):
        try:
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation()
                           for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    GlobalVariable.Serial_Port = None
                    GlobalVariable.Serial_Port = serial.Serial(
                        GlobalVariable.get_com_port, GlobalVariable.get_baud_rate, timeout=0)
                    GlobalVariable.Serial_Port.close()
                    GlobalVariable.Serial_Port.open()
            pass
        except Exception as e:
            print(e)

    def write_serial_port(self):
        try:
            if GlobalVariable.Serial_Port is not None:
                if self.flg_write:
                    self.bytes_to_send = bytes(self.write_protocol, "utf-8")
                    GlobalVariable.Serial_Port.write(self.bytes_to_send)
            pass
        except Exception as e:
            print(e)

    def read_from_serail_port(self):
        try:
            pass
        except Exception as e:
            print(e)

    def display_received_data(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_rs232_save(self):
        try:
            SystemConfig.update_com_port_to_db(self)
            pass
        except Exception as e:
            print(e)

    def on_click_rs232_edit(self):
        try:
            SystemConfig.update_rs_232_controls_state(self, True)
            SystemConfig.disable_verified_status(self)
            self.cmb_input_names = [self.cmbCom1Baudrate, self.cmbCom2Baudrate, self.cmbCom3Baudrate]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBox_Style(self, self.cmb_input_names[i])
            pass
        except Exception as e:
            print(e)

    ''' Input settings Ui menu access and logic'''

    def on_click_input_edit(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_input_save(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_input_cancel(self):
        try:
            pass
        except Exception as e:
            print(e)

    ''' Output settings Ui menu access and logic'''

    def on_click_output_edit(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_output_save(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_output_cancel(self):
        try:
            pass
        except Exception as e:
            print(e)

    '''Calibration Menu Controls access and logic'''

    def on_click_edit_calibration(self):
        try:
            CalibrationSettings.update_calibration_controls_state(self, True)
            CalibrationSettings.disable_lable_status(self, False)
            UiComponents.calibration_normal_state(self)
            if GlobalEntities.calibration_saved:
                CalibrationSettings.disable_current_load(self)
            pass
        except Exception as e:
            print(e)

    def on_click_reset_calibration(self):
        try:
            CalibrationSettings.reset_calibration(self)
            pass
        except Exception as e:
            print(e)

    def on_click_save_calibration(self):
        try:
            CalibrationSettings.start_calibration(self)
            pass
        except Exception as e:
            print(e)

    def on_click_calibration_auto(self):
        try:
            CalibrationSettings.auto_mode(self)

            pass
        except Exception as e:
            print(e)

    def on_click_calibration_manual(self):
        try:
            CalibrationSettings.manual_mode(self)

            pass
        except Exception as e:
            print(e)

    def on_changed_decimal(self, text):
        try:
            if str(text) == '0':
                self.txtCalCapacity.setMaxLength(6)
                self.txtMaxCapacity.setMaxLength(6)
            else:
                self.txtCalCapacity.setMaxLength(7)
                self.txtMaxCapacity.setMaxLength(7)
        except Exception as e:
            print(e)

    def on_click_ApplyCalZero(self):
        try:
            CalibrationSettings.apply_cal_zero(self)
            pass
        except Exception as e:
            print(e)

    def on_click_ApplyCalSpan(self):
        try:
            CalibrationSettings.apply_cal_span(self)
            pass
        except Exception as e:
            print(e)

    def write_all_parameters(self):
        try:
            AppConfig.write_all_parameters(self)
            pass
        except Exception as e:
            print(e)

    def write_data_to_controller(self):
        try:
            AppConfig.write_data_to_controller(self)
            pass
        except Exception as e:
            print(e)

    def read_data_from_controller(self):
        try:
            AppConfig.read_data_from_controller(self)
            pass
        except Exception as e:
            print(e)

    def update_status(self):
        try:
            AppConfig.update_status(self)
            pass
        except Exception as e:
            print(e)

    def display_data(self):
        try:
            AppConfig.display_data(self)
            pass
        except Exception as e:
            print(e)

    def WriteDataToController(self):
        try:
            CalibrationSettings.WriteDataToController(self)
            pass
        except Exception as e:
            print(e)

    def ReadControllerData(self):
        try:
            CalibrationSettings.ReadControllerData(self)
            pass
        except Exception as e:
            print(e)

    def UpdateReadData(self):
        try:
            CalibrationSettings.UpdateReadData(self)
            pass
        except Exception as e:
            print(e)

    def WriteData(self):
        try:
            CalibrationSettings.WriteData(self)
            pass
        except Exception as e:
            print(e)

    def functionToReadRawAdcData(self):
        try:
            CalibrationSettings.functionToReadRawAdcData(self)
            pass
        except Exception as e:
            print(e)

    def UpdateData(self):
        try:
            CalibrationSettings.UpdateData(self)
            pass
        except Exception as e:
            print(e)

    def writeAllParameters(self):
        try:
            CalibrationSettings.writeAllParameters(self)
            pass
        except Exception as e:
            print(e)

    def UpdateAllParameters(self):
        try:
            CalibrationSettings.UpdateAllParameters(self)
            pass
        except Exception as e:
            print(e)

    def WriteDataToController1(self):
        try:
            CalibrationSettings.WriteDataToController1(self)
            pass
        except Exception as e:
            print(e)

    def write_current_load(self):
        try:
            CalibrationSettings.write_current_load(self)
            pass
        except Exception as e:
            print(e)

    def read_current_load(self):
        try:
            CalibrationSettings.read_current_load(self)
            pass
        except Exception as e:
            print(e)

    def display_current_load(self):
        try:
            CalibrationSettings.display_current_load(self)
            pass
        except Exception as e:
            print(e)

    '''Printer setings menu access and logic'''

    def on_click_custom_printer(self):
        try:
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "Entry":
                    self.update_entry_selection()
                    pass
                elif button_name == "ReEntry":
                    self.update_re_entry_selection()
                    pass
            pass
        except Exception as e:
            print(e)

    def update_entry_selection(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_entry, self.btn_re_entry)
            for index in range(len(GlobalEntities.print_entry_header)):
                GlobalEntities.print_entry_header[index].setVisible(True)
                GlobalEntities.print_entry_code[index].setVisible(True)

            for index in range(len(GlobalEntities.print_reentry_header)):
                GlobalEntities.print_reentry_header[index].setVisible(False)
                GlobalEntities.print_reentry_code[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def update_re_entry_selection(self):
        try:
            UiComponents.update_toggle_style_sheet(self, self.btn_re_entry, self.btn_entry)
            for index in range(len(GlobalEntities.print_entry_header)):
                GlobalEntities.print_entry_header[index].setVisible(False)
                GlobalEntities.print_entry_code[index].setVisible(False)

            for index in range(len(GlobalEntities.print_reentry_header)):
                GlobalEntities.print_reentry_header[index].setVisible(True)
                GlobalEntities.print_reentry_code[index].setVisible(True)
            pass
        except Exception as e:
            print(e)

    def on_click_printer_add(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_printer_edit(self):
        try:
            SystemConfig.update_print_controls_state(self, True)
            self.btn_printer_save.setEnabled(True)
            SystemConfig.disable_verified_status(self)
            self.update_entry_selection()
            pass
        except Exception as e:
            print(e)

    def on_click_printer_save(self):
        try:
            SystemConfig.save_print_configuration_db(self)
            pass
        except Exception as e:
            print(e)

    def on_changed_printer_name(self, text):
        try:
            pass
        except Exception as e:
            print(e)

    '''Peripherals Menu controls access and logic'''

    def on_click_edit_peripherals(self):
        try:
            SystemConfig.update_peripherals_controls_state(self, True)
            SystemConfig.disable_verified_status(self)
            self.cmb_input_names = [self.cmbPeripherals1, self.cmbPeripherals2]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBox_Style(self, self.cmb_input_names[i])

            pass
        except Exception as e:
            print(e)

    def on_click_save_peripherals(self):
        try:
            SystemConfig.update_peripherals_comport_db(self)
            pass
        except Exception as e:
            print(e)

    '''Preferences Menu access and logic'''

    def on_click_preference_menu(self):
        try:
            pass
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_app_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lbl_logo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            print(e)

    def on_click_date_time_auto(self):
        try:
            self.lblContinentHeader.setText("Continent")
            self.lblRegionHeader.setText("Region")
            self.cmbRegion.setVisible(True)
            self.cmbContinent.setVisible(True)
            UiComponents.auto_toggle(self)
            self.flg_manual_enable = False
            from Presentation.Py.GeneralSettings import GeneralSettings
            self.StatusLabel = [self.lbl_continent_status, self.lbl_region_status]
            for i in range(len(self.StatusLabel)):
                self.StatusLabel[i].setVisible(False)
        except Exception as e:
            print(e)

    def on_click_date_time_manual(self):
        try:
            self.lblContinentHeader.setText("Date")
            self.lblRegionHeader.setText("Time")
            self.txt_date.setVisible(True)
            self.txt_time.setVisible(True)
            self.cmbRegion.setVisible(False)
            self.cmbContinent.setVisible(False)
            UiComponents.manual_toggle(self)
            self.flg_manual_enable = True
            from Presentation.Py.GeneralSettings import GeneralSettings
            self.StatusLabel = [self.lbl_continent_status, self.lbl_region_status]
            for i in range(len(self.StatusLabel)):
                self.StatusLabel[i].setVisible(False)
        except Exception as e:
            print(e)

    '''System Diagnostics'''

    def initialize_system_diagnostics(self):
        try:
            self.dict_com_ports = {
                'COM1': '/dev/ttyAMA0',
                'COM2': '/dev/ttyAMA1',
                'COM3': '/dev/ttyAMA3',
            }
        except Exception as e:
            print(e)

    '''initialize_com_config_ports method initializes all serial COM ports and stores their status.'''

    def initialize_com_config_ports(self):
        try:
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            # Initialize all COM ports and store their status
            self.port_status = {}
            for com_name, port_path in self.dict_com_ports.items():
                if port_path in serialports:
                    self.port_status[com_name] = self.test_communication(port_path)
                else:
                    self.port_status[com_name] = 'Port not available'

            return self.port_status
        except Exception as e:
            print(f"Exception occurred: {e}")
            return None

    '''Each com port  button click tests the respective COM port by calling the test_communication method and return 
    status'''

    def test_communication(self, port_path):
        try:
            test_data = b'U'  # Example test data
            with serial.Serial(port_path, baudrate=9600, timeout=1) as ser:
                ser.write(test_data)
                response = ser.read(1)  # Read 1 byte
                if response == b'u':
                    return 'Communication successful'
                else:
                    return 'No response or incorrect response'
        except serial.SerialException as e:
            return f"Serial exception: {e}"
        except Exception as e:
            return f"Exception: {e}"

    def test_port(self, com_name):
        try:
            port_path = self.dict_com_ports[com_name]
            status = self.test_communication(port_path)
            self.update_button_color(com_name, status)
            print(f"{com_name}: {status}")
        except Exception as e:
            print(e)

    '''this function is used to assign the button names for updating button status'''

    def update_button_color(self, com_name, status):
        try:
            if com_name == 'COM1':
                button = self.btn_rS232_com1
            elif com_name == 'COM2':
                button = self.btn_rS232_com2
            elif com_name == 'COM3':
                button = self.btn_rS232_com3
            UiComponents.update_com_config_status(self, button, status)
        except Exception as e:
            print(e)

    '''Ethernet UI menu access control and logic'''

    def on_click_ethernet_communication(self, index):
        try:
            UiComponents.update_sub_menu_components(self, self.Ethernet)
            if not self.dict_user_permission["GeneralVisible"] == "1":
                SettingsEthernetUi.create_ethernet_ui(self)
                SystemConfig.init_Ethernet_communication(self, index)
                if self.dict_user_permission["GeneralRead"] == "1":
                    self.menu_access(False, self.frmEthernet)
                else:
                    self.menu_access(True, self.frmEthernet)
            else:
                self.wgt.raise_()
                self.wgt_main.lower()
                SettingsAccessDeniedUi.sub_layout_Ui(self)
                self.setToolTipMessage(275, 120)
                pass
        except Exception as e:
            print(e)

    def update_camera_buttons(self):
        try:
            # Get the selected number from the combobox
            selected_number = self.cmbCameraQuantity.currentText()
            print(selected_number)

            # Determine the number of buttons to enable
            num_buttons = int(selected_number) if selected_number.isdigit() else 0

            # Disable buttons based on the selection
            if num_buttons == 1:
                self.btn2.setEnabled(False)
                self.btn2.hide()
                self.btn3.setEnabled(False)
                self.btn3.hide()
                self.btn4.setEnabled(False)
                self.btn4.hide()
            if num_buttons == 2:
                self.btn3.setEnabled(False)
                self.btn3.hide()
                self.btn4.setEnabled(False)
                self.btn4.hide()
                self.btn2.setEnabled(True)
                self.btn2.setVisible(True)
            if num_buttons == 3:
                self.btn4.setEnabled(False)
                self.btn4.hide()
                self.btn2.setEnabled(True)
                self.btn2.setVisible(True)
                self.btn3.setEnabled(True)
                self.btn3.setVisible(True)
            if num_buttons == 4:
                self.btn2.setEnabled(True)
                self.btn2.setVisible(True)
                self.btn3.setEnabled(True)
                self.btn3.setVisible(True)
                self.btn4.setEnabled(True)
                self.btn4.setVisible(True)
                pass
            pass
        except Exception as e:
            print(e)

    def on_click_ethernet_edit(self):
        try:
            SystemConfig.update_ethernet_controls_state(self, True)
            SystemConfig.disable_verified_status(self)
        except Exception as e:
            print(e)

    def on_click_ethernet_save(self):
        try:
            if self.index == None:
                SystemConfig.save_camera_quantity(self)
            else:
                SystemConfig.save_camera_quantity(self)
                SystemConfig.save_ethernet_values(self, self.index)
        except Exception as e:
            print(e)

    def on_click_ethernet_cancel(self):
        try:
            pass
        except Exception as e:
            print(e)

    def on_click_cam(self):
        try:
            self.index=1
            sender = self.sender()
            if sender is not None:
                button_name = sender.objectName()
                if button_name == "btn1":
                    self.index = 1
                    SystemConfig.on_loading_ethernet_settings(self, index=self.index)
                    pass
                if button_name == "btn2":
                    self.index = 2
                    SystemConfig.on_loading_ethernet_settings(self, index=self.index)
                    print("idx2")
                if button_name == "btn3":
                    self.index = 3
                    SystemConfig.on_loading_ethernet_settings(self, index=self.index)
                    pass
                if button_name == "btn4":
                    self.index = 4
                    SystemConfig.on_loading_ethernet_settings(self, index=self.index)
                    pass
                for button in [self.btn1, self.btn2, self.btn3, self.btn4]:
                    button.setStyleSheet("background-color: none; color: black;")

                    # Set the style of the clicked button
                clicked_button = self.sender()
                clicked_button.setStyleSheet("background-color: black; color: white;")
        except Exception as e:
            print(e)

    def create_stacked_widgets(self):
        try:
            self.create_stacked_widgets()
        except Exception as e:
            print(e)







