from DataAccess.BaseDA import BaseDA


class AppFeaturesDA(BaseDA):
    def get_app_feature_count(self, feature_name):
        try:
            self.query = "SELECT COUNT(Id) FROM T_MasterAppSettings WHERE FeatureName = '" + feature_name + "'"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def insert_app_fetaure(self, feature_list):
        try:
            self.query = "INSERT INTO T_MasterAppSettings (FeatureName,StatusID) VALUES (?,?)"
            return self.execute_many(self.query, feature_list)
            pass
        except Exception as e:
            print(e)

    def update_app_features(self, features_list):
        try:
            self.query = "UPDATE T_MasterAppSettings SET StatusID = '" + features_list[1] + "' WHERE FeatureName = '" + \
                         features_list[0] + "'"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def fetch_configured_features(self):
        try:
            self.query = "SELECT FeatureName,StatusID FROM T_MasterAppSettings"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)