from DataAccess.BaseDA import BaseDA


class VehicleReEntryDA(BaseDA):

    def get_all_entries(self):
        try:
            query = "SELECT cast(SerialNo as text) FROM T_Entry WHERE(grossWt>0 OR tareWt>0)AND NOT(grossWt>0 AND tareWt>0) order by SerialNo desc"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_all_vehicles(self):
        try:
            query = "SELECT header1 FROM T_Entry WHERE(grossWt>0 OR tareWt>0)AND NOT(grossWt>0 AND tareWt>0) order by SerialNo desc"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_selected_entries(self, entry_id):
        try:
            query = "SELECT * FROM T_Entry WHERE SerialNo ='" + entry_id + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_selected_vehicle(self, vehicle_no):
        try:
            query = "SELECT * FROM T_Entry WHERE header1 ='" + vehicle_no + "' order by SerialNo desc"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code1name(self, code):
        try:
            query = "SELECT f_code1Name FROM T_Code1 WHERE f_code1No ='" + code + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code2name(self, code):
        try:
            query = "SELECT f_code2Name FROM T_Code2 WHERE f_code2No ='" + code + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code3name(self, code):
        try:
            query = "SELECT f_code3Name FROM T_Code3 WHERE f_code3No ='" + code + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code4name(self, code):
        try:
            query = "SELECT f_code4Name FROM T_Code4 WHERE f_code4No ='" + code + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code5name(self, code):
        try:
            query = "SELECT f_code5Name FROM T_Code5 WHERE f_code5No ='" + code + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def update_entry_details(self, param):
        try:
            query = "UPDATE T_Entry" \
                    " SET" \
                    " header2 ='" + param.Field2 + "'" \
                    " ,header3 ='" + param.Field3 + "'" \
                    " ,header4 ='" + param.Field4 + "'" \
                    " ,Header5 ='" + param.Field5 + "'" \
                    " ,code1_no ='" + param.Code1 + "'" \
                    " ,code2_no ='" + param.Code2 + "'" \
                    " ,code3_no ='" + param.Code3 + "'" \
                    " ,code4_no ='" + param.Code4 + "'" \
                    " ,code5_no ='" + param.Code5 + "'" \
                    " ,code1_value ='" + param.code1_value + "'" \
                    " ,code2_value ='" + param.code2_value + "'" \
                    " ,code3_value ='" + param.code3_value + "'" \
                    " ,code4_value ='" + param.code4_value + "'" \
                    " ,code5_value ='" + param.code5_value + "'" \
                    " ,grossWt ='" + param.GrossWt + "'" \
                    " ,grossDate ='" + param.GrossDate + "'" \
                    " ,tareWt ='" + param.TareWt + "'" \
                    " ,tareDate ='" + param.TareDate + "'" \
                    " ,ReEntry_Amount ='" + param.Amount + "'" \
                    " ,NetWt ='" + param.NetWt + "'" \
                    ",ReportDate ='" + param.report_date + "'" \
                    ",ReportTime ='" + param.report_time + "'" \
                                                           ",gunny_bag_status ='" + param.gunny_status + "'" \
                                                                                                  " WHERE SerialNo = '" + param.SerialNo + "'"
            return self.execute_dml(query)
        except Exception as e:
            print(e)

    def get_code_and_header(self, ftype):
        try:
            query = "SELECT Name, EX_ED FROM T_CodeAndHeader WHERE Type='" + ftype + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_other_settings(self, ftype):
        try:
            query = "SELECT Name, Status FROM T_OtherSettings WHERE Name='" + ftype + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def Get_Header(self):
        try:
            self.query = ""
            self.query = "SELECT f_Header1,f_Header2,f_Header3,f_Header4,f_Header5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_HeaderParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def get_code(self):
        try:
            self.query = ""
            self.query = "SELECT f_Code1,f_Code2,f_Code3,f_Code4,f_Code5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_CodeParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)



