from DataAccess.BaseDA import BaseDA


class UserPermissionDA(BaseDA):

    def InsertUserRoles(self, UserRole):
        try:
            if not UserRole == "":
                self.Query = "INSERT  INTO T_UserRoles (RoleName,StatusID) VALUES ('" + UserRole + "','1')"
                self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)
        pass

    def FetchUserStatus(self, UserRole):
        try:
            self.Query = "SELECT COUNT(RoleId) FROM T_UserRoles WHERE RoleName = '" + UserRole + "'"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)

    def FetchMaximumCustomRoleCount(self):
        try:
            self.Query = "SELECT COUNT(RoleId) FROM T_UserRoles"
            return self.execute_select(self.Query)
        except Exception as e:
            print(e)

    def GetUserRoleID(self, UserRole):
        try:
            self.Query = "SELECT RoleId FROM T_UserRoles WHERE RoleName = '" + UserRole + "'"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)
        pass

    def SaveUserPermissionSettings(self, dictUserAccess):
        try:
            if not dictUserAccess is None:
                self.Query = "INSERT INTO T_UserPermission (RoleId,SysConfigRead,SysConfigWrite,SysConfigVisible," \
                             "AppConfigRead,AppConfigWrite,AppConfigVisible,GeneralRead,GeneralWrite,GeneralVisible,WebhooksRead,WebhooksWrite,WebhooksVisible," \
                             "ParameterRead,ParameterWrite,ParameterVisible,ProfileRead,ProfileWrite,ProfileVisible,NotificationRead,NotificationWrite,NotificationVisible,AdvantagesRead,AdvantagesWrite,AdvantagesVisible" \
                             ") VALUES ('" + dictUserAccess["UserName"] + "','" + dictUserAccess[
                                 "SysConfigRead"] + "','" + dictUserAccess["SysConfigWrite"] + "','" + dictUserAccess[
                                 "SysConfigVisible"] + "'," \
                                                       "'" + dictUserAccess["AppConfigRead"] + "','" + dictUserAccess[
                                 "AppConfigWrite"] + "','" + dictUserAccess["AppConfigVisible"] + "','" + dictUserAccess[
                                 "GeneralRead"] + "'," \
                                                  "'" + dictUserAccess["GeneralWrite"] + "','" + dictUserAccess[
                                 "GeneralVisible"] + "','" + dictUserAccess["WebhooksRead"] + "','" + dictUserAccess[
                                 "WebhooksWrite"] + "'," \
                                                    "'" + dictUserAccess["WebhooksVisible"] + "','" + dictUserAccess[
                                 "ParameterRead"] + "','" + dictUserAccess["ParameterWrite"] + "','" + \
                             dictUserAccess["ParameterVisible"] + "'," \
                                                                    "'" + dictUserAccess["ProfileRead"] + "','" + \
                             dictUserAccess["ProfileWrite"] + "','" + dictUserAccess["ProfileVisible"] + "'," \
                                                                                                           "'" + \
                             dictUserAccess["NotificationRead"] + "','" + dictUserAccess["NotificationWrite"] + "','" + \
                             dictUserAccess["NotificationVisible"] + "'," \
                                                                     "'" + dictUserAccess["AdvantagesRead"] + "','" + \
                             dictUserAccess["AdvantagesWrite"] + "','" + dictUserAccess["AdvantagesVisible"] + "')"
                return self.execute_query(self.Query)
                pass
            pass
        except Exception as e:
            print(e)

    def UpdateUserPermissionSettings(self, dictUserAccess):
        try:
            if not dictUserAccess is None:
                self.Query = "UPDATE T_UserPermission SET SysConfigRead ='" + dictUserAccess[
                    "SysConfigRead"] + "',SysConfigWrite = '" + dictUserAccess[
                                 "SysConfigWrite"] + "',SysConfigVisible = '" + dictUserAccess[
                                 "SysConfigVisible"] + "'," \
                                                       "AppConfigRead = '" + dictUserAccess[
                                 "AppConfigRead"] + "',AppConfigWrite = '" + dictUserAccess[
                                 "AppConfigWrite"] + "',AppConfigVisible = '" + dictUserAccess["AppConfigVisible"] + "'," \
                                                                                                               "GeneralRead = '" + \
                             dictUserAccess["GeneralRead"] + "',GeneralWrite = '" + dictUserAccess[
                                 "GeneralWrite"] + "',GeneralVisible = '" + dictUserAccess["GeneralVisible"] + "'," \
                                                                                                               "WebhooksRead = '" + \
                             dictUserAccess["WebhooksRead"] + "',WebhooksWrite = '" + dictUserAccess[
                                 "WebhooksWrite"] + "',WebhooksVisible = '" + dictUserAccess["WebhooksVisible"] + "'," \
                                                                                                                  "ParameterRead = '" + \
                             dictUserAccess["ParameterRead"] + "',ParameterWrite = '" + dictUserAccess[
                                 "ParameterWrite"] + "',ParameterVisible = '" + dictUserAccess[
                                 "ParameterVisible"] + "'," \
                                                         "ProfileRead = '" + dictUserAccess[
                                 "ProfileRead"] + "',ProfileWrite = '" + dictUserAccess[
                                 "ProfileWrite"] + "',ProfileVisible = '" + dictUserAccess["ProfileVisible"] + "'," \
                                                                                                                  "NotificationRead = '" + \
                             dictUserAccess["NotificationRead"] + "',NotificationWrite = '" + dictUserAccess[
                                 "NotificationWrite"] + "',NotificationVisible = '" + dictUserAccess[
                                 "NotificationVisible"] + "'," \
                                                          "AdvantagesRead = '" + dictUserAccess[
                                 "AdvantagesRead"] + "',AdvantagesWrite = '" + dictUserAccess[
                                 "AdvantagesWrite"] + "',AdvantagesVisible = '" + dictUserAccess[
                                 "AdvantagesVisible"] + "' WHERE RoleId = '" + dictUserAccess["UserName"] + "'"
                return self.execute_query(self.Query)
                pass
            pass
        except Exception as e:
            print(e)

    def FetchAvailableRoles(self):
        try:
            self.Query = "SELECT RoleName FROM T_UserRoles"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)
        pass

    def FetchSelectedRoleStatus(self, RoleName):
        try:
            if not RoleName == "":
                self.Query = "SELECT Role.RoleName,Permission.SysConfigRead,Permission.SysConfigWrite,Permission.SysConfigVisible," \
                             "Permission.AppConfigRead,Permission.AppConfigWrite,Permission.AppConfigVisible,Permission.GeneralRead,Permission.GeneralWrite,Permission.GeneralVisible,Permission.WebhooksRead,Permission.WebhooksWrite,Permission.WebhooksVisible," \
                             "Permission.ParameterRead,Permission.ParameterWrite,Permission.ParameterVisible," \
                             "Permission.ProfileRead,Permission.ProfileWrite,Permission.ProfileVisible,Permission.NotificationRead,Permission.NotificationWrite,Permission.NotificationVisible," \
                             "Permission.AdvantagesRead,Permission.AdvantagesWrite,Permission.AdvantagesVisible " \
                             "FROM T_UserRoles Role INNER JOIN T_UserPermission Permission ON Role.RoleId = Permission.RoleId WHERE Role.RoleName = '" + RoleName + "'"
                return self.execute_select(self.Query)

        except Exception as e:
            print(e)

    def FetchActiveUserDetails(self):
        try:
            self.Query = "SELECT Permission.SysConfigRead,Permission.SysConfigWrite,Permission.SysConfigVisible," \
                         "Permission.AppConfigRead,Permission.AppConfigWrite,Permission.AppConfigVisible,Permission.GeneralRead,Permission.GeneralWrite,Permission.GeneralVisible,Permission.WebhooksRead,Permission.WebhooksWrite,Permission.WebhooksVisible," \
                         "Permission.ParameterRead,Permission.ParameterWrite,Permission.ParameterVisible," \
                         "Permission.ProfileRead,Permission.ProfileWrite,Permission.ProfileVisible,Permission.NotificationRead,Permission.NotificationWrite,Permission.NotificationVisible," \
                         "Permission.AdvantagesRead,Permission.AdvantagesWrite,Permission.AdvantagesVisible " \
                         "FROM T_Users User INNER JOIN T_UserRoles Role ON User.RoleId = Role.RoleId INNER JOIN T_UserPermission Permission ON Role.RoleId = Permission.RoleId WHERE User.StatusID = '1'"
            print(self.Query)

            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)

    def delete_selected_user_role(self, role_id):
        try:
            self.Query = "DELETE FROM T_UserRoles WHERE RoleId = '" + role_id + "'"
            return self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)

    def delete_user_permission(self, role_id):
        try:
            self.Query = "DELETE FROM T_UserPermission WHERE RoleId = '" + role_id + "'"
            return self.execute_query(self.Query)
        except Exception as e:
            print(e)

    def Update_Role_ID(self, role_id):
        try:
            self.Query = "UPDATE T_Users SET RoleId = '0' WHERE RoleID = '" + role_id + "'"
            return self.execute_query(self.Query)
        except Exception as e:
            print(e)
