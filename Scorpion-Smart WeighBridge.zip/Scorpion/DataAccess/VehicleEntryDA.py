from DataAccess.BaseDA import BaseDA


class VehicleEntryDA(BaseDA):
    def insert_entry_details(self, param):
        try:
            query = "INSERT INTO T_Entry (SerialNo," \
                    "header1,header2,header3,header4," \
                    "Header5,code1_no,code2_no,code3_no," \
                    "code4_no,code5_no,code1_value,code2_value,code3_value,code4_value,code5_value,grossWt,grossUnit," \
                    "grossDate,tareWt,tareUnit,tareDate,Amount,netWt," \
                    "ReportDate,ReportTime,ReEntry_Amount,first_entry,gunny_bag_status,manual_entry_status" \
                    ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'0',?,?,?)"
            return self.execute_many(query, param)
        except Exception as e:
            print(e)

    def insert_entry_gunnydetails(self, param):
        try:
            query = "INSERT INTO T_Entry (SerialNo," \
                    "header1,header2,header3,header4," \
                    "Header5,code1_no,code2_no,code3_no," \
                    "code4_no,code5_no,code1_value,code2_value,code3_value,code4_value,code5_value,grossWt,grossUnit," \
                    "grossDate,tareWt,tareUnit,tareDate,Amount,netWt, ReportDate, ReportTime,BagWeight,BagQuantity,ReEntry_Amount,first_entry,gunny_bag_status,manual_entry_status" \
                    ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'0',?,?,?)"
            return self.execute_many(query, param)
        except Exception as e:
            print(e)

    def get_code1(self):
        try:
            query = "SELECT f_Code1No FROM T_Code1"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code2(self):
        try:
            query = "SELECT f_Code2No FROM T_Code2"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code3(self):
        try:
            query = "SELECT f_Code3No FROM T_Code3"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code4(self):
        try:
            query = "SELECT f_Code4No FROM T_Code4"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_code5(self):
        try:
            query = "SELECT f_Code5No FROM T_Code5"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_entry_count(self):
        try:
            query = "select Max(SerialNo)+1 from T_Entry"
            return self.execute_selectone(query)
        except Exception as e:
            print(e)

    def get_code_and_header(self, ftype):
        try:
            query = "SELECT Name, EX_EN FROM T_CodeAndHeader WHERE Type='" + ftype + "'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_unit(self):
        try:
            query = "SELECT Name, Status FROM T_OtherSettings WHERE Name ='Unit'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_gunny_status(self):
        try:
            query = "SELECT Status FROM T_OtherSettings WHERE Name = 'GunnyBag'"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def Get_header(self):
        try:
            self.query = ""
            self.query = "SELECT f_Header1,f_Header2,f_Header3,f_Header4,f_Header5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_HeaderParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def Get_Code(self):
        try:
            self.query = ""
            self.query = "SELECT f_Code1,f_Code2,f_Code3,f_Code4,f_Code5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_CodeParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def get_entry_details(self):
        try:
            self.query = ""
            self.query = "SELECT * FROM T_Entry WHERE SerialNo = (SELECT MAX(SerialNo) FROM T_Entry);"
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def get_transaction_details(self, date):
        try:
            self.query = ""
            self.query = "SELECT ReportDate,(SELECT COUNT(Amount) FROM T_Entry WHERE ReportDate = '"+date+"' AND Amount > '0' ) As EntryTransaction,(SELECT COUNT(ReEntry_Amount) FROM T_Entry WHERE ReportDate = '"+date+"' AND ReEntry_Amount > '0' ) AS ReEntryTransaction,SUM(Amount),SUM(ReEntry_Amount) from T_Entry  WHERE ReportDate = '"+date+"'"
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def get_all_vehicles(self):
        try:
            self.query = ""
            self.query = "SELECT header1 FROM T_Entry "
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def update_transaction_details(self, list_details):
        try:
            self.query = ""
            self.query = "UPDATE T_transaction_details SET f_transaction_date = '" + list_details[
                0] + "',f_no_of_entry_transactions = '" + list_details[1] + "',f_no_of_re_entry_transactions = '" + list_details[2] + "',f_entry_amount = '" + list_details[
                             3] + "',f_reentry_amount = '" + list_details[4] + "' WHERE ID = '1'"
            return self.execute_dml(self.query)
        except Exception as e:
            print(e)

    def fetch_transaction_details_param(self):
        try:
            self.query = "SELECT *  FROM T_transaction_details "
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

