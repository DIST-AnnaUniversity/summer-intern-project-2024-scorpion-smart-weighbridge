from DataAccess.BaseDA import BaseDA


class LoginDA(BaseDA):
    def get_user_info(self, user):
        query = "SELECT Name,Password,RoleID,StatusID FROM T_Users WHERE Name = '" + user + "'"
        return self.execute_select(query)

    def update_status(self):
        query = "Update T_Users SET StatusID  = '0' WHERE StatusID  = '1'"
        return self.execute_dml(query)

    def set_active_user(self, user):
        query = "Update T_Users SET StatusID  = '1' WHERE Name  = '" + user + "'"
        return self.execute_dml(query)

    def get_Activated_Profile_info(self):
        try:
            query = "SELECT Name,Email,PhoneNumber,ProfilePicture,RoleId FROM T_Users WHERE StatusID = 1"
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def Set_Editted_Logo(self, Logo, Date):
        self.query = ""
        self.query = "UPDATE T_Users SET ProfilePicture = '" + Logo + "',UpdateDate = '" + Date + "' WHERE StatusID = '1'"
        return self.execute_dml(self.query)

    def Set_Editted_Profile_info(self, Updated_ProfileDetails_List):
        self.query = ""
        self.query = "UPDATE T_Users SET Name = '" + Updated_ProfileDetails_List[0] + "',Email = '" + \
                     Updated_ProfileDetails_List[1] + "',PhoneNumber = '" + Updated_ProfileDetails_List[
                         2] + "',ProfilePicture = '" + Updated_ProfileDetails_List[3] + "',UpdateDate = '" + \
                     Updated_ProfileDetails_List[3] + "' WHERE StatusID = 1 "
        return self.execute_dml(self.query)

    def CreateUser(self, list):
        query = 'INSERT INTO T_Users (Name,Designation,Email,Password,PhoneNumber,ProfilePicture,RoleId,Cust_CODE,InsertDate,UpdateDate,StatusID)VALUES(?,?,?,?,?,?,?,?,?,?,?)'
        self.execute_many(query, list)
        pass

    def user_already_exist(self, name):
        self.query = ""
        self.query = "SELECT count(UserId) FROM T_Users WHERE Name = '" + name + "'"
        return self.execute_select(self.query)

    def FetchAvailableRoles(self):
        try:
            self.Query = "SELECT RoleName FROM T_UserRoles"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)
        pass

    def Users(self):
        query = "SELECT USer.Name,USer.Name,DisplayStatus.RoleName FROM T_Users USer INNER JOIN T_UserRoles DisplayStatus ON USer.RoleId = DisplayStatus.RoleId"
        return self.execute_select(query)

    def set_Roles(self, result_data, status, UserID, Time):
        query = "UPDATE T_Users SET RoleId ='" + result_data + "',UpdateDate ='" + Time + "',StatusID ='" + status + "' WHERE UserId = '" + UserID + "'"
        return self.execute_dml(query)

    def Update_AssignRoles(self, UserId, RoleId, date):
        self.query = "UPDATE T_Users SET RoleId = '" + RoleId + "',UpdateDate = '" + date + "' WHERE UserId ='" + UserId + "'"
        return self.execute_dml(self.query)

    def fetch_selected_role_id(self, role_name):
        self.Query = "SELECT RoleId FROM T_UserRoles WHERE RoleName = '" + role_name + "' "
        return self.execute_select(self.Query)

    def fetch_selected_userID(self, user_name):
        query = "SELECT UserID FROM T_Users WHERE Name = '" + user_name + "'"
        return self.execute_select(query)
