from DataAccess.BaseDA import BaseDA


class MainScreenDA(BaseDA):
    def get_code_name(self, field, status):
        try:
            query = "select " + field + " from T_CodeParameters WHERE " + status + " = 1"
            output = self.execute_select(query)
            result = output[0][0] if len(output) > 0 else ""
            return result
        except Exception as e:
            print(e)

    def get_header_name(self, field, status):
        try:
            query = "select " + field + " from T_HeaderParameters WHERE " + status + " = 1"
            output = self.execute_select(query)
            result = output[0][0] if len(output) > 0 else ""
            return result
        except Exception as e:
            print(e)

    def get_entry_details(self):
        try:
            query = "select SerialNo,header1,grossWt,tareWt,netwt,(Amount + ReEntry_Amount) AS TotalAmount from " \
                    "T_Entry order by SerialNo desc LIMIT 10"
            return self.execute_select(query)
        except Exception as e:
            print(e)

    def get_header_footer(self):
        try:
            query = "select SerialNo,header1,grossWt,tareWt,netwt,Amount from " \
                    "T_Entry order by SerialNo desc"
            return self.execute_select(query)
        except Exception as e:
            print(e)


    def get_selected_filters(self,column_name):
        try:
            self.query = "SELECT DISTINCT "+column_name+" FROM T_Entry ORDER BY SerialNo DESC"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_user_names(self):
        try:
            self.query = "SELECT Name FROM T_Users"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_selected_product_details(self, column_name, column_value):
        try:
            self.query = ""
            self.query = "SELECT SerialNo,header1,header2,header3,header4,Header5,code1_no," \
                         "code2_no,code3_no,code4_no,code5_no," \
                         "grossWt,tareWt,netWt,Amount,grossUnit,grossDate,tareDate,ReEntry_Amount,first_entry,gunny_bag_status,manual_entry_status FROM T_Entry WHERE "+column_name+" = '"+column_value+"'"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def update_password(self, user_name, password):
        try:
            self.query = ""
            self.query = "Update T_Users SET Password = '"+password+"' WHERE Name = '"+user_name+"' "
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    ''''tare logic'''

    def insert_tare_log(self, list_tare_values):
        try:
            self.query = ""
            self.query = "INSERT INTO T_TareLog (UserID,LastTaredDatetime,TareWeight,InsertDate,Unit,StatusID) VALUES " \
                         "(?,?,?,?,?,?)"
            list_tare_values.append('1')
            return self.execute_many(self.query, list_tare_values)
        except OSError as e:
            print(e)

    def delete_top_record_from_tare_log(self):
        try:
            self.Query = "DELETE FROM T_TareLog WHERE ID in (SELECT ID FROM T_TareLog LIMIT 1)"
            return self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)

    def fetch_tare_log_count(self):
        try:
            self.Query = "SELECT COUNT(ID) FROM T_TareLog"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)

    def set_tare_status_inactive(self):
        try:
            self.Query = "UPDATE T_TareLog SET StatusID = '0' WHERE StatusID = '1'"
            return self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)

    def get_camera_status(self):
        try:
            self.Query = "SELECT StatusID FROM T_MasterAppSettings where FeatureName= 'CameraSettings' "
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)

    def get_bill_data(self, index):
        try:
            self.query = ""
            self.query = f"SELECT SerialNo,header1,header2,header3,header4,Header5,code1_value," \
                         "code2_value,code3_value,code4_value,code5_value," \
                         f"grossWt,tareWt,netWt,Amount,grossUnit,grossDate,tareDate,ReEntry_Amount,first_entry,gunny_bag_status,manual_entry_status FROM T_Entry WHERE SerialNo = {index}"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)




