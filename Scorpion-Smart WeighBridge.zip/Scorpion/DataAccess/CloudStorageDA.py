from DataAccess.BaseDA import BaseDA


class CloudStorageDA(BaseDA):
    def __init__(self, parent=None):
        super().__init__(parent)

    def get_cloud_storage_da(self):
        try:
            self.query = ""
            self.query = "SELECT CustomerName,DomainName,CustomerCode,DeviceID,ServerHostname,ServerDbName," \
                         "ServerPassword,ServerPort FROM T_CloudStorage WHERE Id='1'"
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def get_app_fetaures_status(self, feature_name):
        try:
            self.query = "SELECT StatusID FROM T_MasterAppSettings WHERE FeatureName = '" + feature_name + "'"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    '''For updating cloud data in local'''

    def insert_entry_details_cloud(self, param):
        try:
            query = "INSERT INTO T_CloudStorageReport (SerialNo," \
                    "header1,header2,header3,header4," \
                    "Header5,code1_no,code2_no,code3_no," \
                    "code4_no,code5_no,code1_value,code2_value,code3_value,code4_value,code5_value,grossWt,grossUnit," \
                    "grossDate,tareWt,tareUnit,tareDate,Amount,netWt," \
                    "ReportDate,ReportTime,Cust_Code,DeviceId" \
                    ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            return self.execute_many(query, param)
        except Exception as e:
            print(e)

    def insert_entry_gunnydetails_cloud(self, param):
        try:
            query = "INSERT INTO T_CloudStorageReport (SerialNo," \
                    "header1,header2,header3,header4," \
                    "Header5,code1_no,code2_no,code3_no," \
                    "code4_no,code5_no,code1_value,code2_value,code3_value,code4_value,code5_value,grossWt,grossUnit," \
                    "grossDate,tareWt,tareUnit,tareDate,Amount,netWt, ReportDate, ReportTime,BagWeight,BagQuantity,Cust_Code,DeviceId" \
                    ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            return self.execute_many(query, param)
        except Exception as e:
            print(e)

    def get_cloud_storage_report_count(self):
        try:
            self.query = "SELECT COUNT(SerialNo) FROM T_CloudStorageReport"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def delete_cloud_storage_report(self):
        try:
            self.query = "DELETE  FROM T_CloudStorageReport"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def get_cloud_local_storage(self):
        try:
            self.query = "SELECT * FROM T_CloudStorageReport"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    '''Re Entry logic'''

    def get_cloud_storage_count(self, serial_no):
        try:
            self.query = "SELECT COUNT(SerialNo) FROM T_CloudStorageReport WHERE SerialNo = '"+serial_no+"'"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def update_reentry_details_local(self, param):
        try:
            query = "UPDATE T_CloudStorageReport" \
                    " SET" \
                    " header1 ='" + param.Field1 + "'" \
                    " ,header2 ='" + param.Field2 + "'" \
                    " ,header3 ='" + param.Field3 + "'" \
                    " ,header4 ='" + param.Field4 + "'" \
                    " ,Header5 ='" + param.Field5 + "'" \
                    " ,code1_no ='" + param.Code1 + "'" \
                    " ,code2_no ='" + param.Code2 + "'" \
                    " ,code3_no ='" + param.Code3 + "'" \
                    " ,code4_no ='" + param.Code4 + "'" \
                    " ,code5_no ='" + param.Code5 + "'" \
                    " ,code1_value ='" + param.code1_value + "'" \
                    " ,code2_value ='" + param.code2_value + "'" \
                    " ,code3_value ='" + param.code3_value + "'" \
                    " ,code4_value ='" + param.code4_value + "'" \
                    " ,code5_value ='" + param.code5_value + "'" \
                    " ,grossWt ='" + param.GrossWt + "'" \
                    " ,grossDate ='" + param.GrossDate + "'" \
                    " ,tareWt ='" + param.TareWt + "'" \
                    " ,tareDate ='" + param.TareDate + "'" \
                    " ,ReEntry_Amount ='" + param.Amount + "'" \
                    " ,NetWt ='" + param.NetWt + "'" \
                    ",ReportDate ='" + param.report_date + "'" \
                    ",ReportTime ='" + param.report_time + "'" \
                    " WHERE SerialNo = '" + param.SerialNo + "'"
            return self.execute_dml(query)
        except Exception as e:
            print(e)

    def insert_reentry_details_local(self, param):
        try:
            self.query = "INSERT INTO T_CloudStorageReport (SerialNo,header1,header2,header3,header4,Header5,code1_no," \
                         "code2_no,code3_no,code4_no,code5_no,code1_value,code2_value,code3_value,code4_value," \
                         "code5_value,grossWt,grossDate,tareWt,tareDate,ReEntry_Amount,NetWt,ReportDate,ReportTime,Cust_Code,DeviceId) " \
                         "VALUES ('"+param.SerialNo+"','"+param.Field1+"','"+param.Field2+"','"+param.Field3+"','"+param.Field4+"','"+param.Field5+"','"+param.Code1+"'" \
                        ",'"+param.Code2+"','"+param.Code3+"','"+param.Code4+"','"+param.Code5+"','"+param.code1_value+"','"+param.code2_value+"'" \
                        ",'"+param.code3_value+"','"+param.code4_value+"','"+param.code5_value+"','"+param.GrossWt+"','"+param.GrossDate+"','"+param.TareWt+"','"+param.TareDate+"','"+param.Amount+"'," \
                        "'"+param.NetWt+"','"+param.report_date+"','"+param.report_time+"','"+param.CustCode+"','"+param.DeviceId+"')"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)


