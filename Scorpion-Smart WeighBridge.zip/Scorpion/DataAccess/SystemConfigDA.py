from DataAccess.BaseDA import BaseDA


class SystemConfigDA(BaseDA):
    def update_com_port(self, port_no):
        try:
            self.query = "UPDATE T_PortSettings SET f_PortNo = '" + port_no + "'"
            pass
        except Exception as e:
            print(e)

    def update_com_baudrates(self, baud_rate, id):
        try:
            self.query = "UPDATE T_MasterComSettings SET BaudRate = '" + baud_rate + "' WHERE Id = " + id + ""
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def get_configured_baudrates(self):
        try:
            self.query = "SELECT BaudRate FROM T_MasterComSettings"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_printer_port(self):
        try:
            self.query = "SELECT Master.ComPort,Master.BaudRate FROM T_peripherals Peripherals INNER JOIN T_MasterComSettings Master " \
                         " ON Master.Id = Peripherals.Printer WHERE Peripherals.Id = 1"
            return self.execute_select(self.query)
        except Exception as e:
            print(e)

    def get_remote_protocol_port(self):
        try:
            self.query = "SELECT Master.ComPort,Master.BaudRate FROM T_peripherals Peripherals INNER JOIN T_MasterComSettings Master " \
                         " ON Master.Id = Peripherals.RemoteProtocol WHERE Peripherals.Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def update_printer_comport(self, column_name, port_no):
        try:
            self.query = "UPDATE T_peripherals SET " + column_name + "= (SELECT Id FROM T_MasterComSettings WHERE " \
                                                                     "ComPort = '" + port_no + "') WHERE Id = 1"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def get_print_configurations(self):
        try:
            self.query = "SELECT Header.f_Header1,Header.f_Header2,Header.f_Header3,Header.f_Header4," \
                         "Header.f_Header5,Code.f_Code1,Code.f_Code2,Code.f_Code3,Code.f_Code4,Code.f_Code5," \
                         "Print.Header1Entry,Print.Header2Entry,Print.Header3Entry,Print.Header4Entry," \
                         "Print.Header5Entry,Print.Header1ReEntry,Print.Header2ReEntry,Print.Header3ReEntry," \
                         "Print.Header4ReEntry,Print.Header5ReEntry,Print.Code1Entry,Print.Code2Entry," \
                         "Print.Code3Entry,Print.Code4Entry,Print.Code5Entry,Print.Code1ReEntry,Print.Code2ReEntry," \
                         "Print.Code3ReEntry,Print.Code4ReEntry,Print.Code5ReEntry FROM T_HeaderParameters Header " \
                         "INNER JOIN T_CodeParameters Code ON Header.f_ID = Code.f_ID INNER JOIN T_EntryPrintConfig " \
                         "Print ON Header.f_ID = Print.Id WHERE Print.Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_print_configutation_count(self):
        try:
            self.query = "SELECT COUNT(Id) FROM T_EntryPrintConfig"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def insert_print_configurations(self, print_config):
        try:
            self.query = "INSERT INTO T_EntryPrintConfig (Header1Entry,Header2Entry,Header3Entry,Header4Entry," \
                         "Header5Entry,Header1ReEntry,Header2ReEntry,Header3ReEntry," \
                         "Header4ReEntry,Header5ReEntry,Code1Entry,Code2Entry," \
                         "Code3Entry,Code4Entry,Code5Entry,Code1ReEntry,Code2ReEntry," \
                         "Code3ReEntry,Code4ReEntry,Code5ReEntry) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            return self.execute_many(self.query, print_config)
            pass
        except Exception as e:
            print(e)

    def update_print_configurations(self, print_config):
        try:
            self.query = "UPDATE T_EntryPrintConfig SET Header1Entry = '" + print_config[0] + "',Header2Entry= '" + \
                         print_config[1] + "',Header3Entry= '" + print_config[2] + "',Header4Entry= '" + print_config[
                             3] + "'," \
                                  "Header5Entry= '" + print_config[4] + "',Header1ReEntry= '" + print_config[
                             5] + "',Header2ReEntry = '" + print_config[6] + "',Header3ReEntry = '" + print_config[
                             7] + "'," \
                                  "Header4ReEntry= '" + print_config[8] + "',Header5ReEntry = '" + print_config[
                             9] + "',Code1Entry == '" + print_config[10] + "',Code2Entry = '" + print_config[11] + "'," \
                                                                                                                   "Code3Entry = '" + \
                         print_config[12] + "',Code4Entry = '" + print_config[13] + "',Code5Entry = '" + print_config[
                             14] + "',Code1ReEntry = '" + print_config[15] + "',Code2ReEntry = '" + print_config[
                             16] + "'," \
                                   "Code3ReEntry = '" + print_config[17] + "',Code4ReEntry = '" + print_config[
                             18] + "',Code5ReEntry = '" + print_config[19] + "' WHERE Id = 1"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    ''''Calibration logic'''
    def Save_Params(self, listValues):
        try:
            self.query = ""
            self.query = "INSERT INTO T_Calibration (CalZero,CalSpan,CalCapacity," \
                         "DecimalPoint,Resolution,MaxCapacity,UpdateDate,UserID,Unit,Mode,StatusID) VALUES (?,?,?,?,?,?,?,?," \
                         "?,?,?)"
            listValues.append('1')
            return self.execute_many(self.query, listValues)
        except OSError as e:
            print(e)

    def delete_top_record_from_calibration(self):
        try:
            self.Query = "DELETE FROM T_Calibration WHERE ID in (SELECT ID FROM T_Calibration LIMIT 1)"
            return self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)

    def fetch_calibration_count(self):
        try:
            self.Query = "SELECT COUNT(ID) FROM T_Calibration"
            return self.execute_select(self.Query)
            pass
        except Exception as e:
            print(e)

    def set_data_as_inactive(self):
        try:
            self.Query = "UPDATE T_Calibration SET StatusID = '0' WHERE StatusID = '1'"
            return self.execute_query(self.Query)
            pass
        except Exception as e:
            print(e)

    def get_Activated_Profile_info(self):
        try:
            query = "SELECT Name,Email,PhoneNumber,ProfilePicture,RoleId FROM T_Users WHERE StatusID = 1"
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def get_DateTime(self):
        try:
            self.Query = "SELECT Calibration.UpdateDate,Calibration.UserId,Calibration.Mode FROM T_Calibration Calibration WHERE " \
                         "Calibration.StatusID = '1'"
            return self.execute_select(self.Query)
        except OSError as e:
            print(e)
        pass

    def get_active_resolution(self):
        try:
            self.Query = "SELECT Resolution FROM T_Calibration WHERE " \
                         "StatusID = '1'"
            return self.execute_select(self.Query)
        except OSError as e:
            print(e)
        pass

    def Get_Code(self):
        try:
            self.query = ""
            self.query = "SELECT f_Header1,f_Header2, FROM T_Mastercommunication WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    ''' Ethernet logic+camera'''

    def get_camera_status(self):
        try:
            query = "SELECT StatusID FROM T_MasterAppSettings where FeatureName = 'CameraSettings'"
            return self.execute_select(query)
        except Exception as e:
            print(e)
            return 0

    def Get_ethernet_Count(self):
        query = "SELECT count(CommId) FROM T_MasterCamera"
        return self.execute_select(query)

    def get_index(self):
        query = "SELECT CommId FROM T_MasterCamera"
        return self.execute_select(query)

    def get_Ethernet(self, index):
        try:
            query = (f"SELECT CommunicationAddress, CommunicationChannel, CommunicationUsername,"
                     f" CommunicationPassword, CommunicationURL FROM T_MasterCamera WHERE CommId = '{index}'")
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def Save_Ethernet(self, ethernet_list, index):
        try:
            query = (f"INSERT INTO T_MasterCamera CommunicationAddress, CommunicationChannel, "
                     f"CommunicationUsername, CommunicationPassword, CommunicationURL VALUES (?, ?, ?, ?, ?) "
                     f"WHERE CommId = '{index}'")
            return self.execute_dml(query, ethernet_list, index)
        except OSError as e:
            print(e)

    def Update_Ethernet(self, ethernet_list, index):
        try:
            query = ("UPDATE T_MasterCamera SET CommunicationAddress = ?, CommunicationChannel = ?, "
                     "CommunicationUsername = ?, CommunicationPassword = ? "
                     "WHERE CommId = ?")
            params = ethernet_list + [index]
            print(f"Update_Ethernet Query: {query}")
            print(f"Update_Ethernet Params: {params}")
            return self.execute_dml(query, params)
        except OSError as e:
            print(e)


    def get_url1(self):
        try:
            self.query = "SELECT CommunicationURL FROM T_MasterCamera WHERE CommId = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_url1(self):
        try:
            self.query = "SELECT CommunicationURL FROM T_MasterCamera WHERE CommId = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_url2(self):
        try:
            self.query = "SELECT CommunicationURL FROM T_MasterCamera WHERE CommId = 2"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_url3(self):
        try:
            self.query = "SELECT CommunicationURL FROM T_MasterCamera WHERE CommId = 3"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_url4(self):
        try:
            self.query = "SELECT CommunicationURL FROM T_MasterCamera WHERE CommId = 4"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def Update_url(self, ethernet_list, index):
        try:
            # Construct the RTSP URL
            ip_address = ethernet_list[0]
            port_number = ethernet_list[1]
            username = ethernet_list[2]
            password = ethernet_list[3]
            rtsp_url = self.construct_rtsp_url(username, password, ip_address, port_number)
            print(f"Constructed RTSP URL: {rtsp_url}")

            # Update the URL in the database
            query = "UPDATE T_MasterCamera SET CommunicationURL = ? WHERE CommId = ?"
            params = [rtsp_url, index]
            print(f"Update_url Query: {query}")
            print(f"Update_url Params: {params}")

            return self.execute_dml(query, params)
        except OSError as e:
            print(e)

    def construct_rtsp_url(self, username, password, ip_address, port_number):
        # Construct the RTSP URL
        rtsp_url = f"rtsp://{username}:{password}@{ip_address}:{port_number}/live"
        return rtsp_url


    def get_camera_Quantity(self):
        try:
            self.query = "SELECT CameraQuantity FROM T_MasterCamera"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def save_camera_Quantity(self, count):
        try:
            query = ("INSERT INTO T_MasterCamera CameraQuantity VALUES (?)")
            return self.execute_dml(query, count)
        except OSError as e:
            print(e)

    def Update_Camera_Quantity(self, quantity):
        try:
            print(quantity)
            self.query = "UPDATE T_MasterCamera SET CameraQuantity = '" + quantity + "' WHERE CommId = 5"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def update_cam1_status(self, features_list):
        try:
            self.query = "UPDATE T_MasterCamera SET StatusID = 1 WHERE CommId = 1"
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

