from DataAccess.BaseDA import BaseDA


class WebhooksDA(BaseDA):

    def get_cloud_storage_data(self):
        try:
            self.query = "SELECT * FROM T_CloudStorage WHERE Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def get_cloud_storage_count(self):
        try:
            self.query = "SELECT COUNT(Id) FROM T_CloudStorage WHERE Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def update_cloud_storage_data(self, cloud_config):
        try:
            self.query = "UPDATE T_CloudStorage SET CustomerName = '" + cloud_config[0] + "',DomainName = '" + \
                         cloud_config[1] + "',CustomerCode = '" + cloud_config[2] + "',DeviceID = '" + cloud_config[
                             3] + "',ServerHostname = '" + cloud_config[4] + "',ServerDbName = '" + cloud_config[
                             5] + "',ServerPassword= '" + cloud_config[6] + "',ServerPort = '" + cloud_config[
                             7] + "' WHERE Id = 1"

            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_storage_data(self, cloud_config):
        try:
            self.query = "INSERT INTO T_CloudStorage (CustomerName,DomainName,CustomerCode,DeviceID,ServerHostname," \
                         "ServerDbName,ServerPassword,ServerPort) VALUES (?,?,?,?,?,?,?,?)"
            return self.execute_many(self.query, cloud_config)
            pass
        except Exception as e:
            print(e)

    def delete_db_backup(self):
        query = "DELETE FROM T_Report"
        self.execute_dml(query)
