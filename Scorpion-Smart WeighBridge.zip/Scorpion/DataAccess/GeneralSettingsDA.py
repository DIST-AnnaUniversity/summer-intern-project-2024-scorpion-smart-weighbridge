from DataAccess.BaseDA import BaseDA


class GeneralSettingsDA(BaseDA):

    def Save_Region(self, continent, region):
        self.query = ""
        self.query = "INSERT INTO T_GeneralSettings (Continent,Region, DateTime) Values('" + continent + "''" + region + "', 'Auto')"
        return self.execute_dml(self.query)

    def Update_Region(self, region, continent):
        self.query = ""
        self.query = "UPDATE T_GeneralSettings SET Continent ='" + continent + "', Region= '" + region + "', DateTime= 'Auto'"
        return self.execute_dml(self.query)

    def save_date_time(self, date, time):
        self.query = ""
        self.query = "INSERT INTO T_GeneralSettings (ManualContinent,ManualRegion, DateTime) Values('" + date + "','" + time + "',""Manual)"
        return self.execute_dml(self.query)

    def update_manual_entry(self, date, time):
        self.query = ""
        self.query = "UPDATE T_GeneralSettings SET ManualContinent ='" + date + "', ManualRegion= '" + time + "', DateTime= 'Manual'"
        return self.execute_dml(self.query)

    def GetSavedRegion(self):
        self.query = "SELECT Continent, Region, ManualContinent, ManualRegion,DateTime FROM T_GeneralSettings "
        return self.execute_select(self.query)

    def Get_GeneralSettings_Count(self):
        self.query = "SELECT count(G_ID) FROM T_GeneralSettings "
        return self.execute_select(self.query)

    def get_Parameters(self):
        try:
            query = "SELECT Header1,Header2,Header3,BrowserLogo FROM T_GeneralSettings"
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def Save_Headers(self, Code1_Parameters):
        try:
            self.query = ""
            self.query = "INSERT INTO T_GeneralSettings (Header1,Header2,Header3,BrowserLogo) VALUES (?,?,?,?)"
            return self.execute_many(self.query, Code1_Parameters)
        except OSError as e:
            print(e)

    def Update_Headers(self, listofheaders):
        try:
            self.query = "UPDATE T_GeneralSettings SET Header1 = '" + listofheaders[0] + "',Header2 = '" + \
                         listofheaders[1] + "',Header3 = '" + listofheaders[2] + "',BrowserLogo = '" + listofheaders[
                             3] + "'"
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    def get_footer_Parameters(self):
        try:
            query = "SELECT Footer1,Footer2,Footer3 FROM T_GeneralSettings"
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def Save_Footers(self, Code1_Parameters):
        try:
            self.query = ""
            self.query = "INSERT INTO T_GeneralSettings (Footer1,Footer2,Footer3) VALUES (?,?,?)"
            return self.execute_many(self.query, Code1_Parameters)
        except OSError as e:
            print(e)

    def Update_Footers(self, listofheaders):
        try:
            self.query = "UPDATE T_GeneralSettings SET Footer1 = '" + listofheaders[0] + "',Footer2 = '" + \
                         listofheaders[1] + "',Footer3 = '" + listofheaders[2] + "'"
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    def update_stamping_details(self, list_stamping_details):
        try:
            self.query = "UPDATE T_StampingDetails SET stamping_user = '" + list_stamping_details[
                0] + "',stamping_date = '" + \
                         list_stamping_details[1] + "',stamping_time = '" + list_stamping_details[
                             2] + "',stamping_image = '" + list_stamping_details[3] + "',status ='1' WHERE ID = '1'"
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    def get_stamping_details(self):
        try:
            query = "SELECT stamping_user,stamping_date,stamping_time,stamping_image,status FROM T_StampingDetails WHERE ID = '1'"
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def get_stamping_date(self):
        try:
            query = "SELECT stamping_date FROM T_StampingDetails WHERE status = '1'"
            return self.execute_select(query)
        except OSError as e:
            print(e)
