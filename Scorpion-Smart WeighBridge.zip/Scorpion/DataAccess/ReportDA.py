from DataAccess.BaseDA import BaseDA


class ReportDA(BaseDA):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.query = ""

    def get_headers_fields(self):
        try:
            self.query = ""
            self.query = "SELECT * FROM T_HeaderParameters WHERE f_ID = 1"
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_header_daily_data(self, header_name, from_date):
        try:
            self.query = ""
            self.query = "SELECT DISTINCT " + header_name + " FROM T_Entry WHERE ReportDate = '" + from_date + "'"
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_header_monthly_data(self, header_name, from_date, to_date):
        try:
            self.query = ""
            self.query = "SELECT DISTINCT " + header_name + " FROM T_Entry WHERE ReportDate BETWEEN '" + from_date + "' AND '" + to_date + "'  "
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_code_daily_data(self, code_name, from_date):
        try:
            self.query = ""
            self.query = "SELECT DISTINCT " + code_name + " FROM T_Entry WHERE ReportDate = '" + from_date + "' "
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_code_monthly_data(self, code_name, from_date, to_date):
        try:
            self.query = ""
            self.query = "SELECT DISTINCT " + code_name + " FROM T_Entry WHERE ReportDate BETWEEN '" + from_date + "' AND '" + to_date + "' "
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_codes_fields(self):
        try:
            self.query = ""
            self.query = "SELECT * FROM T_CodeParameters WHERE f_ID = 1 "
            return self.execute_select(self.query)
        except Exception as err:
            print(err)

    def get_daily_products(self, date, combobox_value, header_name):
        try:
            self.query = ""
            self.query = "SELECT SerialNo,ReportDate,ReportTime,header1,header2,header3,header4,Header5,code1_no," \
                         "code2_no,code3_no,code4_no,code5_no," \
                         "grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate = '" + date + "' AND " + header_name + "='" + combobox_value + "'"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def on_load_daily_products(self, date):
        try:
            self.query = ""
            self.query = "SELECT SerialNo,ReportDate,ReportTime,header1,header2,header3,header4,Header5,code1_no," \
                         "code2_no,code3_no,code4_no,code5_no," \
                         "grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate = '" + date + "' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def GetMonthlyProducts(self, date, header_name, combobox_value):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime,code1_no,code2_no,code3_no,code4_no,code5_no, " \
                         "header1,header2,header3,header4,header5,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND " + header_name + "='" + combobox_value + "' "
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetHeader1Data(self, date, header1):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND header1= '" + header1 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetHeader2Data(self, date, header2):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND header2= '" + header2 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetHeader3Data(self, date, header3):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND header3= '" + header3 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetHeader4Data(self, date, header4):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND header4= '" + header4 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetHeader5Data(self, date, header5):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime,code1_no,code2_no,code3_no,code4_no,code5_no, " \
                         "header1,header2,header3,header4,header5,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND header5= '" + header5 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetCode1Data(self, date, code1):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND code1_no= '" + code1 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetCode2Data(self, date, code2):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND code2_no= '" + code2 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetCode3Data(self, date, code3):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND code3_no= '" + code3 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetCode4Data(self, date, code4):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND code4_no= '" + code4 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def GetCode5Data(self, date, code5):
        try:
            self.query = "SELECT SerialNo,ReportDate,ReportTime, " \
                         "header1,header2,header3,header4,header5,code1_no,code2_no,code3_no,code4_no,code5_no,grossWt,tareWt,netWt,Amount,ReEntry_Amount,(Amount + ReEntry_Amount) AS TotalAmount FROM T_Entry WHERE " \
                         "ReportDate='" + date + "' AND code5_no= '" + code5 + "'"
            return self.execute_select(self.query)
            pass
        except OSError as e:
            print(e)
        pass

    def get_calibration_record(self):
        try:
            self.query = "SELECT UserId,UpdateDate,CAST(DecimalPoint AS INTEGER) AS DecimalPoint,Resolution,CalZero,CalSpan,CalCapacity,MaxCapacity,Unit FROM T_Calibration ORDER BY ID DESC"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def get_tare_record(self):
        try:
            self.query = "SELECT UserId,LastTaredDateTime,Unit FROM T_TareLog ORDER BY ID DESC"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)



