from DataAccess.BaseDA import BaseDA


class ParameterSettingsDA(BaseDA):
    def Get_Code(self):
        try:
            self.query = ""
            self.query = "SELECT f_Header1,f_Header2,f_Header3,f_Header4,f_Header5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_HeaderParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def Update_Headers(self, listCode):
        try:
            self.query = ""
            self.query = "UPDATE T_HeaderParameters SET f_Header1 = '" + listCode[0] + "',f_Header2 = '" + \
                         listCode[1] + "', f_Header3 = '" + listCode[2] + "', f_Header4 = '" + \
                         listCode[3] + "', f_Header5 = '" + listCode[4] + "', f_EnableEntry1 = '" + \
                         listCode[5] + "', f_EnableEntry2 = '" + listCode[6] + "', f_EnableEntry3 = '" + \
                         listCode[7] + "', f_EnableEntry4 = '" + listCode[8] + "', f_EnableEntry5 = '" + \
                         listCode[9] + "', f_EnableReEntry1 = '" + listCode[10] + "', f_EnableReEntry2 = '" + \
                         listCode[11] + "', f_EnableReEntry3 = '" + listCode[12] + "', f_EnableReEntry4 = '" + \
                         listCode[13] + "', f_EnableReEntry5 = '" + listCode[14] + "'WHERE f_ID =1"
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    def Get_Code_details(self):
        try:
            self.query = ""
            self.query = "SELECT f_Code1,f_Code2,f_Code3,f_Code4,f_Code5,f_EnableEntry1," \
                         "f_EnableEntry2,f_EnableEntry3,f_EnableEntry4,f_EnableEntry5,f_EnableReEntry1," \
                         "f_EnableReEntry2,f_EnableReEntry3,f_EnableReEntry4," \
                         "f_EnableReEntry5 FROM T_CodeParameters WHERE f_ID = '1' "
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def Update_Codes(self, listCode):
        try:
            self.query = ""
            self.query = "UPDATE T_CodeParameters SET f_Code1 = '" + listCode[0] + "',f_Code2 = '" + \
                         listCode[1] + "', f_Code3 = '" + listCode[2] + "', f_Code4 = '" + \
                         listCode[3] + "', f_Code5 = '" + listCode[4] + "', f_EnableEntry1 = '" + \
                         listCode[5] + "', f_EnableEntry2 = '" + listCode[6] + "', f_EnableEntry3 = '" + \
                         listCode[7] + "', f_EnableEntry4 = '" + listCode[8] + "', f_EnableEntry5 = '" + \
                         listCode[9] + "', f_EnableReEntry1 = '" + listCode[10] + "', f_EnableReEntry2 = '" + \
                         listCode[11] + "', f_EnableReEntry3 = '" + listCode[12] + "', f_EnableReEntry4 = '" + \
                         listCode[13] + "', f_EnableReEntry5 = '" + listCode[14] + "'WHERE f_ID =1"
            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    '''Code Details Entry logic'''

    def Add_Code_Parameters(self, Code1_Parameters, code_no):
        try:
            self.query = ""
            self.query = f'INSERT INTO T_Code{code_no} (f_Code{code_no}No,f_Code{code_no}Name) VALUES (?,?)'
            return self.execute_many(self.query, Code1_Parameters)
        except OSError as e:
            print(e)

    def get_Parameters(self, code_no):
        try:
            query = f'SELECT f_Code{code_no}No, f_Code{code_no}Name  FROM T_Code{code_no}'
            return self.execute_select(query)
        except OSError as e:
            print(e)

    def delete_Parameters(self, code1No, code_no):
        try:
            # query = "DELETE FROM T_Code1 WHERE f_Code1No='" + code1No + "'"
            query = f'DELETE FROM T_Code{code_no} WHERE f_Code{code_no}No= {code1No}'
            return self.execute_dml(query)
        except OSError as e:
            print(e)

    def Update_Parameters(self, code_parameters, code_no):
        try:
            self.query = ""
            self.query = "UPDATE T_Code" + code_no + " SET f_Code" + code_no + "No = '" + code_parameters[
                0] + "',f_Code" + code_no + "Name = '" + \
                         code_parameters[1] + "' WHERE f_Code" + code_no + "No = '" + code_parameters[2] + "' "

            return self.execute_dml(self.query)
        except OSError as e:
            print(e)

    def Get_Other_settings(self):
        try:
            self.query = ""
            self.query = "SELECT Status FROM T_OtherSettings"
            return self.execute_select(self.query)
        except OSError as e:
            print(e)

    def Save_ParameterOther_Settings(self, listOther):
        try:
            self.query = ""
            name = ["Amount", "DateTime", "GunnyBag", "Unit", "Display", "Manual Entry", "Manual Mode"]
            values = [listOther[0], listOther[1], listOther[2], listOther[3], "Code", listOther[4], listOther[5]]
            for i in range(len(name)):
                self.query = "UPDATE T_OtherSettings SET Status='" + values[i] + "' WHERE Name='" + name[i] + "'"
                self.execute_query(self.query)
            self.execute_close()
        except OSError as e:
            print(e)
