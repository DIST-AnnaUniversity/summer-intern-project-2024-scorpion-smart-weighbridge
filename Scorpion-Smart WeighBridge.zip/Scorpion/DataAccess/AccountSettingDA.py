from DataAccess.BaseDA import BaseDA


class AccountSettingDA(BaseDA):
    def fetch_selected_role_id(self, role_name):
        self.Query = "SELECT RoleId FROM T_UserRoles WHERE RoleName = '" + role_name + "' "
        return self.execute_select(self.Query)

    def fetch_selected_userID(self, user_name):
        query = "SELECT UserID FROM T_Users WHERE Name = '" + user_name + "'"
        return self.execute_select(query)

    def Update_AssignRoles(self, UserId, RoleId, date):
        self.query = "UPDATE T_Users SET RoleId = '" + RoleId + "',UpdateDate = '" + date + "' WHERE UserId ='" + UserId + "'"
        return self.execute_dml(self.query)