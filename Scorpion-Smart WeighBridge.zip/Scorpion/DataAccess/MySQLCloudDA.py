from DataAccess.MySQLBaseDA import MySQLBaseDA


class MySQLCloudDA(MySQLBaseDA):

    def insert_cloud_entry_details(self, param_tuple):
        try:
            query = "INSERT INTO t_vehicleentry (SerialNo," \
                    "Header1,Header2,Header3,Header4," \
                    "Header5,Code1,Code2,Code3," \
                    "Code4,Code5,Code1_Value,Code2_Value,Code3_Value,Code4_Value,Code5_Value,GrossWt,GrossUnit," \
                    "GrossDate,TareWt,TareUnit,TareDate,Amount,NetWt," \
                    "ReportDate,ReportTime,CustCode,DeviceId) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            return self.execute_many(query, param_tuple)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_gunny_entry_details(self, param_tuple):
        try:
            query = "INSERT INTO t_vehicleentry (SerialNo," \
                    "Header1,Header2,Header3,Header4," \
                    "Header5,Code1,Code2,Code3," \
                    "Code4,Code5,Code1_Value,Code2_Value,Code3_Value,Code4_Value,Code5_Value,GrossWt,GrossUnit," \
                    "GrossDate,TareWt,TareUnit,TareDate,Amount,NetWt," \
                    "ReportDate,ReportTime,BagWeight,BagQuantity,CustCode,DeviceId" \
                    ") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            return self.execute_many(query, param_tuple)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_from_local_details(self, param_tuple):
        try:
            query = "INSERT INTO t_vehicleentry (SerialNo," \
                     "Header1,Header2,Header3,Header4," \
                    "Header5,Code1,Code2,Code3," \
                    "Code4,Code5,Code1_Value,Code2_Value,Code3_Value,Code4_Value,Code5_Value,GrossWt,GrossUnit," \
                    "GrossDate,TareWt,TareUnit,TareDate,Amount,NetWt," \
                    "ReportDate,ReportTime,BagWeight,BagQuantity," \
                    "ReEntry_Amount,CustCode,DeviceId" \
                    ") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            return self.execute_many(query, param_tuple)
            pass
        except Exception as e:
            print(e)

    def update_cloud_from_local_details(self, param_tuple):
        try:
            query = "UPDATE t_vehicleentry SET SerialNo = '" + param_tuple[0] + "',Header1 = '"+param_tuple[1]+"',Header2 = '"+param_tuple[2]+"',Header3 = '"+param_tuple[3]+"',Header4 = '"+param_tuple[4]+"',Header5 = '"+param_tuple[5]+"',Code1 = '"+param_tuple[6]+"',Code2 = '"+param_tuple[7]+"',Code3 = '"+param_tuple[8]+"',Code4 = '"+param_tuple[9]+"',Code5 = '"+param_tuple[10]+"'" \
                     ",Code1_Value = '"+param_tuple[11]+"',Code2_Value = '"+param_tuple[12]+"',Code3_Value = '"+param_tuple[13]+"',Code4_Value = '"+param_tuple[14]+"',Code5_Value = '"+param_tuple[15]+"',GrossWt = '"+param_tuple[16]+"',GrossUnit = '"+param_tuple[17]+"',GrossDate = '"+param_tuple[18]+"',TareWt = '"+param_tuple[19]+"',TareUnit = '"+param_tuple[20]+"',TareDate = '"+param_tuple[21]+"',Amount = '"+param_tuple[22]+"',NetWt = '"+param_tuple[23]+"', " \
                      "ReportDate = '"+param_tuple[24]+"', ReportTime = '"+param_tuple[25]+"',BagWeight = '"+param_tuple[26]+"',BagQuantity = '"+param_tuple[27]+"',ReEntry_Amount = '"+param_tuple[28]+"',CustCode = '"+param_tuple[29]+"',DeviceId = '"+param_tuple[30]+"' WHERE SerialNo =  = '"+param_tuple[0]+"'"
            return self.execute_query(query)
            pass
        except Exception as e:
            print(e)

    def validate_existing_data_cloud(self, serial_no):
        try:
            self.query = "SELECT COUNT(SerialNo) FROM t_vehicleentry WHERE SerialNo = '" + serial_no + "'"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def update_reentry_details_cloud(self, param):
        try:
            query = "UPDATE t_vehicleentry" \
                    " SET" \
                    " Header1 ='" + param.Field1 + "'" \
                    " ,Header2 ='" + param.Field2 + "'" \
                    " ,Header3 ='" + param.Field3 + "'" \
                    " ,Header4 ='" + param.Field4 + "'" \
                    " ,Header5 ='" + param.Field5 + "'" \
                    " ,Code1 ='" + param.Code1 + "'" \
                    " ,Code2 ='" + param.Code2 + "'" \
                    " ,Code3 ='" + param.Code3 + "'" \
                    " ,Code4 ='" + param.Code4 + "'" \
                    " ,Code5 ='" + param.Code5 + "'" \
                    " ,Code1_Value ='" + param.code1_value + "'" \
                    " ,Code2_Value ='" + param.code2_value + "'" \
                    " ,Code3_Value ='" + param.code3_value + "'" \
                    " ,Code4_Value ='" + param.code4_value + "'" \
                    " ,Code5_Value ='" + param.code5_value + "'" \
                    " ,GrossWt ='" + param.GrossWt + "'" \
                    " ,GrossDate ='" + param.GrossDate + "'" \
                    " ,TareWt ='" + param.TareWt + "'" \
                    " ,TareDate ='" + param.TareDate + "'" \
                    " ,ReEntry_Amount ='" + param.Amount + "'" \
                    " ,NetWt ='" + param.NetWt + "'" \
                    ",ReportDate ='" + param.report_date + "'" \
                    ",ReportTime ='" + param.report_time + "'" \
                    " WHERE SerialNo = '" + param.SerialNo + "'"
            return self.execute_dml(query)
        except Exception as e:
            print(e)