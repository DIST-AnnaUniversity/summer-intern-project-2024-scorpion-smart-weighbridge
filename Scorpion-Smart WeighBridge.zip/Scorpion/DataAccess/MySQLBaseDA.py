import mysql.connector

from BusinessLogic.CloudStorageBL import CloudStorageBL


class MySQLBaseDA:
    def __init__(self, parent=None):
        # Establish a connection to MySQL server
        self.curs_obj = None
        self.password = None
        self.database_name = None
        self.host_name = None
        self.user_name = None
        self.connection = None
        self.result = []

    def setup_connection(self):
        try:
            if self.connection is None:
                cloud_storage_records = CloudStorageBL().get_cloud_storage_bl()
                if cloud_storage_records:
                    self.user_name = str(cloud_storage_records[0])
                    self.host_name = str(cloud_storage_records[4])
                    self.database_name = str(cloud_storage_records[5])
                    self.password = str(cloud_storage_records[6])

                    self.connection = mysql.connector.connect(
                        host=self.host_name,
                        user=self.user_name,
                        password=self.password,
                        database=self.database_name
                    )
                    self.curs_obj = self.connection.cursor()
                else:
                    raise ValueError("No cloud storage records found.")
        except Exception as e:
            print(e)

    def execute_select(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchall()
            self.connection.commit()
            self.connection.close()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_dml(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.connection.commit()
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_query(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.connection.commit()
        except OSError as DB_err:
            print(DB_err)

    def execute_close(self):
        try:
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_many(self, query, value):
        try:
            self.setup_connection()
            self.curs_obj.execute(query, value)
            self.connection.commit()
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_selectone(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchone()
            self.connection.commit()
            self.connection.close()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_select_many(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchall()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_select_many_params(self, query, params):
        try:
            self.setup_connection()
            self.curs_obj.execute(query, params)
            self.result = self.curs_obj.fetchall()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_many_Value(self, query):
        try:
            self.setup_connection()
            self.curs_obj.execute(query)
            self.connection.commit()
        except OSError as DB_err:
            print(DB_err)
