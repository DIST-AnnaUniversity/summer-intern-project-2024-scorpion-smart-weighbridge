from DataAccess.BaseDA import BaseDA


class AppConfigDA(BaseDA):

    def fetch_app_config(self):
        try:
            self.query = "SELECT auto_zero,power_on_tare FROM T_AppConfig WHERE Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def fetch_app_config_count(self):
        try:
            self.query = "SELECT COUNT(Id) FROM T_AppConfig WHERE Id = 1"
            return self.execute_select(self.query)
            pass
        except Exception as e:
            print(e)

    def save_app_config(self, app_config):
        try:
            self.query = "INSERT INTO T_AppConfig (auto_zero,moving_average,adc_filter) VALUES (?,?,?)"
            return self.execute_many(self.query, app_config)
            pass
        except Exception as e:
            print(e)

    def update_app_config(self, app_config):
        try:
            self.query = "UPDATE T_AppConfig SET auto_zero = '" + app_config[0] + "',moving_average = '" + app_config[
                1] + "',adc_filter = '" + app_config[2] + "' "
            return self.execute_query(self.query)
            pass
        except Exception as e:
            print(e)
