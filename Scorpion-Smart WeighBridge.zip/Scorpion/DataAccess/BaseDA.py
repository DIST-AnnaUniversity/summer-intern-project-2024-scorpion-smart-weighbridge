import os
import sqlite3
from pathlib import Path
class BaseDA:
    DATABASE_PATH = os.path.join(Path(__file__).parent.parent, "AppData"
                                                               "/Database"
                                                               "/WeighBridge"
                                                               ".db")

    def __init__(self, parent=None):
        self.connection = sqlite3.connect(self.DATABASE_PATH)
        self.curs_obj = self.connection.cursor()
        self.result = []

    def execute_select(self, query, params=None):
        try:
            if params:
                self.curs_obj.execute(query, params)
            else:
                self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchall()
            self.connection.commit()
            self.connection.close()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_dml(self, query, params=None):
        try:
            if params:
                self.curs_obj.execute(query, params)
            else:
                self.curs_obj.execute(query)
            self.connection.commit()
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_query(self, query):
        try:
            self.curs_obj.execute(query)
            self.connection.commit()
        except OSError as DB_err:
            print(DB_err)

    def execute_close(self):
        try:
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_many(self, query, value):
        try:
            self.curs_obj.execute(query, value)
            self.connection.commit()
            self.connection.close()
        except OSError as DB_err:
            print(DB_err)

    def execute_selectone(self, query):
        try:
            self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchone()
            self.connection.commit()
            self.connection.close()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_select_many(self, query):
        try:
            self.curs_obj.execute(query)
            self.result = self.curs_obj.fetchall()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_select_many_params(self, query, params):
        try:
            self.curs_obj.execute(query, params)
            self.result = self.curs_obj.fetchall()
            return self.result
        except OSError as DB_err:
            print(DB_err)

    def execute_many_Value(self, query):
        try:
            self.curs_obj.execute(query)
            self.connection.commit()
        except OSError as DB_err:
            print(DB_err)
