from BusinessLogic.BaseBL import BaseBL
from DataAccess.MainScreenDA import MainScreenDA


class MainScreenBL(BaseBL):
    # def get_entry_details(self, header, field):
    #     return MainScreenDA(self).get_entry_details(header, field)

    # def get_name_by_type(self, type):
    #     return MainScreenDA(self).get_name_by_type(type)

    def get_code_name(self, f, s):
        return MainScreenDA(self).get_code_name(f, s)

    def get_header_name(self, f, s):
        return MainScreenDA(self).get_header_name(f, s)

    def get_entry_details(self):
        try:
            return MainScreenDA(self).get_entry_details()
        except Exception as e:
            print(e)

    def get_selected_filters(self, column_name):
        try:
            self.filters = []
            self.result = MainScreenDA().get_selected_filters(column_name)
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.filters.append(str(data))
            return self.filters
            pass
        except Exception as e:
            print(e)
            return self.filters

    def get_selected_product_details(self, column_name, column_value):
        try:
            self.selected_items = []
            self.result = MainScreenDA().get_selected_product_details(column_name,column_value)
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.selected_items.append(str(data))
            return self.selected_items
            pass
        except Exception as e:
            print(e)
            return self.selected_items

    def get_users(self):
        try:
            self.users = []
            self.result = MainScreenDA().get_user_names()
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.users.append(str(data))
            return self.users
            pass
        except Exception as e:
            print(e)
            return self.users

    def update_new_password(self,user_name,password):
        try:
            return MainScreenDA().update_password(user_name,password)
        except Exception as e:
            print(e)

    def insert_tare_log(self, list_values):
        try:
            return MainScreenDA(self).insert_tare_log(list_values)
        except Exception as e:
            print(e)
            return 0

    def delete_record_from_tare_log(self):
        try:
            MainScreenDA().delete_top_record_from_tare_log()
        except Exception as e:
            print(e)

    def fetch_tare_log_count(self):
        try:
            self.Result = MainScreenDA().fetch_tare_log_count()
            for row_number, row_data in enumerate(self.Result):
                for column_number, column_data in enumerate(row_data):
                    if not column_data is None and not str(column_number) == "":
                        return column_data
                    else:
                        return 0
            return 0
        except Exception as e:
            print(e)
            return 0

    def set_tare_status_inactive(self):
        try:
            MainScreenDA().set_tare_status_inactive()
            pass
        except Exception as e:
            print(e)

    def get_camera_status(self):
        try:
            self.Result = MainScreenDA().get_camera_status()
            for row_number, row_data in enumerate(self.Result):
                for column_number, column_data in enumerate(row_data):
                    if not column_data is None and not str(column_number) == "":
                        return column_data
                    else:
                        return 0
            return 0
        except Exception as e:
            print(e)
            return 0

    def get_bill_data(self, index):
        try:
            self.bill_data = []
            self.result = MainScreenDA().get_bill_data(index)
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.bill_data.append(str(data))
            return self.bill_data
            pass
        except Exception as e:
            print(e)
            return self.bill_data



