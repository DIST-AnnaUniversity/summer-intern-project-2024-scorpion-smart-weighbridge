from BusinessLogic.BaseBL import BaseBL
from DataAccess.MySQLCloudDA import MySQLCloudDA


class MySQLCloudBL(BaseBL):
    def insert_cloud_entry_details(self, param_tuple):
        try:
            return MySQLCloudDA().insert_cloud_entry_details(param_tuple)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_gunny_entry_details(self, param_tuple):
        try:
            return MySQLCloudDA().insert_cloud_gunny_entry_details(param_tuple)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_from_local_details(self, param_tuple):
        try:
            if MySQLCloudBL().validate_existing_data_cloud(param_tuple[0]) == "0":
                return MySQLCloudDA().insert_cloud_from_local_details(param_tuple)
            else:
                return MySQLCloudDA().update_cloud_from_local_details(param_tuple)
            pass
        except Exception as e:
            print(e)

    def validate_existing_data_cloud(self, serial_no):
        try:
            self.result_count = "0"
            self.result = MySQLCloudDA().validate_existing_data_cloud(str(serial_no))
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.result_count = str(data)
            return self.result_count
            pass
        except Exception as e:
            print(e)
            return self.result_count

    def update_re_entry_cloud_details(self,params):
        try:
            return MySQLCloudDA().update_reentry_details_cloud(params)
            pass
        except Exception as e:
            print(e)
