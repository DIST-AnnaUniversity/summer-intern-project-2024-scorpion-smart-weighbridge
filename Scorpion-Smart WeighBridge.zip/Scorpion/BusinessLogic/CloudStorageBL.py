from BusinessLogic.BaseBL import BaseBL
from DataAccess.CloudStorageDA import CloudStorageDA


class CloudStorageBL(BaseBL):
    def get_cloud_storage_bl(self):
        try:
            lst_cloud_storage_details = []
            for row_number, row_data in enumerate(CloudStorageDA(self).get_cloud_storage_da()):
                for data in row_data:
                    lst_cloud_storage_details.append(str(data))
            return lst_cloud_storage_details
        except Exception as e:
            print(e)

    def get_app_features_status(self, feature_name):
        try:
            self.status = "0"
            self.result = CloudStorageDA().get_app_fetaures_status(feature_name)
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.status = str(data)
            return self.status
            pass
        except Exception as e:
            print(e)
            return self.status

    def insert_entry_details_cloud(self, par1_tuple):
        try:
            CloudStorageDA(self).insert_entry_details_cloud(par1_tuple)
        except Exception as e:
            print(e)

    def insert_entry_gunnydetails_cloud(self, par1_tuple):
        try:
            CloudStorageDA(self).insert_entry_gunnydetails_cloud(par1_tuple)
        except Exception as e:
            print(e)

    def get_cloud_storage_report_count(self):
        try:
            self.report_count = 0
            self.result = CloudStorageDA().get_cloud_storage_report_count()
            if self.result is not None:
                for row_count, row_data in enumerate(self.result):
                    for column_count, data in enumerate(row_data):
                        self.report_count = int(data)
            return self.report_count
            pass
        except Exception as e:
            print(e)

    def delete_cloud_local_storage(self):
        try:
            return CloudStorageDA().delete_cloud_storage_report()
            pass
        except Exception as e:
            print(e)

    def get_cloud_local_storage(self):
        try:
            return CloudStorageDA().get_cloud_local_storage()
            pass
        except Exception as e:
            print(e)

    def get_cloud_storage_local_count(self, serial_no):
        try:
            self.result_count = "0"
            self.result = CloudStorageDA().get_cloud_storage_count(serial_no)
            for row_count, row_data in enumerate(self.result):
                for column_count, data in enumerate(row_data):
                    self.result_count = str(data)
            return self.result_count
            pass
        except Exception as e:
            print(e)
            return self.result_count

    def update_re_entry_cloud_storage(self, param):
        try:
            if CloudStorageBL().get_cloud_storage_local_count(param.SerialNo) == "0":
                return CloudStorageDA().insert_reentry_details_local(param)
            else:
                return CloudStorageDA().update_reentry_details_local(param)
            pass
        except Exception as e:
            print(e)
