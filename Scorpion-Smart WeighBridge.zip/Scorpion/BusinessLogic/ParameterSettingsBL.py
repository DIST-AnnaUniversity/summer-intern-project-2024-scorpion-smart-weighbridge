from BusinessLogic.BaseBL import BaseBL
from DataAccess.ParameterSettingsDA import ParameterSettingsDA


class ParameterSettingsBL(BaseBL):

    def Get_Code(self):
        self.lst_Code_Parameter = []
        for row_number, row_data in enumerate(ParameterSettingsDA(self).Get_Code()):
            for column_number, data in enumerate(row_data):
                self.lst_Code_Parameter.append(str(data))
        return self.lst_Code_Parameter

    def Update_Headers(self, listCode):
        return ParameterSettingsDA(self).Update_Headers(listCode)
        pass

    def Get_Code_details(self):
        self.lst_Code_Parameter = []
        for row_number, row_data in enumerate(ParameterSettingsDA(self).Get_Code_details()):
            for column_number, data in enumerate(row_data):
                self.lst_Code_Parameter.append(str(data))
        return self.lst_Code_Parameter

    def Update_Codes(self, listCode):
        return ParameterSettingsDA(self).Update_Codes(listCode)
        pass

    def Add_Code1_Parameters(self, Code1_Parameters, code_no):
        return ParameterSettingsDA(self).Add_Code_Parameters(Code1_Parameters, code_no)
        pass

    def get_Parameters(self, code_no):
        return ParameterSettingsDA(self).get_Parameters(code_no)

    def delete_Parameters(self, code1No, code_no):
        return ParameterSettingsDA(self).delete_Parameters(code1No, code_no)

    def update_Parameters(self,code_parameters, code_no):
        return ParameterSettingsDA(self).Update_Parameters(code_parameters, code_no)

    def Get_Other_settings(self):
        try:
            self.FetchOther = []
            for row_number, row_data in enumerate(ParameterSettingsDA(self).Get_Other_settings()):
                for column_number, data in enumerate(row_data):
                    self.FetchOther.append(str(data))
            return self.FetchOther
        except Exception as e:
            print(e)
            return self.FetchOther

    def Save_ParameterOther_Settings(self, listOther):
        return ParameterSettingsDA(self).Save_ParameterOther_Settings(listOther)
        pass
