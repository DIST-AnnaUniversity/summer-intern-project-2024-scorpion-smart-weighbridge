from BusinessLogic.BaseBL import BaseBL
from DataAccess.AccountSettingDA import AccountSettingDA


class AccountSettingBL(BaseBL):

    def fetch_selected_roles(self, role_name):
        try:
            self.role_id = ""
            self.result = AccountSettingDA().fetch_selected_role_id(role_name)
            for row_number, row_data in enumerate(self.result):
                for column_number, column_data in enumerate(row_data):
                    self.role_id = str(column_data)
            return self.role_id
            pass
        except Exception as e:
            print(e)
            return self.role_id

    def fetch_selected_userID(self, role):
        Result = AccountSettingDA(self).fetch_selected_userID(role)
        for data in Result:
            for self.tempresult_data in data:
                result_data = str(self.tempresult_data)
        return result_data

    def Update_AssignRoles(self, UserId, RoleId, date):
        return AccountSettingDA(self).Update_AssignRoles(UserId, RoleId, date)
