from BusinessLogic.BaseBL import BaseBL
from DataAccess.GeneralSettingsDA import GeneralSettingsDA


class GeneralSettingsBL(BaseBL):

    def Save_Region(self, region, continent):
        return GeneralSettingsDA(self).Save_Region(continent, region)

    def Update_Region(self, region, continent):
        return GeneralSettingsDA(self).Update_Region(region, continent)

    def save_date_time(self, date, time):
        return GeneralSettingsDA(self).save_date_time(date, time)

    def update_manual_entry(self, date, time):
        return GeneralSettingsDA(self).update_manual_entry(date, time)

    def GetSavedRegion(self):
        return GeneralSettingsDA(self).GetSavedRegion()

    def Get_GeneralSettings_Count(self):
        getCount = "0"
        for row_number, row_data in enumerate(GeneralSettingsDA(self).Get_GeneralSettings_Count()):
            for column_number, data in enumerate(row_data):
                getCount = str(data)
        return getCount
        pass

    def get_Parameters(self):
        list_parameters = []
        for row_number, row_data in enumerate(GeneralSettingsDA(self).get_Parameters()):
            for data in row_data:
                list_parameters.append(str(data))

        return list_parameters

    def Save_Headers(self, Insert_Header_Details):
        return GeneralSettingsDA(self).Save_Headers(Insert_Header_Details)
        pass

    def Update_Headers(self, listofheaders):
        return GeneralSettingsDA(self).Update_Headers(listofheaders)
        pass

    def get_footer_Parameters(self):
        list_parameters = []
        for row_number, row_data in enumerate(GeneralSettingsDA(self).get_footer_Parameters()):
            for data in row_data:
                list_parameters.append(str(data))

        return list_parameters

    def Save_Footer(self, Insert_Header_Details):
        return GeneralSettingsDA(self).Save_Footers(Insert_Header_Details)
        pass

    def Update_Footer(self, listofheaders):
        return GeneralSettingsDA(self).Update_Footers(listofheaders)
        pass

    def update_stamping_details(self, list_stamping_details):
        try:
            return GeneralSettingsDA(self).update_stamping_details(list_stamping_details)
        except Exception as e:
            print(e)

    def get_stamping_details(self):
        try:
            list_stamping_details = []
            for row_number, row_data in enumerate(GeneralSettingsDA(self).get_stamping_details()):
                for data in row_data:
                    list_stamping_details.append(str(data))
            return list_stamping_details
        except Exception as e:
            print(e)

    def get_stamping_date(self):
        try:
            stamping_date = ""
            for row_number, row_data in enumerate(GeneralSettingsDA(self).get_stamping_date()):
                for data in row_data:
                    stamping_date = (str(data))
            return stamping_date
        except Exception as e:
            print(e)
