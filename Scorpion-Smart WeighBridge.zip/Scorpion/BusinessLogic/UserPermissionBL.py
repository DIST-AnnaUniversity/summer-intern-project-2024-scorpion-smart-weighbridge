from BusinessLogic.BaseBL import BaseBL
from DataAccess.UserPermissionDA import UserPermissionDA


class UserPermissionBL(BaseBL):
    def InsertUserRoles(self, UserRole):
        return UserPermissionDA().InsertUserRoles(UserRole)


    def FetchUserRoleStatus(self, UserRole):
        self.Result = UserPermissionDA().FetchUserStatus(UserRole)
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                return column_data

    def InsertUserAccessStatus(self, dictUserAccess):
        return UserPermissionDA().SaveUserPermissionSettings(dictUserAccess)

    def UpdateUserPermissionSettings(self, dictUserAccess):
        return UserPermissionDA().UpdateUserPermissionSettings(dictUserAccess)

    def GetUserRoleId(self, UserRole):
        self.Result = UserPermissionDA().GetUserRoleID(UserRole)
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                return str(column_data)

    def FetchAvailableRoles(self):
        self.lstAvailableRoles = []
        self.Result = UserPermissionDA().FetchAvailableRoles()
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                if not row_number == 0:
                    self.lstAvailableRoles.append(column_data)
        return self.lstAvailableRoles

    def FetchMaximumCustomRoleCount(self):
        self.Result = UserPermissionDA().FetchMaximumCustomRoleCount()
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                return column_data

    def FetchSelectedRoleStatus(self, RoleName):
        self.lstRoleStatus = []
        self.Result = UserPermissionDA().FetchSelectedRoleStatus(RoleName)
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                self.lstRoleStatus.append(str(column_data))
        return self.lstRoleStatus

    def FetchActiveUserDetails(self):
        try:
            self.lstUserDetails = []
            self.Result = UserPermissionDA().FetchActiveUserDetails()
            for row_number, row_data in enumerate(self.Result):
                for column_number, column_data in enumerate(row_data):
                    self.lstUserDetails.append(str(column_data))
            return self.lstUserDetails
            pass
        except Exception as e:
            print(e)
            return self.lstUserDetails

    def delete_selected_user_role(self, role_id):
        try:
            UserPermissionDA().delete_selected_user_role(role_id)
        except Exception as e:
            print(e)
            pass

    def delete_selected_user_permission(self, role_id):
        try:
            UserPermissionDA().delete_user_permission(role_id)
        except Exception as e:
            print(e)

    def Update_Role_ID(self, RoleId):
        try:
            return UserPermissionDA().Update_Role_ID(RoleId)
        except Exception as e:
            print(e)
