from BusinessLogic.BaseBL import BaseBL
from DataAccess.SystemConfigDA import SystemConfigDA


class SystemConfigBL(BaseBL):

    def update_com_port(self, port_no):
        try:
            pass
        except Exception as e:
            print(e)

    def update_com_baudrates(self, baud_rates):
        try:
            for index in range(len(baud_rates)):
                SystemConfigDA().update_com_baudrates(baud_rates[index], str(index + 1))
            pass
        except Exception as e:
            print(e)

    def get_configured_baud_rates(self):
        try:
            self.baud_rates = []
            self.result = SystemConfigDA().get_configured_baudrates()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for data in row_data:
                        self.baud_rates.append(str(data))
            return self.baud_rates
            pass
        except Exception as e:
            print(e)
            return self.baud_rates

    def get_printer_port(self):
        try:
            self.baud_rates = []
            self.result = SystemConfigDA().get_printer_port()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for data in row_data:
                        self.baud_rates.append(str(data))
            return self.baud_rates
            pass
        except Exception as e:
            print(e)
            return self.baud_rates

    def get_remote_protocol_port(self):
        try:
            self.baud_rates = []
            self.result = SystemConfigDA().get_remote_protocol_port()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for data in row_data:
                        self.baud_rates.append(str(data))
            return self.baud_rates
            pass
        except Exception as e:
            print(e)
            return self.baud_rates

    def update_printer_port(self, column_name, port_no):
        try:
            return SystemConfigDA().update_printer_comport(column_name, port_no)
            pass
        except Exception as e:
            print(e)

    def get_printer_configuration(self):
        try:
            self.print_configurations = []
            self.result = SystemConfigDA().get_print_configurations()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for column_number, column_data in enumerate(row_data):
                        self.print_configurations.append(column_data)
            return self.print_configurations
        except Exception as e:
            print(e)
            return self.print_configurations

    def get_print_config_count(self):
        try:
            getCount = "0"
            self.result = SystemConfigDA().get_print_configutation_count()
            for row_number, row_data in enumerate(self.result):
                for column_number, data in enumerate(row_data):
                    getCount = str(data)
            return getCount
            pass
        except Exception as e:
            print(e)
            return getCount

    def update_print_config(self, print_config):
        try:
            return SystemConfigDA().update_print_configurations(print_config)
            pass
        except Exception as e:
            print(e)

    def insert_print_config(self, print_config):
        try:
            return SystemConfigDA().insert_print_configurations(print_config)
            pass
        except Exception as e:
            print(e)

    def Save_Params(self, listValues):
        try:
            return SystemConfigDA(self).Save_Params(listValues)
        except Exception as e:
            print(e)
            return 0

    def delete_record_from_calibration(self):
        try:
            SystemConfigDA().delete_top_record_from_calibration()
        except Exception as e:
            print(e)

    def fetch_calibration_count(self):
        try:
            self.Result = SystemConfigDA().fetch_calibration_count()
            for row_number, row_data in enumerate(self.Result):
                for column_number, column_data in enumerate(row_data):
                    if not column_data is None and not str(column_number) == "":
                        return column_data
                    else:
                        return 0
            return 0
        except Exception as e:
            print(e)
            return 0

    def set_data_as_inactive(self):
        try:
            SystemConfigDA().set_data_as_inactive()
            pass
        except Exception as e:
            print(e)

    def get_Activated_Profile_info(self):
        try:
            list_parameters = []
            for row_number, row_data in enumerate(SystemConfigDA(self).get_Activated_Profile_info()):
                for data in row_data:
                    list_parameters.append(str(data))
            return list_parameters
        except Exception as e:
            print(e)
            return list_parameters

    def get_DateTime(self):
        try:
            getDetails = []
            for row_number, row_data in enumerate(SystemConfigDA(self).get_DateTime()):
                for column_number, data in enumerate(row_data):
                    getDetails.append(str(data))
            return getDetails
        except Exception as e:
            print(e)
            return getDetails

    def get_active_resolution(self):
        try:
            return_resolution = ""
            for row_number, row_data in enumerate(SystemConfigDA(self).get_active_resolution()):
                for column_number, data in enumerate(row_data):
                    return_resolution = str(data)
            return return_resolution
        except Exception as e:
            print(e)
            return return_resolution

    ''' Ethernet+camera BL'''

    def get_camera_status(self):
        try:
            self.Result = SystemConfigDA().get_camera_status()
            for row_number, row_data in enumerate(self.Result):
                for column_number, column_data in enumerate(row_data):
                    if column_data is not None and str(column_number) != "":
                        return column_data
                    else:
                        return 0
            return 0
        except Exception as e:
            print(e)
            return 0

    def get_Ethernet(self, index):
        ethernet_list = []
        try:
            for row_number, row_data in enumerate(SystemConfigDA().get_Ethernet(index)):
                for data in row_data:
                    ethernet_list.append(str(data))
            print(ethernet_list)
            return ethernet_list
        except OSError as e:
            print(e)
            return ethernet_list

    def Get_ethernet_Count(self):
        getCount = "0"
        try:
            for row_number, row_data in enumerate(SystemConfigDA().Get_ethernet_Count()):
                for column_number, data in enumerate(row_data):
                    getCount = str(data)
            return getCount
        except OSError as e:
            print(e)
            return getCount

    def Save_Ethernet(self, ethernet_details, index):
        try:
            return SystemConfigDA().Save_Ethernet(ethernet_details, index)
        except OSError as e:
            print(e)

    def Update_Ethernet(self, ethernet_details, index):
        try:
            return SystemConfigDA().Update_Ethernet(ethernet_details, index)
        except OSError as e:
            print(e)

    def Update_url(self, ethernet_details, index):
        try:
            return SystemConfigDA().Update_url(ethernet_details, index)
        except OSError as e:
            print(e)

    def get_camera_Quantity(self):
        getCount = "0"
        try:
            for row_number, row_data in enumerate(SystemConfigDA().get_camera_Quantity()):
                for column_number, data in enumerate(row_data):
                    getCount = str(data)
            return getCount
        except OSError as e:
            print(e)
            return getCount

    def get_url1(self):
        try:
            getURL1 = " "
            for row_number, row_data in enumerate(SystemConfigDA().get_url1()):
                for column_number, data in enumerate(row_data):
                    getURL1 = str(data)
                    return getURL1

        except OSError as e:
            print(e)

    def get_url2(self):
        try:
            getURL2 = " "
            for row_number, row_data in enumerate(SystemConfigDA().get_url2()):
                for column_number, data in enumerate(row_data):
                    getURL2 = str(data)
            return getURL2
        except OSError as e:
            print(e)

    def get_url3(self):
        try:
            getURL3 = " "
            for row_number, row_data in enumerate(SystemConfigDA().get_url3()):
                for column_number, data in enumerate(row_data):
                    getURL3 = str(data)
            return getURL3
        except OSError as e:
            print(e)

    def get_url4(self):
        try:
            getURL4 = " "
            for row_number, row_data in enumerate(SystemConfigDA().get_url4()):
                for column_number, data in enumerate(row_data):
                    getURL4 = str(data)
            return getURL4
        except OSError as e:
            print(e)


    def save_camera_quantity(self, count):
        try:
            return SystemConfigDA().save_camera_Quantity(count)
        except OSError as e:
            print(e)

    def Update_Camera_Quantity(self, quantity):
        try:
            return SystemConfigDA().Update_Camera_Quantity(quantity)
        except OSError as e:
            print(e)



