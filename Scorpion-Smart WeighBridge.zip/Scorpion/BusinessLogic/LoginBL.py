import re

from BusinessLogic.BaseBL import BaseBL
from DataAccess.LoginDA import LoginDA


class LoginBL(BaseBL):
    def get_user_info(self, user):
        list_users = []
        for data in LoginDA(self).get_user_info(user):
            list_users = data
        return list_users

    def update_status(self):
        return LoginDA(self).update_status()

    def set_active_user(self, user):
        return LoginDA(self).set_active_user(user)

    def get_Activated_Profile_info(self):
        list_parameters = []
        for row_number, row_data in enumerate(LoginDA(self).get_Activated_Profile_info()):
            for data in row_data:
                list_parameters.append(str(data))
        return list_parameters

    def Set_Editted_Logo(self, Logo, Time):
        return LoginDA(self).Set_Editted_Logo(Logo, Time)
        pass

    def Set_Editted_Profile_info(self, Updated_ProfileDetails_List):
        return LoginDA(self).Set_Editted_Profile_info(Updated_ProfileDetails_List)
        pass

    def user_already_exist(self, user_data):
        username = user_data[0]
        getCount = ""
        for row_number, row_data in enumerate(LoginDA(self).user_already_exist(username)):
            for column_number, data in enumerate(row_data):
                getCount = str(data)
        print(getCount)
        return getCount

        # a = AccountSettingsDA(self).user_already_exist(username)
        # print(a)

    def CreateNewUser(self, list):
        print(list)
        regex = re.compile("[_!#$%^&*()<>?/}{~:]+")
        self.EmailId = ""
        self.EmailId = list[2]
        if len(list[0]) == 0 or len(list[1]) == 0 or len(list[2]) == 0 or len(list[3]) == 0 or len(
                list[4]) == 0 or len(list[5]) == 0 or len(list[5]) < 10 or not self.EmailId.__contains__(
            "@") or regex.search(
            self.EmailId) is not None:
            return 1
        elif list[3] != list[4]:
            return 2
        else:
            del list[4]
            print(list)
            LoginDA(self).CreateUser(list)
            return 3

    def FetchAvailableRoles(self):
        self.lstAvailableRoles = []
        self.Result = LoginDA().FetchAvailableRoles()
        for row_number, row_data in enumerate(self.Result):
            for column_number, column_data in enumerate(row_data):
                if not row_number == 0:
                    self.lstAvailableRoles.append(column_data)
        return self.lstAvailableRoles

    def get_Users(self):
        return LoginDA(self).Users()
    
    def set_Roles(self, result_data, status, UserID, Time):
        return LoginDA(self).set_Roles(result_data, status, UserID, Time)

    def Update_AssignRoles(self, UserId, RoleId, date):
        return LoginDA(self).Update_AssignRoles(UserId, RoleId, date)

    def fetch_selected_roles(self, role_name):
        try:
            self.role_id = ""
            self.result = LoginDA().fetch_selected_role_id(role_name)
            for row_number, row_data in enumerate(self.result):
                for column_number, column_data in enumerate(row_data):
                    self.role_id = str(column_data)
            return self.role_id
            pass
        except Exception as e:
            print(e)
            return self.role_id
        finally:
            pass

    def fetch_selected_userID(self, role):
        Result = LoginDA(self).fetch_selected_userID(role)
        for data in Result:
            for self.tempresult_data in data:
                result_data = str(self.tempresult_data)
        return result_data
