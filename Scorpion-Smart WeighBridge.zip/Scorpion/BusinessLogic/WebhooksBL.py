from BusinessLogic.BaseBL import BaseBL
from DataAccess.WebhooksDA import WebhooksDA


class WebhooksBL(BaseBL):
    def get_cloud_storage_data(self):
        try:
            self.app_config = []
            self.result = WebhooksDA().get_cloud_storage_data()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for data in row_data:
                        self.app_config.append(str(data))
            return self.app_config
            pass
        except Exception as e:
            print(e)

    def get_cloud_storage_count(self):
        try:
            getCount = "0"
            self.result = WebhooksDA().get_cloud_storage_count()
            for row_number, row_data in enumerate(self.result):
                for column_number, data in enumerate(row_data):
                    getCount = str(data)
            return getCount
            pass
        except Exception as e:
            print(e)

    def update_cloud_storage_data(self,cloud_config):
        try:
            return WebhooksDA().update_cloud_storage_data(cloud_config)
            pass
        except Exception as e:
            print(e)

    def insert_cloud_storage_data(self,cloud_config):
        try:
            return WebhooksDA().insert_cloud_storage_data(cloud_config)
            pass
        except Exception as e:
            print(e)

    def delete_db_backup(self):
        try:
            WebhooksDA().delete_db_backup()
        except Exception as e:
            print(e)