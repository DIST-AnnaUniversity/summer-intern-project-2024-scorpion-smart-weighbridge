from BusinessLogic.BaseBL import BaseBL
from DataAccess.VehicleEntryDA import VehicleEntryDA


class VehicleEntryBL(BaseBL):
    def insert_entry_details(self, par1_tuple):
        try:
            VehicleEntryDA(self).insert_entry_details(par1_tuple)
        except Exception as e:
            print(e)

    def insert_entry_gunnydetails(self, par1_tuple):
        try:
            VehicleEntryDA(self).insert_entry_gunnydetails(par1_tuple)
        except Exception as e:
            print(e)


    def get_gunny_status(self):
        try:
            return VehicleEntryDA(self).get_gunny_status()
        except Exception as e:
            print(e)

    def get_code1(self):
        try:
            return VehicleEntryDA(self).get_code1()
        except Exception as e:
            print(e)

    def get_code2(self):
        try:
            return VehicleEntryDA(self).get_code2()
        except Exception as e:
            print(e)

    def get_code3(self):
        try:
            return VehicleEntryDA(self).get_code3()
        except Exception as e:
            print(e)

    def get_code4(self):
        try:
            return VehicleEntryDA(self).get_code4()
        except Exception as e:
            print(e)

    def get_code5(self):
        try:
            return VehicleEntryDA(self).get_code5()
        except Exception as e:
            print(e)

    def get_entry_count(self):
        try:
            return VehicleEntryDA(self).get_entry_count()
        except Exception as e:
            print(e)

    def get_code_and_header(self, ftype):
        try:
            return VehicleEntryDA(self).get_code_and_header(ftype)
        except Exception as e:
            print(e)

    def get_unit(self):
        try:
            return VehicleEntryDA(self).get_unit()
        except Exception as e:
            print(e)

    def Get_header(self):
        try:
            self.lst_Code_Parameter = []
            for row_number, row_data in enumerate(VehicleEntryDA(self).Get_header()):
                for column_number, data in enumerate(row_data):
                    self.lst_Code_Parameter.append(str(data))
            return self.lst_Code_Parameter
        except Exception as e:
            print(e)

    def Get_Code(self):
        try:
            self.lst_Code_Parameter = []
            for row_number, row_data in enumerate(VehicleEntryDA(self).Get_Code()):
                for column_number, data in enumerate(row_data):
                    self.lst_Code_Parameter.append(str(data))
            return self.lst_Code_Parameter
        except Exception as e:
            print(e)

    def get_entry_details(self):
        try:
            return VehicleEntryDA(self).get_entry_details()
        except Exception as e:
            print(e)

    def get_transaction_details(self, date):
        try:
            self.lst_transaction_details = []
            for row_number, row_data in enumerate(VehicleEntryDA(self).get_transaction_details(date)):
                for column_number, data in enumerate(row_data):
                    self.lst_transaction_details.append(str(data))
            return self.lst_transaction_details
        except Exception as e:
            print(e)

    def get_vehicle_numbers(self):
        try:
            self.lst_vehicle_numbers = []
            for row_number, row_data in enumerate(VehicleEntryDA(self).get_all_vehicles()):
                for column_number, data in enumerate(row_data):
                    self.lst_vehicle_numbers.append(str(data))
            return self.lst_vehicle_numbers
        except Exception as e:
            print(e)

    def update_transaction_details(self, list_details):
        try:
            return VehicleEntryDA(self).update_transaction_details(list_details)
        except Exception as e:
            print(e)

    def fetch_transaction_details_param(self):
        try:
            self.lst_transaction_details = []
            for row_number, row_data in enumerate(VehicleEntryDA(self).fetch_transaction_details_param()):
                for column_number, data in enumerate(row_data):
                    self.lst_transaction_details.append(str(data))
            return self.lst_transaction_details
        except Exception as e:
            print(e)
