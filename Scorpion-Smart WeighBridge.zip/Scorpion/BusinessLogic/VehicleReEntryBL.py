from BusinessLogic.BaseBL import BaseBL
from DataAccess.VehicleReEntryDA import VehicleReEntryDA


class VehicleReEntryBL(BaseBL):

    def get_all_entries(self):
        try:
            self.SerialNo = []
            for row_number, row_data in enumerate(VehicleReEntryDA(self).get_all_entries()):
                for column_number, data in enumerate(row_data):
                    self.SerialNo.append(str(data))
            return self.SerialNo
        except Exception as e:
            print(e)

    def get_all_vehicles(self):
        try:
            return VehicleReEntryDA(self).get_all_vehicles()
        except Exception as e:
            print(e)



    def get_selected_entries(self, entry_id):
        try:
            return VehicleReEntryDA(self).get_selected_entries(entry_id)
        except Exception as e:
            print(e)

    def get_selected_vehicle(self, vehicle_no):
        try:
            return VehicleReEntryDA(self).get_selected_vehicle(vehicle_no)
        except Exception as e:
            print(e)

    def update_entry_details(self, model):
        try:
            VehicleReEntryDA(self).update_entry_details(model)
        except Exception as e:
            print(e)

    def get_code_and_header(self, ftype):
        try:
            return VehicleReEntryDA(self).get_code_and_header(ftype)
        except Exception as e:
            print(e)

    def get_other_settings(self, ftype):
        try:
            return VehicleReEntryDA(self).get_other_settings(ftype)
        except Exception as e:
            print(e)

    def get_code1name(self, param):
        try:
            return VehicleReEntryDA(self).get_code1name(param)
        except Exception as e:
            print(e)

    def get_code2name(self, param):
        try:
            return VehicleReEntryDA(self).get_code2name(param)
        except Exception as e:
            print(e)

    def get_code3name(self, param):
        try:
            return VehicleReEntryDA(self).get_code3name(param)
        except Exception as e:
            print(e)

    def get_code4name(self, param):
        try:
            return VehicleReEntryDA(self).get_code4name(param)
        except Exception as e:
            print(e)

    def get_code5name(self, param):
        try:
            return VehicleReEntryDA(self).get_code5name(param)
        except Exception as e:
            print(e)

    def Get_Header(self):
        try:
            self.lst_Code_Parameter = []
            for row_number, row_data in enumerate(VehicleReEntryDA(self).Get_Header()):
                for column_number, data in enumerate(row_data):
                    self.lst_Code_Parameter.append(str(data))
            return self.lst_Code_Parameter
        except Exception as e:
            print(e)

    def get_code(self):
        try:
            self.lst_Code_Parameter = []
            for row_number, row_data in enumerate(VehicleReEntryDA(self).get_code()):
                for column_number, data in enumerate(row_data):
                    self.lst_Code_Parameter.append(str(data))
            return self.lst_Code_Parameter
        except Exception as e:
            print(e)

