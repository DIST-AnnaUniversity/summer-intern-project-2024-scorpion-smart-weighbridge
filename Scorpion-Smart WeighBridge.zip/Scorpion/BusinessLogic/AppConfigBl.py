from BusinessLogic.BaseBL import BaseBL
from DataAccess.AppConfigDA import AppConfigDA


class AppConfigBL(BaseBL):
    def fetch_app_config(self):
        try:
            self.app_config = []
            self.result = AppConfigDA().fetch_app_config()
            if self.result is not None:
                for row_number, row_data in enumerate(self.result):
                    for data in row_data:
                        self.app_config.append(str(data))
            return self.app_config
        except Exception as e:
            print(e)
            return self.app_config

    def fetch_app_config_count(self):
        try:
            getCount = "0"
            self.result = AppConfigDA().fetch_app_config_count()
            for row_number, row_data in enumerate(self.result):
                for column_number, data in enumerate(row_data):
                    getCount = str(data)
            return getCount
            pass
        except Exception as e:
            print(e)

    def save_app_config(self, app_config):
        try:
            return AppConfigDA().save_app_config(app_config)
            pass
        except Exception as e:
            print(e)

    def update_app_config(self,app_config):
        try:
            return AppConfigDA().update_app_config(app_config)
            pass
        except Exception as e:
            print(e)
