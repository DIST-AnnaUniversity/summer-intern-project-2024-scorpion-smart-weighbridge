class BaseBL:
    temp = ""
