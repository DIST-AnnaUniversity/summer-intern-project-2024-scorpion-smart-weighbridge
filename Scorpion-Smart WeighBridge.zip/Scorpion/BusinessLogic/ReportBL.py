from BusinessLogic.BaseBL import BaseBL
from DataAccess.ReportDA import ReportDA


class ReportBL(BaseBL):

    def __init__(self):
        self.lst_code = []
        self.lst_header = []

    def get_headers_fields(self):
        try:
            self.lst_header.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_headers_fields()):
                for column_number, data in enumerate(row_data):
                    self.lst_header.append(str(data))
            return self.lst_header
        except Exception as err:
            print(err)

    def get_header_daily_data(self, header_name, from_date):
        try:
            self.lst_header.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_header_daily_data(header_name, from_date)):
                for column_number, data in enumerate(row_data):
                    self.lst_header.append(str(data))
            return self.lst_header
        except Exception as err:
            print(err)

    def get_header_monthly_data(self, header_name, from_date, to_date):
        try:
            self.lst_header.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_header_monthly_data(header_name, from_date, to_date)):
                for column_number, data in enumerate(row_data):
                    self.lst_header.append(str(data))
            return self.lst_header
        except Exception as err:
            print(err)

    def get_code_daily_data(self, code_name,from_date):
        try:
            self.lst_code.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_code_daily_data(code_name,from_date)):
                for column_number, data in enumerate(row_data):
                    self.lst_code.append(str(data))
            return self.lst_code
        except Exception as err:
            print(err)

    def get_code_monthly_data(self, code_name,from_date,to_date):
        try:
            self.lst_code.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_code_monthly_data(code_name,from_date,to_date)):
                for column_number, data in enumerate(row_data):
                    self.lst_code.append(str(data))
            return self.lst_code
        except Exception as err:
            print(err)

    def get_codes_fields(self):
        try:
            self.lst_code.clear()
            for row_number, row_data in enumerate(ReportDA(self).get_codes_fields()):
                for column_number, data in enumerate(row_data):
                    self.lst_code.append(str(data))
            return self.lst_code
        except Exception as err:
            print(err)

    def get_daily_products(self, dates, combobox_value, header_name):
        try:
            return ReportDA(self).get_daily_products(dates, combobox_value, header_name)
        except Exception as err:
            print(err)

    def on_load_daily_products(self, dates):
        try:
            return ReportDA(self).on_load_daily_products(dates)
        except Exception as err:
            print(err)

    def GetMonthlyProducts(self, date, header_name, combobox_value):
        try:
            return ReportDA(self).GetMonthlyProducts(date, header_name, combobox_value)
        except Exception as err:
            print(err)

    def GetHeader1Data(self, date, header1):
        try:
            return ReportDA(self).GetHeader1Data(date, header1)
        except Exception as err:
            print(err)

    def GetHeader2Data(self, date, header2):
        try:
            return ReportDA(self).GetHeader2Data(date, header2)
        except Exception as err:
            print(err)

    def GetHeader3Data(self, date, header3):
        try:
            return ReportDA(self).GetHeader3Data(date, header3)
        except Exception as err:
            print(err)

    def GetHeader4Data(self, date, header4):
        try:
            return ReportDA(self).GetHeader4Data(date, header4)
        except Exception as err:
            print(err)

    def GetHeader5Data(self, date, header5):
        try:
            return ReportDA(self).GetHeader5Data(date, header5)
        except Exception as err:
            print(err)

    def GetCode1Data(self, date, code1):
        try:
            return ReportDA(self).GetCode1Data(date, code1)
        except Exception as err:
            print(err)


    def GetCode2Data(self, date, code2):
        try:
            return ReportDA(self).GetCode2Data(date, code2)
        except Exception as err:
            print(err)

    def GetCode3Data(self, date, code3):
        try:
            return ReportDA(self).GetCode3Data(date, code3)
        except Exception as err:
            print(err)

    def GetCode4Data(self, date, code4):
        try:
            return ReportDA(self).GetCode4Data(date, code4)
        except Exception as err:
            print(err)

    def GetCode5Data(self, date, code5):
        try:
            return ReportDA(self).GetCode5Data(date, code5)
        except Exception as err:
            print(err)

    def get_calibration_record(self):
        try:
            return ReportDA(self).get_calibration_record()
        except Exception as err:
            print(err)

    def get_tare_record(self):
        try:
            return ReportDA(self).get_tare_record()
        except Exception as err:
            print(err)
