from BusinessLogic.BaseBL import BaseBL
from DataAccess.AppFeaturesDA import AppFeaturesDA


class AppFeaturesBL(BaseBL):

    def get_app_feature_count(self, feature_name):
        try:
            self.feature_count = "0"
            self.result = AppFeaturesDA().get_app_feature_count(feature_name)
            for row_number, row_data in enumerate(self.result):
                for column_number, data in enumerate(row_data):
                    self.feature_count = str(data)
            return self.feature_count
            pass
        except Exception as e:
            print(e)
            return self.feature_count

    def insert_app_fetaures(self, features_list):
        try:
            return AppFeaturesDA().insert_app_fetaure(features_list)
            pass
        except Exception as e:
            print(e)

    def update_app_fetaures(self, features_list):
        try:
            return AppFeaturesDA().update_app_features(features_list)
            pass
        except Exception as e:
            print(e)

    def fetch_app_features(self):
        try:
            self.result = None
            self.result = AppFeaturesDA().fetch_configured_features()
            return self.result
            pass
        except Exception as e:
            print(e)
            return None
