import sys
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QApplication, QLabel, QLineEdit, QFrame, QComboBox, QStackedWidget, QVBoxLayout, \
    QHBoxLayout, QWidget, QPushButton, QGraphicsDropShadowEffect


class SettingsEthernetUi(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Ethernet Camera Settings")
        self.setGeometry(100, 100, 600, 600)

        self.main_layout = QVBoxLayout(self)

        self.frmEthernet = QFrame(self)
        self.main_layout.addWidget(self.frmEthernet)

        # Header
        self.lblHeader = QLabel("Ethernet Camera", self.frmEthernet)
        self.lblHeader.setFont(QFont('Inter', 15))
        self.lblHeader.setStyleSheet("text-align: left; border:0px solid grey;")
        self.lblHeader.setFixedSize(200, 41)

        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.lblHeader.setGraphicsEffect(shadow)

        # Edit and Save buttons
        self.btnEthernetEdit = QPushButton(self.frmEthernet)
        self.btnEthernetEdit.setFixedSize(42, 42)
        self.btnEthernetEdit.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(/path/to/Edit.png); "
                                           "border : none "
                                           "}"
                                           "QPushButton::hover"
                                           "{"
                                           "background-image :url(/path/to/EditHover.png); "
                                           "}"
                                           "QPushButton::disabled"
                                           "{"
                                           "background-image :url(/path/to/EditDisable.png); "
                                           "}")
        self.btnEthernetSave = QPushButton(self.frmEthernet)
        self.btnEthernetSave.setFixedSize(42, 42)
        self.btnEthernetSave.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(/path/to/Save.png); "
                                           "border : none "
                                           "}"
                                           "QPushButton::hover"
                                           "{"
                                           "background-image :url(/path/to/SaveHover.png); "
                                           "}"
                                           "QPushButton::disabled"
                                           "{"
                                           "background-image :url(/path/to/SaveDisable.png); "
                                           "}")

        # Camera Quantity
        self.lblCameraQuantity = QLabel("Camera Quantity", self.frmEthernet)
        self.lblCameraQuantity.setFont(QFont('Inter', 12))
        self.lblCameraQuantity.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.cmbCameraQuantity = QComboBox(self.frmEthernet)
        self.cmbCameraQuantity.addItems(["1", "2", "3", "4"])
        self.cmbCameraQuantity.setFont(QFont('Inter', 12))
        self.cmbCameraQuantity.setFixedSize(100, 31)
        self.cmbCameraQuantity.currentIndexChanged.connect(self.on_camera_quantity_changed)

        # Ethernet Details Layout
        ethernet_details_layout = QHBoxLayout()
        self.frmEthernet.setLayout(ethernet_details_layout)

        # Ethernet Details
        self.lblEthernetIpAddress = QLabel("IP Address", self.frmEthernet)
        self.lblEthernetIpAddress.setFont(QFont('Inter', 12))
        self.lblEthernetIpAddress.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.txtEthernetIpAddress = QLineEdit(self.frmEthernet)
        self.txtEthernetIpAddress.setFont(QFont('Inter', 12))
        self.txtEthernetIpAddress.setFixedSize(200, 31)

        self.lblEthernetPortNumber = QLabel("Port No", self.frmEthernet)
        self.lblEthernetPortNumber.setFont(QFont('Inter', 12))
        self.lblEthernetPortNumber.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.txtEthernetPortNumber = QLineEdit(self.frmEthernet)
        self.txtEthernetPortNumber.setFont(QFont('Inter', 12))
        self.txtEthernetPortNumber.setFixedSize(200, 31)

        self.lblUsername = QLabel("Username", self.frmEthernet)
        self.lblUsername.setFont(QFont('Inter', 12))
        self.lblUsername.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.txtUsername = QLineEdit(self.frmEthernet)
        self.txtUsername.setFont(QFont('Inter', 12))
        self.txtUsername.setFixedSize(200, 31)

        self.lblPassword = QLabel("Password", self.frmEthernet)
        self.lblPassword.setFont(QFont('Inter', 12))
        self.lblPassword.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.txtPassword = QLineEdit(self.frmEthernet)
        self.txtPassword.setFont(QFont('Inter', 12))
        self.txtPassword.setEchoMode(QLineEdit.Password)
        self.txtPassword.setFixedSize(200, 31)

        self.lblUrl = QLabel("URL", self.frmEthernet)
        self.lblUrl.setFont(QFont('Inter', 12))
        self.lblUrl.setStyleSheet("border:0px solid lightgrey; text-align:left;")
        self.txtUrl = QLineEdit(self.frmEthernet)
        self.txtUrl.setFont(QFont('Inter', 12))
        self.txtUrl.setFixedSize(200, 31)

        # Layout for details
        self.details_layout = QVBoxLayout()
        self.frmEthernet.setLayout(self.details_layout)
        self.details_layout.addWidget(self.lblHeader)
        self.details_layout.addWidget(self.btnEthernetEdit)
        self.details_layout.addWidget(self.btnEthernetSave)

        # Ethernet details layout
        ethernet_details_layout = QHBoxLayout()
        ethernet_details_layout.addWidget(self.lblEthernetIpAddress)
        ethernet_details_layout.addWidget(self.txtEthernetIpAddress)
        ethernet_details_layout.addWidget(self.lblEthernetPortNumber)
        ethernet_details_layout.addWidget(self.txtEthernetPortNumber)

        username_password_layout = QHBoxLayout()
        username_password_layout.addWidget(self.lblUsername)
        username_password_layout.addWidget(self.txtUsername)
        username_password_layout.addWidget(self.lblPassword)
        username_password_layout.addWidget(self.txtPassword)

        url_layout = QHBoxLayout()
        url_layout.addWidget(self.lblUrl)
        url_layout.addWidget(self.txtUrl)

        self.details_layout.addLayout(ethernet_details_layout)
        self.details_layout.addLayout(username_password_layout)
        self.details_layout.addLayout(url_layout)
        self.details_layout.addWidget(self.lblCameraQuantity)
        self.details_layout.addWidget(self.cmbCameraQuantity)

        # Stacked widget for camera configurations
        self.stackedWidget = QStackedWidget(self.frmEthernet)
        self.stackedWidget.setFixedSize(408, 200)
        for i in range(4):
            page = QWidget()
            layout = QVBoxLayout(page)
            layout.addWidget(QLabel(f"Camera Configuration {i + 1}"))
            self.stackedWidget.addWidget(page)

        self.details_layout.addWidget(self.stackedWidget)

        self.on_camera_quantity_changed(0)

    def on_camera_quantity_changed(self, index):
        self.stackedWidget.setCurrentIndex(index)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = SettingsEthernetUi()
    window.show()
    sys.exit(app.exec_())
