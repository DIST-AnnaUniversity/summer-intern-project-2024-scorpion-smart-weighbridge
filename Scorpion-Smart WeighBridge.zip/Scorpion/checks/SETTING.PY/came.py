def on_click_ethernet_communication(self):
    try:
        UiComponents.update_sub_menu_components(self, self.Ethernet)
        if self.dict_user_permission["GeneralVisible"] == "1":
            SettingsEthernetUi.create_ethernet_ui(self)
            SystemConfig.init_Ethernet_communication(self)
            if self.dict_user_permission["GeneralRead"] == "1":
                self.menu_access(False, self.frmEthernet)
            else:
                self.menu_access(True, self.frmEthernet)
        else:
            self.wgt.raise_()
            self.wgt_main.lower()
            SettingsAccessDeniedUi.sub_layout_Ui(self)
            self.setToolTipMessage(275, 120)
    except Exception as e:
        print(e)


def on_click_ethernet_edit(self):
    try:
        SystemConfig.update_ethernet_controls_state(self, True)
        SystemConfig.disable_verified_status(self)
    except Exception as e:
        print(e)


def on_click_ethernet_save(self):
    try:
        self.save_current_camera_details()
        SystemConfig.save_ethernet_values(self)
    except Exception as e:
        print(e)


def on_camera_quantity_changed(self, index):
    try:
        self.save_current_camera_details()
        self.current_camera_index = index
        self.load_camera_details(index)
    except Exception as e:
        print(e)


def save_current_camera_details(self):
    try:
        self.camera_details[self.current_camera_index] = {
            "ip_address": self.txtEthernetIpAddress.text(),
            "port_number": self.txtEthernetPortNumber.text(),
            "username": self.txtUsername.text(),
            "password": self.txtPassword.text(),
            "url": self.txtUrl.text(),
        }
    except Exception as e:
        print(e)


def load_camera_details(self, index):
    try:
        details = self.camera_details[index]
        self.txtEthernetIpAddress.setText(details.get("ip_address", ""))
        self.txtEthernetPortNumber.setText(details.get("port_number", ""))
        self.txtUsername.setText(details.get("username", ""))
        self.txtPassword.setText(details.get("password", ""))
        self.txtUrl.setText(details.get("url", ""))
    except Exception as e:
        print(e)