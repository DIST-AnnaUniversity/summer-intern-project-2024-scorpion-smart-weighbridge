
import platform
import sys
import os
  # This import remains the same because cv2 is the module name for opencv-python
from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QDialog, QMessageBox
from PyQt5.QtCore import QTime, pyqtSlot
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtGui import QPixmap, QFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView
from PyQt5.QtCore import pyqtSignal

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.CloudStorageBL import CloudStorageBL
from BusinessLogic.LoginBL import LoginBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable
import cv2


class CameraScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Camera Feed")
        self.setStyleSheet("background-color: white;")
        self.setGeometry(0, 2, 900, 480)

        self.camera_layout = QVBoxLayout(self)
        self.camera_layout.setContentsMargins(5, 5, 5, 5)  # Adjust margins
        self.camera_layout.setSpacing(5)  # Adjust spacing

        self.top_row = QHBoxLayout()
        self.bottom_row = QHBoxLayout()

        self.camera_layout.addLayout(self.top_row)
        self.camera_layout.addLayout(self.bottom_row)

        self.camera_1 = QLabel(self)
        self.camera_2 = QLabel(self)
        self.camera_3 = QLabel(self)
        self.camera_4 = QLabel(self)

        self.camera_labels = {
            "camera_1": self.camera_1,
            "camera_2": self.camera_2,
            "camera_3": self.camera_3,
            "camera_4": self.camera_4,
        }
        self.captured_images = {
            "camera_1": [],
            "camera_2": [],
            "camera_3": [],
            "camera_4": [],
        }
        self.full_screen_dialogs = {}

        self.camera_1.mousePressEvent = lambda event: self.display_full_screen(self.camera_1)
        self.camera_2.mousePressEvent = lambda event: self.display_full_screen(self.camera_2)
        self.camera_3.mousePressEvent = lambda event: self.display_full_screen(self.camera_3)
        self.camera_4.mousePressEvent = lambda event: self.display_full_screen(self.camera_4)

        self.top_row.addWidget(self.create_camera_widget(self.camera_1, "Capture 1", "camera_1"))
        self.top_row.addWidget(self.create_camera_widget(self.camera_2, "Capture 2", "camera_2"))
        self.bottom_row.addWidget(self.create_camera_widget(self.camera_3, "Capture 3", "camera_3"))
        self.bottom_row.addWidget(self.create_camera_widget(self.camera_4, "Capture 4", "camera_4"))

        self.print_button = QPushButton("Print PDF", self)
        self.print_button.setFixedSize(840, 60)
        self.print_button.clicked.connect(self.print_pdf)
        self.print_button.setEnabled(False)  # Initially disabled

        self.camera_layout.addWidget(self.print_button)  # Add print button to the main layout

        # Create a layout for the home button
        self.close_button = QPushButton("X", self)
        self.close_button.setFixedSize(50, 20)  # Adjust the size of the close button
        self.close_button.clicked.connect(self.go_home)
        self.close_button.setStyleSheet("position: absolute; top: 5px; right: 1px;")  # Position the button
        self.close_button.setParent(self)
        # Add the top right layout to the main layout

        self.cap = cv2.VideoCapture(0)  # Assuming you have 4 cameras connected, change index (0) if needed

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.datetime_timer = QTimer(self)
        self.datetime_timer.timeout.connect(self.update_datetime)
        self.datetime_timer.start(1000)

        self.current_datetime = ""

    def showEvent(self, event):
        super().showEvent(event)
        # Reinitialize the webcam capture and start the timer
        self.cap = cv2.VideoCapture(0)
        self.timer.start(1000 // 30)

    def go_home(self):
        # Release the webcam
        if self.cap is not None:
            self.cap.release()
            self.cap = None
        # Stop the timer
        self.timer.stop()
        # Close the window
        self.close()


    def create_camera_widget(self, camera_label, capture_button_text, camera_name):
        camera_widget = QWidget()
        camera_layout = QVBoxLayout()
        camera_layout.setContentsMargins(0, 0, 0, 0)  # Adjust margins
        camera_layout.setSpacing(0)  # Adjust spacing

        camera_label.setFixedSize(250, 150)  # Adjust the size of the camera feed label

        capture_button = QPushButton(capture_button_text)
        capture_button.setFixedSize(200, 40)
        capture_button.clicked.connect(lambda: self.capture_image(camera_name))

        camera_layout.addWidget(camera_label)
        camera_layout.addWidget(capture_button)

        camera_widget.setLayout(camera_layout)
        return camera_widget


    def update_camera_feed(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

            painter = QPainter(qImg)
            painter.setPen(QColor(Qt.white))
            painter.setFont(QFont("Arial", 12))
            painter.drawText(10, 20, self.current_datetime)
            painter.end()

            for camera_name, camera_label in self.camera_labels.items():
                qImg_scaled = qImg.scaled(camera_label.size(), Qt.KeepAspectRatio)
                pixmap = QPixmap.fromImage(qImg_scaled)
                camera_label.setPixmap(pixmap)

    def update_datetime(self):
        self.current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")

    def display_full_screen(self, label):
        if isinstance(label, QLabel) and label.pixmap():
            camera_name = next(key for key, value in self.camera_labels.items() if value is label)
            if camera_name not in self.full_screen_dialogs:
                self.full_screen_dialogs[camera_name] = FullScreenDialog(self.cap, camera_name, self)
            self.full_screen_dialogs[camera_name].showFullScreen()

    def capture_image(self, camera_name):
        if not os.path.exists("captured_images"):
            os.makedirs("captured_images")

        current_datetime = QDateTime.currentDateTime().toString("yyyyMMdd_HHmmss")
        image_path = os.path.join("captured_images", f"{camera_name}_{current_datetime}.jpg")
        cv2.imwrite(image_path, cv2.cvtColor(self.cap.read()[1], cv2.COLOR_BGR2RGB))
        self.captured_images[camera_name].append(image_path)
        QMessageBox.information(self, "Capture", f"Image captured and saved at {image_path}.")

        # Check if any two cameras have captured at least one image each, then enable the print button
        cameras_with_images = [camera for camera, images in self.captured_images.items() if len(images) >= 1]

        if len(cameras_with_images) >= 2:
            self.print_button.setEnabled(True)
        else:
            self.print_button.setEnabled(False)

    def print_pdf(self):
        # Find cameras with at least one captured image
        cameras_with_images = [camera_name for camera_name, images in self.captured_images.items() if len(images) >= 1]

        if len(cameras_with_images) < 1:
            QMessageBox.warning(self, "Print Error", "Need at least one image from any camera to print.")
            return

        # Prepare PDF
        now = datetime.now()
        time_str = now.strftime("%H.%M.%S")
        date_str = now.strftime("%d-%m-%y")
        month_folder = now.strftime("%b")
        year_folder = now.strftime("%Y")

        base_pdf_path = r'C:\Users\shrey\OneDrive\Pictures\PDF Reports'
        year_path_pdf = os.path.join(base_pdf_path, year_folder)
        month_path_pdf = os.path.join(year_path_pdf, month_folder)
        date_path_pdf = os.path.join(month_path_pdf, date_str)

        if not os.path.exists(date_path_pdf):
            os.makedirs(date_path_pdf)

        pdf_file_name = f"combined_bill_{time_str}.pdf"
        pdf_file_path = os.path.join(date_path_pdf, pdf_file_name)

        c = canvas.Canvas(pdf_file_path, pagesize=A4)
        width, height = A4

        margin = 20
        space_between_images = 20
        vertical_offset = 50

        # Draw the title
        title = "WEIGHMENT CERTIFICATE"
        c.setFont("Helvetica-Bold", 16)
        title_width = c.stringWidth(title)
        title_x = (width - title_width) / 2
        title_y = height - margin - 20
        c.drawString(title_x, title_y, title)

        # Underline the title
        c.line(title_x, title_y - 5, title_x + title_width, title_y - 5)

        # Adjust the text_y value to increase or decrease the space below the title
        text_y = height - margin - 120  # Adjust this value for spacing

        # Dashed lines
        c.setStrokeColor(colors.black)
        c.setDash(6, 3)
        c.line(margin, text_y + 60, width - margin, text_y + 60)
        c.line(margin, text_y - 250, width - margin, text_y - 250)
        c.setDash(1, 0)

        left_details = [
            f"BILL NO                      : ",
            f"MATERIAL                  : ",
            f"AGENT NAME            : ",
            f"PLACE OF LOADING : ",
            f"MOISTURE VALUE    : ",
            f"SIZE                            : ",
            f"GROSS Wt (Kg)          : ",
            f"TARE  Wt (Kg)            : ",
            f"NETT  Wt (Kg)            : "
        ]

        right_details = [
            f"VEHICLE                            : ",
            f"SUPERVISOR NAME        : ",
            f"COUNT                              : ",
            f"MSEZ DELIVERY NO        : ",
            f"SUPPLIER CHALLAN NO : ",
            f"AMOUNT (RS)                   : ",
            f"TIME                                   : ",
            f"DATE                                  : "
        ]

        line_spacing = 25

        c.setFont("Helvetica", 11)
        for i, label in enumerate(left_details):
            c.drawString(margin + 20, text_y - (i * line_spacing), label)

        for i, label in enumerate(right_details):
            c.drawString(margin + 320, text_y - (i * line_spacing), label)

        text_y -= max(len(left_details), len(right_details)) * line_spacing + 20

        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        text_y -= 20

        c.setFont("Helvetica", 10)
        additional_text = "LCS - For All Your Weighing Needs"
        additional_text_width = c.stringWidth(additional_text)
        additional_text_x = (width - additional_text_width) / 2
        c.drawString(additional_text_x, text_y - 2, additional_text)

        # Adjust image dimensions and placement
        # Adjust image dimensions and placement
        # Adjust image dimensions and placement
        img_width = 180  # Set a fixed width for images
        img_height = 120  # Set a fixed height for images
        space_between_images = 20  # Set spacing between images horizontally
        second_image_offset = 240  # Set the offset for the second image

        for camera_idx, camera_name in enumerate(cameras_with_images):
            images_to_print = self.captured_images[camera_name][:2]  # Limit to two images per camera

            # Draw camera header
            text_cam = f"Camera {camera_name[-1]}"
            text_cam = f"Camera {camera_name[-1]}"
            c.setFont("Helvetica-Bold", 12)
            c.drawString(margin, text_y, text_cam)
            text_y -= 20

            x_pos = margin  # Starting position for the first image

            for idx, image_path in enumerate(images_to_print):
                if idx >= 2:
                    break  # Limit to two images per camera

                image = cv2.imread(image_path)
                image_height, image_width, _ = image.shape
                aspect_ratio = image_width / image_height

                if idx == 1:
                    # Adjust x_pos for the second image
                    x_pos += second_image_offset

                # Calculate position for each image
                c.drawImage(image_path, x_pos, text_y - img_height, width=img_width, height=img_height)

                # Move x_pos for the next image to be drawn next to the current one
                x_pos += img_width + space_between_images

            text_y -= img_height + 20  # Adjust vertical position for the next camera section

        # Add signatures
        c.setFont("Helvetica", 12)
        text_operator = "Signature of the Operator"
        text_width_operator = c.stringWidth(text_operator, "Helvetica", 12)
        c.drawString(margin + 20, margin + 5, text_operator)
        c.line(margin + 20, margin + 20, margin + 220, margin + 20)

        text_supervisor = "Signature of the Supervisor"
        text_width_supervisor = c.stringWidth(text_supervisor, "Helvetica", 12)
        c.drawString(width - margin - text_width_supervisor - 20, margin + 5, text_supervisor)
        c.line(width - margin - 220, margin + 20, width - margin - 20, margin + 20)

        c.save()

        # Clear captured images
        for camera_name in cameras_with_images:
            self.captured_images[camera_name].clear()

        QMessageBox.information(self, "PDF Generated", f"PDF has been generated and saved at:\n{pdf_file_path}")




class FullScreenDialog(QDialog):
    def __init__(self, cap, camera_name, parent=None):  # Corrected method name
        super(FullScreenDialog, self).__init__(parent)
        self.cap = cap
        self.camera_name = camera_name
        self.setWindowTitle("Full Screen View")
        self.setGeometry(100, 100, 800, 600)
        self.setWindowState(Qt.WindowFullScreen)

        self.layout = QVBoxLayout(self)
        self.camera_label = QLabel(self)
        self.layout.addWidget(self.camera_label)



        self.setLayout(self.layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.captured_images = []

    def update_camera_feed(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

            painter = QPainter(qImg)
            painter.setPen(QColor(Qt.white))
            painter.setFont(QFont("Arial", 12))
            current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")
            painter.drawText(10, 20, current_datetime)
            painter.end()

            qImg_scaled = qImg.scaled(self.camera_label.size(), Qt.KeepAspectRatio)
            pixmap = QPixmap.fromImage(qImg_scaled)
            self.camera_label.setPixmap(pixmap)



class MainScreen(QMainWindow):
    def __init__(self, parent=None):
        super(MainScreen, self).__init__(parent)
        self.setWindowTitle("Main Screen")
        self.setGeometry(100, 100, 800, 600)

        self.btn_camera = QPushButton("Open Camera", self)
        self.btn_camera.clicked.connect(self.show_camera_boxes)

        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.btn_camera)
        central_widget = QWidget()
        central_widget.setLayout(self.layout)
        self.setCentralWidget(central_widget)

        self.camera_screen = None
        self.cap = cv2.VideoCapture(0)  # Assuming you have 1 camera connected, change index (0) if needed

    def show_camera_boxes(self):
        if not self.camera_screen:
            # Create a new CameraScreen instance only if it doesn't exist
            self.camera_screen = CameraScreen(self, self.cap)
        self.camera_screen.show()  # Show the existing CameraScreen instance

# Create an instance of the MainScreen class and run the application
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainScreen()
    window.show()
    sys.exit(app.exec_())






