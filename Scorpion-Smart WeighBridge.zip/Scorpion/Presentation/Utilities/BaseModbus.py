class BaseModbus:
    temp = ""