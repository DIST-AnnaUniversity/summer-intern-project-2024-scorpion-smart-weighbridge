import binascii
import codecs

from Presentation.Utilities.BaseModbus import BaseModbus


class Modbus(BaseModbus):

    def ConvertToHex(self, WriteProtocol):
        return bytes.fromhex(WriteProtocol)
        pass

    def ConvertToInt(self, ReadData):
        return int(ReadData, 16)

    def CalculateCRC(self, Protocol):
        crc = 0xFFFF
        for pos in Protocol:
            crc ^= pos
            for i in range(8):
                if (crc & 1) != 0:
                    crc >>= 1
                    crc ^= 0xA001
                else:
                    crc >>= 1
        ProtocolWithCRC = "%04X" % crc
        ReturnProtocol = ProtocolWithCRC[2:4] + ProtocolWithCRC[0:2]
        return ReturnProtocol
        pass

    def ConvertToAsciiChar(self, hex_str):
        hex_str = hex_str.replace(' ', '').replace('0x', '').replace('\t', '').replace('\n', '')
        ascii_str = binascii.unhexlify(hex_str)
        return ascii_str

    def HexToAscciChar(self, data):
        ascii_output = self.ConvertToAsciiChar(data)
        ascii_output = ''.join(chr(i) for i in ascii_output)
        return ascii_output

    def StringtoHex(self, address):
        x = hex(int(address))[2:]
        if len(x) == 2:
            x = "00" + x
        if len(x) == 1:
            x = "000" + x
        if len(x) == 3:
            x = "0" + x
        if len(x) == 5:
            x = "0" + x
        return x
