class GlobalEntities:
    header_params_checkbox = {}

    header_checkbox_names = []
    re_header_checkbox_names = []
    selected_code_no = ""

    print_entry_header = []
    print_reentry_header = []
    print_entry_code = []
    print_reentry_code = []
    print_params_checkbox = {}
    cust_code = ""
    device_id = ""
    cloud_storage_status = "0"
    remote_config_status = "0"

    text_box_entry_count = 0
    text_box_contents = []

    calibration_saved = False
    parameter_active_screen_events = {"save": None, "yes": None, "No": None}
