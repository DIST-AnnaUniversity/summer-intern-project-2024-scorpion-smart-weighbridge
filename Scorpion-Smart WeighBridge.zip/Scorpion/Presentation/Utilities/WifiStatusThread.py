from PyQt5.QtCore import QThread, pyqtSignal
import subprocess

from Presentation.Utilities.GlobalVariable import GlobalVariable

"""A Threading class 
to check Whether wifi is connected or not.
 And also Scans Available wifi when the device is connected to  some network.
 """


class WifiStatusThread(QThread):
    signal = pyqtSignal(int)

    def __init__(self,):
        super().__init__()
        self.flg_stop = False

    def run(self):
        while not self.flg_stop:
            try:
                # Checking the state of Wi-Fi (on/off) using the command
                cmd = "nmcli -t -f device,state dev | grep wlan0"

                output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
                lines = output.split("\n")
                wifi_status = lines[0]

                """ 
                Writing the command to terminal and checking for response 
                If response is 'connected' or 'disconnected' we will emit status as 1 if 'unavailable' as 0,
                1 indicates that Wi-Fi is turned ON and 0 as OFF,
                When the response is 'connected' we will start scan for available Wi-Fi
                The Scanned wifi will be loaded to the list,
                Adding the list of wifi inside a queue using multiprocessing
                """

                if wifi_status.__contains__('connected') or wifi_status.__contains__('disconnected'):
                    self.wifi_status_code = 1
                    self.signal.emit(self.wifi_status_code)
                    GlobalVariable.wifi_status = True
                elif wifi_status.__contains__('unavailable'):
                    self.wifi_status_code = 0
                    self.signal.emit(self.wifi_status_code)
                    GlobalVariable.wifi_status = False
            except Exception as e:
                print(e)

    def stop_thread(self):
        try:
            self.flg_stop = True
        except Exception as e:
            print(e)


