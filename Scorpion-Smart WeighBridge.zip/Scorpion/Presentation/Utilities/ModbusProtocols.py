class ModbusProtocols:
    DecimalWriteProtocol = "0103006600016415"
    # DecimalWriteProtocol = "01030001000a940D"
    # CurrentLoadWriteProtocol = "01030007000275CA"
    CurrentLoadWriteProtocol = "010300040005C408"
    RawADCReadAddress = "0000"
    TareWriteProtocol = "010600050001580B"
    RawAdcReadProtocol = "010300000002C40B"
    read_app_config_all = "0103012C0003C5FE"
    DecimalReadProtocolLength = 14
    LoadReadProtocolLength = 30

    # Calibration Protocols
    ReadAddress = "0103"
    WriteAddress = "0106"
    MaxCapacityReadAddress = "0100"
    DecimalPointReadAddress = "0102"
    ResolutionReadAddress = "0103"
    CalZeroReadAddress = "0104"
    CalSpanReadAddress = "0106"
    CalCapacityReadAddress = "0108"
    auto_zero_write_address = "302"
    moving_average_write_address = "301"
    adc_filter_write_address = "300"
    Readbyte2 = "0002"
    Readbyte1 = "0001"



