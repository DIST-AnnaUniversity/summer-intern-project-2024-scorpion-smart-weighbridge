import time
from PyQt5.QtCore import QThread, pyqtSignal
from wifi import Cell
import subprocess
import multiprocessing
from Presentation.Utilities.GlobalVariable import GlobalVariable

"""A Threading class 
to check Whether wifi is connected or not.
 And also Scans Available wifi when the device is connected to  some network.
 """


class WifiScannerThread(QThread):
    signal = pyqtSignal(list, int, str)
    get_available_wifi_queue = multiprocessing.Queue()

    def __init__(self):
        super().__init__()
        self.connected_ssid = None
        self.flg_stop = False

    def run(self):
        self.lstAvailableWifi = []
        while not self.flg_stop:
            try:
                # Checking the state of Wi-Fi (on/off) using the command
                cmd = "nmcli -t -f device,state dev | grep wlan0"

                output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
                lines = output.split("\n")
                wifi_status = lines[0]

                self.connected_ssid = self.get_connected_ssid()

                """ 
                Writing the command to terminal and checking for response 
                If response is 'connected' or 'disconnected' we will emit status as 1 if 'unavailable' as 0,
                1 indicates that Wi-Fi is turned ON and 0 as OFF,
                When the response is 'connected' we will start scan for available Wi-Fi
                The Scanned wifi will be loaded to the list,
                Adding the list of wifi inside a queue using multiprocessing
                """

                if wifi_status.__contains__('connected') or wifi_status.__contains__('disconnected'):
                    self.wifi_status_code = 1
                    GetAvailableWifi = list(Cell.all('wlan0'))
                    # Adding Wi-Fi list inside a queue
                    self.get_available_wifi_queue.put(GetAvailableWifi)
                    if not self.get_available_wifi_queue.empty():
                        self.lstAvailableWifi = []
                        # If not the list is empty get the values from the queue
                        self.get_wifi_list = self.get_available_wifi_queue.get()
                        for i, Wifi_Name in enumerate(self.get_wifi_list):
                            # remove duplicate ssids from the list and append it to new list.
                            if not Wifi_Name.ssid in self.lstAvailableWifi:
                                self.lstAvailableWifi.append(Wifi_Name.ssid)
                        self.signal.emit(self.lstAvailableWifi, self.wifi_status_code, self.connected_ssid)
                        GlobalVariable.check_wifi_status = False
                elif wifi_status.__contains__('unavailable'):
                    self.lstAvailableWifi = []
                    self.wifi_status_code = 0
                    self.signal.emit(self.lstAvailableWifi, self.wifi_status_code, self.connected_ssid)
                    GlobalVariable.check_wifi_status = False

            except Exception as e:
                print(e)

    def stop_wifi_thread(self):
        try:
            self.flg_stop = True
        except Exception as e:
            print(e)


    def get_connected_ssid(self):
        try:
            output = subprocess.check_output("iwgetid -r", shell=True).decode().strip()
            return output
        except subprocess.CalledProcessError:
            return None

