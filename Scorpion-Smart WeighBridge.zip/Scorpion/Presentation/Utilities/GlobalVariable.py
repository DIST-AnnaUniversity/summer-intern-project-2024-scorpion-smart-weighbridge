class GlobalVariable:
    app_version = "VERSION 1.0.4"
    language_setting_items = None
    super_admin_login = True

    FlagWriteDecimal = True
    get_com_port = "/dev/ttyAMA2"
    get_baud_rate = "115200"
    Serial_Port = None
    dict_com_ports = {
        'COM1': '/dev/ttyAMA0',
        'COM2': '/dev/ttyAMA1',
        'COM3': '/dev/ttyAMA3',
    }

    # For Data Read and Write
    FlagReadDecimal = False
    FlagWriteLoad = False
    FlagReadLoad = False
    FlagDisplayData = False
    FlagWriteTare = False

    TempDecimalWriteProtocol = ""
    TempLoadWriteProtocol = ""
    DecimalPoint = ""
    active_unit = ''

    FlagStartRead = False
    ReceivedLoadData = ""

    """ login screen """

    ActiveUser = ""
    active_user_password = ""
    ActiveUserRoleID = ""
    super_admin_login = False
    Logo = ""
    flgProfileInfoSave = False
    ListUpdateProfileDetails = []
    edited_profile_picture_name = ""
    time = ""
    listSignupInfo = []
    profile_picture_name = ""
    wifi_status = True
    start_char = "%"
    end_char = "$"
    device_id = "01"
    open_brace = "["
    close_brace = "]"
    stamping_image = ""
    USB_Junk_Folder = ["64AE-EDB8", "F26D-EBC4", "F26D-EBC41", "F26D-EBC42", "F26D-EBC43", "F26D-EBC44", "F26D-EBC45",
                       "F26D-EBC46", "F26D-EBC47", "F26D-EBC48", "F26D-EBC49"]

    # Camera Bill
    Bill_index = ""
