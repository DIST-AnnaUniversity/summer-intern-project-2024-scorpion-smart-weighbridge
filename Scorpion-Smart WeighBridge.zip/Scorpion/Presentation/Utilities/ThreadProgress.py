import time
from PyQt5.QtCore import QThread, pyqtSignal


class ThreadProgress(QThread):
    signal = pyqtSignal(int)

    def __init__(self, parent=None):
        QThread.__init__(self, parent)

    def run(self):
        i = 0
        while i < 101:
            time.sleep(0.1)
            self.signal.emit(i)
            i += 5
