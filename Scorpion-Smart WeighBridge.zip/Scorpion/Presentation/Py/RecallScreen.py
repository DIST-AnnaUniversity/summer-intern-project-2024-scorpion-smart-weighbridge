from datetime import datetime

from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, QDateTime, QTimer, QTime
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtWidgets import QMainWindow, QCompleter, QSizePolicy

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.MainScreenBL import MainScreenBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
import PyPDF2
from PyQt5 import QtCore

from Presentation.Py.extended_combobox import ExtendedComboBox


class RecallScreen(QMainWindow, PathConfig.UI.FROM_RECALL):
    def __init__(self, parent=None):
        super(RecallScreen, self).__init__(parent)
        QMainWindow.__init__(self)
        print(PathConfig.UI.FROM_RECALL)
        self.previous_reentry_header = None
        self.previous_entry_header = None
        self.main_obj = None
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_RECALL)
        self.recall_bg.setPixmap(pixmap.scaled(800, 480))
        UiComponents.RecallUiComponents(self)
        self.fetch_header_settings()
        self.on_load_event()
        self.event_handlers()

        self.key_actions = {
            Qt.Key_P: self.on_click_print,
            Qt.Key_Escape: self.on_click_back
            # Qt.Key_S: self.on_click_search
        }

    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def on_load_event(self):
        try:
            self.cmb_bill_no = ExtendedComboBox(self.pnl_recall_entry)
            self.cmb_bill_no.setParent(self.pnl_recall_entry)
            self.cmb_bill_no.setGeometry(10, 96, 311, 41)
            self.cmb_bill_no.setFont(QFont('Inter', 15))
            self.filter_items = []
            self.entry_result = []
            self.selected_filter = ""
            self.serial_print_data = ""
            # UiComponents.update_toggle_style_sheet(self, self.btn_bill, self.btn_vehicle)
            self.get_selected_filter_items("SerialNo")
            self.on_click_search()
            self.tool_tip.setVisible(False)
            self.pnl_max_preview.move(500000, 0)
            self.tmr_msg = QTimer()
            self.tmr_msg.setSingleShot(True)
            self.tmr_msg.setInterval(2000)
            self.timerdatetime = QTimer(self)
            self.timerdatetime.timeout.connect(self.date_time)
            self.timerdatetime.start(100)
            self.set_label_values()
            pass
        except Exception as e:
            print(e)

    def apply_auto_completion_combobox(self):
        try:
            self.cmb_bill_no.clear()
            self.cmb_bill_no.addItems(self.filter_items)
        except Exception as e:
            print(e)

    def get_selected_filter_items(self, column_name):
        try:
            self.lbl_print_data.setText("")
            self.selected_filter = str(column_name)
            self.filter_items = MainScreenBL().get_selected_filters(column_name)
            self.cmb_bill_no.clear()
            if len(self.filter_items) > 0:
                self.apply_auto_completion_combobox()
                self.on_click_search()
            pass
        except Exception as e:
            print(e)

    def event_handlers(self):
        try:
            self.btn_bill.clicked.connect(self.on_click_bill)
            self.btn_vehicle.clicked.connect(self.on_click_vehicle)
            self.btn_back.clicked.connect(self.on_click_back)
            self.btn_print.clicked.connect(self.on_click_print)
            self.btn_print_preview.clicked.connect(self.on_click_print)
            self.btn_search.clicked.connect(self.on_click_search)
            self.btn_maximize.clicked.connect(self.on_click_maximize)
            self.btn_close.clicked.connect(self.on_click_close_preview)
            self.cmb_bill_no.activated[str].connect(self.on_changed_bill_no)
        except Exception as e:
            print(e)

    def on_changed_bill_no(self):
        try:
            self.on_click_search()
        except Exception as e:
            print(e)

    def on_click_bill(self):
        try:
            UiComponents.update_bill_toggle_style_sheet(self)
            self.get_selected_filter_items("SerialNo")
            pass
        except Exception as e:
            print(e)

    def on_click_vehicle(self):
        try:
            UiComponents.update_vehicle_toggle_style_sheet(self)
            self.get_selected_filter_items("header1")
            pass
        except Exception as e:
            print(e)

    def on_click_back(self):
        try:
            if self.main_obj is None:
                from Presentation.Py.MainScreen import MainScreen
                self.main_obj = MainScreen(self)
                self.main_obj.show()
                self.hide()
                pass
        except Exception as e:
            print(e)

    def on_click_print(self):
        try:
            self.print_details = SystemConfigBL().get_printer_port()
            import serial
            # Open a connection to the printer on the specified serial port
            if self.print_result and len(self.print_details) > 0:
                ser = serial.Serial(self.print_details[0], self.print_details[1], timeout=1)
                self.bytes_to_send = bytes(self.serial_print_data, "utf-8")
                ser.write(self.bytes_to_send)
                ser.close()
                self.setToolTipMessage("Print Success", True)
            else:
                self.setToolTipMessage("Print Failed", False)
            pass
        except Exception as e:
            print(e)
            self.setToolTipMessage("Print Failed", False)

    def write_pdf_content_to_serial(self, pdf_file_path, serial_port):
        # Open PDF file
        with open(pdf_file_path, 'rb') as pdf_file:
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            # Read each page of the PDF and send it to serial port
            for page_num in range(1):
                page = pdf_reader.pages[0]
                page_content = page.extract_text()
                page_content = page.get_contents()
                print(page_content)
                # Write page content to serial port
                # serial_port.write(page_content.encode())

    def setToolTipMessage(self, msg, status):
        try:
            if status:
                pixmap = QPixmap(PathConfig.IMG.IMAGE_VERIFIED_BG)
                self.lbl_tool_tip_bg.setPixmap(pixmap)
            else:
                pixmap = QPixmap(PathConfig.IMG.IMAGE_RED_BG)
                self.lbl_tool_tip_bg.setPixmap(pixmap)
            self.lblToolTipMsg.setText("")
            self.tool_tip.setVisible(True)
            self.lblToolTipMsg.setText(str(msg))
            self.tool_tip.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def on_click_search(self):
        try:
            if not self.cmb_bill_no.currentText() == "":
                self.lbl_print_data.setText("")
                self.get_entry_data_based_on_search(self.selected_filter, self.cmb_bill_no.currentText())
            pass
        except Exception as e:
            print(e)

    def get_entry_data_based_on_search(self, column_name, column_value):
        try:
            self.entry_result = MainScreenBL().get_selected_product_details(column_name, column_value)
            if len(self.entry_result) > 0:
                self.print_result = self.print_data()
                if self.print_result:
                    self.lbl_print_data.clear()
                    self.lbl_max_preview.clear()
                    self.lbl_print_data.setText(str(self.print_result))
                    self.lbl_max_preview.setText(str(self.print_result))
                    self.lbl_print_data.setAlignment(QtCore.Qt.AlignCenter)
                    self.lbl_max_preview.setAlignment(QtCore.Qt.AlignCenter)
                    font = self.lbl_print_data.font()
                    font.setPointSize(7)  # Set an initial font size
                    self.lbl_print_data.setFont(font)

                    font = self.lbl_max_preview.font()
                    font.setPointSize(10)
                    self.lbl_max_preview.setFont(font)

                    self.lbl_print_data.setWordWrap(True)
                    self.lbl_max_preview.setWordWrap(True)
                    # Set size policy to allow the label to expand horizontally and vertically
                    self.lbl_print_data.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                    self.lbl_max_preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                    # Adjust size hint to minimum size hint
                    self.lbl_print_data.adjustSize()
                    self.lbl_max_preview.adjustSize()
            pass
        except Exception as e:
            print(e)

    def on_click_maximize(self):
        try:
            self.pnl_max_preview.move(0, 0)
            self.pnl_max_preview.raise_()
            pass
        except Exception as e:
            print(e)

    def on_click_close_preview(self):
        try:
            self.pnl_max_preview.move(500000, 0)
            pass
        except Exception as e:
            print(e)

    def create_print_data(self):
        try:
            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.header1 = self.return_header[0]
            self.header2 = self.return_header[1]
            self.header3 = self.return_header[2]
            width = 80

            self.serial_print_data = ""
            self.serial_print_data += f"{self.header1.center(width)}\n"
            self.serial_print_data += f"{self.header2.center(width)}\n"
            self.serial_print_data += f"{self.header3.center(width)}\n"

            self.serial_print_data += f"Recall Bill                               DateTime:{date_string}" + "\n"
            self.serial_print_data += "==============================================================================" + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += Helper.get_table_data_as_string_old(self.tableWidget)
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "signature of the operator                               signature of the party" + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "==============================================================================" + "\n"
            self.serial_print_data += "                          LCS-for all your weighing needs                    " + "\n"
            print(self.serial_print_data)
            pass
        except Exception as e:
            print(e)

    def print_data(self):
        try:
            self.lstValueBillGross = []
            self.lstValue_NetTareWt = []
            self.PdfHeader1 = []
            self.PdfHeader2 = []
            self.PdfInputData1 = []
            self.PdfInputData2 = []
            self.PdfHeader1.append("Bill No")
            self.PdfInputData1.append(str(self.entry_result[0]))
            self.lst_fetch_Enable_Code = []
            self.print_details = SystemConfigBL().get_printer_configuration()
            self.return_header = GeneralSettingsBL().get_Parameters()
            if not len(self.print_details) == 0:
                if self.print_details[10] == '1':
                    self.PdfHeader2.append(self.print_details[0])
                    self.PdfInputData2.append(str(self.entry_result[1]))
                else:
                    pass
                if self.print_details[11] == '1':
                    self.PdfHeader2.append(self.print_details[1])
                    self.PdfInputData2.append(str(self.entry_result[2]))
                else:
                    pass
                if self.print_details[12] == '1':
                    self.PdfHeader2.append(self.print_details[2])
                    self.PdfInputData2.append(str(self.entry_result[3]))
                else:
                    pass
                if self.print_details[13] == '1':
                    self.PdfHeader2.append(self.print_details[3])
                    self.PdfInputData2.append(str(self.entry_result[4]))
                else:
                    pass
                if self.print_details[14] == '1':
                    self.PdfHeader2.append(self.print_details[4])
                    self.PdfInputData2.append(str(self.entry_result[5]))
                else:
                    pass
            if str(self.entry_result[18]) == '0':
                if self.entry_result[19] == "Gross":
                    self.PdfHeader2.append("Gross Amount")
                    self.PdfInputData2.append(str(self.entry_result[14]))
                if self.entry_result[19] == "Tare":
                    self.PdfHeader2.append("Tare Amount")
                    self.PdfInputData2.append(str(self.entry_result[14]))
                if self.entry_result[19] == "Manual":
                    self.PdfHeader2.append("Amount")
                    self.PdfInputData2.append(str(self.entry_result[14]))
            else:
                if self.entry_result[19] == "Tare":
                    self.previous_entry_header = "Tare Amount"
                    self.previous_reentry_header = "Gross Amount"
                else:
                    self.previous_entry_header = "Gross Amount"
                    self.previous_reentry_header = "Tare Amount"
                self.PdfHeader2.append(self.previous_entry_header)
                self.PdfInputData2.append(str(self.entry_result[14]))
                self.PdfHeader2.append(self.previous_reentry_header)
                self.PdfInputData2.append(str(self.entry_result[18]))
                self.PdfHeader2.append("Total Amount")
                self.PdfInputData2.append(str(int(self.entry_result[14])+int(self.entry_result[18])))

            self.PdfHeader2.append("Tare Date/Time")
            self.PdfInputData2.append(str(self.entry_result[17]))
            self.PdfHeader2.append("Gross Date/Time")
            self.PdfInputData2.append(str(self.entry_result[16]))

            if not len(self.print_details) == 0:
                if self.print_details[20] == '1':
                    self.PdfHeader1.append(self.print_details[5])
                    self.PdfInputData1.append(str(self.entry_result[6]))
                else:
                    pass
                if self.print_details[21] == '1':
                    self.PdfHeader1.append(self.print_details[6])
                    self.PdfInputData1.append(str(self.entry_result[7]))
                else:
                    pass
                if self.print_details[22] == '1':
                    self.PdfHeader1.append(self.print_details[7])
                    self.PdfInputData1.append(str(self.entry_result[8]))
                else:
                    pass
                if self.print_details[23] == '1':
                    self.PdfHeader1.append(self.print_details[8])
                    self.PdfInputData1.append(str(self.entry_result[9]))
                else:
                    pass
                if self.print_details[24] == '1':
                    self.PdfHeader1.append(self.print_details[9])
                    self.PdfInputData1.append(str(self.entry_result[10]))
                else:
                    pass

            self.PdfHeader1.append("Net Wt  (" + str(self.entry_result[15]) + ")")
            if self.entry_result[20] == '1':
                self.PdfHeader1.append("Gross Wt(" + str(self.entry_result[15]) + ") #")
            else:
                self.PdfHeader1.append("Gross Wt(" + str(self.entry_result[15]) + ")")
            if self.entry_result[21] == '1':
                self.PdfHeader1.append("Tare Wt (" + str(self.entry_result[15]) + ") *")
            else:
                self.PdfHeader1.append("Tare Wt (" + str(self.entry_result[15]) + ")")

            self.PdfInputData1.append(str(self.entry_result[13]))
            self.PdfInputData1.append(str(self.entry_result[11]))
            self.PdfInputData1.append(str(self.entry_result[12]))
            self.tableWidget.clearContents()
            # Reset row and column counts to zero
            self.tableWidget.setRowCount(0)
            self.tableWidget.setColumnCount(0)
            self.tableWidget.horizontalHeader().setVisible(False)
            self.tableWidget.verticalHeader().setVisible(False)
            self.tableWidget.setColumnCount(8)
            count = 0
            max_length = max(len(self.PdfHeader1), len(self.PdfHeader2))

            for idx in range(max_length):
                self.tableWidget.setColumnWidth(0, 10)
                self.tableWidget.setColumnWidth(1, 10)
                self.tableWidget.setColumnWidth(2, 10)
                self.tableWidget.setColumnWidth(3, 10)
                self.tableWidget.setColumnWidth(4, 10)
                self.tableWidget.setColumnWidth(5, 10)
                self.tableWidget.insertRow(idx)
                self.tableWidget.setRowHeight(idx, 65)
                # Check if index exists in the first list
                if idx < len(self.PdfHeader1):
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem(self.PdfHeader1[idx].rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem(self.PdfInputData1[idx].ljust(16)))
                else:
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem("".rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem("".ljust(19)))
                # Check if index exists in the second list
                if idx < len(self.PdfHeader2) and count < len(self.PdfInputData2):
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem(self.PdfHeader2[count].rjust(18)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem(self.PdfInputData2[count].ljust(18)))
                    count += 1
                else:
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem("".rjust(18)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem("".ljust(18)))
            self.create_print_data()
            self.dashed_line = ""
            self.empty_space = " "
            self.span_space = "&nbsp;" * 80  # Create 20 non-breaking spaces
            self.dashed_line = self.dashed_line.ljust(80, "=")
            self.empty_space = self.empty_space.ljust(80, " ")
            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.table_data = "<p>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[0] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[1] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[2] + "</h6>"
            self.table_data += "<div>"
            self.table_data += "<span>Recall Bill</span>"
            self.table_data += " <span>{}</span>".format("&nbsp;" * 40)
            self.table_data += "<span>DateTime: {}</span>".format(date_string)
            self.table_data += "</div>"
            self.table_data += self.dashed_line + "\n"
            self.table_data += Helper.get_table_data_as_string(self, self.tableWidget)
            self.table_data += "<br>"
            self.table_data += "<div>"
            self.table_data += "<span>signature of the operator</span>"
            self.table_data += " <span>{}</span>".format(self.span_space)
            self.table_data += "<span>signature of the party</span>"
            self.table_data += "</div>"
            self.table_data += "<br>"
            self.table_data += self.dashed_line + "\n"
            self.table_data += "<div style='text-align: center;'>LCS-for all your weighing needs</div>"
            self.table_data += "</p>"
            # print(self.table_data)
            return self.table_data
        except Exception as e:
            print(e)

    def date_time(self):
        try:
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_current_time.setText(formatted_datetime)
        except Exception as e:
            print(e)

    def set_label_values(self):
        try:
            # self.get_type_details("Amount", self.lbl_amount_header, self.txt_amount)
            self.get_type_details("DateTime", self.lbl_current_time, self.lbl_current_time)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:
            type_row = VehicleReEntryBL().get_other_settings(type)
            lbldisplay.setText(type_row[0][0])
            isVisible = True if int(type_row[0][1]) else False
            lbldisplay.setVisible(isVisible)
            valdisplay.setVisible(isVisible)
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lblLogo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            pass
