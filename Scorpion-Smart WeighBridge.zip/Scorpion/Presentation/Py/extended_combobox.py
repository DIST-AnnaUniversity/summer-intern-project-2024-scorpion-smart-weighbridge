from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt, QSortFilterProxyModel, QModelIndex, pyqtSignal
from PyQt5.QtWidgets import QCompleter, QComboBox


class ExtendedComboBox(QComboBox):
    def __init__(self, parent=None):
        super(ExtendedComboBox, self).__init__(parent)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setEditable(True)
        noResults = pyqtSignal()  # Signal to emit when there are no results
        # add a filter model to filter matching items
        self.pFilterModel = CustomFilterProxyModel(self)
        self.pFilterModel.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.pFilterModel.setSourceModel(self.model())

        # add a completer, which uses the filter model
        self.completer = QCompleter(self.pFilterModel, self)

        # always show all (filtered) completions
        self.completer.setCompletionMode(QCompleter.UnfilteredPopupCompletion)
        self.setCompleter(self.completer)

        # connect signals
        self.lineEdit().textEdited.connect(self.pFilterModel.setFilterFixedString)
        self.lineEdit().setMaxLength(15)
        self.completer.activated.connect(self.on_completer_activated)
        self.completer.popup().setStyleSheet("background-color:rgb(245, 245, 245);;color:black;font:22px Inter;selection-background-color:#17a2b8")

    # on selection of an item from the completer, select the corresponding item from combobox
    def on_completer_activated(self, text):
        try:
            if text:
                index = self.findText(text)
                self.setCurrentIndex(index)
                self.activated[str].emit(self.itemText(index))
        except Exception as e:
            print(e)

    # on model change, update the models of the filter and completer as well
    def setModel(self, model):
        try:
            super(ExtendedComboBox, self).setModel(model)
            self.pFilterModel.setSourceModel(model)
            self.completer.setModel(self.pFilterModel)
        except Exception as e:
            print(e)

    # on model column change, update the model column of the filter and completer as well
    def setModelColumn(self, column):
        try:
            self.completer.setCompletionColumn(column)
            self.pFilterModel.setFilterKeyColumn(column)
            super(ExtendedComboBox, self).setModelColumn(column)
        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            # Do not process the enter key event to prevent adding the text to the combo box
            event.ignore()
            return
        super(ExtendedComboBox, self).keyPressEvent(event)


class CustomFilterProxyModel(QSortFilterProxyModel):
    def rowCount(self, parent=QModelIndex()):
        # If the filter yields no results, return 1 to show the "No data results found" message
        if super(CustomFilterProxyModel, self).rowCount(parent) == 0:
            return 1
        return super(CustomFilterProxyModel, self).rowCount(parent)

    def data(self, index, role=Qt.DisplayRole):
        # If there are no results, show "No data results found"
        if super(CustomFilterProxyModel, self).rowCount() == 0:
            if role == Qt.DisplayRole:
                return "No results"
            else:
                return None
        return super(CustomFilterProxyModel, self).data(index, role)
