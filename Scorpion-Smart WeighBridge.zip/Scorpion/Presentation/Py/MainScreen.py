import platform

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QLineEdit
from decimal import Decimal

import speech_recognition as sr
from PyQt5.QtWidgets import QMessageBox, QMainWindow
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QPixmap
from datetime import datetime
import platform

from PyQt5.QtCore import QTime, pyqtSlot
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QAbstractItemView

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.CloudStorageBL import CloudStorageBL
from BusinessLogic.LoginBL import LoginBL
from BusinessLogic.MainScreenBL import MainScreenBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Py.Camera import CameraScreen

class MainScreen(QMainWindow, PathConfig.UI.FROM_MAIN):
    def __init__(self, parent=None):
        super(MainScreen, self).__init__(parent)
        QMainWindow.__init__(self)
        self.formatted_datetime = ""
        self.active_user_name = None
        self.converted_negative_status = ""
        self.negative_sign = ""
        self.flg_validation = False
        self.confirm_new_password = ""
        self.new_password = ""
        self.forgot_pwd_user_name = ""
        self.tare_weight = ""
        self.recall_obj = None
        self.camera_obj = None
        self.report_obj = None
        self.vehicle_reentry = None
        self.vehicle_entry = None
        self.setupUi(self)
        self.disable_camera_settings()
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_MAIN)
        self.main_screen_bg.setPixmap(pixmap.scaled(800, 480))
        UiComponents.MainScreenUiComponents(self)
        self.event_handlers()
        self.fetch_header_settings()
        self.lbl_username.setText("Please Login")

        '''Declarations'''

        GlobalVariable.FlagWriteDecimal = True
        self.FlagTare = False
        self.obj_settings = None
        self.PortNo = ""
        self.GetLoad = ""
        self.PortNo = ""
        self.Tempdisplaydata = ""
        self.TempDisplay = ""
        self.DisplayData = ""
        self.DecimalPoint = ""
        self.GetComSettings()
        self.timerWriteData = QTimer(self)
        self.timerWriteData.timeout.connect(self.WriteToController)
        self.timerWriteData.start(100)
        self.timerReadData = QTimer(self)
        self.timerReadData.timeout.connect(self.ReadControllerData)
        self.timerReadData.start(100)
        self.timerShowData = QTimer(self)
        self.timerShowData.timeout.connect(self.DisplayReceivedData)
        self.timerShowData.start(100)
        self.timerdatetime = QTimer(self)
        self.timerdatetime.timeout.connect(self.date_time)
        self.timerdatetime.start(100)

        self.headers = ["SI.NO", "Vehicle", "Gross Weight", "Tare Weight", "Net Weight", "Amount"]
        self.main_screen_load_event()
        self.assign_return_keyevents()
        self.assign_return_password_keyevents()
        Helper.fetch_device_details(self)

        '''Wifi Status'''
        if not platform.system() == "Windows":
            WifiConfiguration.start_thread_for_wifi_status(self)

        self.key_actions = {
            Qt.Key_F1: self.on_click_entry,
            Qt.Key_F4: self.on_click_re_entry,
            Qt.Key_F10: self.on_click_tare,
            Qt.Key_S: self.on_click_settings,
            Qt.Key_R: self.on_click_report,
            Qt.Key_L: self.on_click_login,
            Qt.Key_F2: self.on_click_recall,
            Qt.Key_F9: self.on_click_help,
            Qt.Key_C: self.on_click_camera
        }

        self.assign_tab_order()

    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def date_time(self):
        try:
            current_datetime = datetime.now()
            self.formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_current_time.setText(self.formatted_datetime)
        except Exception as e:
            print(e)

    def assign_tab_order(self):
        self.setFocusPolicy(Qt.StrongFocus)
        if self.pnl_login.isVisible():
            self.setTabOrder(self.txt_username, self.txt_password)
            self.setTabOrder(self.txt_password, self.btn_login_ok)
        elif self.pnl_forgot_password.isVisible():
            self.setTabOrder(self.txt_forgot_pwd_username, self.txt_new_password)
            self.setTabOrder(self.txt_new_password, self.txt_confirm_new_password)
            self.setTabOrder(self.txt_confirm_new_password, self.btn_update_password)

    def show_camera_boxes(self):
        self.camera_screen = CameraScreen(self)
        self.camera_screen.show()

    def closeEvent(self, event):
        if hasattr(self, 'camera_screen') and self.camera_screen.isVisible():
            self.camera_screen.close()
        event.accept()

    def assign_return_keyevents(self):
        self.txt_username.returnPressed.connect(self.txt_pass_focus)
        self.txt_password.returnPressed.connect(self.on_click_login_ok)

    def assign_return_password_keyevents(self):
        self.txt_forgot_pwd_username.returnPressed.connect(self.txt_new_pass_focus)
        self.txt_new_password.returnPressed.connect(self.txt_confirm_new_pass_focus)
        self.txt_confirm_new_password.returnPressed.connect(self.on_click_update_password)

    def txt_pass_focus(self):
        if self.txt_password.isEnabled():
            self.txt_password.setFocus()
        else:
            pass

    def txt_new_pass_focus(self):
        self.txt_new_password.setFocus()

    def txt_confirm_new_pass_focus(self):
        self.txt_confirm_new_password.setFocus()

    def main_screen_load_event(self):
        self.pnl_login.setVisible(False)
        self.pnl_alert.setVisible(False)
        self.btn_hide_new_password.setVisible(False)
        self.btn_hide_confirm_new_password.setVisible(False)
        self.pnl_stamping_alert.setVisible(False)
        self.tmr_access_denied = QTimer()
        self.tmr_access_denied.setSingleShot(True)
        self.tmr_access_denied.setInterval(2000)
        self.check_login()
        self.lbl_error.setText("")
        self.tool_tip.setVisible(False)
        self.pnl_forgot_password.setVisible(False)
        self.fill_entry_details()
        self.btn_re_entry.setFlat(True)
        self.btn_entry.setFlat(True)
        self.btn_show_new_password.raise_()
        self.btn_show_confirm_new_password.raise_()
        self.set_unit_display()
        Helper.get_remote_config_status(self)
        if GlobalEntities.remote_config_status == '1':
            self.open_remote_config_port()
        self.tmr_msg = QTimer()
        self.tmr_msg.setSingleShot(True)
        self.tmr_msg.setInterval(2000)
        self.set_label_values()
        self.get_stamping_date()

    def event_handlers(self):
        try:
            self.btn_settings.clicked.connect(self.on_click_settings)
            self.btn_help.clicked.connect(self.on_click_help)
            self.btn_login.clicked.connect(self.on_click_login)
            self.btn_login_ok.clicked.connect(self.on_click_login_ok)
            self.btn_stamping_ok.clicked.connect(self.on_click_stamping_ok)
            self.btn_login_close.clicked.connect(self.on_click_login_close)
            self.btn_entry.clicked.connect(self.on_click_entry)
            self.btn_re_entry.clicked.connect(self.on_click_re_entry)
            self.btn_report.clicked.connect(self.on_click_report)
            self.btn_tare.clicked.connect(self.on_click_tare)
            self.btn_yes.clicked.connect(self.on_click_yes)
            self.btn_no.clicked.connect(self.on_click_no)
            self.btn_show_password.clicked.connect(self.on_click_show_password)
            self.btn_hide_password.clicked.connect(self.on_click_hide_password)
            self.btn_recall.clicked.connect(self.on_click_recall)
            self.btn_forgot_password.clicked.connect(self.on_click_forgot_password)
            self.btn_forgot_pwd_close.clicked.connect(self.on_click_forgot_password_close)
            self.btn_show_new_password.clicked.connect(self.on_click_show_new_password)
            self.btn_hide_new_password.clicked.connect(self.on_click_hide_new_password)
            self.btn_show_confirm_new_password.clicked.connect(self.on_click_show_confirm_new_password)
            self.btn_hide_confirm_new_password.clicked.connect(self.on_click_hide_confirm_new_password)
            self.btn_update_password.clicked.connect(self.on_click_update_password)
            self.btn_forgot_password.setFlat(True)
            self.btn_camera.clicked.connect(self.on_click_camera)
            self.voice_button.clicked.connect(self.on_click_voice_button)

        except Exception as e:
            print(e)

    def on_click_update_password(self):
        try:
            self.forgot_pwd_user_name = self.txt_forgot_pwd_username.text()
            self.new_password = self.txt_new_password.text()
            self.confirm_new_password = self.txt_confirm_new_password.text()
            self.users = MainScreenBL().get_users()
            self.check_forgot_password_validation()
            if not self.flg_validation:
                MainScreenBL().update_new_password(self.forgot_pwd_user_name, self.new_password)
                self.setToolTipCorrectMessage("Password Updated")
                self.pnl_forgot_password.setVisible(False)
                self.pnl_login.setVisible(True)
                self.txt_username.setFocus()
        except Exception as e:
            print(e)

    def on_click_voice_button(self):
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()
        QMessageBox.information(self, "Voice Command", "Speak Now")
        try:
            with microphone as source:
                audio = recognizer.listen(source)
            command = recognizer.recognize_google(audio).lower()
            if "open camera" in command:
                self.show_camera_boxes()
            if "open settings" in command:
                self.on_click_settings()
        except sr.UnknownValueError:
            QMessageBox.warning(self, "Voice Command", "Could not understand the audio")
        except sr.RequestError:
            QMessageBox.warning(self, "Voice Command", "Could not request results; check your network connection")

    def check_forgot_password_validation(self):
        try:
            if self.forgot_pwd_user_name:
                self.flg_validation = False
                self.lbl_forgot_pwd_error.setText("")
                if self.new_password:
                    self.flg_validation = False
                    self.lbl_forgot_pwd_error.setText("")
                    if self.confirm_new_password:
                        self.flg_validation = False
                        self.lbl_forgot_pwd_error.setText("")
                        if self.forgot_pwd_user_name in self.users:
                            self.flg_validation = False
                            self.lbl_forgot_pwd_error.setText("")
                            if self.new_password == self.confirm_new_password:
                                self.flg_validation = False
                                self.lbl_forgot_pwd_error.setText("")
                            else:
                                self.flg_validation = True
                                self.lbl_forgot_pwd_error.setText("Password Doesn't Match")
                                return
                        else:
                            self.flg_validation = True
                            self.lbl_forgot_pwd_error.setText("Invalid User Name")
                            return
                    else:
                        self.flg_validation = True
                        self.lbl_forgot_pwd_error.setText("enter confirm new pwd")
                        return
                else:
                    self.flg_validation = True
                    self.lbl_forgot_pwd_error.setText("enter new pwd")
                    return
            else:
                self.flg_validation = True
                self.lbl_forgot_pwd_error.setText("enter user name")
                return

        except Exception as e:
            print(e)

    def on_click_forgot_password(self):
        try:
            self.pnl_forgot_password.setVisible(True)
            self.txt_forgot_pwd_username.setFocus()
            self.pnl_login.setVisible(False)
            self.txt_forgot_pwd_username.setText("")
            self.lbl_forgot_pwd_error.setText("")
            self.txt_new_password.setText("")
            self.txt_confirm_new_password.setText("")
        except Exception as e:
            print(e)

    def on_click_forgot_password_close(self):
        try:
            self.pnl_forgot_password.setVisible(False)
            self.pnl_login.setVisible(True)
            self.txt_username.setFocus()
            self.txt_username.clear()
            self.txt_password.clear()
            self.pnl_login.setVisible(True)
            self.btn_hide_password.setVisible(False)
            self.btn_show_password.setVisible(True)
            self.btn_hide_password.lower()
            self.btn_show_password.raise_()
        except Exception as e:
            print(e)

    def fill_entry_details(self):
        try:
            self.return_entry_details = MainScreenBL().get_entry_details()
            if self.return_entry_details:
                self.tw_entry_details.setRowCount(0)
                self.tw_entry_details.setColumnCount(len(self.headers))
                self.tw_entry_details.setHorizontalHeaderLabels(self.headers)
                self.tw_entry_details.setEditTriggers(QAbstractItemView.NoEditTriggers)
                header = self.tw_entry_details.horizontalHeader()
                header.setStyleSheet(
                    "QHeaderView::section { background-color:rgb(231, 231, 231); }")
                for r_num, r_data in enumerate(self.return_entry_details):
                    self.tw_entry_details.insertRow(r_num)
                    r_data = list(r_data)
                    row = []
                    for i in range(len(r_data)):
                        if i == 2 or i == 3:
                            if str(r_data[i]) == '0':
                                r_data[i] = ""
                        if i == 4:
                            if str(r_data[i]) == 'NA':
                                r_data[i] = ""
                        row.append(r_data[i])
                    for i in range(len(row)):
                        item = QTableWidgetItem((str(row[i])))
                        item.setFont(QFont('Arial', 12))
                        item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                        self.tw_entry_details.setItem(r_num, i, item)
                        self.tw_entry_details.setColumnWidth(i, 95)
                        afont = PyQt5.QtGui.QFont()
                        afont.setFamily("Arial Black")
                        afont.setPointSize(9)
                        self.tw_entry_details.horizontalHeaderItem(i).setFont(afont)
            else:
                self.tw_entry_details.clear()
                self.tw_entry_details.setRowCount(0)
        except Exception as e:
            print(e)

    def GetComSettings(self):
        try:
            # self.PortNo = PortSettingBL().get_Comm_Settings()
            # if not self.PortNo == "":
            #     GlobalVariable.GetCOMPortNo = self.PortNo
            self.OpenCommunicationPort()
            pass
        except OSError as e:
            print(e)

    def OpenCommunicationPort(self):
        try:

            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    GlobalVariable.Serial_Port = None
                    GlobalVariable.Serial_Port = serial.Serial(GlobalVariable.get_com_port,
                                                               GlobalVariable.get_baud_rate,
                                                               timeout=0)
                    GlobalVariable.Serial_Port.close()
                    GlobalVariable.Serial_Port.open()
                    self.FlagCheckComm = True
                else:
                    self.FlagCheckComm = False
            else:
                self.FlagCheckComm = False
        except Exception as e:
            print(e)

    def WriteToController(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagWriteDecimal:
                    GlobalVariable.TempDecimalWriteProtocol = bytes.fromhex(ModbusProtocols.DecimalWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempDecimalWriteProtocol)
                    GlobalVariable.TempDecimalWriteProtocol = ""
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadDecimal = True
                    GlobalVariable.FlagReadLoad = False
                    GlobalVariable.FlagWriteDecimal = False
                elif GlobalVariable.FlagWriteLoad:
                    GlobalVariable.TempLoadWriteProtocol = bytes.fromhex(ModbusProtocols.CurrentLoadWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempLoadWriteProtocol)
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadLoad = True
                    pass
                elif GlobalVariable.FlagWriteTare:
                    GlobalVariable.TempTareProtocol = bytes.fromhex(ModbusProtocols.TareWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempTareProtocol)
                    GlobalVariable.FlagWriteTare = False
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagWriteLoad = True
                    self.FlagTare = True
                    pass

        except Exception as e:
            print(e)

    def ReadControllerData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagStartRead:
                    self.ReadData = GlobalVariable.Serial_Port.read_all().hex()
                    if not self.ReadData is None:
                        if GlobalVariable.FlagReadDecimal:
                            self.DecimalReadData = self.ReadData
                            if len(self.DecimalReadData) == ModbusProtocols.DecimalReadProtocolLength:
                                GlobalVariable.DecimalPoint = self.DecimalReadData[6: 10]
                                GlobalVariable.DecimalPoint = Modbus.ConvertToInt(self, GlobalVariable.DecimalPoint)
                                GlobalVariable.FlagReadDecimal = False
                                GlobalVariable.FlagWriteLoad = True
                                pass
                        if GlobalVariable.FlagReadLoad:  # 01030a00010c41000000d4000035df
                            self.LoadReadData = self.ReadData
                            if len(self.LoadReadData) == ModbusProtocols.LoadReadProtocolLength:
                                self.negative_sign = self.LoadReadData[6:10]
                                self.converted_negative_status = Modbus.ConvertToInt(self, self.negative_sign)
                                self.GetLoad = self.LoadReadData[22:26] + self.LoadReadData[18:22]  # 000002d4
                                self.Tempdisplaydata = Modbus.ConvertToInt(self, self.GetLoad)
                                self.TempDisplay = str(self.Tempdisplaydata)
                                if len(self.TempDisplay) == 4:
                                    self.TempDisplay = "0" + self.TempDisplay
                                elif len(self.TempDisplay) == 3:
                                    self.TempDisplay = "00" + self.TempDisplay
                                elif len(self.TempDisplay) == 2:
                                    self.TempDisplay = "000" + self.TempDisplay
                                elif len(self.TempDisplay) == 1:
                                    self.TempDisplay = "0000" + self.TempDisplay
                                if GlobalEntities.remote_config_status == '1':
                                    self.write_data_to_remote_config_port(self.TempDisplay)
                                N = 5 - int(GlobalVariable.DecimalPoint)
                                if not N == 5:
                                    self.DisplayData = str(self.TempDisplay)[:N] + "." + str(self.TempDisplay)[
                                                                                         N:]
                                else:
                                    self.DisplayData = str(self.TempDisplay)
                                GlobalVariable.FlagDisplayData = True
                        if self.FlagTare:
                            self.save_tare_log()
                            self.setToolTipCorrectMessage("Tare Successfull")
                            self.FlagTare = False
        except Exception as e:
            print(e)

    def DisplayReceivedData(self):
        if GlobalVariable.FlagDisplayData:
            if not self.DisplayData == "":
                self.Display(self.DisplayData, self.TempDisplay)

    def Display(self, displayData, checkStatusDisplayData):
        try:
            if not displayData == "":
                self.tare_weight = ""
                if checkStatusDisplayData.__contains__("99999"):
                    self.lbl_weight.setText(str("-OR-"))
                elif checkStatusDisplayData.__contains__("77777"):
                    self.lbl_weight.setText(str("-UR-"))
                elif checkStatusDisplayData.__contains__("88888"):
                    self.lbl_weight.setText(str("-OC-"))
                else:
                    if str(self.converted_negative_status) == '1' or str(self.converted_negative_status) == '3':
                        self.lbl_weight.setText(str('-' + str(Decimal(displayData))))
                        self.tare_weight = str('-' + str(Decimal(displayData)))
                    else:
                        self.lbl_weight.setText(str(Decimal(displayData)))
                        self.tare_weight = str(str(Decimal(displayData)))
        except OSError as e:
            print(e)

    def disable_timers(self):
        try:
            self.timerShowData.stop()
            self.timerReadData.stop()
            self.timerWriteData.stop()
            self.timerdatetime.stop()
            self.Start = False
            self.flgread = False
            WifiConfiguration.stop_wifi_thread(self)
        except Exception as e:
            print(e)

    def redirect_Screen(self, screen_name):
        try:
            screen_name.show()
            self.hide()
            pass
        except Exception as e:
            print(e)

    def on_click_settings(self):
        try:

            if not GlobalVariable.ActiveUser == "":
                if self.obj_settings is None:
                    self.disable_timers()
                    from Presentation.Py.SettingScreen import SettingScreen
                    self.obj_settings = SettingScreen(self)
                    self.redirect_Screen(self.obj_settings)
            else:
                self.setToolTipMessage("Settings")
        except Exception as e:
            print(e)

    def on_click_help(self):
        try:
            self.obj_help = None
            if self.obj_help is None:
                self.disable_timers()
                from Presentation.Py.HelpScreen import HelpScreen
                self.obj_help = HelpScreen(self)
                self.redirect_Screen(self.obj_help)
        except Exception as e:
            print(e)

    def on_click_login(self):
        try:
            if GlobalVariable.ActiveUser:
                self.reset_enabled = False
                self.logout_enabled = True
                self.display_logout_popup()
            else:
                self.txt_username.setFocus()
                self.txt_username.clear()
                self.txt_password.clear()
                self.pnl_login.setVisible(True)
                self.pnl_login.setGeometry(263, 84, 385, 352)
                self.btn_hide_password.setVisible(False)
                self.btn_show_password.setVisible(True)
                self.btn_hide_password.lower()
                self.btn_show_password.raise_()
                self.txt_username.setText("lcsswd")
                self.txt_password.setText("lcs130795swd")

        except Exception as e:
            print(e)

    def on_click_stamping_ok(self):
        try:
            self.pnl_stamping_alert.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_login_ok(self):
        try:
            lst_users = []
            self.lbl_error.setText("")
            self.user = ""
            self.password = ""
            self._UserName = ""
            self._Password = ""
            self._RoleID = ""
            self.user = self.txt_username.text()
            self.password = self.txt_password.text()
            if len(self.user) == 0 or len(self.password) == 0:
                self.lbl_error.setText("Invalid Credentials!!!")
            else:
                lst_users = LoginBL().get_user_info(self.user)
                try:
                    if not len(lst_users) == 0:
                        self._UserName = lst_users[0]
                        self._Password = lst_users[1]
                        self._RoleID = lst_users[2]
                    if self._Password == self.password and self._UserName == self.user:
                        GlobalVariable.ActiveUser = self.user
                        GlobalVariable.active_user_password = self.password
                        GlobalVariable.ActiveUserRoleID = self._RoleID
                        self.result = LoginBL().update_status()
                        self.result = LoginBL().set_active_user(self.user)
                        self.pnl_login.setVisible(False)
                        self.lbl_username.setText("")
                        self.btn_login.setText(self.user)
                        self.lbl_username.setText(self.user)
                        if self._UserName == "lcsswd" and self._Password == "lcs130795swd":
                            GlobalVariable.super_admin_login = True
                        else:
                            GlobalVariable.super_admin_login = False
                    else:
                        GlobalVariable.super_admin_login = False
                        if self._Password == "" and self._UserName == "":
                            self.lbl_error.setText("Invalid UserName!")
                        elif not self._Password == self.password:
                            self.lbl_error.setText("Invalid Password!")
                        elif not self._UserName == self.user:
                            self.lbl_error.setText("Invalid UserName!")
                    return self.password
                except TypeError as e:
                    GlobalVariable.super_admin_login = False
                    self.lbl_error.setText("Invalid User Name/Password!")
                    return None
        except Exception as e:
            print(e)

    def on_click_login_close(self):
        try:
            self.pnl_login.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_yes(self):
        try:
            if self.logout_enabled:
                GlobalVariable.ActiveUser = ""
                self.logout_enabled = False
                LoginBL().update_status()
                self.btn_login.setText("Login")
                self.lbl_username.setText("Please Login")

            self.pnl_alert.setVisible(False)

        except Exception as e:
            print(e)

    def on_click_no(self):
        try:
            self.logout_enabled = False
            self.pnl_alert.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_show_password(self):
        try:
            self.lbl_error.setText("")
            self.btn_hide_password.setVisible(True)
            self.btn_show_password.setVisible(False)
            self.btn_show_password.lower()
            self.btn_hide_password.raise_()
            self.txt_password.setEchoMode(QLineEdit.Normal)
        except Exception as e:
            print(e)

    def on_click_show_new_password(self):
        try:
            self.lbl_forgot_pwd_error.setText("")
            self.btn_hide_new_password.setVisible(True)
            self.btn_show_new_password.setVisible(False)
            self.btn_show_new_password.lower()
            self.btn_hide_new_password.raise_()
            self.txt_new_password.setEchoMode(QLineEdit.Normal)
        except Exception as e:
            print(e)

    def on_click_hide_new_password(self):
        try:
            self.lbl_forgot_pwd_error.setText("")
            self.btn_hide_new_password.setVisible(False)
            self.btn_show_new_password.setVisible(True)
            self.btn_show_new_password.raise_()
            self.btn_hide_new_password.lower()
            self.txt_new_password.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def on_click_show_confirm_new_password(self):
        try:
            self.lbl_forgot_pwd_error.setText("")
            self.btn_hide_confirm_new_password.setVisible(True)
            self.btn_show_confirm_new_password.setVisible(False)
            self.btn_show_confirm_new_password.lower()
            self.btn_hide_confirm_new_password.raise_()
            self.txt_confirm_new_password.setEchoMode(QLineEdit.Normal)
        except Exception as e:
            print(e)

    def on_click_hide_confirm_new_password(self):
        try:
            self.lbl_forgot_pwd_error.setText("")
            self.btn_hide_confirm_new_password.setVisible(False)
            self.btn_show_confirm_new_password.setVisible(True)
            self.btn_show_confirm_new_password.raise_()
            self.btn_hide_confirm_new_password.lower()
            self.txt_confirm_new_password.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def set_unit_display(self):
        try:
            unit_row = VehicleEntryBL().get_unit()
            self.lbl_unit.setText(unit_row[0][1])
            if unit_row[0][1] == 'Ton':
                GlobalVariable.active_unit = "Tonnes"
            else:
                GlobalVariable.active_unit = unit_row[0][1]
        except OSError as e:
            print(e)

    def on_click_hide_password(self):
        try:
            self.btn_show_password.setVisible(True)
            self.btn_hide_password.setVisible(False)
            self.lbl_error.setText("")
            self.btn_hide_password.lower()
            self.btn_show_password.raise_()
            self.txt_password.setEchoMode(QLineEdit.Password)
        except Exception as e:
            print(e)

    def display_logout_popup(self):
        try:
            self.pnl_alert.raise_()
            self.pnl_alert.setVisible(True)
            self.pnl_alert.setGeometry(284, 154, 340, 180)
        except Exception as e:
            print(e)

    def on_click_entry(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                self.btn_entry.setEnabled(False)
                if self.vehicle_entry is None:
                    from Presentation.Py.VehicleEntry import VehicleEntry
                    self.disable_timers()
                    self.vehicle_entry = VehicleEntry(self)
                    self.redirect_Screen(self.vehicle_entry)
            else:
                self.setToolTipMessage("Entry")
        except Exception as e:
            print(e)

    def on_click_re_entry(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                if self.vehicle_reentry is None:
                    self.disable_timers()
                    from Presentation.Py.VehicleReEntry import VehicleReEntry
                    self.vehicle_reentry = VehicleReEntry(self)
                    self.vehicle_reentry.show()
                    self.hide()
            else:
                self.setToolTipMessage("ReEntry")
        except Exception as e:
            print(e)

    def on_click_report(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                if self.report_obj is None:
                    from Presentation.Py.ReportScreen import ReportScreen
                    self.disable_timers()
                    self.report_obj = ReportScreen(self)
                    self.report_obj.show()
                    self.hide()
            else:
                self.setToolTipMessage("Report")
        except Exception as e:
            print(e)

    def on_click_tare(self):
        try:
            GlobalVariable.FlagWriteTare = True
            GlobalVariable.FlagWriteLoad = False
            GlobalVariable.FlagStartRead = False
        except Exception as e:
            print(e)

    def get_stamping_date(self):
        try:
            self.return_stamping_date = GeneralSettingsBL().get_stamping_date()
            if self.return_stamping_date:
                self.stamping_date = self.return_stamping_date
                self.display_message(self.stamping_date)
        except Exception as e:
            print(e)

    def calculate_previous_month(self, stamping_date):
        try:
            # Calculate the target month by subtracting the given months
            stamping_date = datetime.strptime(stamping_date, '%d-%m-%Y')
            target_month = stamping_date.month - 1
            target_year = stamping_date.year
            target_date = stamping_date.day
            if target_month == 0:
                target_month = 12
                target_year -= 1
            previous_month_date = datetime(target_year, target_month, target_date)
            return previous_month_date
        except Exception as e:
            print(e)

    def display_message(self, stamping_date):
        try:
            previous_month_date = self.calculate_previous_month(stamping_date)
            current_date = datetime.now()
            if (current_date.year == previous_month_date.year and
                    current_date.month == previous_month_date.month):
                self.pnl_stamping_alert.setVisible(True)
        except Exception as e:
            print(e)

    def setToolTipMessage(self, AcessBtn):
        try:
            tooltips = {
                "Settings": (150, 360),
                "Report": (150, 300),
                "Entry": (150, 140),
                "ReEntry": (150, 230),
                "Recall": (590, 56)
            }

            if AcessBtn in tooltips:
                x, y = tooltips[AcessBtn]
                self.tool_tip.setGeometry(x, y, 169, 54)
                self.tool_tip.setVisible(True)
                self.tool_tip.raise_()
                self.tmr_access_denied.start()
                self.tmr_access_denied.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def setToolTipCorrectMessage(self, msg):
        try:
            self.lbl_tool_tip_bg_correct.setStyleSheet("QLabel"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Message.png); "
                                                                                              "border : none "
                                                                                              "}")
            self.lblToolTipMsgCorrect.setText("")
            self.lblToolTipMsgCorrect.setText(msg)
            self.tool_tip_correct.setVisible(True)
            self.lblToolTipMsgCorrect.setText(str(msg))
            self.tool_tip_correct.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip_correct.hide)
        except Exception as e:
            print(e)

    def set_label_values(self):
        try:
            self.get_type_details("DateTime", self.lbl_current_time, self.lbl_current_time)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:
            type_row = VehicleReEntryBL().get_other_settings(type)
            lbldisplay.setText(type_row[0][0])
            isVisible = True if int(type_row[0][1]) else False
            lbldisplay.setVisible(isVisible)
            valdisplay.setVisible(isVisible)
        except Exception as e:
            print(e)

    def check_login(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                self.btn_login.setText("Logout")
                self.lbl_username.setText("")
                self.lbl_username.setText(GlobalVariable.ActiveUser)
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_app_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lblLogo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            pass

    def on_click_camera(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                if self.camera_obj is None:
                    from Presentation.Py.Camera import CameraScreen
                    self.disable_timers()
                    self.camera_obj = CameraScreen(self)
                    self.camera_obj.show()

            else:
                self.setToolTipMessage("Camera")
            pass
        except Exception as e:
            print(e)

    def on_click_recall(self):
        try:
            if not GlobalVariable.ActiveUser == "":
                if self.recall_obj is None:
                    from Presentation.Py.RecallScreen import RecallScreen
                    self.disable_timers()
                    self.recall_obj = RecallScreen(self)
                    self.recall_obj.show()
                    self.hide()
            else:
                self.setToolTipMessage("Recall")
            pass
        except Exception as e:
            print(e)

    def open_remote_config_port(self):
        try:
            self.remote_port_details = SystemConfigBL().get_remote_protocol_port()
            if not len(self.remote_port_details) == 0:
                self.remote_port = self.remote_port_details[0]
                self.remote_baud = self.remote_port_details[1]
            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    self.remote_config_port = None
                    self.remote_config_port = serial.Serial(self.remote_port,
                                                            self.remote_baud,
                                                            timeout=0)
                    self.remote_config_port.close()
                    self.remote_config_port.open()
        except Exception as e:
            print(e)

    def write_data_to_remote_config_port(self, read_data):
        try:
            self.assign_protocol_format = GlobalVariable.start_char + GlobalVariable.device_id + GlobalVariable.open_brace + str(
                GlobalVariable.DecimalPoint) + " " + str(
                read_data) + GlobalVariable.close_brace + GlobalVariable.end_char
            if self.assign_protocol_format:
                self.bytes_to_send = bytes(self.assign_protocol_format, "utf-8")
                self.remote_config_port.write(self.bytes_to_send)
        except Exception as e:
            print(e)

    @pyqtSlot(int)
    def update_wifi_status(self, status_code):
        try:
            self.wifi_status_code = status_code
            if self.wifi_status_code == 1:
                # self.lblWifiStatus.setStyleSheet("background-color:green;")
                UiComponents.wifi_status_on(self)
            elif self.wifi_status_code == 0:
                # self.lblWifiStatus.setStyleSheet("background-color:red;")
                UiComponents.wifi_status_off(self)
        except Exception as e:
            print(e)

    def save_tare_log(self):
        try:
            self.active_user_name = ""
            self.active_user_details = SystemConfigBL().get_Activated_Profile_info()
            if not len(self.active_user_details) == 0:
                self.active_user_name = self.active_user_details[0]
            else:
                self.active_user_name = ""
            self.list_tare_details = []
            self.list_tare_details.append(str(self.active_user_name))
            self.list_tare_details.append(str(self.formatted_datetime))
            self.list_tare_details.append(str(self.tare_weight))
            self.list_tare_details.append(str(self.formatted_datetime))
            self.list_tare_details.append(str(GlobalVariable.active_unit))
            if len(self.list_tare_details) == 5:
                self.tare_data_count = MainScreenBL().fetch_tare_log_count()
                if self.tare_data_count < 10:
                    MainScreenBL().set_tare_status_inactive()
                    self.insert_tare_log = MainScreenBL().insert_tare_log(self.list_tare_details)
                else:
                    MainScreenBL().delete_record_from_tare_log()
                    MainScreenBL().set_tare_status_inactive()
                    self.insert_tare_log = MainScreenBL().insert_tare_log(self.list_tare_details)
            else:
                pass
            pass
        except Exception as e:
            print(e)

    def disable_camera_settings(self):
        try:
            self.camera = MainScreenBL.get_camera_status(self)
            if self.camera == 0:
                self.btn_camera.setEnabled(False)
                self.btn_camera.hide()
            else:
                pass
            pass
        except Exception as e:
            print(e)













