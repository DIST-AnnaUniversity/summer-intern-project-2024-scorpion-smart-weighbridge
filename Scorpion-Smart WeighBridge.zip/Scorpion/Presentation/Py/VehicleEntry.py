import platform
import time
from datetime import datetime
import serial
from PyQt5.QtCore import Qt, QTimer, QTime, QRegExp, QDateTime, pyqtSlot, QSortFilterProxyModel
from PyQt5.QtGui import QPixmap, QRegExpValidator
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QMainWindow, QLineEdit, QComboBox, QSizePolicy, QApplication, QCompleter
from PyQt5 import QtWidgets
from decimal import Decimal
from BusinessLogic.CloudStorageBL import CloudStorageBL
# from Services.mobile_notification_services import Mobile_Notifications
from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Bundles.UiConfiguration import PathConfig
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.ReEntryCamera import Preview
from Presentation.Py.extended_combobox import ExtendedComboBox

from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols


class Modelentry:
    SerialNo = ""
    Code1 = ""
    Code2 = ""
    Code3 = ""
    Code4 = ""
    Code5 = ""
    code1_value = ""
    code2_value = ""
    code3_value = ""
    code4_value = ""
    code5_value = ""
    Field1 = ""
    Field2 = ""
    Field3 = ""
    Field4 = ""
    Field5 = ""
    CurrentWt = ""
    GrossWt = ""
    TareWt = ""
    NetWt = ""
    GrossDate = ""
    TareDate = ""
    Amount = ""
    Unit = ""
    report_date = ""
    report_time = ""
    bag_weight = ""
    bag_quantity = ""


class VehicleEntry(QMainWindow, PathConfig.UI.FROM_ENTRY):
    def __init__(self, parent=None):
        super(VehicleEntry, self).__init__(parent)
        QMainWindow.__init__(self)
        self.converted_negative_status = ""
        self.manual_status = None
        self.gunny_status = None
        self.first_entry = ""
        self.main_screen = None
        self.camera_obj = None
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_Entry)
        self.entry_bg.setPixmap(pixmap.scaled(800, 480))
        self.create_custom_combobox()
        UiComponents.VehicleEntryUiComponents(self)
        UiComponents.shortcuts(self)
        self.event_handlers()
        'Declarations'
        self.assign_protocol_format = None
        self.tool_tip.setVisible(False)
        self.current_serial_no = None
        self.flg_code1 = False
        self.flg_code2 = False
        self.flg_code3 = False
        self.lbl_msg.setVisible(False)
        self.flg_code4 = False
        self.flg_code5 = False
        self.flg_header1 = False
        self.flg_header2 = False
        self.flg_header3 = False
        self.flg_header4 = False
        self.flg_header5 = False
        self.flg_gunny_bag = False
        self.flg_save_enabled = False
        self.flg_check_save = False
        self.flg_manual_mode = False
        self.header_enable = False
        self.flg_save = False
        self.code_display = False
        self.code_enable = False
        GlobalVariable.FlagWriteDecimal = True
        self.FlagTare = False
        self.PortNo = ""
        self.negative_sign = ""
        self.GetLoad = ""
        self.flg_manual_auto = False
        self.FlagTare = False
        self.PortNo = ""
        self.count = 0
        self.code_count = 0
        self.header_count = 0
        self.bytes_to_send = ""
        self.code_display_count = 0
        self.Tempdisplaydata = ""
        self.TempDisplay = ""
        self.DisplayData = ""
        self.DecimalPoint = ""
        self.serial_print_data = ""
        self.GetComSettings()
        self.is_validation_error = False
        self.gunny = None
        self.on_load_event()

        self.key_actions = {
            Qt.Key_F1: self.on_click_entry,
            Qt.Key_F2: self.on_click_recall,
            Qt.Key_Escape: self.on_click_home,
            Qt.Key_P: self.on_click_print,
            Qt.Key_S: self.on_click_save,
            Qt.Key_G: self.on_click_gross,
            Qt.Key_D: self.on_click_delete,
            Qt.Key_M: self.manual_entry,
            Qt.Key_T: self.on_click_tare,
            Qt.Key_A: self.on_press_key_A,
            Qt.Key_C: self.on_click_cancel,
            Qt.Key_F12: self.on_manual_tare_wt_selection,
            Qt.Key_F5: self.header_back,
            Qt.Key_F6: self.header_next,
            Qt.Key_F7: self.code_back,
            Qt.Key_F8: self.code_next,
            Qt.Key_Y: self.on_click_y_key,
            Qt.Key_N: self.on_click_N_key,
            Qt.Key_Return: self.on_click_enter
        }

    def on_click_y_key(self):
        try:
            if self.pnl_manual_entry.isVisible():
                self.on_click_manual_entry_ok()
            elif self.pnl_save_confirm.isVisible():
                self.on_click_save_confirm_ok()
            elif self.pnl_discard_changes.isVisible():
                self.on_click_discard_changes_ok()
            elif self.pnl_gunny_bag.isVisible():
                self.on_click_gunnyBag_OK()
        except Exception as e:
            print(e)

    def on_click_N_key(self):
        try:
            if self.pnl_manual_entry.isVisible():
                self.on_click_manual_entry_cancel()
            elif self.pnl_save_confirm.isVisible():
                self.on_click_save_confirm_cancel()
            elif self.pnl_discard_changes.isVisible():
                self.on_click_discard_changes_cancel()
            elif self.pnl_gunny_bag.isVisible():
                self.on_click_gunnyBag_Cancel()
        except Exception as e:
            print(e)

    def on_click_delete(self):
        try:
            # UiComponents.shortcuts(self)
            self.txt_amount.clearFocus()
            self.txt_amount.clear()
            if self.txt_gross_weight.text():
                self.on_click_gross_wt_clr()
            elif self.txt_tare_weight.text():
                self.on_click_tare_wt_clr()
        except Exception as e:
            print(e)

    def setToolTipCorrectMessage(self, msg):
        try:
            self.lbl_tool_tip_bg.setStyleSheet("QLabel"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Message.png); "
                                                                                      "border : none "
                                                                                      "}")
            self.lblToolTipMsg.setText("")
            self.tool_tip.setVisible(True)
            self.lblToolTipMsg.setText(str(msg))
            self.tool_tip.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def setToolTipMessage(self, msg):
        try:
            self.lbl_tool_tip_bg.setStyleSheet("QLabel"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/LeftRedMessage.png); "
                                                                                      "border : none "
                                                                                      "}")
            self.lblToolTipMsg.setText("")
            self.tool_tip.setVisible(True)
            self.lblToolTipMsg.setText(str(msg))
            self.tool_tip.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        UiComponents.set_combo_box(self, self.list_cmb_code_names)
        # UiComponents.shortcuts(self)
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def mousePressEvent(self, event):
        # UiComponents.shortcuts(self)
        UiComponents.set_combo_box(self, self.list_cmb_code_names)

    def on_click_back(self):
        try:
            if not self.code_enable:
                self.display_back_header()
            else:
                self.display_back_code()
        except Exception as e:
            print(e)

    def on_click_enter(self):
        try:
            if self.txt_amount.text() and not self.flg_save and not self.flg_save_enabled and self.btn_save.isEnabled():
                self.on_click_save()
            elif self.flg_save and not self.flg_save_enabled and self.btn_save.isEnabled():
                self.on_click_save_confirm_ok()
                self.flg_save = False
            elif not self.header_enable:
                if 2 <= self.count_of_ones <= 5 and not self.code_enable:
                    getattr(self, f"display_header_count{self.count_of_ones}")()
                self.code_enable = False
                if self.header_enable:
                    UiComponents.complete_image(self, self.btn_header_next)
            elif not self.code_enable:
                self.code_enable = False
                UiComponents.complete_image(self, self.btn_header_next)
                if 2 <= self.code_count_of_ones <= 5 and self.header_enable:
                    getattr(self, f"display_code_count{self.code_count_of_ones}")()
                if self.code_enable:
                    UiComponents.complete_image(self, self.btn_code_next)
                    self.btn_tare_weight.setFocus()
                    self.tmr_error_msg.start(1000)
                    self.lbl_msg.setText("Press G for Gross/Press T for Tare")
            else:
                pass
        except Exception as e:
            print(e)

    '''if 5 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count5(self):
        try:

            if self.count == 0:
                if self.list_text_header_names[0].text():
                    self.move_header_locations()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_text_header_names[1].setFocus()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[1])
                    self.list_label_header_names[1].move(5, 29)
                    self.list_text_header_names[1].move(165, 25)
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    self.list_text_header_names[2].setFocus()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[2])
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[2].text()))
                    self.list_label_header_names[2].move(5, 29)
                    self.list_text_header_names[2].move(165, 25)
                    self.count += 1
            elif self.count == 2:
                if self.list_text_header_names[2].text():
                    self.move_header_locations()
                    self.list_text_header_names[3].setFocus()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[3])
                    self.list_text_header_names[3].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[3].text()))
                    self.list_label_header_names[3].move(5, 29)
                    self.list_text_header_names[3].move(165, 25)
                    self.count += 1
            elif self.count == 3:
                if self.list_text_header_names[3].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[4])
                    self.list_text_header_names[4].setFocus()
                    self.list_text_header_names[4].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[4].text()))
                    self.list_label_header_names[4].move(5, 29)
                    self.list_text_header_names[4].move(165, 25)
                    self.count += 1
            elif self.count == 4:
                if self.list_text_header_names[4].text():
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    def move_header_locations(self):
        try:
            for i in range(len(self.list_text_header_names)):
                self.list_text_header_names[i].move(3535, 454)
                self.list_label_header_names[i].move(3535, 454)
        except Exception as e:
            print(e)

    def move_code_locations(self):
        try:
            for i in range(len(self.list_label_code_names)):
                self.list_label_code_names[i].move(35635, 454)
                self.list_cmb_code_names[i].move(35356, 454)
                self.list_label_code_value_names[i].move(36535, 454)
        except Exception as e:
            print(e)

    def display_back_header(self):
        try:
            self.count = 0
            if self.header_count == 0:
                self.move_header_locations()
                UiComponents.set_text_box_active_style(self, self.list_text_header_names[0])
                self.list_text_header_names[0].setFocus()
                self.list_label_header_names[0].move(5, 29)
                self.list_text_header_names[0].move(165, 25)
            elif self.header_count == 1:
                self.move_header_locations()
                UiComponents.set_text_box_active_style(self, self.list_text_header_names[0])
                self.list_text_header_names[0].setFocus()
                self.list_label_header_names[0].move(5, 29)
                self.list_text_header_names[0].move(165, 25)
            elif self.header_count == 2:
                self.move_header_locations()
                UiComponents.set_text_box_active_style(self, self.list_text_header_names[1])
                self.list_text_header_names[1].setFocus()
                self.list_label_header_names[1].move(5, 29)
                self.list_text_header_names[1].move(165, 25)
            elif self.header_count == 3:
                self.move_header_locations()
                UiComponents.set_text_box_active_style(self, self.list_text_header_names[2])
                self.list_text_header_names[2].setFocus()
                self.list_label_header_names[2].move(5, 29)
                self.list_text_header_names[2].move(165, 25)
            elif self.header_count == 4:
                self.move_header_locations()
                UiComponents.set_text_box_active_style(self, self.list_text_header_names[3])
                self.list_text_header_names[3].setFocus()
                self.list_label_header_names[3].move(5, 29)
                self.list_text_header_names[3].move(165, 25)
            self.header_count = self.header_count - 1
            self.header_enable = False
            self.code_enable = False
        except Exception as e:
            print(e)

    '''if 4 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count4(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[1])
                    self.list_text_header_names[1].setFocus()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(5, 29)
                    self.list_text_header_names[1].move(165, 25)
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[2])
                    self.list_text_header_names[2].setFocus()
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[2].text()))
                    self.list_label_header_names[2].move(5, 29)
                    self.list_text_header_names[2].move(165, 25)
                    self.count += 1
            elif self.count == 2:
                if self.list_text_header_names[2].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[3])
                    self.list_text_header_names[3].setFocus()
                    self.list_text_header_names[3].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[3].text()))
                    self.list_label_header_names[3].move(5, 29)
                    self.list_text_header_names[3].move(165, 25)
                    self.count += 1
            elif self.count == 3:
                if self.list_text_header_names[3].text():
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 3 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count3(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[1])
                    self.list_text_header_names[1].setFocus()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(5, 29)
                    self.list_text_header_names[1].move(165, 25)
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[2])
                    self.list_text_header_names[2].setFocus()
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[2].move(5, 29)
                    self.list_text_header_names[2].move(165, 25)

                    self.count += 1
            elif self.count == 2:
                if self.list_text_header_names[2].text():
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 2 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count2(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].text():
                    self.move_header_locations()
                    UiComponents.set_text_box_active_style(self, self.list_text_header_names[1])
                    self.list_text_header_names[1].setFocus()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(5, 29)
                    self.list_text_header_names[1].move(165, 25)
                    self.count += 1
            if self.count == 1:
                if self.list_text_header_names[1].text():
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 5 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count5(self):
        try:
            UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[0].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                    self.list_label_code_names[0].move(9, 110)
                    self.list_cmb_code_names[0].move(170, 106)
                    self.list_label_code_value_names[0].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[1].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[1])
                    self.list_label_code_names[1].move(9, 110)
                    self.list_cmb_code_names[1].move(170, 106)
                    self.list_label_code_value_names[1].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 2:
                if self.list_label_code_value_names[1].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[2].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[2])
                    self.list_label_code_names[2].move(9, 110)
                    self.list_cmb_code_names[2].move(170, 106)
                    self.list_label_code_value_names[2].move(360, 106)
                    self.code_count += 1

            elif self.code_count == 3:
                if self.list_label_code_value_names[2].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[3].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[3])
                    self.list_label_code_names[3].move(9, 110)
                    self.list_cmb_code_names[3].move(170, 106)
                    self.list_label_code_value_names[3].move(360, 106)
                    self.code_count += 1

            elif self.code_count == 4:
                if self.list_label_code_value_names[3].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[4].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[4])
                    self.list_label_code_names[4].move(9, 110)
                    self.list_cmb_code_names[4].move(170, 106)
                    self.list_label_code_value_names[4].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 5:
                self.code_enable = True
            self.code_display_count = self.code_count

        except Exception as e:
            print(e)

    def display_back_code(self):
        try:
            self.code_count = 0
            if self.code_display_count == 0:
                self.move_code_locations()
                self.list_cmb_code_names[0].setFocus()
                UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                self.list_label_code_names[0].move(9, 110)
                self.list_cmb_code_names[0].move(170, 106)
                self.list_label_code_value_names[0].move(360, 106)
            elif self.code_display_count == 1:
                self.move_code_locations()
                self.list_cmb_code_names[0].setFocus()
                UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                self.list_label_code_names[0].move(9, 110)
                self.list_cmb_code_names[0].move(170, 106)
                self.list_label_code_value_names[0].move(360, 106)
            elif self.code_display_count == 2:
                self.move_code_locations()
                self.list_cmb_code_names[1].setFocus()
                UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[1])
                self.list_label_code_names[1].move(9, 110)
                self.list_cmb_code_names[1].move(170, 106)
                self.list_label_code_value_names[1].move(360, 106)
            elif self.code_display_count == 3:
                self.move_code_locations()
                self.list_cmb_code_names[2].setFocus()
                UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[2])
                self.list_label_code_names[2].move(9, 110)
                self.list_cmb_code_names[2].move(170, 106)
                self.list_label_code_value_names[2].move(360, 106)
            elif self.code_display_count == 4:
                self.move_code_locations()
                self.list_cmb_code_names[3].setFocus()
                UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[3])
                self.list_label_code_names[3].move(9, 110)
                self.list_cmb_code_names[3].move(170, 106)
                self.list_label_code_value_names[3].move(360, 106)
            self.code_display_count = self.code_display_count - 1
            self.header_enable = False
        except Exception as e:
            print(e)

    '''if 4 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count4(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[0].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                    self.list_label_code_names[0].move(9, 110)
                    self.list_cmb_code_names[0].move(170, 106)
                    self.list_label_code_value_names[0].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[1].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[1])
                    self.list_label_code_names[1].move(9, 110)
                    self.list_cmb_code_names[1].move(170, 106)
                    self.list_label_code_value_names[1].move(360, 106)
                    self.code_count += 1

            elif self.code_count == 2:
                if self.list_label_code_value_names[1].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[2].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[2])
                    self.list_label_code_names[2].move(9, 110)
                    self.list_cmb_code_names[2].move(170, 106)
                    self.list_label_code_value_names[2].move(360, 106)
                    self.code_count += 1

            elif self.code_count == 3:
                if self.list_label_code_value_names[2].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[3].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[3])
                    self.list_label_code_names[3].move(9, 110)
                    self.list_cmb_code_names[3].move(170, 106)
                    self.list_label_code_value_names[3].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 4:
                self.code_enable = True
            self.code_display_count = self.code_count
        except Exception as e:
            print(e)

    '''if 3 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count3(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[0].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                    self.list_label_code_names[0].move(9, 110)
                    self.list_cmb_code_names[0].move(170, 106)
                    self.list_label_code_value_names[0].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[1].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[1])
                    self.list_label_code_names[1].move(9, 110)
                    self.list_cmb_code_names[1].move(170, 106)
                    self.list_label_code_value_names[1].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 2:
                if self.list_label_code_value_names[1].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[2].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[2])
                    self.list_label_code_names[2].move(9, 110)
                    self.list_cmb_code_names[2].move(170, 106)
                    self.list_label_code_value_names[2].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 3:
                self.code_enable = True
            self.code_display_count = self.code_count
        except Exception as e:
            print(e)

    '''if 2 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count2(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[0].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[0])
                    self.list_label_code_names[0].move(9, 110)
                    self.list_cmb_code_names[0].move(170, 106)
                    self.list_label_code_value_names[0].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_cmb_code_names[1].setFocus()
                    UiComponents.set_combo_box_active_style(self, self.list_cmb_code_names[1])
                    self.list_label_code_names[1].move(9, 110)
                    self.list_cmb_code_names[1].move(170, 106)
                    self.list_label_code_value_names[1].move(360, 106)
                    self.code_count += 1
            elif self.code_count == 2:
                self.code_enable = True
                self.code_display_count = self.code_count
        except Exception as e:
            print(e)

    def event_handlers(self):
        try:
            self.btn_save.clicked.connect(self.on_click_save)
            self.btn_preview.clicked.connect(self.on_click_preview)
            self.btn_entry.clicked.connect(self.on_click_entry)
            self.btn_print.clicked.connect(self.on_click_print)
            self.btn_print_preview.clicked.connect(self.on_click_print)
            self.btn_discard_changes_ok.clicked.connect(self.on_click_discard_changes_ok)
            self.btn_discard_changes_cancel.clicked.connect(self.on_click_discard_changes_cancel)
            self.btn_cancel.clicked.connect(self.on_click_cancel)
            self.btn_save_confirm_cancel.clicked.connect(self.on_click_save_confirm_cancel)
            self.btn_save_confirm_ok.clicked.connect(self.on_click_save_confirm_ok)
            self.btn_manual_entry_cancel.clicked.connect(self.on_click_manual_entry_cancel)
            self.btn_manual_entry_ok.clicked.connect(self.on_click_manual_entry_ok)
            self.btn_tare_weight.clicked.connect(self.on_click_tare)
            self.btn_gross_weight.clicked.connect(self.on_click_gross)
            self.btn_home.clicked.connect(self.on_click_home)
            self.btn_gross_weight_delete.clicked.connect(self.on_click_gross_wt_clr)
            self.btn_tare_weight_delete.clicked.connect(self.on_click_tare_wt_clr)
            self.btn_recall.clicked.connect(self.on_click_recall)
            self.cmb_code1.activated[str].connect(self.on_changed_code1)
            self.cmb_code2.activated[str].connect(self.on_changed_code2)
            self.cmb_code3.activated[str].connect(self.on_changed_code3)
            self.cmb_code4.activated[str].connect(self.on_changed_code4)
            self.cmb_code5.activated[str].connect(self.on_changed_code5)
            self.btn_manual.clicked.connect(self.manual_entry)
            self.btn_manual_close.clicked.connect(self.manual_entry_close)
            self.rb_tare_weight.toggled.connect(self.on_manual_tare_wt_selection)
            self.btn_gunny_bag_ok.clicked.connect(self.on_click_gunnyBag_OK)
            self.btn_gunny_bag_cancel.clicked.connect(self.on_click_gunnyBag_Cancel)
            self.btn_gunny_bag.clicked.connect(self.GunnyBag_StateChange)
            self.btn_header_next.clicked.connect(self.header_next)
            self.btn_header_back.clicked.connect(self.header_back)
            self.btn_code_next.clicked.connect(self.code_next)
            self.btn_code_back.clicked.connect(self.code_back)
            self.btn_close_preview.clicked.connect(self.on_click_close_preview)
            self.txt_header1.textChanged.connect(self.vehicle_text_changed)
            self.txt_amount.textChanged.connect(self.amount_text_changed)
            self.txt_gross_weight.textChanged.connect(self.gross_text_changed)
            self.txt_tare_weight.textChanged.connect(self.tare_text_changed)
            self.txt_bag_count.textChanged.connect(self.bag_count_text_changed)
            self.cmb_code1.currentIndexChanged.connect(self.on_code1_index_changed)
            self.cmb_code2.currentIndexChanged.connect(self.on_code2_index_changed)
            self.cmb_code3.currentIndexChanged.connect(self.on_code3_index_changed)
            self.cmb_code4.currentIndexChanged.connect(self.on_code4_index_changed)
            self.cmb_code5.currentIndexChanged.connect(self.on_code5_index_changed)
        except Exception as e:
            print(e)

    def on_code1_index_changed(self, index):
        index = self.cmb_code1.currentIndex()
        self.selected_code_1 = self.cmb_code1.itemText(index)

    def on_code2_index_changed(self, index):
        index = self.cmb_code2.currentIndex()
        self.selected_code_2 = self.cmb_code2.itemText(index)

    def on_code3_index_changed(self, index):
        index = self.cmb_code3.currentIndex()
        self.selected_code_3 = self.cmb_code3.itemText(index)

    def on_code4_index_changed(self, index):
        index = self.cmb_code4.currentIndex()
        self.selected_code_4 = self.cmb_code4.itemText(index)

    def on_code5_index_changed(self, index):
        index = self.cmb_code5.currentIndex()
        self.selected_code_5 = self.cmb_code5.itemText(index)

    def amount_text_changed(self, text):
        try:
            cleaned_text = text.replace('D', '').replace('d', '')
            cleaned_text_save = text.replace('S', '').replace('s', '')

            if 'D' in text or 'd' in text:
                self.txt_amount.setText(cleaned_text)
                self.txt_amount.clear()
                self.on_click_delete()
            elif 'S' in text or 's' in text:
                self.txt_amount.setText(cleaned_text_save)
                if self.txt_amount.text() and not self.flg_save and not self.flg_save_enabled and self.btn_save.isEnabled():
                    self.on_click_save()
        except Exception as e:
            print(e)

    def bag_count_text_changed(self, text):
        try:
            # UiComponents.set_text_box_normal_style(self, self.txt_gross_weight)
            # UiComponents.shortcuts(self)
            cleaned_text1 = text.replace('Y', '').replace('y', '')
            cleaned_text2 = text.replace('N', '').replace('n', '')
            if 'Y' in text or 'y' in text:
                self.txt_bag_count.setText(cleaned_text1)
                self.on_click_gunnyBag_OK()
            elif 'N' in text or 'n' in text:
                self.txt_bag_count.setText(cleaned_text2)
                self.on_click_gunnyBag_Cancel()
        except Exception as e:
            print(e)

    def gross_text_changed(self, text):
        try:
            cleaned_text = text.replace('G', '').replace('g', '')
            if 'G' in text or 'g' in text:
                self.txt_gross_weight.setText(cleaned_text)
                self.on_click_gross()
        except Exception as e:
            print(e)

    def tare_text_changed(self, text):
        try:
            cleaned_text = text.replace('T', '').replace('t', '')
            if 'T' in text or 't' in text:
                self.txt_tare_weight.setText(cleaned_text)
                self.on_click_tare()
        except Exception as e:
            print(e)

    def vehicle_text_changed(self, text):
        try:
            text = text.upper()
            if len(text) == 0:
                self.lbl_header.setText("xx-xx-xx-xxxx")
            if len(text) == 1:
                self.lbl_header.setText(str(text) + "x-xx-xx-xxxx")
            if len(text) == 2:
                self.lbl_header.setText(str(text) + "-xx-xx-xxxx")
            if len(text) == 3:
                self.lbl_header.setText(str(text[0]) + str(text[1]) + "-" + str(text[2]) + "x-xx-xxxx")
            if len(text) == 4:
                self.lbl_header.setText(str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-xx-xxxx")
            if len(text) == 5:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + "x-xxxx")
            if len(text) == 6:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + str(
                        text[5]) + "-xxxx")
            if len(text) == 7:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + str(
                        text[5]) + "-" + str(text[6]) + "xxx")
            if len(text) == 8:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + str(
                        text[5]) + "-" + str(text[6]) + str(text[7]) + "xx")
            if len(text) == 9:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + str(
                        text[5]) + "-" + str(text[6]) + str(text[7]) + str(text[8]) + "x")
            if len(text) == 10:
                self.lbl_header.setText(
                    str(text[0]) + str(text[1]) + "-" + str(text[2]) + str(text[3]) + "-" + str(text[4]) + str(
                        text[5]) + "-" + str(text[6]) + str(text[7]) + str(text[8]) + str(text[9]))
        except Exception as e:
            print(e)

    def header_next(self):
        try:
            if self.count_of_ones == 5:
                self.display_header_count5()
            elif self.count_of_ones == 4:
                self.display_header_count4()
            elif self.count_of_ones == 3:
                self.display_header_count3()
            elif self.count_of_ones == 2:
                self.display_header_count2()
            if self.header_enable:
                UiComponents.complete_image(self, self.btn_header_next)
        except Exception as e:
            print(e)

    def header_back(self):
        try:
            self.display_back_header()
        except Exception as e:
            print(e)

    def code_next(self):
        try:
            if self.code_count_of_ones == 5:
                self.display_code_count5()
            elif self.code_count_of_ones == 4:
                self.display_code_count4()
            elif self.code_count_of_ones == 3:
                self.display_code_count3()
            elif self.code_count_of_ones == 2:
                self.display_code_count2()
            if self.code_enable:
                UiComponents.complete_image(self, self.btn_code_next)
        except Exception as e:
            print(e)

    def code_back(self):
        try:
            self.display_back_code()
        except Exception as e:
            print(e)

    def GunnyBag_StateChange(self):
        try:
            self.pnl_manual_entry.setVisible(False)
            if not self.txt_gross_weight.text():
                self.is_validation_error = True
                self.pnl_gunny_bag.setVisible(False)
                self.setToolTipMessage("enter gross weight !!")
                return self.is_validation_error
            else:
                self.flg_gunny_bag = True
                self.txt_bag_weight.clear()
                self.txt_bag_count.clear()
                self.pnl_gunny_bag.setVisible(True)
                self.txt_bag_weight.setFocus()
        except OSError as e:
            print(e)

    def on_click_gunnyBag_OK(self):
        try:
            if self.txt_bag_weight.text() != "" and self.txt_bag_count.text() != "" and self.txt_gross_weight.text() != "":
                self.bagweight = int(self.txt_bag_weight.text())
                self.bagcount = int(self.txt_bag_count.text())
                self.grosswt = int(self.txt_gross_weight.text()) - int(self.bagweight * self.bagcount)
                self.txt_gross_weight.setText(str(round(self.grosswt, 6)))
                self.netwt_calculation()
                self.btn_gunny_bag.setEnabled(False)
                self.pnl_gunny_bag.setVisible(False)
            else:
                self.gunny_bag_validation()
            self.txt_amount.setFocus()
        except OSError as e:
            print(e)

    def on_click_gunnyBag_Cancel(self):
        try:
            self.txt_bag_weight.setText("")
            self.txt_bag_count.setText("")
            self.pnl_gunny_bag.setVisible(False)
            self.flg_gunny_bag = False
            self.txt_amount.setFocus()
        except OSError as e:
            print(e)

    def on_click_recall(self):
        try:
            self.get_previous_entry_details()
            self.btn_save.setEnabled(False)
            self.print_data()
            self.btn_print.setEnabled(True)
            self.enable_controls(False)
        except OSError as e:
            print(e)

    def on_press_key_A(self):
        try:
            if self.txt_amount.isEnabled():
                self.txt_amount.setFocus()
                UiComponents.set_text_box_active_style(self, self.txt_amount)
            else:
                print("txt_amount_is_disabled")
            pass
        except OSError as e:
            print(e)

    def on_manual_gross_wt_selection(self):
        try:
            self.txt_tare_date_time.clear()
            self.txt_tare_weight.clear()
            UiComponents.ok_default(self, self.btn_tare_weight)
            self.pnl_manual.setVisible(False)
            self.rb_gross_weight.setEnabled(True)
            self.btn_tare_weight.setEnabled(False)
            self.txt_tare_weight.setEnabled(False)
            self.btn_gross_weight.setEnabled(True)
            self.txt_gross_weight.setReadOnly(False)
            self.txt_gross_weight.setEnabled(True)
            self.txt_gross_weight.setFocus()
            self.netwt_calculation()
            UiComponents.set_text_box_active_style(self, self.txt_gross_weight)
        except OSError as e:
            print(e)

    def on_manual_tare_wt_selection(self):
        try:
            self.txt_gross_date_time.clear()
            self.txt_gross_weight.clear()
            UiComponents.ok_default(self, self.btn_gross_weight)
            self.pnl_manual.setVisible(False)
            self.rb_tare_weight.setEnabled(True)
            self.btn_gross_weight.setEnabled(False)
            self.txt_gross_weight.setEnabled(False)
            self.btn_tare_weight.setEnabled(True)
            self.txt_tare_weight.setReadOnly(False)
            self.txt_tare_weight.setEnabled(True)
            self.netwt_calculation()
            self.txt_tare_weight.setFocus()
            UiComponents.set_text_box_active_style(self, self.txt_tare_weight)
        except OSError as e:
            print(e)

    def manual_entry(self):
        try:
            pass
            # self.pnl_manual.setVisible(True)
            # self.flg_manual_mode = True
            # self.rb_tare_weight.setEnabled(True)
            # self.rb_tare_weight.setCheckable(True)
        except Exception as e:
            print(e)

    def manual_entry_close(self):
        try:
            self.flg_manual_mode = False
            self.pnl_manual.setVisible(False)
        except Exception as e:
            print(e)

    def on_changed_code1(self):
        try:
            code1name_value = VehicleReEntryBL().get_code1name(self.cmb_code1.currentText())
            if code1name_value:
                self.lbl_code_value1.setText(code1name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code2(self):
        try:

            code2name_value = VehicleReEntryBL().get_code2name(self.cmb_code2.currentText())
            if code2name_value:
                self.lbl_code_value2.setText(code2name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code3(self):
        try:
            code3name_value = VehicleReEntryBL().get_code3name(self.cmb_code3.currentText())
            if code3name_value:
                self.lbl_code_value3.setText(code3name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code4(self):
        try:
            code4name_value = VehicleReEntryBL().get_code4name(self.cmb_code4.currentText())
            if code4name_value:
                self.lbl_code_value4.setText(code4name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code5(self):
        try:
            code5name_value = VehicleReEntryBL().get_code5name(self.cmb_code5.currentText())
            if code5name_value:
                self.lbl_code_value5.setText(code5name_value[0][0])
        except OSError as e:
            print(e)

    def date_time(self):
        try:
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_current_time.setText(formatted_datetime)
        except Exception as e:
            print(e)

    def GetComSettings(self):
        try:
            # self.PortNo = PortSettingBL().get_Comm_Settings()
            # if not self.PortNo == "":
            #     GlobalVariable.GetCOMPortNo = self.PortNo
            self.OpenCommunicationPort()
            pass
        except OSError as e:
            print(e)

    def OpenCommunicationPort(self):
        try:
            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    GlobalVariable.Serial_Port = None
                    GlobalVariable.Serial_Port = serial.Serial(GlobalVariable.get_com_port,
                                                               GlobalVariable.get_baud_rate,
                                                               timeout=0)
                    GlobalVariable.Serial_Port.close()
                    GlobalVariable.Serial_Port.open()
                    self.FlagCheckComm = True
                else:
                    self.FlagCheckComm = False
            else:
                self.FlagCheckComm = False
        except Exception as e:
            print(e)

    def open_remote_config_port(self):
        try:
            self.remote_port_details = SystemConfigBL().get_remote_protocol_port()
            if not len(self.remote_port_details) == 0:
                self.remote_port = self.remote_port_details[0]
                self.remote_baud = self.remote_port_details[1]
            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    self.remote_config_port = None
                    self.remote_config_port = serial.Serial(self.remote_port,
                                                            self.remote_baud,
                                                            timeout=0)
                    self.remote_config_port.close()
                    self.remote_config_port.open()
        except Exception as e:
            print(e)

    def WriteToController(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagWriteDecimal:
                    GlobalVariable.TempDecimalWriteProtocol = bytes.fromhex(ModbusProtocols.DecimalWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempDecimalWriteProtocol)
                    GlobalVariable.TempDecimalWriteProtocol = ""
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadDecimal = True
                    GlobalVariable.FlagReadLoad = False
                    GlobalVariable.FlagWriteDecimal = False
                elif GlobalVariable.FlagWriteLoad:
                    GlobalVariable.TempLoadWriteProtocol = bytes.fromhex(ModbusProtocols.CurrentLoadWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempLoadWriteProtocol)
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadLoad = True
                    pass
                elif GlobalVariable.FlagWriteTare:
                    GlobalVariable.TempTareProtocol = bytes.fromhex(ModbusProtocols.TareWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempTareProtocol)
                    GlobalVariable.FlagWriteTare = False
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagWriteLoad = True
                    self.FlagTare = True
                    pass

        except Exception as e:
            print(e)

    def ReadControllerData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagStartRead:
                    self.ReadData = GlobalVariable.Serial_Port.read_all().hex()
                    if not self.ReadData is None:
                        if GlobalVariable.FlagReadDecimal:
                            self.DecimalReadData = self.ReadData
                            if len(self.DecimalReadData) == ModbusProtocols.DecimalReadProtocolLength:
                                GlobalVariable.DecimalPoint = self.DecimalReadData[6: 10]
                                GlobalVariable.DecimalPoint = Modbus.ConvertToInt(self, GlobalVariable.DecimalPoint)
                                GlobalVariable.FlagReadDecimal = False
                                GlobalVariable.FlagWriteLoad = True
                                pass
                        if GlobalVariable.FlagReadLoad:  # 01030a00010c41000000d4000035df
                            self.LoadReadData = self.ReadData
                            if len(self.LoadReadData) == ModbusProtocols.LoadReadProtocolLength:
                                self.negative_sign = self.LoadReadData[6:10]
                                self.converted_negative_status = Modbus.ConvertToInt(self, self.negative_sign)
                                self.GetLoad = self.LoadReadData[22:26] + self.LoadReadData[18:22]  # 000002d4
                                self.Tempdisplaydata = Modbus.ConvertToInt(self, self.GetLoad)
                                self.TempDisplay = str(self.Tempdisplaydata)
                                if len(self.TempDisplay) == 4:
                                    self.TempDisplay = "0" + self.TempDisplay
                                elif len(self.TempDisplay) == 3:
                                    self.TempDisplay = "00" + self.TempDisplay
                                elif len(self.TempDisplay) == 2:
                                    self.TempDisplay = "000" + self.TempDisplay
                                elif len(self.TempDisplay) == 1:
                                    self.TempDisplay = "0000" + self.TempDisplay
                                if GlobalEntities.remote_config_status == '1':
                                    self.write_data_to_remote_config_port(self.TempDisplay)
                                N = 5 - int(GlobalVariable.DecimalPoint)
                                if not N == 5:
                                    self.DisplayData = str(self.TempDisplay)[:N] + "." + str(self.TempDisplay)[
                                                                                         N:]
                                else:
                                    self.DisplayData = str(self.TempDisplay)
                                GlobalVariable.FlagDisplayData = True

        except Exception as e:
            print(e)

    def write_data_to_remote_config_port(self, read_data):
        try:
            self.assign_protocol_format = GlobalVariable.start_char + GlobalVariable.device_id + GlobalVariable.open_brace + str(
                GlobalVariable.DecimalPoint) + " " + str(
                read_data) + GlobalVariable.close_brace + GlobalVariable.end_char
            if self.assign_protocol_format:
                self.bytes_to_send = bytes(self.assign_protocol_format, "utf-8")
                self.remote_config_port.write(self.bytes_to_send)
        except Exception as e:
            print(e)

    def DisplayReceivedData(self):
        try:
            if GlobalVariable.FlagDisplayData:
                if not self.DisplayData == "":
                    self.Display(self.DisplayData, self.TempDisplay)
        except Exception as e:
            print(e)

    def Display(self, displayData, checkStatusDisplayData):
        try:
            if not displayData == "":
                if checkStatusDisplayData.__contains__("99999"):
                    self.lbl_weight.setText(str("-OR-"))
                elif checkStatusDisplayData.__contains__("77777"):
                    self.lbl_weight.setText(str("-UR-"))
                elif checkStatusDisplayData.__contains__("88888"):
                    self.lbl_weight.setText(str("-OC-"))
                else:
                    if str(self.converted_negative_status) == '1' or str(self.converted_negative_status) == '3':
                        self.lbl_weight.setText(str('-' + str(Decimal(displayData))))
                    else:
                        self.lbl_weight.setText(str(Decimal(displayData)))
        except OSError as e:
            print(e)

    def on_click_save(self):
        try:
            self.btn_save_confirm_ok.setEnabled(True)
            self.btn_save_confirm_ok.setFocus()
            self.flg_save = True
            self.pnl_save_confirm.setVisible(True)
        except Exception as e:
            print(e)

    def save(self):
        try:

            self.btn_print.setFocus()
            self.pnl_save_confirm.setVisible(False)
            self.btn_home.setEnabled(False)
            self.flg_save_enabled = True
            self.flg_check_save = True
            if self.flg_code1:
                self.code1 = self.selected_code_1
                self.code1_value = self.lbl_code_value1.text()
            else:
                self.code1 = ""
                self.code1_value = ""
            if self.flg_code2:
                self.code2 =self.selected_code_2
                self.code2_value = self.lbl_code_value2.text()
            else:
                self.code2 = ""
                self.code2_value = ""
            if self.flg_code3:
                self.code3 = self.selected_code_3
                self.code3_value = self.lbl_code_value3.text()
            else:
                self.code3 = ""
                self.code3_value = ""
            if self.flg_code4:
                self.code4 = self.selected_code_4
                self.code4_value = self.lbl_code_value4.text()
            else:
                self.code4 = ""
                self.code4_value = ""
            if self.flg_code5:
                self.code5 = self.selected_code_5
                self.code5_value = self.lbl_code_value5.text()
            else:
                self.code5 = ""
                self.code5_value = ""
            self.grossunit = self.lbl_unit.text()
            self.tareunit = self.lbl_unit.text()
            self.netwt_calculation()
            self.serial_no = self.txt_serial_no.text()
            self.grosswt = self.txt_gross_weight.text()
            self.grossdate = self.txt_gross_date_time.text()
            self.tarewt = self.txt_tare_weight.text()
            if not self.tarewt:
                self.tarewt = 0
                self.first_entry = "Gross"
            if not self.grosswt:
                self.grosswt = 0
                self.first_entry = "Tare"
            if self.tarewt and self.grosswt:
                self.first_entry = "Manual"
            if self.flg_gunny_bag:
                self.gunny_status = '1'
            else:
                self.gunny_status = '0'
            if self.flg_manual_mode:
                self.manual_status = '1'
            else:
                self.manual_status = '0'
            self.taredate = self.txt_tare_date_time.text()
            self.amount = self.txt_amount.text()
            self.net_weight = self.txt_net_weight.text()
            self.field1 = self.txt_header1.text().upper()
            self.field2 = self.txt_header2.text()
            self.field3 = self.txt_header3.text()
            self.field4 = self.txt_header4.text()
            self.field5 = self.txt_header5.text()
            self.bagweight = self.txt_bag_weight.text()
            self.bagcount = self.txt_bag_count.text()
            self.field6 = self.code1
            self.field7 = self.code2
            self.field8 = self.code3
            self.field9 = self.code4
            self.field10 = self.code5
            self.field11 = self.code1_value
            self.field12 = self.code2_value
            self.field13 = self.code3_value
            self.field14 = self.code4_value
            self.field15 = self.code5_value
            date = datetime.now()
            self.report_date = (date.strftime("%Y-%m-%d"))
            time = QTime.currentTime()
            self.report_time = (time.toString())
            if self.input_validation_error():
                self.pnl_save_confirm.setVisible(False)
            else:
                if self.bagweight and self.bagcount != "":
                    param_tuple = (self.serial_no, self.field1,
                                   self.field2, self.field3,
                                   self.field4, self.field5,
                                   self.field6, self.field7,
                                   self.field8, self.field9,
                                   self.field10, self.field11, self.field12, self.field13, self.field14, self.field15,
                                   self.grosswt,
                                   self.grossunit, self.grossdate,
                                   self.tarewt, self.tareunit,
                                   self.taredate, self.amount, self.net_weight,
                                   self.report_date, self.report_time,
                                   self.bagweight, self.bagcount, self.first_entry, self.gunny_status,
                                   self.manual_status
                                   )
                    VehicleEntryBL().insert_entry_gunnydetails(param_tuple)
                    # from Presentation.Py.CloudStorage import CloudStorage
                    # if GlobalEntities.cloud_storage_status == "1":
                    #     CloudStorage.store_data_cloud(self, param_tuple, "Gunny")
                else:
                    param_tuple = (self.serial_no, self.field1,
                                   self.field2, self.field3,
                                   self.field4, self.field5,
                                   self.field6, self.field7,
                                   self.field8, self.field9,
                                   self.field10, self.field11, self.field12, self.field13, self.field14, self.field15,
                                   self.grosswt,
                                   self.grossunit, self.grossdate,
                                   self.tarewt, self.tareunit,
                                   self.taredate, self.amount, self.net_weight,
                                   self.report_date, self.report_time, self.first_entry, self.gunny_status,
                                   self.manual_status
                                   )
                    VehicleEntryBL().insert_entry_details(param_tuple)
                    # from Presentation.Py.CloudStorage import CloudStorage
                    # if GlobalEntities.cloud_storage_status == "1":
                    #     CloudStorage.store_data_cloud(self, param_tuple, "NA")
                self.print_data()
                self.update_transaction_details()
                # from Services.mobile_notification_services import Mobile_Notifications
                transaction_details = VehicleEntryBL().fetch_transaction_details_param()
                # Mobile_Notifications.send_data_to_firestore_db(self, transaction_details)
                self.enable_controls(False)
                self.btn_print.setEnabled(True)
                self.btn_preview.setEnabled(True)
                self.btn_save.setEnabled(False)
                self.setToolTipCorrectMessage("saved successfully")
                self.btn_home.setEnabled(True)

                self.btn_save_confirm_ok.setEnabled(True)
                self.btn_gunny_bag.setEnabled(False)
            self.flg_save = False
            self.flg_save_enabled = False
            # self.flg_check_save = False
        except Exception as e:
            print(e)

    def update_cloud_to_local(self):
        try:
            from Presentation.Py.CloudStorage import CloudStorage
            if GlobalVariable.wifi_status:
                self.cloud_storage_count = CloudStorageBL().get_cloud_storage_report_count()
                if self.cloud_storage_count > 0:
                    self.local_report = CloudStorageBL().get_cloud_local_storage()
                    for each_record in self.local_report:
                        self.result = CloudStorage.update_local_to_cloud_data(self, each_record)
                    CloudStorageBL().delete_cloud_local_storage()
            pass
        except Exception as e:
            print(e)

    def update_transaction_details(self):
        try:
            self.return_transaction_details = VehicleEntryBL().get_transaction_details(self.report_date)
            if len(self.return_transaction_details) > 0:
                VehicleEntryBL().update_transaction_details(self.return_transaction_details)
        except Exception as e:
            print(e)

    def netwt_calculation(self):
        try:
            self.grosswt = self.txt_gross_weight.text()
            self.tarewt = self.txt_tare_weight.text()
            self.grosswt = '0' if self.grosswt == "" else self.grosswt
            self.tarewt = '0' if self.tarewt == "" else self.tarewt
            if self.grosswt != '0' and self.tarewt != '0':
                if '.' in self.grosswt and '.' in self.tarewt:
                    self.net_weight = float(self.grosswt) - float(self.tarewt)
                elif not '.' in self.grosswt and not '.' in self.tarewt:
                    self.net_weight = int(self.grosswt) - int(self.tarewt)
                elif '.' in self.grosswt and not '.' in self.tarewt:
                    self.net_weight = float(self.grosswt) - int(self.tarewt)
                elif not '.' in self.grosswt and '.' in self.tarewt:
                    self.net_weight = int(self.grosswt) - float(self.tarewt)
                if self.flg_manual_mode:
                    self.txt_net_weight.setText(str(self.net_weight))
                return str(self.net_weight)
        except Exception as e:
            print(e)

    def input_validation_error(self):
        try:
            self.is_validation_error = False
            if self.flg_header1 and len(str(self.txt_header1.text()).strip(" ")) == 0:
                self.is_validation_error = True
                self.setToolTipMessage("enter header 1 !!")
                self.txt_header1.setFocus()
                UiComponents.set_text_box_active_style(self, self.txt_header1)
                self.btn_home.setEnabled(True)
                return self.is_validation_error
            else:
                if self.flg_header2 and len(str(self.txt_header2.text()).strip(" ")) == 0:
                    self.is_validation_error = True
                    self.txt_header2.setFocus()
                    UiComponents.set_text_box_active_style(self, self.txt_header2)
                    self.setToolTipMessage("enter header 2 !!")
                    self.btn_home.setEnabled(True)
                    return self.is_validation_error

                else:
                    if self.flg_header3 and len(str(self.txt_header3.text()).strip(" ")) == 0:
                        self.is_validation_error = True
                        self.setToolTipMessage("enter header 3 !!")
                        self.btn_home.setEnabled(True)
                        return self.is_validation_error
                    else:
                        if self.flg_header4 and len(str(self.txt_header4.text()).strip(" ")) == 0:
                            self.is_validation_error = True
                            self.setToolTipMessage("enter header 4 !!")
                            self.btn_home.setEnabled(True)
                            return self.is_validation_error
                        else:
                            if self.flg_header5 and len(str(self.txt_header5.text()).strip(" ")) == 0:
                                self.is_validation_error = True
                                self.setToolTipMessage("enter header 5 !!")
                                self.btn_home.setEnabled(True)
                                return self.is_validation_error
                            else:
                                if self.flg_code1 and not self.lbl_code_value1.text():
                                    self.is_validation_error = True
                                    self.setToolTipMessage("select code 1 !!")
                                    self.btn_home.setEnabled(True)
                                    return self.is_validation_error
                                else:
                                    if self.flg_code2 and len(str(self.lbl_code_value2.text()).strip(" ")) == 0:
                                        self.is_validation_error = True
                                        self.setToolTipMessage("select code 2 !!")
                                        self.btn_home.setEnabled(True)
                                        return self.is_validation_error
                                    else:

                                        if self.flg_code3 and len(str(self.lbl_code_value3.text()).strip(" ")) == 0:
                                            self.is_validation_error = True
                                            self.setToolTipMessage("select code 3 !!")
                                            self.btn_home.setEnabled(True)
                                            return self.is_validation_error
                                        else:

                                            if self.flg_code4 and len(
                                                    str(self.lbl_code_value4.text()).strip(" ")) == 0:
                                                self.is_validation_error = True
                                                self.setToolTipMessage("select code 4 !!")
                                                self.btn_home.setEnabled(True)
                                                return self.is_validation_error
                                            else:
                                                if self.flg_code5 and len(
                                                        str(self.lbl_code_value5.text()).strip(" ")) == 0:
                                                    self.is_validation_error = True
                                                    self.setToolTipMessage("select code 5 !!")
                                                    self.btn_home.setEnabled(True)
                                                    return self.is_validation_error
                                                else:
                                                    if self.flg_manual_mode:
                                                        if self.txt_gross_weight.text() == "" or self.txt_tare_weight.text() == "":
                                                            if self.txt_gross_weight.text() == "" or str(
                                                                    self.txt_gross_weight.text()) == '0':
                                                                self.is_validation_error = True
                                                                self.txt_gross_weight.setFocus()
                                                                UiComponents.set_text_box_active_style(self,
                                                                                                       self.txt_gross_weight)
                                                                self.setToolTipMessage("enter gross wt")
                                                                self.pnl_gunny_bag.setVisible(False)
                                                                self.btn_home.setEnabled(True)
                                                                return self.is_validation_error
                                                            if self.txt_tare_weight.text() == "" or str(
                                                                    self.txt_tare_weight.text()) == '0':
                                                                self.is_validation_error = True
                                                                self.txt_tare_weight.setFocus()
                                                                UiComponents.set_text_box_active_style(self,
                                                                                                       self.txt_tare_weight)
                                                                self.setToolTipMessage("enter tare wt")
                                                                self.btn_home.setEnabled(True)
                                                                return self.is_validation_error
                                                        else:
                                                            if self.txt_gross_weight.text() and str(
                                                                    self.txt_gross_weight.text()) == '0':
                                                                self.is_validation_error = True
                                                                self.setToolTipMessage("enter gross")
                                                                self.btn_home.setEnabled(True)
                                                                return self.is_validation_error
                                                            else:
                                                                if self.txt_tare_weight.text() and str(
                                                                        self.txt_tare_weight.text()) == '0':
                                                                    self.is_validation_error = True
                                                                    self.setToolTipMessage("enter tare")
                                                                    self.btn_home.setEnabled(True)
                                                                    return self.is_validation_error
                                                                else:
                                                                    if self.txt_amount.isEnabled() and len(
                                                                            str(self.txt_amount.text()).strip(
                                                                                " ")) == 0:
                                                                        self.is_validation_error = True
                                                                        self.txt_amount.setFocus()
                                                                        UiComponents.set_text_box_active_style(self,
                                                                                                               self.txt_amount)
                                                                        self.setToolTipMessage("enter amount !!")
                                                                        self.btn_home.setEnabled(True)
                                                                        return self.is_validation_error

                                                                    else:
                                                                        if self.flg_gunny_bag and len(
                                                                                str(self.txt_bag_weight.text()).strip(
                                                                                    " ")) == 0:
                                                                            self.is_validation_error = True
                                                                            self.setToolTipMessage(
                                                                                "enter bag weight !!")
                                                                            self.txt_bag_weight.setFocus()
                                                                            UiComponents.set_text_box_active_style(self,
                                                                                                                   self.txt_bag_weight)
                                                                            self.btn_home.setEnabled(True)
                                                                            return self.is_validation_error
                                                                        else:
                                                                            if self.flg_gunny_bag and len(
                                                                                    str(self.txt_bag_count.text()).strip(
                                                                                        " ")) == 0:
                                                                                self.is_validation_error = True
                                                                                self.txt_bag_count.setFocus()
                                                                                UiComponents.set_text_box_active_style(
                                                                                    self,
                                                                                    self.txt_bag_count)
                                                                                self.setToolTipMessage(
                                                                                    "enter bag count !!")

                                                                                self.btn_home.setEnabled(True)
                                                                                return self.is_validation_error

                                                    else:
                                                        if self.txt_gross_weight.text() == "" and self.txt_tare_weight.text() == "":
                                                            self.is_validation_error = True
                                                            self.setToolTipMessage("enter tare or gross")
                                                            self.btn_home.setEnabled(True)
                                                            return self.is_validation_error
                                                        else:
                                                            if self.txt_gross_weight.text() and str(
                                                                    self.txt_gross_weight.text()) == '0':
                                                                self.is_validation_error = True
                                                                self.setToolTipMessage("enter gross")
                                                                self.btn_home.setEnabled(True)
                                                                return self.is_validation_error
                                                            else:
                                                                if self.txt_tare_weight.text() and str(
                                                                        self.txt_tare_weight.text()) == '0':
                                                                    self.is_validation_error = True
                                                                    self.setToolTipMessage("enter tare")
                                                                    self.btn_home.setEnabled(True)
                                                                    return self.is_validation_error
                                                                else:
                                                                    if self.txt_amount.isEnabled() and len(
                                                                            str(self.txt_amount.text()).strip(
                                                                                " ")) == 0:
                                                                        self.is_validation_error = True
                                                                        self.txt_amount.setFocus()
                                                                        UiComponents.set_text_box_active_style(self,
                                                                                                               self.txt_amount)
                                                                        self.setToolTipMessage("enter amount !!")
                                                                        self.btn_home.setEnabled(True)
                                                                        return self.is_validation_error

                                                                    else:
                                                                        if self.flg_gunny_bag and len(
                                                                                str(self.txt_bag_weight.text()).strip(
                                                                                    " ")) == 0:
                                                                            self.is_validation_error = True
                                                                            self.setToolTipMessage(
                                                                                "enter bag weight !!")
                                                                            self.txt_bag_weight.setFocus()
                                                                            UiComponents.set_text_box_active_style(self,
                                                                                                                   self.txt_bag_weight)
                                                                            self.btn_home.setEnabled(True)
                                                                            return self.is_validation_error
                                                                        else:
                                                                            if self.flg_gunny_bag and len(
                                                                                    str(self.txt_bag_count.text()).strip(
                                                                                        " ")) == 0:
                                                                                self.is_validation_error = True
                                                                                self.txt_bag_count.setFocus()
                                                                                UiComponents.set_text_box_active_style(
                                                                                    self,
                                                                                    self.txt_bag_count)
                                                                                self.setToolTipMessage(
                                                                                    "enter bag count !!")

                                                                                self.btn_home.setEnabled(True)
                                                                                return self.is_validation_error
        except OSError as e:
            print(e)

    def gunny_bag_validation(self):
        try:
            if not self.txt_gross_weight.text():
                self.is_validation_error = True
                self.pnl_gunny_bag.setVisible(False)
                self.setToolTipMessage("enter gross weight !!")
                return self.is_validation_error
            else:
                if self.flg_gunny_bag and len(str(self.txt_bag_count.text()).strip(" ")) == 0:
                    self.is_validation_error = True
                    self.setToolTipMessage("enter bag count !!")
                    return self.is_validation_error
                else:
                    if self.flg_gunny_bag and len(str(self.txt_bag_weight.text()).strip(" ")) == 0:
                        self.is_validation_error = True
                        self.setToolTipMessage("enter bag weight !!")
                        return self.is_validation_error
        except Exception as e:
            print(e)

    def on_click_cancel(self):
        try:
            self.clear_all_fields()
            self.fill_code_items()
            self.get_serial_no()
            self.tmr_error_msg.stop()
            self.lbl_msg.setVisible(False)
            self.txt_tare_weight.setEnabled(False)
            UiComponents.ok_default(self, self.btn_gross_weight)
            UiComponents.ok_default(self, self.btn_tare_weight)
            UiComponents.set_text_box_normal_style(self, self.txt_gross_weight)
            self.get_type_details("Manual Entry", self.btn_manual, self.btn_manual)
            self.btn_save.setEnabled(True)
            self.flg_save_enabled = False
            self.flg_check_save = False
            self.txt_amount.setEnabled(False)
            self.pnl_save_confirm.setVisible(False)
            self.pnl_manual_entry.setVisible(False)
            self.btn_save_confirm_ok.setEnabled(True)
            self.count = 0
            self.code_count = 0
            self.move_header_locations()
            self.move_code_locations()
            self.list_label_code_names[0].move(9, 110)
            self.list_cmb_code_names[0].setFocus()
            self.list_cmb_code_names[0].move(170, 106)
            self.list_label_code_value_names[0].move(360, 106)
            self.list_label_header_names[0].move(5, 29)
            self.list_text_header_names[0].move(165, 25)
            self.list_text_header_names[0].setFocus()
            self.header_enable = False
            self.code_enable = False
            UiComponents.shortcuts(self)
        except Exception as e:
            print(e)

    def on_click_save_confirm_cancel(self):
        try:
            self.flg_save = False
            self.btn_save_confirm_ok.setEnabled(True)
            self.flg_save_enabled = False
            self.flg_check_save = False
            self.pnl_save_confirm.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_save_confirm_ok(self):
        try:
            self.btn_save_confirm_ok.setEnabled(False)
            self.btn_print.setFocus()
            self.pnl_save_confirm.setVisible(False)
            self.save()
        except Exception as e:
            print(e)

    def on_click_manual_entry_ok(self):
        try:
            if self.flg_manual_mode:
                self.txt_tare_weight.setEnabled(True)
                self.txt_tare_weight.setFocus()
                UiComponents.set_text_box_active_style(self, self.txt_tare_weight)
                self.pnl_manual_entry.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_manual_entry_cancel(self):
        try:
            self.flg_manual_mode = False
            self.pnl_manual_entry.setVisible(False)
            self.txt_amount.setEnabled(True)
            self.txt_amount.setFocus()
            UiComponents.set_text_box_active_style(self, self.txt_amount)
            self.txt_tare_weight.setEnabled(False)
            self.btn_tare_weight.setEnabled(False)
            self.btn_tare_weight_delete.setEnabled(False)
        except Exception as e:
            print(e)

    def on_click_entry(self):
        try:
            UiComponents.ok_default(self, self.btn_gross_weight)
            UiComponents.ok_default(self, self.btn_tare_weight)
            UiComponents.shortcuts(self)
            self.flg_save_enabled = False
            self.flg_check_save = False
            self.pnl_save_confirm.setVisible(False)
            self.enable_controls(True)
            self.txt_tare_weight.setEnabled(False)
            self.txt_tare_date_time.setEnabled(False)
            self.txt_gross_date_time.setEnabled(False)
            self.btn_print.setEnabled(False)
            self.btn_preview.setEnabled(False)
            self.txt_gross_weight.setEnabled(False)
            self.txt_net_weight.setEnabled(False)
            self.txt_serial_no.setEnabled(False)
            self.btn_gunny_bag.setEnabled(False)
            self.clear_all_fields()
            self.fill_code_items()
            self.get_serial_no()
            self.set_label_values()
            self.count = 0
            self.code_count = 0
            self.move_header_locations()
            self.move_code_locations()
            self.list_label_code_names[0].move(9, 110)
            self.list_cmb_code_names[0].setFocus()
            self.list_cmb_code_names[0].move(170, 106)
            self.list_label_code_value_names[0].move(360, 106)
            self.list_label_header_names[0].move(5, 29)
            self.list_text_header_names[0].move(165, 25)
            self.list_text_header_names[0].setFocus()
            self.header_enable = False
            self.code_enable = False
            self.txt_header1.setFocus()
        except Exception as e:
            print(e)

    def on_click_tare_weight(self):
        try:
            GlobalVariable.FlagWriteTare = True
            GlobalVariable.FlagWriteLoad = False
            GlobalVariable.FlagStartRead = False
        except Exception as e:
            print(e)

    def on_click_home(self):
        try:
            if not self.flg_check_save:
                self.get_active_textboxes()
                if self.flg_check_line_edit:
                    self.pnl_discard_changes.setVisible(True)
                else:
                    if self.main_screen is None:
                        self.disable_timers()
                        from Presentation.Py.MainScreen import MainScreen
                        self.main_screen = MainScreen(self)
                        self.main_screen.show()
                        self.hide()
            else:
                if self.main_screen is None:
                    self.disable_timers()
                    from Presentation.Py.MainScreen import MainScreen
                    self.main_screen = MainScreen(self)
                    self.main_screen.show()
                    self.hide()
        except Exception as e:
            print(e)

    def on_click_discard_changes_ok(self):
        try:
            if self.main_screen is None:
                self.disable_timers()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen = MainScreen(self)
                self.main_screen.show()
                self.hide()
        except Exception as e:
            print(e)

    def on_click_discard_changes_cancel(self):
        try:
            self.pnl_discard_changes.setVisible(False)
        except Exception as e:
            print(e)

    def disable_timers(self):
        try:
            self.timerShowData.stop()
            self.timerReadData.stop()
            self.timerWriteData.stop()
            self.timerdatetime.stop()
            # self.tmr_check_wifi.stop()
            self.tmr_error_msg.stop()
            self.Start = False
            self.flgread = False
            WifiConfiguration.stop_wifi_thread(self)
        except Exception as e:
            print(e)

    def enable_controls(self, isEnabled):
        try:
            self.btn_save.setProperty("enabled", isEnabled)
            self.btn_cancel.setProperty("enabled", isEnabled)
            self.btn_gross_weight.setProperty("enabled", isEnabled)
            self.btn_tare_weight.setProperty("enabled", isEnabled)
            self.btn_gross_weight_delete.setProperty("enabled", isEnabled)
            self.btn_tare_weight_delete.setProperty("enabled", isEnabled)
            # self.btn_manual.setProperty("enabled", isEnabled)
            for each_txtbox in self.findChildren(QLineEdit):
                each_txtbox.setProperty("enabled", isEnabled)
            for each_cmbbox in self.findChildren(QComboBox):
                each_cmbbox.setProperty("enabled", isEnabled)
            self.txt_serial_no.setEnabled(False)
            self.txt_amount.setEnabled(False)
        except Exception as e:
            print(e)

    def on_load_event(self):
        try:
            self.timerWriteData = QTimer(self)
            self.timerWriteData.timeout.connect(self.WriteToController)
            self.timerWriteData.start(100)
            self.timerReadData = QTimer(self)
            self.timerReadData.timeout.connect(self.ReadControllerData)
            self.timerReadData.start(100)
            self.timerShowData = QTimer(self)
            self.timerShowData.timeout.connect(self.DisplayReceivedData)
            self.timerShowData.start(100)
            self.timerdatetime = QTimer(self)
            self.timerdatetime.timeout.connect(self.date_time)
            self.timerdatetime.start(100)
            self.tmr_msg = QTimer()
            self.tmr_msg.setSingleShot(True)
            self.tmr_msg.setInterval(2000)
            self.tmr_error_msg = QTimer()
            self.tmr_error_msg.timeout.connect(self.display_msg)
            self.txt_header1.setFocus()
            # self.tmr_check_wifi = QTimer(self)
            # self.tmr_check_wifi.timeout.connect(self.update_cloud_to_local)
            # self.tmr_check_wifi.start(100)
            self.fetch_header_settings()
            self.pnl_max_preview.move(500000, 0)
            self.enable_controls(False)
            self.pnl_save_confirm.setVisible(False)
            self.rb_tare_weight.setEnabled(False)
            self.pnl_manual.setVisible(False)
            self.pnl_manual_entry.setVisible(False)
            # self.btn_manual.setEnabled(False)
            self.btn_gross_weight.setEnabled(False)
            self.btn_print.setEnabled(False)
            self.btn_tare_weight.setEnabled(False)
            self.btn_preview.setEnabled(False)
            self.btn_gunny_bag.setEnabled(False)
            self.pnl_gunny_bag.setVisible(False)
            self.pnl_discard_changes.setVisible(False)
            self.txt_tare_weight.setEnabled(False)
            self.txt_amount.setEnabled(False)
            self.fill_code_items()
            self.get_serial_no()
            self.on_click_entry()
            Helper.fetch_device_details(self)
            Helper.get_cloud_storage_status(self)
            Helper.get_remote_config_status(self)
            self.on_changed_code1()
            self.on_changed_code2()
            self.on_changed_code3()
            self.on_changed_code4()
            self.on_changed_code5()
            self.input_char_validation()
            self.combo_box_styles()
            if GlobalEntities.remote_config_status == '1':
                self.open_remote_config_port()
            '''Wifi Status'''
            if not platform.system() == "Windows":
                WifiConfiguration.start_thread_for_wifi_status(self)
        except Exception as e:
            print(e)

    def display_msg(self):
        try:
            if not self.txt_tare_weight.text() and not self.txt_gross_weight.text():
                text = """
                       <p>Press <span style="font-size:15pt;">G</span> for Gross / Press <span style="font-size:15pt;">T</span> for Tare</p>
                       """
                self.lbl_msg.setText(text)
                self.lbl_msg.setVisible(not self.lbl_msg.isVisible())
            elif self.txt_tare_weight.hasFocus() and self.flg_manual_mode:
                self.lbl_msg.setVisible(not self.lbl_msg.isVisible())
                text = """
                                       <p>Press <span style="font-size:16pt;">T</span> for Tare </p>
                                       """
                self.lbl_msg.setText(text)
            else:
                self.lbl_msg.setVisible(False)
        except Exception as e:
            print(e)

    def get_serial_no(self):
        try:
            self.current_serial_no = VehicleEntryBL().get_entry_count()
            if (self.current_serial_no[0]) is None:
                self.txt_serial_no.setText("1")
            else:
                self.txt_serial_no.setText(str(self.current_serial_no[0]))
        except Exception as e:
            print(e)

    def set_label_values(self):
        try:
            self.set_header_details()
            self.set_code_details()
            self.get_type_details("DateTime", self.lbl_current_time, self.lbl_current_time)
            self.get_type_details("GunnyBag", self.btn_gunny_bag, self.btn_gunny_bag)
            self.get_type_details("Manual Entry", self.btn_manual, self.btn_manual)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:
            if 'code' in type or 'header' in type:
                type_row = VehicleReEntryBL().get_code_and_header(type)
            else:
                type_row = VehicleReEntryBL().get_other_settings(type)
            # if not type == 'Manual Entry' and not type == "GunnyBag":

            isVisible = True if int(type_row[0][1]) else False
            if type == 'Manual Entry':
                lbldisplay.setEnabled(isVisible)
                valdisplay.setEnabled(isVisible)
                if isVisible:
                    self.flg_manual_mode = True
                else:
                    self.flg_manual_mode = False
            elif type == 'GunnyBag':
                lbldisplay.setEnabled(isVisible)
            else:
                lbldisplay.setVisible(isVisible)
                valdisplay.setVisible(isVisible)
                lbldisplay.setText(type_row[0][0])
            self.set_unit_display()
        except Exception as e:
            print(e)

    def set_unit_display(self):
        try:
            unit_row = VehicleEntryBL().get_unit()
            self.lbl_unit.setText(unit_row[0][1])
            self.lbl_gross_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
            self.lbl_tare_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
            self.lbl_net_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
        except OSError as e:
            print(e)

    def set_header_details(self):
        try:
            self.list_header_count = []
            self.lst_header_data = []
            self.lst_header_data.clear()
            self.lst_header_data = VehicleEntryBL().Get_header()
            if not len(self.lst_header_data) == 0:
                self.lbl_header1.setText(self.lst_header_data[0])
                self.lbl_header2.setText(self.lst_header_data[1])
                self.lbl_header3.setText(self.lst_header_data[2])
                self.lbl_header4.setText(self.lst_header_data[3])
                self.lbl_header5.setText(self.lst_header_data[4])
                if self.lst_header_data[5] == '1':
                    self.lbl_header1.setVisible(True)
                    self.txt_header1.setVisible(True)
                    self.flg_header1 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header1.setVisible(False)
                    self.txt_header1.setVisible(False)
                    self.flg_header1 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[6] == '1':
                    self.lbl_header2.setVisible(True)
                    self.txt_header2.setVisible(True)
                    self.flg_header2 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header2.setVisible(False)
                    self.txt_header2.setVisible(False)
                    self.flg_header2 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[7] == '1':
                    self.lbl_header3.setVisible(True)
                    self.txt_header3.setVisible(True)
                    self.flg_header3 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header3.setVisible(False)
                    self.txt_header3.setVisible(False)
                    self.flg_header3 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[8] == '1':
                    self.lbl_header4.setVisible(True)
                    self.txt_header4.setVisible(True)
                    self.flg_header4 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header4.setVisible(False)
                    self.txt_header4.setVisible(False)
                    self.flg_header4 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[9] == '1':
                    self.lbl_header5.setVisible(True)
                    self.txt_header5.setVisible(True)
                    self.flg_header5 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header5.setVisible(False)
                    self.txt_header5.setVisible(False)
                    self.flg_header5 = False
                    self.list_header_count.append('0')
            self.assign_header_control_names()
        except Exception as e:
            print(e)

    def assign_header_control_names(self):
        try:
            self.list_label_header_names = []
            self.list_text_header_names = []
            self.count_of_ones = self.list_header_count.count('1')
            if self.list_header_count[0] == '1':
                self.list_label_header_names.append(self.lbl_header1)
                self.list_text_header_names.append(self.txt_header1)
            if self.list_header_count[1] == '1':
                self.list_label_header_names.append(self.lbl_header2)
                self.list_text_header_names.append(self.txt_header2)
            if self.list_header_count[2] == '1':
                self.list_label_header_names.append(self.lbl_header3)
                self.list_text_header_names.append(self.txt_header3)
            if self.list_header_count[3] == '1':
                self.list_label_header_names.append(self.lbl_header4)
                self.list_text_header_names.append(self.txt_header4)
            if self.list_header_count[4] == '1':
                self.list_label_header_names.append(self.lbl_header5)
                self.list_text_header_names.append(self.txt_header5)
            self.list_text_header_names[0].setPlaceholderText("Enter Vehicle Number")
            self.list_label_header_names[0].move(5, 29)
            self.list_text_header_names[0].move(165, 25)
            self.list_text_header_names[0].setFocus()
            UiComponents.set_text_box_active_style(self, self.list_text_header_names[0])
        except Exception as e:
            print(e)

    def assign_code_control_names(self):
        self.list_label_code_names = []
        self.list_label_code_value_names = []
        self.list_cmb_code_names = []
        self.code_count_of_ones = self.list_code_count.count('1')
        if self.list_code_count[0] == '1':
            self.list_label_code_names.append(self.lbl_code1)
            self.list_cmb_code_names.append(self.cmb_code1)
            self.list_label_code_value_names.append(self.lbl_code_value1)
        if self.list_code_count[1] == '1':
            self.list_label_code_names.append(self.lbl_code2)
            self.list_cmb_code_names.append(self.cmb_code2)
            self.list_label_code_value_names.append(self.lbl_code_value2)
        if self.list_code_count[2] == '1':
            self.list_label_code_names.append(self.lbl_code3)
            self.list_cmb_code_names.append(self.cmb_code3)
            self.list_label_code_value_names.append(self.lbl_code_value3)
        if self.list_code_count[3] == '1':
            self.list_label_code_names.append(self.lbl_code4)
            self.list_cmb_code_names.append(self.cmb_code4)
            self.list_label_code_value_names.append(self.lbl_code_value4)
        if self.list_code_count[4] == '1':
            self.list_label_code_names.append(self.lbl_code5)
            self.list_cmb_code_names.append(self.cmb_code5)
            self.list_label_code_value_names.append(self.lbl_code_value5)
        self.list_label_code_names[0].move(9, 110)
        self.list_cmb_code_names[0].setFocus()
        self.list_cmb_code_names[0].move(170, 106)
        self.list_label_code_value_names[0].move(360, 106)

    def set_code_details(self):
        try:
            self.list_code_count = []
            self.lst_code_details = []
            self.lst_code_details.clear()
            self.lst_code_details = VehicleReEntryBL().get_code()
            if not len(self.lst_code_details) == 0:
                self.lbl_code1.setText(self.lst_code_details[0])
                self.lbl_code2.setText(self.lst_code_details[1])
                self.lbl_code3.setText(self.lst_code_details[2])
                self.lbl_code4.setText(self.lst_code_details[3])
                self.lbl_code5.setText(self.lst_code_details[4])
                if self.lst_code_details[5] == '1':
                    self.lbl_code1.setVisible(True)
                    self.cmb_code1.setVisible(True)
                    self.flg_code1 = True
                    self.lbl_code_value1.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code1.setVisible(False)
                    self.cmb_code1.setVisible(False)
                    self.flg_code1 = False
                    self.list_code_count.append('0')
                    self.lbl_code_value1.setVisible(False)
                if self.lst_code_details[6] == '1':
                    self.lbl_code2.setVisible(True)
                    self.cmb_code2.setVisible(True)
                    self.flg_code2 = True
                    self.lbl_code_value2.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code2.setVisible(False)
                    self.cmb_code2.setVisible(False)
                    self.flg_code2 = False
                    self.lbl_code_value2.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[7] == '1':
                    self.lbl_code3.setVisible(True)
                    self.cmb_code3.setVisible(True)
                    self.flg_code3 = True
                    self.lbl_code_value3.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code3.setVisible(False)
                    self.cmb_code3.setVisible(False)
                    self.flg_code3 = False
                    self.lbl_code_value3.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[8] == '1':
                    self.lbl_code4.setVisible(True)
                    self.cmb_code4.setVisible(True)
                    self.flg_code4 = True
                    self.lbl_code_value4.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code4.setVisible(False)
                    self.cmb_code4.setVisible(False)
                    self.flg_code4 = False
                    self.lbl_code_value4.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[9] == '1':
                    self.lbl_code5.setVisible(True)
                    self.cmb_code4.setVisible(True)
                    self.flg_code5 = True
                    self.lbl_code_value5.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code5.setVisible(False)
                    self.cmb_code5.setVisible(False)
                    self.flg_code5 = False
                    self.lbl_code_value5.setVisible(False)
                    self.list_code_count.append('0')
            self.assign_code_control_names()
        except Exception as e:
            print(e)

    def fill_code_items(self):
        try:
            self.clear_all_fields()
            code_list1 = VehicleEntryBL().get_code1()
            code_list2 = VehicleEntryBL().get_code2()
            code_list3 = VehicleEntryBL().get_code3()
            code_list4 = VehicleEntryBL().get_code4()
            code_list5 = VehicleEntryBL().get_code5()
            cmb_code_names = [self.cmb_code1, self.cmb_code2, self.cmb_code3, self.cmb_code4, self.cmb_code5]
            code_lists = [code_list1, code_list2, code_list3, code_list4, code_list5]
            for i in range(len(cmb_code_names)):
                self.add_combobox_items(cmb_code_names[i], code_lists[i])
        except OSError as e:
            print(e)

    def clear_all_fields(self):
        try:
            for each_txtbox in self.findChildren(QLineEdit):
                each_txtbox.setText("")
            for each_cmbbox in self.findChildren(QComboBox):
                each_cmbbox.clear()
            self.txt_net_weight.setText("NA")
        except OSError as e:
            print(e)

    def add_combobox_items(self, cmb, codes):
        try:
            for row_data in codes:
                cmb.addItems(row_data)
        except OSError as e:
            print(e)

    def input_char_validation(self):
        try:

            reg_ex = QRegExp("[A-Z0-9a-z]{,20}")
            input_validator = QRegExpValidator(reg_ex, self.txt_header1)
            self.txt_header1.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header2)
            self.txt_header2.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header3)
            self.txt_header3.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header4)
            self.txt_header4.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header5)
            self.txt_header5.setValidator(input_validator)
            r"^\d+(\.\d{1})?[Gg]?$"
            reg_num = QRegExp("^[1-9]\d*(\.\d+)?$")
            reg_num_gross = QRegExp("^\d+(\.\d{1})?[Gg]?$")
            reg_num_tare = QRegExp("^\d+(\.\d{1})?[Tt]?$")

            # Validator for gross weight input field
            input_validator_gross = QRegExpValidator(reg_num_gross, self.txt_gross_weight)
            self.txt_gross_weight.setValidator(input_validator_gross)

            # Validator for tare weight input field
            input_validator_tare = QRegExpValidator(reg_num_tare, self.txt_tare_weight)
            self.txt_tare_weight.setValidator(input_validator_tare)
            reg_ex_amount = QRegExp("[0-9DdSs]{,7}")
            # reg_ex = QRegExp("[0-9]{,6}")
            # input_validator = QRegExpValidator(reg_ex, self.txt_bag_weight)
            # self.txt_bag_weight.setValidator(input_validator)
            reg_ex_bag_count = QRegExp("[0-YyNn]{,6}")
            input_validator = QRegExpValidator(reg_ex_bag_count, self.txt_bag_count)
            self.txt_bag_count.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex_amount, self.txt_amount)
            self.txt_amount.setValidator(input_validator)
            self.txt_header1.setMaxLength(10)
            self.txt_header2.setMaxLength(15)
            self.txt_header3.setMaxLength(15)
            self.txt_header4.setMaxLength(15)
            self.txt_header5.setMaxLength(15)
        except Exception as e:
            print(e)

    def on_click_gross(self):
        try:
            self.get_type_details("Manual Entry", self.btn_manual, self.btn_manual)
            if self.btn_gross_weight.isEnabled():
                self.txt_gross_date_time.setText(str(datetime.now().strftime("%d-%m-%Y %H:%M:%S")))
                gunny = VehicleEntryBL().get_gunny_status()
                isVisible = True if int(gunny[0][0]) else False
                if isVisible:
                    self.btn_gunny_bag.setEnabled(True)
                else:
                    self.btn_gunny_bag.setEnabled(False)
                if self.flg_manual_mode:
                    self.pnl_manual_entry.setVisible(True)
                    self.btn_tare_weight.setEnabled(True)
                    self.btn_tare_weight_delete.setEnabled(True)
                if self.DisplayData:
                    self.txt_gross_weight.setText(str(Decimal(self.DisplayData)))
                    self.txt_amount.setEnabled(True)
                    UiComponents.gross_correct_image(self)
                self.netwt_calculation()
                if not self.flg_manual_mode:
                    self.pnl_manual_entry.setVisible(False)
                    self.btn_tare_weight.setEnabled(False)
                    self.btn_tare_weight_delete.setEnabled(True)
                    UiComponents.set_text_box_active_style(self, self.txt_amount)
                    self.txt_amount.setFocus()
        except OSError as e:
            print(e)

    def on_click_tare(self):
        try:
            # UiComponents.shortcuts(self)
            if self.btn_tare_weight.isEnabled():
                self.txt_tare_date_time.setText(str(datetime.now().strftime("%d-%m-%Y %H:%M:%S")))
                if self.flg_manual_mode and self.txt_gross_weight.text():
                    self.tarewt = self.txt_tare_weight.text()
                    UiComponents.tare_correct_image(self)
                    self.txt_amount.setEnabled(True)
                else:
                    if self.DisplayData:
                        self.flg_manual_mode = False
                        self.txt_tare_weight.setText(str(Decimal(self.DisplayData)))
                        self.txt_amount.setEnabled(True)
                        UiComponents.tare_correct_image(self)
                self.netwt_calculation()
                self.btn_gunny_bag.setEnabled(False)
                self.btn_gross_weight.setEnabled(False)
                UiComponents.set_text_box_active_style(self, self.txt_amount)
                self.txt_amount.setFocus()
        except OSError as e:
            print(e)

    def on_click_gross_wt_clr(self):
        try:
            self.txt_amount.setEnabled(False)
            self.pnl_manual_entry.setVisible(False)
            self.txt_gross_date_time.clear()
            self.txt_gross_weight.clear()
            self.txt_amount.clear()
            if self.flg_gunny_bag:
                self.btn_gunny_bag.setEnabled(True)
            else:
                self.btn_gunny_bag.setEnabled(False)
            UiComponents.ok_default(self, self.btn_gross_weight)
            self.netwt_calculation()
            self.btn_tare_weight.setEnabled(True)
            self.tmr_error_msg.start(1000)
        except OSError as e:
            print(e)

    def on_click_tare_wt_clr(self):
        try:
            self.txt_amount.setEnabled(False)
            self.pnl_manual_entry.setVisible(False)
            self.txt_tare_date_time.clear()
            self.txt_tare_weight.clear()
            self.txt_amount.clear()
            self.netwt_calculation()
            UiComponents.ok_default(self, self.btn_tare_weight)
            self.btn_gross_weight.setEnabled(True)
            self.tmr_error_msg.start(1000)
        except OSError as e:
            print(e)

    def get_previous_entry_details(self):
        try:
            self.return_entry_details = VehicleEntryBL().get_entry_details()
            if len(self.return_entry_details) > 0:
                self.fill_entry_details(self.return_entry_details)
        except Exception as e:
            print(e)

    def assign_entries(self):
        try:
            self.fill_code_items()
            self.txt_serial_no.setText(self.SerialNo)
            self.txt_header1.setText(self.Field1)
            self.txt_header2.setText(self.Field2)
            self.txt_header3.setText(self.Field3)
            self.txt_header4.setText(self.Field4)
            self.txt_header5.setText(self.Field5)
            self.cmb_code1.setCurrentText(self.Code1)
            self.cmb_code2.setCurrentText(self.Code2)
            self.cmb_code3.setCurrentText(self.Code3)
            self.cmb_code4.setCurrentText(self.Code4)
            self.cmb_code5.setCurrentText(self.Code5)
            self.lbl_code_value1.setText(self.code1_value)
            self.lbl_code_value2.setText(self.code2_value)
            self.lbl_code_value3.setText(self.code3_value)
            self.lbl_code_value4.setText(self.code4_value)
            self.lbl_code_value5.setText(self.code5_value)
            self.txt_gross_weight.setText(self.GrossWt)
            self.txt_tare_weight.setText(self.TareWt)
            # self.txt_net_weight.setText(self.NetWt)
            self.txt_gross_date_time.setText(self.GrossDate)
            self.txt_tare_date_time.setText(self.TareDate)
            self.txt_amount.setText(self.Amount)
        except OSError as e:
            print(e)

    def validate_default(self, mvalue):
        try:
            return str(mvalue) if mvalue is not None else ""
        except OSError as e:
            print(e)

    def fill_entry_details(self, mdata):
        try:
            self.SerialNo = self.validate_default(mdata[0][0])
            self.Field1 = self.validate_default(mdata[0][1])
            self.Field2 = self.validate_default(mdata[0][2])
            self.Field3 = self.validate_default(mdata[0][3])
            self.Field4 = self.validate_default(mdata[0][4])
            self.Field5 = self.validate_default(mdata[0][5])
            self.Code1 = self.validate_default(mdata[0][6])
            self.Code2 = self.validate_default(mdata[0][7])
            self.Code3 = self.validate_default(mdata[0][8])
            self.Code4 = self.validate_default(mdata[0][9])
            self.Code5 = self.validate_default(mdata[0][10])
            self.code1_value = self.validate_default(mdata[0][11])
            self.code2_value = self.validate_default(mdata[0][12])
            self.code3_value = self.validate_default(mdata[0][13])
            self.code4_value = self.validate_default(mdata[0][14])
            self.code5_value = self.validate_default(mdata[0][15])
            self.GrossWt = self.validate_default(mdata[0][16])
            self.Unit = self.validate_default(mdata[0][17])
            self.GrossDate = self.validate_default(mdata[0][19])
            self.TareWt = self.validate_default(mdata[0][20])
            self.TareDate = self.validate_default(mdata[0][23])
            self.Amount = self.validate_default(mdata[0][25])
            self.NetWt = self.validate_default(mdata[0][24])
            self.assign_entries()
        except Exception as e:
            print(e)

    def create_print_data(self):
        try:
            self.serial_print_data = ""
            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.header1 = self.return_header[0]
            self.header2 = self.return_header[1]
            self.header3 = self.return_header[2]
            width = 80
            self.serial_print_data = ""
            self.serial_print_data += f"{self.header1.center(width)}\n"
            self.serial_print_data += f"{self.header2.center(width)}\n"
            self.serial_print_data += f"{self.header3.center(width)}\n"

            self.serial_print_data += f"Vehicle Entry Bill                               DateTime:{date_string}" + "\n"
            self.serial_print_data += "==============================================================================" + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += Helper.get_table_data_as_string_old(self.tableWidget)
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "signature of the operator                               signature of the party" + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "==============================================================================" + "\n"
            self.serial_print_data += "                          LCS-for all your weighing needs                     " + "\n"
            print(self.serial_print_data)
        except Exception as e:
            print(e)

    def print_data(self):
        try:
            self.lstValueBillGross = []
            self.lstValue_NetTareWt = []
            self.PdfHeader1 = []
            self.PdfHeader2 = []
            self.PdfInputData1 = []
            self.PdfInputData2 = []
            self.PdfHeader1.clear()
            self.PdfInputData1.clear()
            self.PdfHeader1.append("Bill No")
            self.PdfInputData1.append(self.txt_serial_no.text())
            self.lst_fetch_Enable_Code = []
            self.print_details = SystemConfigBL().get_printer_configuration()
            self.return_header = GeneralSettingsBL().get_Parameters()
            if not len(self.print_details) == 0:
                if self.print_details[10] == '1':
                    self.PdfHeader2.append(self.print_details[0])
                    self.PdfInputData2.append(self.txt_header1.text())
                else:
                    pass
                if self.print_details[11] == '1':
                    self.PdfHeader2.append(self.print_details[1])
                    self.PdfInputData2.append(self.txt_header2.text())
                else:
                    pass
                if self.print_details[12] == '1':
                    self.PdfHeader2.append(self.print_details[2])
                    self.PdfInputData2.append(self.txt_header3.text())
                else:
                    pass
                if self.print_details[13] == '1':
                    self.PdfHeader2.append(self.print_details[3])
                    self.PdfInputData2.append(self.txt_header4.text())
                else:
                    pass
                if self.print_details[14] == '1':
                    self.PdfHeader2.append(self.print_details[4])
                    self.PdfInputData2.append(self.txt_header5.text())
                else:
                    pass
            if self.first_entry == "Gross":
                self.PdfHeader2.append("Gross Amount")
            elif self.first_entry == "Tare":
                self.PdfHeader2.append("Tare Amount")
            elif self.first_entry == "Manual":
                self.PdfHeader2.append("Amount")
            self.PdfInputData2.append(self.txt_amount.text())
            self.PdfHeader2.append("Tare Date/Time")
            self.PdfInputData2.append(self.txt_tare_date_time.text())
            self.PdfHeader2.append("Gross Date/Time")
            self.PdfInputData2.append(self.txt_gross_date_time.text())

            self.lst_fetch_Enable_Code = VehicleReEntryBL().get_code()
            if not len(self.print_details) == 0:
                if self.print_details[20] == '1':
                    self.PdfHeader1.append(self.print_details[5])
                    self.PdfInputData1.append(self.selected_code_1)
                else:
                    pass
                if self.print_details[21] == '1':
                    self.PdfHeader1.append(self.print_details[6])
                    self.PdfInputData1.append(self.selected_code_2)
                else:
                    pass
                if self.print_details[22] == '1':
                    self.PdfHeader1.append(self.print_details[7])
                    self.PdfInputData1.append(self.selected_code_3)
                else:
                    pass
                if self.print_details[23] == '1':
                    self.PdfHeader1.append(self.print_details[8])
                    self.PdfInputData1.append(self.selected_code_4)
                else:
                    pass
                if self.print_details[24] == '1':
                    self.PdfHeader1.append(self.print_details[9])
                    self.PdfInputData1.append(self.selected_code_5)
                else:
                    pass
            self.PdfHeader1.append("Net Wt  (" + self.lbl_unit.text() + ")")
            if self.flg_manual_mode:
                self.PdfHeader1.append("Tare Wt (" + self.lbl_unit.text() + ") *")
            else:
                self.PdfHeader1.append("Tare Wt (" + self.lbl_unit.text() + ")")
            if self.flg_gunny_bag:
                self.PdfHeader1.append("Gross Wt(" + self.lbl_unit.text() + ") #")
            else:
                self.PdfHeader1.append("Gross Wt(" + self.lbl_unit.text() + ")")
            self.PdfInputData1.append(self.txt_net_weight.text())
            self.PdfInputData1.append(self.txt_tare_weight.text())
            self.PdfInputData1.append(self.txt_gross_weight.text())
            self.tableWidget.clear()
            self.tableWidget.horizontalHeader().setVisible(False)
            self.tableWidget.verticalHeader().setVisible(False)
            self.tableWidget.setColumnCount(6)
            count = 0
            max_length = max(len(self.PdfHeader1), len(self.PdfHeader2))

            for idx in range(max_length):
                self.tableWidget.setColumnWidth(0, 10)
                self.tableWidget.setColumnWidth(1, 10)
                self.tableWidget.setColumnWidth(2, 10)
                self.tableWidget.setColumnWidth(3, 10)
                self.tableWidget.setColumnWidth(4, 10)
                self.tableWidget.setColumnWidth(5, 10)
                self.tableWidget.insertRow(idx)
                self.tableWidget.setRowHeight(idx, 65)
                # Check if index exists in the first list
                if idx < len(self.PdfHeader1):
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem(self.PdfHeader1[idx].rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem(self.PdfInputData1[idx].ljust(16)))
                else:
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem("".rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem("".ljust(19)))
                # Check if index exists in the second list
                if idx < len(self.PdfHeader2) and count < len(self.PdfInputData2):
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem(self.PdfHeader2[count].rjust(20)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem(self.PdfInputData2[count].ljust(20)))
                    count += 1
                else:
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem("".rjust(20)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem("".ljust(20)))
            self.create_print_data()
            self.create_print_format()
        except Exception as e:
            print(e)

    def create_print_format(self):
        try:
            self.dashed_line = ""
            self.empty_space = " "
            self.span_space = "&nbsp;" * 80  # Create 20 non-breaking spaces
            self.dashed_line = self.dashed_line.ljust(80, "=")
            self.empty_space = self.empty_space.ljust(80, " ")
            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.table_data = "<p>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[0] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[1] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[2] + "</h6>"
            self.table_data += "<div>"
            self.table_data += "<span>Vehicle Entry Bill</span>"
            self.table_data += " <span>{}</span>".format("&nbsp;" * 40)
            self.table_data += "<span>DateTime: {}</span>".format(date_string)
            self.table_data += "</div>"
            self.table_data += self.dashed_line + "\n"
            # self.table_data += "<br>"
            self.table_data += Helper.get_table_data_as_string(self, self.tableWidget)
            self.table_data += "<br>"
            self.table_data += "<div>"
            self.table_data += "<span>signature of the operator</span>"
            self.table_data += " <span>{}</span>".format(self.span_space)
            self.table_data += "<span>signature of the party</span>"
            self.table_data += "</div>"
            self.table_data += "<br>"
            self.table_data += self.dashed_line + "\n"
            self.table_data += "<div style='text-align: center;'>LCS-for all your weighing needs</div>"
            self.table_data += "</p>"
            return self.table_data
        except Exception as e:
            print(e)

    def on_click_print(self):
        try:
            self.print_details = SystemConfigBL().get_printer_port()
            import serial
            # Open a connection to the printer on the specified serial port
            ser = serial.Serial(self.print_details[0], self.print_details[1], timeout=1)
            self.bytes_to_send = bytes(self.serial_print_data, "utf-8")
            ser.write(self.bytes_to_send)
            ser.close()
            self.setToolTipCorrectMessage("printed successfully")
            self.bytes_to_send = ""
            self.serial_print_data = ""
            if self.bytes_to_send == "":
                self.disable_timers()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen = MainScreen(self)
                self.main_screen.show()
                self.hide()
        except OSError as e:
            print(e)

    def on_click_preview(self):
        try:
            self.pnl_max_preview.move(0, 36)
            self.display_preview()
            pass
        except Exception as e:
            print(e)

    def on_click_close_preview(self):
        try:
            self.pnl_max_preview.move(50000000, 36)
            pass
        except Exception as e:
            print(e)

    def display_preview(self):
        try:
            self.print_result = ""
            if self.table_data:
                self.lbl_max_preview.clear()
                self.lbl_max_preview.setText(str(self.table_data))
                font = self.lbl_max_preview.font()
                font.setPointSize(10)
                self.lbl_max_preview.setFont(font)
                self.lbl_max_preview.setWordWrap(True)
                # Set size policy to allow the label to expand horizontally and vertically
                self.lbl_max_preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                # Adjust size hint to minimum size hint
                self.lbl_max_preview.adjustSize()
            pass
        except Exception as e:
            print(e)

    def combo_box_styles(self):
        try:
            self.cmb_input_names = [self.cmb_code1, self.cmb_code2, self.cmb_code3, self.cmb_code4, self.cmb_code5]
            for i in range(len(self.cmb_input_names)):
                UiComponents.set_bordered_combo_box(self, self.cmb_input_names[i])
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_app_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lblLogo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            pass

    def get_active_textboxes(self):
        try:
            self.flg_check_line_edit = False
            for line_edit in self.list_text_header_names:
                if line_edit.text():
                    self.flg_check_line_edit = True
                    return
                else:
                    self.flg_check_line_edit = False
        except Exception as e:
            print(e)

    def create_custom_combobox(self):
        try:
            self.cmb_code1 = ExtendedComboBox(self.widget)
            self.cmb_code1.setParent(self.widget)
            self.cmb_code1.setGeometry(2060, 200, 181, 41)
            self.cmb_code1.setMaxVisibleItems(5)
            self.cmb_code2 = ExtendedComboBox(self.widget)
            self.cmb_code2.setParent(self.widget)
            self.cmb_code2.setGeometry(20650, 2600, 181, 41)
            self.cmb_code2.setMaxVisibleItems(5)
            self.cmb_code3 = ExtendedComboBox(self.widget)
            self.cmb_code3.setParent(self.widget)
            self.cmb_code3.setGeometry(29800, 2060, 181, 41)
            self.cmb_code3.setMaxVisibleItems(5)
            self.cmb_code4 = ExtendedComboBox(self.widget)
            self.cmb_code4.setParent(self.widget)
            self.cmb_code4.setGeometry(27600, 2600, 181, 41)
            self.cmb_code4.setMaxVisibleItems(5)
            self.cmb_code5 = ExtendedComboBox(self.widget)
            self.cmb_code5.setParent(self.widget)
            self.cmb_code5.setGeometry(25600, 2060, 181, 41)
            self.cmb_code5.setMaxVisibleItems(5)
        except Exception as e:
            print(e)

    @pyqtSlot(int)
    def update_wifi_status(self, status_code):
        try:
            self.wifi_status_code = status_code
            if self.wifi_status_code == 1:
                # self.lblWifiStatus.setStyleSheet("background-color:green;")
                UiComponents.wifi_status_on(self)
            elif self.wifi_status_code == 0:
                # self.lblWifiStatus.setStyleSheet("background-color:red;")
                UiComponents.wifi_status_off(self)
        except Exception as e:
            print(e)
