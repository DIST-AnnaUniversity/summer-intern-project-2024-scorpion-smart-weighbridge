from PyQt5.QtWidgets import QLineEdit, QCheckBox, QPushButton, QTableWidgetItem, QHeaderView

from BusinessLogic.ParameterSettingsBL import ParameterSettingsBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Utilities.GlobalEntities import GlobalEntities


class ParameterSettings:
    def __init__(self):
        super().__init__()

    def disable_verified_status(self):
        try:
            for index in range(len(self.label_status)):
                self.label_status[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    '''Header Parameter Configuration logic'''

    def on_loading_parameter_settings(self):
        try:
            ParameterSettings.update_controls_state(self, False)
            ParameterSettings.get_configured_header_settings(self)
            pass
        except Exception as e:
            print(e)

    def update_controls_state(self, state):
        try:
            for text_box in self.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for check_box in self.findChildren(QCheckBox):
                check_box.setEnabled(state)
            self.btn_header_save.setEnabled(state)
            self.btn_entry.setEnabled(state)
            self.btn_re_entry.setEnabled(state)
            self.chk_header1.setEnabled(False)
            self.chk_Reheader1.setEnabled(False)
            pass
        except Exception as e:
            print(e)

    def save_header_parameters(self):
        try:
            if ParameterSettings.get_header_parameters(self):
                ParameterSettings.get_configured_header_settings(self)
                ParameterSettings.update_controls_state(self, False)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                self.btn_entry.setStyleSheet("QPushButton::disabled"
                                             "{"
                                             "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                             "}"
                                             )
                self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                                "{" 
                                                "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )
            pass
        except Exception as e:
            print(e)

    def validate_entered_details(self):
        try:
            for index in range(len(self.label_status)):
                self.label_status[index].setVisible(False)
            self.text_box_count = 0
            for text_box in self.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
        except Exception as e:
            print(e)

    def get_header_parameters(self):
        try:
            if ParameterSettings.validate_entered_details(self):
                self.lst_header_parameters = []
                ParameterSettings.get_check_box_select_status(self)
                self.lst_header_parameters.append(str(self.lbl_header1.text()))
                self.lst_header_parameters.append(str(self.lbl_header2.text()))
                self.lst_header_parameters.append(str(self.lbl_header3.text()))
                self.lst_header_parameters.append(str(self.lbl_header4.text()))
                self.lst_header_parameters.append(str(self.lbl_header5.text()))
                for count, items in enumerate(GlobalEntities.header_params_checkbox.items()):
                    self.lst_header_parameters.append(items[1])
                self.result = ParameterSettingsBL().Update_Headers(self.lst_header_parameters)
                return True
            return False
            pass
        except Exception as e:
            print(e)
            return False

    def get_configured_header_settings(self):
        try:
            self.lst_header_parameters = ParameterSettingsBL().Get_Code()
            if self.lst_header_parameters is not None:
                ParameterSettings.assign_check_box_selected_status(self, self.lst_header_parameters)
                self.lbl_header1.setText(str(self.lst_header_parameters[0]))
                self.lbl_header2.setText(str(self.lst_header_parameters[1]))
                self.lbl_header3.setText(str(self.lst_header_parameters[2]))
                self.lbl_header4.setText(str(self.lst_header_parameters[3]))
                self.lbl_header5.setText(str(self.lst_header_parameters[4]))

        except Exception as e:
            print(e)

    ''' To get the status of Entry and Re-Entry checkbox '''

    def get_check_box_select_status(self):
        try:
            for index in range(len(GlobalEntities.header_checkbox_names)):
                self.check_box_name = GlobalEntities.header_checkbox_names[index].objectName()
                if GlobalEntities.header_checkbox_names[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})

            for index in range(len(GlobalEntities.re_header_checkbox_names)):
                self.check_box_name = GlobalEntities.re_header_checkbox_names[index].objectName()
                if GlobalEntities.re_header_checkbox_names[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})
            pass
        except Exception as e:
            print(e)

    '''For assigning selected status of checkbox '''

    def assign_check_box_selected_status(self, lst_parameters):
        try:
            for count, item in enumerate(GlobalEntities.header_params_checkbox.items()):
                GlobalEntities.header_params_checkbox.update({item[0]: lst_parameters[count + 5]})
            for count, item in enumerate(GlobalEntities.header_params_checkbox.items()):
                if count <= 4:
                    if item[1] == "1":
                        GlobalEntities.header_checkbox_names[count].setChecked(True)
                    else:
                        GlobalEntities.header_checkbox_names[count].setChecked(False)
                elif count >= 5:
                    if item[1] == "1":
                        GlobalEntities.re_header_checkbox_names[count - 5].setChecked(True)
                    else:
                        GlobalEntities.re_header_checkbox_names[count - 5].setChecked(False)
            pass
        except Exception as e:
            print(e)

    '''Code Parameter Configuration logic'''

    def on_loading_code_parameter_settings(self):
        try:
            ParameterSettings.update_code_controls_state(self, False)
            ParameterSettings.get_configured_code_settings(self)
            pass
        except Exception as e:
            print(e)

    def update_code_controls_state(self, state):
        try:
            for text_box in self.frm_code_entered_details.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for check_box in self.frm_code_entered_details.findChildren(QCheckBox):
                check_box.setEnabled(state)

            for button in self.frm_code_entered_details.findChildren(QPushButton):
                button.setEnabled(state)
            self.btn_code_edit.setEnabled(True)
            self.chk_code1.setEnabled(False)
            self.chk_re_code1.setEnabled(False)
            pass
        except Exception as e:
            print(e)

    def save_code_parameters(self):
        try:
            if ParameterSettings.get_code_parameters(self):
                ParameterSettings.get_configured_code_settings(self)
                ParameterSettings.update_code_controls_state(self, False)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                self.btn_entry.setStyleSheet("QPushButton::disabled"
                                             "{"
                                             "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                             "}"
                                             )
                self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                                "{"
                                                "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )
            pass
        except Exception as e:
            print(e)

    def validate_entered_code_details(self):
        try:
            for index in range(len(self.label_status)):
                self.label_status[index].setVisible(False)
            self.text_box_count = 0
            for text_box in self.frm_code_entered_details.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
        except Exception as e:
            print(e)

    def get_code_parameters(self):
        try:
            if ParameterSettings.validate_entered_code_details(self):
                self.lst_header_parameters = []
                ParameterSettings.get_check_box_select_status(self)
                self.lst_header_parameters.append(str(self.lbl_code1.text()))
                self.lst_header_parameters.append(str(self.lbl_code2.text()))
                self.lst_header_parameters.append(str(self.lbl_code3.text()))
                self.lst_header_parameters.append(str(self.lbl_code4.text()))
                self.lst_header_parameters.append(str(self.lbl_code5.text()))
                for count, items in enumerate(GlobalEntities.header_params_checkbox.items()):
                    self.lst_header_parameters.append(items[1])
                self.result = ParameterSettingsBL().Update_Codes(self.lst_header_parameters)
                return True
            return False
            pass
        except Exception as e:
            print(e)
            return False

    def get_configured_code_settings(self):
        try:
            self.lst_header_parameters = ParameterSettingsBL().Get_Code_details()
            if self.lst_header_parameters is not None:
                ParameterSettings.assign_check_box_selected_status(self, self.lst_header_parameters)
                self.lbl_code1.setText(str(self.lst_header_parameters[0]))
                self.lbl_code2.setText(str(self.lst_header_parameters[1]))
                self.lbl_code3.setText(str(self.lst_header_parameters[2]))
                self.lbl_code4.setText(str(self.lst_header_parameters[3]))
                self.lbl_code5.setText(str(self.lst_header_parameters[4]))

        except Exception as e:
            print(e)

    def validate_code_details_entry(self):
        try:
            self.text_box_count = 0
            for text_box in self.frm_code_details.findChildren(QLineEdit):
                self.code_label_status[self.text_box_count].setVisible(False)
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.code_label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
            pass
        except Exception as e:
            print(e)

    def save_code_details(self, code_no, update_status, prev_code):
        try:
            if ParameterSettings.validate_code_details_entry(self):
                self.code_parameters = []
                self.code_parameters.append(self.txt_code_name.text())
                self.code_parameters.append(self.txt_code_value.text())
                if update_status:
                    self.code_parameters.append(prev_code)
                    self.result = ParameterSettingsBL().update_Parameters(self.code_parameters, code_no)

                else:
                    self.result = ParameterSettingsBL().Add_Code1_Parameters(self.code_parameters, code_no)
                pass
            pass
        except Exception as e:
            print(e)

    def fill_code_details(self, code_no):
        try:
            self.dgv_code_details.setRowCount(0)
            self.result = ParameterSettingsBL().get_Parameters(code_no)
            self.dgv_code_details.setColumnCount(2)

            self.dgv_code_details.setColumnWidth(0, 222)
            self.dgv_code_details.setColumnWidth(1, 225)

            self.dgv_code_details.setHorizontalHeaderLabels(
                ['Code', 'Value'])
            for row_number, row_data in enumerate(self.result):
                self.dgv_code_details.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.dgv_code_details.setItem(row_number, column_number, QTableWidgetItem(str(data)))
            ParameterSettings.init_code_details_view(self)
            for text_box in self.frm_code_details.findChildren(QLineEdit):
                text_box.setText("")
            pass
        except Exception as e:
            print(e)

    def assign_code_params_entry_events(self):
        try:
            GlobalEntities.text_box_entry_count = 1
            GlobalEntities.text_box_contents.clear()
            GlobalEntities.text_box_contents = [self.lbl_code1, self.lbl_code2, self.lbl_code3, self.lbl_code4,
                                                self.lbl_code5]
            self.lbl_code1.setFocus()
            GlobalEntities.parameter_active_screen_events.update({"save": self.on_click_code_save})
            GlobalEntities.parameter_active_screen_events.update({"yes": self.on_click_code_save_ok})
            GlobalEntities.parameter_active_screen_events.update({"no": self.on_click_code_hide})
            pass
        except Exception as e:
            print(e)

    def assign_entry_details_params_events(self):
        try:
            GlobalEntities.text_box_entry_count = 1
            GlobalEntities.text_box_contents.clear()
            GlobalEntities.text_box_contents = [self.txt_code_name, self.txt_code_value]
            self.txt_code_name.setFocus()
            GlobalEntities.parameter_active_screen_events.update({"save": self.on_click_code_details_save})
            GlobalEntities.parameter_active_screen_events.update({"yes": None})
            GlobalEntities.parameter_active_screen_events.update({"no": None})
            pass
        except Exception as e:
            print(e)

    def init_code_details_view(self):
        try:
            self.btn_add_code.setEnabled(True)
            self.btn_code_details_edit.setEnabled(True)
            self.btn_code_details_save.setEnabled(False)
            self.txt_code_name.setEnabled(False)
            self.txt_code_value.setEnabled(False)
            pass
        except Exception as e:
            print(e)

    def get_other_settings_status(self):
        try:
            self.general_config = ParameterSettingsBL().Get_Other_settings()
            if not len(self.general_config) <= 0:
                self.amount_status = self.general_config[0]
                self.date_time_status = str(self.general_config[1])
                self.gunny_status = str(self.general_config[2])
                self.unit_value = str(self.general_config[3])
                self.manual_status = str(self.general_config[5])
                self.manual_mode = str(self.general_config[6])
                ParameterSettings.set_other_settings_status(self)
                ParameterSettings.update_other_settings_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def set_other_settings_status(self):
        try:
            if self.amount_status == "1":
                self.btn_amount_enable.raise_()
                self.btn_amount_disable.lower()
            else:
                self.btn_amount_enable.lower()
                self.btn_amount_disable.raise_()
            if self.date_time_status == "1":
                self.btn_date_enable.raise_()
                self.btn_date_disable.lower()
            else:
                self.btn_date_enable.lower()
                self.btn_date_disable.raise_()

            if self.gunny_status == "1":
                self.btn_gunny_enable.raise_()
                self.btn_gunny_disable.lower()
            else:
                self.btn_gunny_enable.lower()
                self.btn_gunny_disable.raise_()
            if self.manual_status == "1": # auto =1 and manual =0
                if self.manual_mode == "1":
                    UiComponents.update_toggle_style_sheet(self, self.btn_auto, self.btn_manual)
                else:
                    UiComponents.update_toggle_style_sheet(self, self.btn_manual, self.btn_auto)
                self.btn_auto.setVisible(True)
                self.btn_manual.setVisible(True)
                self.btn_manual_enable.raise_()
                self.btn_manual_disable.lower()
            else:
                self.btn_auto.setVisible(False)
                self.btn_manual.setVisible(False)
                self.btn_manual_enable.lower()
                self.btn_manual_disable.raise_()
            if self.unit_value == "Kg":
                UiComponents.update_toggle_style_sheet(self, self.btn_unit_1, self.btn_unit_2)
            else:
                UiComponents.update_toggle_style_sheet(self, self.btn_unit_2, self.btn_unit_1)
            pass
        except Exception as e:
            print(e)

    def save_other_settings(self):
        try:
            self.other_configs = []
            self.other_configs.append(self.amount_status)
            self.other_configs.append(self.date_time_status)
            self.other_configs.append(self.gunny_status)
            self.other_configs.append(self.unit_value)
            self.other_configs.append(self.manual_status)
            self.other_configs.append(self.manual_mode)
            self.result = ParameterSettingsBL().Save_ParameterOther_Settings(self.other_configs)
            ParameterSettings.update_other_settings_controls_state(self, False)
            MessagePopup.setting_msg_popup(self, "correct", "Saved Successfully !! ")
            pass
        except Exception as e:
            print(e)

    def update_other_settings_controls_state(self, state):
        try:
            for button in self.frm_other_settings.findChildren(QPushButton):
                button.setEnabled(state)
            self.btn_other_param_edit.setEnabled(not state)
            self.btn_other_param_save.setEnabled(state)

        except Exception as e:
            print(e)
