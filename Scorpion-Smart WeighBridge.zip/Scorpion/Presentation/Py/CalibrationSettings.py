import time
from datetime import datetime

from PyQt5.QtCore import QTimer, QRegExp
from PyQt5.QtGui import QPixmap, QRegExpValidator
from PyQt5.QtWidgets import QPushButton, QLineEdit, QComboBox

from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from decimal import Decimal


class CalibrationSettings:
    def __init__(self):
        super().__init__()

    def update_calibration_controls_state(self, state):
        try:
            for button in self.frmCalibration.findChildren(QPushButton):
                button.setEnabled(state)
            for text_box in self.frmCalibration.findChildren(QLineEdit):
                text_box.setEnabled(state)
            for combo_box in self.frmCalibration.findChildren(QComboBox):
                combo_box.setEnabled(state)
            self.btnEditCalibration.setEnabled(not state)

            self.frm_sub_menu.setEnabled(not state)
            for count, item in enumerate(self.dict_main_menu.items()):
                item[1].setEnabled(not state)
            self.Home.setEnabled(not state)
            if self.flg_auto_mode:
                self.txtCalSpan.setEnabled(False)
                self.txtCalZero.setEnabled(False)
            else:
                self.txtCalSpan.setEnabled(True)
                self.txtCalZero.setEnabled(True)
            self.btn_manual.setEnabled(True)
            self.btn_auto.setEnabled(True)

        except Exception as e:
            print(e)

    def auto_mode(self):
        try:
            UiComponents.calibration_auto_toggle(self)
            self.flg_auto_mode = True
            self.txtCalSpan.setEnabled(False)
            self.txtCalZero.setEnabled(False)
            UiComponents.calibration_normal_state(self)
            CalibrationSettings.disable_lable_status(self, False)
        except Exception as e:
            print(e)

    def manual_mode(self):
        try:
            UiComponents.calibration_manual_toggle(self)
            self.flg_auto_mode = False
            self.txtCalSpan.setEnabled(True)
            self.txtCalZero.setEnabled(True)
            UiComponents.calibration_normal_state(self)
            CalibrationSettings.disable_lable_status(self, False)
        except Exception as e:
            print(e)

    def init_calibration(self):
        try:
            CalibrationSettings.Get_DateTime_fromDB(self)
            GlobalVariable.FlagWriteDecimal = True
            self.FlagWriteData = True
            self.FlagReadData = False
            self.FlagDisplayData = False
            self.FlagWriteAllParams = False
            self.FlagWriteAll = False
            # self.flg_auto_mode = True
            self.WriteProtocol = ""
            self.GetCRC = ""
            self.negative_sign = ""
            self.ReadData = ""
            self.converted_negative_status = ""
            self.WriteProtocol = "01030064000a8412"
            self.WriteSuccessfull = False
            self.FlagReadonly = False
            self.flgResponse = False
            self.FlagLoad = True
            self.FlagWriteDecimal = False
            self.FlagWriteResolution = False
            self.FlagWriteCalCapacity = False
            self.FlagWriteCalSpan = False
            self.FlagWriteCalZero = False
            self.FlagWriteMaxCapacity = False
            self.FlagUpdateSuccessfully = False

            # RawAdc Flags
            self.FlagWriteRawAdc = False
            self.FlagReadRawAdc = False
            self.FlagDisplayRawAdc = False
            self.FlagUpdateDataRawAdc = True

            self.FlagWriteDataAll = False

            self.FlagRawAdc = False
            self.FlagCheckResolution = False
            self.DefaultResolution = ['1', '2', '5', '10', '20', '50', '100']
            self.cmbResolution.addItems(self.DefaultResolution)
            self.DefaultDecimalvalues = ['0', '1', '2', '3']
            self.cmbDecimalPoint.addItems(self.DefaultDecimalvalues)

            self.DefaultUnit = ['g', 'kg', 'tonnes']
            self.cmbUnit.addItems(self.DefaultUnit)

            self.timerWriteData.timeout.connect(self.WriteDataToController)
            self.timerWriteData.start(100)
            self.timerReadData.timeout.connect(self.ReadControllerData)
            self.timerReadData.start(100)

            self.timerShowData.timeout.connect(self.UpdateReadData)
            self.timerShowData.start(100)

            self.timerWriteRawAdc.timeout.connect(self.WriteData)
            self.timerWriteRawAdc.start(100)

            self.timerReadRawAdc.timeout.connect(self.functionToReadRawAdcData)
            self.timerReadRawAdc.start(100)

            self.timerShowRawAdc.timeout.connect(self.UpdateData)
            self.timerShowRawAdc.start(100)

            self.timerWriteAllData.timeout.connect(self.writeAllParameters)
            self.timerWriteAllData.start(200)

            self.timerUpdateSuccessfully.timeout.connect(self.UpdateAllParameters)
            self.timerUpdateSuccessfully.start(200)

            self.timerWriteData1.timeout.connect(self.WriteDataToController1)
            self.timerWriteData1.start(200)

            self.timerWriteCurrentLoad.timeout.connect(self.write_current_load)
            self.timerWriteCurrentLoad.setInterval(100)
            self.timerReadCurrentLoad.timeout.connect(self.read_current_load)
            self.timerReadCurrentLoad.setInterval(100)

            self.timerShowCurrentLoad.timeout.connect(self.display_current_load)
            self.timerShowCurrentLoad.setInterval(100)
            CalibrationSettings.input_validation(self)
        except Exception as e:
            print(e)

    def input_validation(self):
        try:
            reg_ex = QRegExp("[0-9]{,7}")
            input_validator_cal_span = QRegExpValidator(reg_ex, self.txtCalSpan)
            self.txtCalSpan.setValidator(input_validator_cal_span)
            input_validator_cal_zero = QRegExpValidator(reg_ex, self.txtCalZero)
            self.txtCalZero.setValidator(input_validator_cal_zero)

        except Exception as e:
            print(e)

    def disable_lable_status(self, state):
        try:
            self.lblDecimalPointStatus.setVisible(state)
            self.lblMaxCapacityStatus.setVisible(state)
            self.lblCalZeroStatus.setVisible(state)
            self.lblCalSpanStatus.setVisible(state)
            self.lblResolutionStatus.setVisible(state)
            self.lblCalCapacityStatus.setVisible(state)
            pass
        except Exception as e:
            print(e)

    def init_current_load_timer(self):
        try:
            self.timerWriteCurrentLoad.start()
            self.timerReadCurrentLoad.start()
            self.timerShowCurrentLoad.start()

            self.timerWriteRawAdc.stop()
            self.timerReadRawAdc.stop()
            self.timerShowRawAdc.stop()
            pass
        except Exception as e:
            print(e)

    def disable_current_load(self):
        try:
            self.timerWriteCurrentLoad.stop()
            self.timerReadCurrentLoad.stop()
            self.timerShowCurrentLoad.stop()
            self.timerWriteRawAdc.start(100)
            self.timerReadRawAdc.start(100)
            self.timerShowRawAdc.start(100)
            pass
        except Exception as e:
            print(e)

    def Get_DateTime_fromDB(self):
        try:
            self.calibrated_date = ""
            self.calibrated_user = ""
            self.Calibrated_Datetime = SystemConfigBL().get_DateTime()
            if not len(self.Calibrated_Datetime) == 0:
                self.calibrated_date = str(self.Calibrated_Datetime[0])
                self.calibrated_user = str(self.Calibrated_Datetime[1])
                self.calibrated_mode = str(self.Calibrated_Datetime[2])
                self.lblDateTime.setText(
                    self.calibrated_date + " - " + self.calibrated_user)
                self.lbl_mode.setText(self.calibrated_mode)
                if self.calibrated_mode == "Auto":
                    CalibrationSettings.auto_mode(self)
                else:
                    CalibrationSettings.manual_mode(self)
        except Exception as e:
            print(e)

    def write_current_load(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagWriteDecimal:
                    GlobalVariable.TempDecimalWriteProtocol = bytes.fromhex(ModbusProtocols.DecimalWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempDecimalWriteProtocol)
                    GlobalVariable.TempDecimalWriteProtocol = ""
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadDecimal = True
                    GlobalVariable.FlagReadLoad = False
                    GlobalVariable.FlagWriteDecimal = False
                elif GlobalVariable.FlagWriteLoad:
                    GlobalVariable.TempLoadWriteProtocol = bytes.fromhex(ModbusProtocols.CurrentLoadWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempLoadWriteProtocol)
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadLoad = True
                    pass
            pass
        except Exception as e:
            print(e)

    def read_current_load(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagStartRead:
                    self.ReadData = GlobalVariable.Serial_Port.read_all().hex()
                    if not self.ReadData is None:
                        if GlobalVariable.FlagReadDecimal:
                            self.DecimalReadData = self.ReadData
                            if len(self.DecimalReadData) == ModbusProtocols.DecimalReadProtocolLength:
                                GlobalVariable.DecimalPoint = self.DecimalReadData[6: 10]
                                GlobalVariable.DecimalPoint = Modbus.ConvertToInt(self, GlobalVariable.DecimalPoint)
                                GlobalVariable.FlagReadDecimal = False
                                GlobalVariable.FlagWriteLoad = True
                                pass
                        if GlobalVariable.FlagReadLoad:  # 01030a00010c41000000d4000035df
                            self.LoadReadData = self.ReadData
                            if len(self.LoadReadData) == ModbusProtocols.LoadReadProtocolLength:
                                self.negative_sign = self.LoadReadData[6:10]
                                self.converted_negative_status = Modbus.ConvertToInt(self, self.negative_sign)
                                self.GetLoad = self.LoadReadData[22:26] + self.LoadReadData[18:22]  # 000002d4
                                self.Tempdisplaydata = Modbus.ConvertToInt(self, self.GetLoad)
                                self.TempDisplay = str(self.Tempdisplaydata)
                                if len(self.TempDisplay) == 4:
                                    self.TempDisplay = "0" + self.TempDisplay
                                elif len(self.TempDisplay) == 3:
                                    self.TempDisplay = "00" + self.TempDisplay
                                elif len(self.TempDisplay) == 2:
                                    self.TempDisplay = "000" + self.TempDisplay
                                elif len(self.TempDisplay) == 1:
                                    self.TempDisplay = "0000" + self.TempDisplay
                                N = 5 - int(GlobalVariable.DecimalPoint)
                                if not N == 5:
                                    self.DisplayData = str(self.TempDisplay)[:N] + "." + str(self.TempDisplay)[
                                                                                         N:]
                                else:
                                    self.DisplayData = str(self.TempDisplay)
                                GlobalVariable.FlagDisplayData = True
            pass
        except Exception as e:
            print(e)

    def display_current_load(self):
        try:
            if GlobalVariable.FlagDisplayData:
                if not self.DisplayData == "":
                    CalibrationSettings.Display(self, self.DisplayData, self.TempDisplay)
            pass
        except Exception as e:
            print(e)

    def Display(self, displayData, checkStatusDisplayData):
        try:
            if not displayData == "":
                if checkStatusDisplayData.__contains__("99999"):
                    self.txtCurrentLoad.setText(str("-OR-"))
                elif checkStatusDisplayData.__contains__("77777"):
                    self.txtCurrentLoad.setText(str("-UR-"))
                elif checkStatusDisplayData.__contains__("88888"):
                    self.txtCurrentLoad.setText(str("-OC-"))
                else:
                    if str(self.converted_negative_status) == '1':
                        self.txtCurrentLoad.setText(str('-' + str(Decimal(displayData))))
                    else:
                        self.txtCurrentLoad.setText(str(Decimal(displayData)))
        except OSError as e:
            print(e)

    def start_calibration(self):
        try:
            self.FlagWriteAll = True
            self.FlagWriteDecimal = True
            pass
        except Exception as e:
            print(e)

    def reset_calibration(self):
        try:
            UiComponents.calibration_normal_state(self)
            self.ReadData = ""
            self.WriteProtocol = "01030064000a8412"
            self.FlagWriteData = True
            self.FlagWriteRawAdc = False
            self.FlagReadRawAdc = False
            pass
        except Exception as e:
            print(e)

    def apply_cal_zero(self):
        try:
            if self.flg_auto_mode:
                self.txtCalZero.setText(str(self.txtRawADC.text()))
                if self.txtCalZero.text():
                    UiComponents.calibration_completed_status(self, self.btnApplyCalZero)
            else:
                if self.txtCalZero.text():
                    UiComponents.calibration_completed_status(self, self.btnApplyCalZero)
            self.txtCalZero.setEnabled(False)
        except Exception as e:
            print(e)

    def apply_cal_span(self):
        try:
            if self.flg_auto_mode:
                self.txtCalSpan.setText(str(self.txtRawADC.text()))
                if self.txtCalSpan.text():
                    UiComponents.calibration_completed_status(self, self.btnApplyCalSpan)
            else:
                if self.txtCalSpan.text():
                    UiComponents.calibration_completed_status(self, self.btnApplyCalSpan)
            self.txtCalSpan.setEnabled(False)
        except Exception as e:
            print(e)

    def WriteDataToController(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.FlagWriteData:
                    self.ReadData = ""
                    self.TempWriteCalibProtocol = bytes.fromhex(self.WriteProtocol)
                    GlobalVariable.Serial_Port.write(self.TempWriteCalibProtocol)
                    self.TempWriteCalibProtocol = ""
                    self.FlagWriteData = False
                    self.FlagReadData = True
                    pass
            pass
        except OSError as e:
            print(e)

    def ReadControllerData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.FlagReadData:
                    self.ReadData = ""
                    self.ReadData = GlobalVariable.Serial_Port.read_all().hex()
                    # print(self.ReadData)
                    if not self.ReadData is None and not self.ReadData == "" and not self.FlagWriteAllParams:
                        if len(self.ReadData) == 50:
                            self.ResponseData = self.ReadData
                            CalibrationSettings.SubString_All_Parameters(self, self.ResponseData)
                            self.FlagReadData = False
                            self.ResponseData = ""
                        else:
                            self.FlagWriteData = True
                    else:
                        if self.ReadData.__contains__("0106"):
                            # self.FlagWriteData = True
                            pass
        except OSError as e:
            print(e)

    def SubString_All_Parameters(self, ResponseData):
        try:
            self.listAllParameters = []
            self.listData = []
            self._MaxCapacity = ResponseData[10:14] + ResponseData[6:10]
            self.listAllParameters.append(self._MaxCapacity)
            self._DecimalPoint = ResponseData[14:18]
            self.listAllParameters.append(self._DecimalPoint)
            self._Resolution = ResponseData[18:22]
            self.listAllParameters.append(self._Resolution)
            self._CalCapacity = ResponseData[42:46] + ResponseData[38:42]
            self.listAllParameters.append(self._CalCapacity)
            self._CalZero = ResponseData[26:30] + ResponseData[22:26]
            self.listAllParameters.append(self._CalZero)
            self._CalSpan = ResponseData[34:38] + ResponseData[30:34]
            self.listAllParameters.append(self._CalSpan)
            for i in range(len(self.listAllParameters)):
                self.Tempdisplay = Modbus.ConvertToInt(self, self.listAllParameters[i])
                self.listData.append(self.Tempdisplay)
            CalibrationSettings.Display_all_Parameters(self)
            self.listData.clear()
            self.listAllParameters.clear()
            self.FlagWriteData = False
            self.FlagWriteRawAdc = True
        except OSError as e:
            print(e)

    def Display_all_Parameters(self):
        try:
            self.MaxCapacity = ""
            self.CalCapacity = ""
            if len(self.listData) > 0:
                _maxcapacity = str(self.listData[0])
                _calcapacity = str(self.listData[3])
                self._decimal = self.listData[1]
                self.MaxCapacity = CalibrationSettings.fill_Zero(self, _maxcapacity)
                self.CalCapacity = CalibrationSettings.fill_Zero(self, _calcapacity)
                N = 5 - int(self._decimal)
                if not N == 5:
                    self.MaxCapacity = str(self.MaxCapacity)[:N] + "." + str(self.MaxCapacity)[
                                                                         N:]
                    self.CalCapacity = str(self.CalCapacity)[:N] + "." + str(self.CalCapacity)[
                                                                         N:]
                self.txtMaxCapacity.setText(str(self.MaxCapacity))
                self.cmbDecimalPoint.setCurrentText(str(self.listData[1]))
                self.cmbResolution.setCurrentText(str(self.listData[2]))
                self.txtCalZero.setText(str(self.listData[4]))
                self.txtCalSpan.setText(str(self.listData[5]))
                self.txtCalCapacity.setText(str(self.CalCapacity))
                self.FlagWriteData = False
            pass
        except Exception as e:
            print(e)

    def UpdateReadData(self):
        try:
            if self.FlagDisplayData:
                if self.FlagReadMaxCapacity:
                    self.MaxCapacityResponse = self.ReadResponse
                    self.MaxCapacityResponse = CalibrationSettings.fill_Zero(self, self.MaxCapacityResponse)
                    if not self.DecimalPointResponse == "":
                        N = 5 - int(self.DecimalPointResponse)
                        if not N == 5:
                            self.MaxCapacityResponse = str(self.MaxCapacityResponse)[:N] + "." + str(
                                self.MaxCapacityResponse)[
                                                                                                 N:]
                        self.txtMaxCapacity.setText(str(self.MaxCapacityResponse))
                    else:
                        self.DecimalPointResponse = self.cmbDecimalPoint.currentText()
                        N = 5 - int(self.DecimalPointResponse)
                        if not N == 5:
                            self.MaxCapacityResponse = str(self.MaxCapacityResponse)[:N] + "." + str(
                                self.MaxCapacityResponse)[
                                                                                                 N:]
                        self.txtMaxCapacity.setText(str(self.CalCapacityResponse))
                    self.FlagReadMaxCapacity = False
                    self.MaxCapacityResponse = ""
                    self.FlagDisplayData = False
                    self.FlagmaxCapacity = False


                elif self.FlagReadDecimalPoint:
                    self.DecimalPointResponse = self.ReadResponse
                    self.cmbDecimalPoint.setCurrentText(self.DecimalPointResponse)
                    self.FlagReadDecimalPoint = False
                    self.FlagLoad = False
                    self.FlagDisplayData = False
                    if self.FlagmaxCapacity:
                        self.ReadMaxCapacity()
                    if self.FlagCalCapacity:
                        self.ReadCalCapacity()

                    if self.WriteSuccessfull:
                        self.gbProductMsg.setVisible(True)
                        self.lblProductAlertMsg.setVisible(True)
                        self.btnMessageAlert.setVisible(True)
                        self.lblProductAlertMsg.setText("Updated Successfully")
                        self.WriteSuccessfull = False
                        self.FlagLoad = True
                        # self.Update_TextBoxes()
                        GlobalVariable.DecimalPoint = self.cmbDecimalPoint.currentText()
                    pass

                elif self.FlagReadResolution:
                    self.ResolutionResponse = self.ReadResponse
                    self.cmbResolution.setCurrentText(self.ResolutionResponse)
                    self.FlagReadResolution = False
                    self.ResolutionResponse = ""
                    self.FlagDisplayData = False
                    pass

                elif self.FlagReadCalZero:
                    self.CalZeroResponse = self.ReadResponse
                    self.txtCalZero.setText(str(self.CalZeroResponse))
                    self.FlagReadCalZero = False
                    self.CalZeroResponse = ""
                    self.FlagDisplayData = False

                    self.WriteProtocol = ""

                    pass
                elif self.FlagReadCalSpan:
                    self.CalSpanResponse = self.ReadResponse
                    self.txtCalSpan.setText(str(self.CalSpanResponse))
                    self.FlagReadCalSpan = False
                    self.FlagDisplayData = False

                    self.WriteProtocol = ""
                    pass
                elif self.FlagReadCalCapacity:
                    self.CalCapacityResponse = self.ReadResponse
                    self.CalCapacityResponse = CalibrationSettings.fill_Zero(self, self.CalCapacityResponse)
                    if not self.DecimalPointResponse == "":
                        N = 5 - int(self.DecimalPointResponse)
                        if not N == 5:
                            self.CalCapacityResponse = str(self.CalCapacityResponse)[:N] + "." + str(
                                self.CalCapacityResponse)[
                                                                                                 N:]
                        self.txtCalCapacity.setText(str(self.CalCapacityResponse))
                    else:
                        self.DecimalPointResponse = self.cmbDecimalPoint.currentText()
                        N = 5 - int(self.DecimalPointResponse)
                        if not N == 5:
                            self.CalCapacityResponse = str(self.CalCapacityResponse)[:N] + "." + str(
                                self.CalCapacityResponse)[
                                                                                                 N:]
                        self.txtCalCapacity.setText(str(self.CalCapacityResponse))
                    self.FlagReadCalCapacity = False
                    self.FlagDisplayData = False
                    self.FlagCalCapacity = False

                    self.WriteProtocol = ""
                    pass
                else:
                    if self.WriteSuccessfull:
                        self.WriteSuccessfull = False
                        self.FlagWriteParams = False
                        #
                        # self.Update_TextBoxes()
        except OSError as e:
            print(e)

    def WriteData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.FlagWriteRawAdc:
                    self.TempWriteCalibProtocol = bytes.fromhex(ModbusProtocols.RawAdcReadProtocol)
                    GlobalVariable.Serial_Port.write(self.TempWriteCalibProtocol)
                    self.FlagReadRawAdc = True
                    pass
            pass
        except OSError as e:
            print(e)

    def functionToReadRawAdcData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.FlagReadRawAdc:
                    self.ReadRawAdcData = ""
                    self.ResponseTemp = GlobalVariable.Serial_Port.read_all().hex()
                    self.ReadRawAdcData = str(self.ResponseTemp)
                    if not self.ReadRawAdcData is None and not self.ReadRawAdcData == "" and not self.ReadRawAdcData.__contains__(
                            "0106") and len(self.ReadRawAdcData) == 18:
                        self.Response = self.ReadRawAdcData
                        self.GetLoad = self.Response[10:14] + self.Response[6:10]  # 000002d4
                        self.displaydata = Modbus.ConvertToInt(self, self.GetLoad)
                        self.Responsedata = str(self.displaydata)
                        self.FlagDisplayRawAdc = True
                    else:
                        pass
        except OSError as e:
            print(e)

    def UpdateData(self):
        try:
            if self.FlagDisplayRawAdc and len(self.Responsedata) <= 5:
                self.txtRawADC.setText(str(self.Responsedata))
                # UiComponents.RawAdcGreen(self)
        except OSError as e:
            print(e)

    def writeAllParameters(self):
        if self.FlagWriteAll:
            if self.FlagWriteDecimal:
                CalibrationSettings.on_click_DownloadDecimalPoint(self)
                self.FlagWriteAll = False
            if self.FlagWriteResolution:
                CalibrationSettings.on_click_DownloadResolution(self)
                self.FlagWriteAll = False
            if self.FlagWriteMaxCapacity:
                CalibrationSettings.on_click_DownloadMaxCapacity(self)
                self.FlagWriteAll = False
            if self.FlagWriteCalZero:
                CalibrationSettings.on_click_DownloadCalZero(self)
                self.FlagWriteAll = False
            if self.FlagWriteCalSpan:
                CalibrationSettings.on_click_btnDownloadCalSpan(self)
                self.FlagWriteAll = False
            if self.FlagWriteCalCapacity:
                CalibrationSettings.on_click_DownloadCalCapacity(self)
                self.FlagWriteAll = False

    def UpdateAllParameters(self):
        if self.FlagUpdateSuccessfully:
            if self.FlagWriteDecimal:
                self.FlagWriteResolution = True
                self.FlagWriteDecimal = False
                self.FlagUpdateSuccessfully = False
                self.lblDecimalPointStatus.setVisible(True)
                self.lblDecimalPointStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True
            elif self.FlagWriteResolution:
                self.FlagWriteMaxCapacity = True
                self.FlagWriteResolution = False
                self.FlagUpdateSuccessfully = False
                self.lblResolutionStatus.setVisible(True)
                self.lblResolutionStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True
            elif self.FlagWriteMaxCapacity:
                self.FlagWriteCalZero = True
                self.FlagWriteMaxCapacity = False
                self.FlagUpdateSuccessfully = False
                self.lblMaxCapacityStatus.setVisible(True)
                self.lblMaxCapacityStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True
            elif self.FlagWriteCalZero:
                self.FlagWriteCalSpan = True
                self.FlagWriteCalZero = False
                self.FlagUpdateSuccessfully = False
                self.lblCalZeroStatus.setVisible(True)
                self.lblCalZeroStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True

            elif self.FlagWriteCalSpan:
                self.FlagWriteCalCapacity = True
                self.FlagWriteCalSpan = False
                self.FlagUpdateSuccessfully = False
                self.lblCalSpanStatus.setVisible(True)
                self.lblCalSpanStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True

            elif self.FlagWriteCalCapacity:
                self.FlagWriteCalCapacity = False
                self.FlagUpdateSuccessfully = False
                self.lblCalCapacityStatus.setVisible(True)
                self.lblCalCapacityStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_VERIFIED))
                self.FlagWriteAll = True
                CalibrationSettings.update_calibration_controls_state(self, False)
                CalibrationSettings.save_calibration_settings(self)
                MessagePopup.setting_msg_popup(self, "correct", "Calibrated Success")
                CalibrationSettings.Get_DateTime_fromDB(self)
                GlobalEntities.calibration_saved = True
                if GlobalEntities.calibration_saved:
                    self.txtCalSpan.setEnabled(False)
                    self.txtCalZero.setEnabled(False)
                CalibrationSettings.init_current_load_timer(self)

    def WriteDataToController1(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.FlagWriteDataAll:
                    self.ReadData = ""
                    print(self.WriteProtocol)
                    self.TempWriteCalibProtocol = Modbus().ConvertToHex(self.WriteProtocol)
                    GlobalVariable.Serial_Port.write(self.TempWriteCalibProtocol)
                    time.sleep(0.5)
                    self.TempWriteCalibProtocol = ""
                    # self.FlagReadData = True
                    if self.FlagWriteAllParams:
                        self.FlagUpdateSuccessfully = True
                        self.FlagWriteAllParams = False
                    self.FlagWriteDataAll = False
                    pass
            pass
        except OSError as e:
            print(e)

    def fill_Zero(self, input):
        try:
            if len(input) == 1:
                input = "0000" + input
            if len(input) == 2:
                input = "000" + input
            if len(input) == 3:
                input = "00" + input
            if len(input) == 4:
                input = "0" + input
            return input
        except OSError as e:
            print(e)

    def on_click_DownloadDecimalPoint(self):
        try:
            self.Decimal = self.cmbDecimalPoint.currentText()
            self.DecimalPoint = self.Decimal
            if not self.DecimalPoint == "":
                self.data = Modbus().StringtoHex(ModbusProtocols.DecimalPointReadAddress)
                if len(self.DecimalPoint) == 1:
                    self.DecimalPoint = "000" + self.DecimalPoint
                self.DecimalPoint = Modbus().StringtoHex(self.DecimalPoint)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.DecimalPoint
                self.HexReadDecimalPoint = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexReadDecimalPoint)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True
            else:
                self.lblDecimalPointStatus.setVisible(True)
                self.lblDecimalPointStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))
        except OSError as e:
            print(e)

    def on_click_DownloadResolution(self):
        try:
            self.FlagWriteAllParams = True
            self.WriteSuccessfull = False
            self.Resolution = self.cmbResolution.currentText()
            self.Resolution = self.Resolution
            if not self.Resolution == "":
                if len(self.Resolution) == 1:
                    self.Resolution = "000" + self.Resolution
                if len(self.Resolution) == 2:
                    self.Resolution = "00" + self.Resolution
                if len(self.Resolution) == 3:
                    self.Resolution = "0" + self.Resolution
                self.Resolution = Modbus().StringtoHex(self.Resolution)
                self.data = Modbus().StringtoHex(ModbusProtocols.ResolutionReadAddress)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.Resolution
                self.HexResolution = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexResolution)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True



            else:
                self.lblResolutionStatus.setVisible(True)
                self.lblResolutionStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))


        except OSError as e:
            print(e)

    def on_click_DownloadMaxCapacity(self):
        try:
            self.MaxCapacity = self.txtMaxCapacity.text()
            self.MaxCapacity = self.MaxCapacity.replace(".", "")
            if not self.MaxCapacity == "" and int(self.MaxCapacity) <= 99999:
                if len(self.MaxCapacity) > 4:
                    self.MaxCapacity = Modbus().StringtoHex(self.MaxCapacity)
                self.data = Modbus().StringtoHex(ModbusProtocols.MaxCapacityReadAddress)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.MaxCapacity
                self.HexReadMaxCapacity = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexReadMaxCapacity)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True


            else:
                self.lblMaxCapacityStatus.setVisible(True)
                self.lblMaxCapacityStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))

        except OSError as e:
            print(e)

    def on_click_DownloadCalCapacity(self):
        try:
            self.WriteSuccessfull = False
            self.CalCapacity = ""
            self.CalCapacity = self.txtCalCapacity.text()
            self.MaxCapacity = self.txtMaxCapacity.text()
            self.MaxCapacity = self.MaxCapacity.replace(".", "")
            self.CalCapacity = self.CalCapacity.replace(".", "")
            if not self.CalCapacity == "" and int(self.CalCapacity) <= int(self.MaxCapacity):
                if len(self.CalCapacity) == 1:
                    self.CalCapacity = "000" + self.CalCapacity
                if len(self.CalCapacity) == 2:
                    self.CalCapacity = "00" + self.CalCapacity
                if len(self.CalCapacity) == 3:
                    self.CalCapacity = "0" + self.CalCapacity
                if len(self.CalCapacity) > 4:
                    self.CalCapacity = Modbus().StringtoHex(self.CalCapacity)
                self.data = Modbus().StringtoHex(ModbusProtocols.CalCapacityReadAddress)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.CalCapacity
                self.HexCalCapacity = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexCalCapacity)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True

            else:
                self.lblCalCapacityStatus.setVisible(True)
                self.lblCalCapacityStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))

        except OSError as e:
            print(e)

    def on_click_btnDownloadCalSpan(self):
        try:
            self.CalSpan = ""
            self.CalSpan = self.txtCalSpan.text()
            if not self.CalSpan == "":
                if len(self.CalSpan) == 1:
                    self.CalSpan = "000" + self.CalSpan
                    self.CalSpan = Modbus().StringtoHex(self.CalSpan)
                if len(self.CalSpan) == 2:
                    self.CalSpan = "00" + self.CalSpan
                    self.CalSpan = Modbus().StringtoHex(self.CalSpan)
                if len(self.CalSpan) == 3:
                    self.CalSpan = "0" + self.CalSpan
                    self.CalSpan = Modbus().StringtoHex(self.CalSpan)
                if len(self.CalSpan) >= 4:
                    self.CalSpan = Modbus().StringtoHex(self.CalSpan)
                self.data = Modbus().StringtoHex(ModbusProtocols.CalSpanReadAddress)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.CalSpan
                self.HexCalSpan = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexCalSpan)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True

            else:
                self.lblCalSpanStatus.setVisible(True)
                self.lblCalSpanStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))

        except OSError as e:
            print(e)

    def on_click_DownloadCalZero(self):
        try:
            self.CalZero = self.txtCalZero.text()
            if not self.CalZero == "":
                if len(self.CalZero) == 1:
                    self.CalZero = "000" + self.CalZero
                    self.CalZero = Modbus().StringtoHex(self.CalZero)
                if len(self.CalZero) == 2:
                    self.CalZero = "00" + self.CalZero
                    self.CalZero = Modbus().StringtoHex(self.CalZero)
                if len(self.CalZero) == 3:
                    self.CalZero = "0" + self.CalZero
                    self.CalZero = Modbus().StringtoHex(self.CalZero)
                if len(self.CalZero) >= 4:
                    self.CalZero = Modbus().StringtoHex(self.CalZero)
                self.data = Modbus().StringtoHex(ModbusProtocols.CalZeroReadAddress)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.CalZero
                self.HexCalCapacity = Modbus().ConvertToHex(self.address)
                self.GetCRC = Modbus().CalculateCRC(self.HexCalCapacity)
                self.TempProtocol = self.address + self.GetCRC
                self.WriteProtocol = self.TempProtocol
                self.FlagWriteDataAll = True
                self.FlagWriteAllParams = True
                self.FlagUpdateDataRawAdc = False

            else:
                self.lblCalZeroStatus.setVisible(True)
                self.lblCalZeroStatus.setPixmap(QPixmap(PathConfig.IMG.IMAGE_ERROR))

        except OSError as e:
            print(e)

    def Get_datetime(self):
        self.datetime = datetime.now()
        self.Current_datetime = self.datetime.strftime("%d/%m/%Y %H:%M:%S")

    def save_calibration_settings(self):
        try:
            CalibrationSettings.get_unit(self)
            self.UserName = ""
            self.Activated_profile_list = SystemConfigBL().get_Activated_Profile_info()
            if not len(self.Activated_profile_list) == 0:
                self.UserName = self.Activated_profile_list[0]
            else:
                self.UserName = ""
            CalibrationSettings.Get_datetime(self)
            self.listValues = []
            self.listValues.append(self.txtCalZero.text())
            self.listValues.append(self.txtCalSpan.text())
            self.listValues.append(self.txtCalCapacity.text())
            self.listValues.append(self.cmbDecimalPoint.currentText())
            self.listValues.append(self.cmbResolution.currentText())
            self.listValues.append(self.txtMaxCapacity.text())
            self.listValues.append(self.Current_datetime)
            self.listValues.append(str(self.UserName))
            self.listValues.append(str(GlobalVariable.active_unit))
            if self.flg_auto_mode:
                self.listValues.append("Auto")
            else:
                self.listValues.append("Manual")
            if len(self.listValues) == 10:
                self.calibration_data_count = SystemConfigBL().fetch_calibration_count()
                if self.calibration_data_count < 10:
                    SystemConfigBL().set_data_as_inactive()
                    self.Save = SystemConfigBL().Save_Params(self.listValues)
                else:
                    SystemConfigBL().delete_record_from_calibration()
                    SystemConfigBL().set_data_as_inactive()
                    self.Save = SystemConfigBL().Save_Params(self.listValues)
            else:
                pass
            pass
        except Exception as e:
            print(e)

    def disable_calibration_timers(self):
        try:
            if GlobalVariable.Serial_Port is not None:
                GlobalVariable.Serial_Port.close()
                GlobalVariable.Serial_Port = None
            self.timerWriteData.stop()
            self.timerReadData.stop()
            self.timerShowData.stop()
            self.timerWriteRawAdc.stop()
            self.timerReadRawAdc.stop()
            self.timerShowRawAdc.stop()
            self.timerWriteAllData.stop()
            self.timerUpdateSuccessfully.stop()
            self.timerWriteData1.stop()
            self.timerWriteCurrentLoad.stop()
            self.timerReadCurrentLoad.stop()
            self.timerShowCurrentLoad.stop()
            pass
        except Exception as e:
            print(e)

    def get_unit(self):
        try:
            unit_row = VehicleEntryBL().get_unit()
            if unit_row[0][1] == 'Ton':
                GlobalVariable.active_unit = "Tonnes"
            else:
                GlobalVariable.active_unit = unit_row[0][1]
        except OSError as e:
            print(e)
