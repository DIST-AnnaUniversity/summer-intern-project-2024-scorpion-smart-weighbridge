import json
import os
import subprocess

from PyQt5.QtGui import QBrush, QColor
from PyQt5.QtWidgets import QTableWidgetItem
from Presentation.Utilities.WifiStatusThread import WifiStatusThread
from Presentation.Utilities.WifiThread import WifiScannerThread
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Bundles.UiConfiguration import PathConfig


class WifiConfiguration:
    def __init__(self):
        super().__init__()

        #     Get Commands from JSON file

        with open(PathConfig.JSONPath.wifi_commands_path, 'r') as file:
            wifi_commands = json.load(file)

            self.cmd_connect_network = (wifi_commands['connect_network'])
            self.cmd_connect_protected_network = (wifi_commands['protected_network_password'])

    # For adding the list of networks to the table Widget
    def DisplayAvailableWifi(self, lstAvailableWifi, ssid):
        try:
            flg_ssid = False
            self.connected_msg = "CONNECTED"
            self.row_count = 0
            # self.dgvWifiList.setRowCount(0)

            ssid = ssid.replace('\n', '')
            if ssid in lstAvailableWifi:
                lstAvailableWifi.remove(ssid)
                lstAvailableWifi.insert(0, ssid)

            for i, Wifi_Name in enumerate(lstAvailableWifi):
                # Empty validation for avoiding empty data in the table widget
                if not Wifi_Name == '':
                    if str(Wifi_Name) in str(ssid):
                        Wifi_Name = Wifi_Name.ljust(100) + self.connected_msg
                        flg_ssid = True
                    self.dgvWifiList.insertRow(self.row_count)
                    self.dgvWifiList.setRowHeight(self.row_count, 60)
                    self.dgvWifiList.setItem(self.row_count, 0, QTableWidgetItem(str(Wifi_Name)))
                    if flg_ssid:
                        colored_text = QTableWidgetItem(str(Wifi_Name))
                        colored_text.setForeground(QBrush(QColor(53, 138, 94)))
                        self.dgvWifiList.setItem(self.row_count, 0, colored_text)
                        flg_ssid = False
                    self.row_count = self.row_count + 1
                else:
                    print("scanning")

            GlobalVariable.check_wifi_status = True
        except Exception as e:
            print(e)

    # For connecting the Wi-Fi network, the network credentials are passed to this function

    def configure_wifi(self, ssid, cmd_connect_network, cmd_connect_protected_network, password=None):
        try:
            if password:
                # Command for connecting Wi-fi which are password protected.
                command = "nmcli device wifi connect '" + ssid + "' password '" + password + "'"
                print(command)
                # subprocess.run(command)
                os.system(command)
            else:
                # Command for connecting open network

                command = cmd_connect_network + " '" + ssid + "'"
                print(command)
                os.system(command)
        except Exception as e:
            print(e)

    # To check whether the wi-fi is enabled or not during load event.
    def is_wifi_enabled(self):
        try:
            cmd = "nmcli -t -f device,state dev"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()

            lines = output.split("\n")
            for line in lines:
                device, state = line.split(":")
                if device == "wlan0":
                    if state == "unavailable":
                        print("Wi-Fi is turned off")
                        return False
                    elif state == "disconnected" or state == "connected":
                        print("Wi-Fi is turned on but not connected")
                        return True
                    else:
                        print("Wi-Fi state is unknown")
                    break
            else:
                print("Wi-Fi interface not found")
        except subprocess.CalledProcessError:
            return False

    # Function for activating the Thread which will Scan and add Wi-Fi networks
    def start_wifi_thread(self):
        try:
            GlobalVariable.check_wifi_status = True
            self.wifi_thread = WifiScannerThread()
            self.wifi_thread.signal.connect(self.update_live_wifi)
            self.wifi_thread.start()
        except Exception as e:
            print(e)

    def start_thread_for_wifi_status(self):
        try:
            self.wifi_status_thread = WifiStatusThread()
            self.wifi_status_thread.signal.connect(self.update_wifi_status)
            if not self.wifi_status_thread.isRunning():
                self.wifi_status_thread.start()
        except Exception as e:
            print(e)

    def stop_wifi_thread(self):
        try:
            GlobalVariable.wifi_status = False
            if self.wifi_status_thread.isRunning():
                self.wifi_status_thread.stop_thread()
        except Exception as e:
            print(e)


    # For terminating the thread
    def terminate_thread(self):
        try:
            GlobalVariable.check_wifi_status = False
            if self.wifi_thread.isRunning():
                self.wifi_thread.stop_wifi_thread()
        except Exception as e:
            print(e)

    def is_wifi_connected(self):
        try:
            # Run the command to get the SSID of the connected WiFi
            result = subprocess.check_output(['iwgetid', '--raw', 'wlan0'])
            ssid = result.decode('utf-8').strip()
            # If the SSID is not empty, wi-fi is connected
            return bool(ssid)
        except subprocess.CalledProcessError:
            # An error occurred, indicating wi-fi is not connected
            return False