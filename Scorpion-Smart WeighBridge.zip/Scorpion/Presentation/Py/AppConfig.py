import time

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QLineEdit

from BusinessLogic.AppConfigBl import AppConfigBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols


class AppConfig:
    def __init__(self):
        super().__init__()

    def init_app_config_menu(self):
        try:
            self.flg_write_all = False
            self.flg_read_data = False
            self.flg_write_data = True
            self.flg_write_auto_zero = False
            self.flg_read_auto_zero = False
            self.flg_write_moving_average = False
            self.flg_read_moving_average = False
            self.flg_write_adc_filter = False
            self.flg_read_adc_filter = False
            self.flg_write_all_params = False
            self.write_protocol = ""
            self.flg_write_data_all = False
            self.flg_updated_successfully = False
            self.temp_write_protocol = ""
            self.read_data = ""
            self.ResponseData = ""

            AppConfig.update_app_config_control_state(self, False)
            self.cmb_adc_filter.addItems(["1", "2", "3", "4", "5", "6", "7", "8", "9"])
            self.cmb_adc_filter.setMaxVisibleItems(5)
            self.timer_read_app_config.timeout.connect(self.read_data_from_controller)
            self.timer_read_app_config.start(100)
            self.timer_write_app_config.timeout.connect(self.write_data_to_controller)
            self.timer_write_app_config.start(100)
            self.timer_write_all_app_config.timeout.connect(self.write_all_parameters)
            self.timer_write_all_app_config.start(100)
            self.timer_display_app_config.timeout.connect(self.display_data)
            self.timer_display_app_config.start(100)
            self.timer_update_status.timeout.connect(self.update_status)
            self.timer_update_status.start(100)

        except Exception as e:
            print(e)

    def write_all_parameters(self):
        try:
            if self.flg_write_all:
                if self.flg_write_adc_filter:
                    AppConfig.download_adc_filter(self)
                    self.flg_write_all = False
                if self.flg_write_moving_average:
                    AppConfig.download_moving_average(self)
                    self.flg_write_all = False
                if self.flg_write_auto_zero:
                    AppConfig.download_auto_zero(self)
                    self.flg_write_all = False
        except Exception as e:
            print(e)

    def write_data_to_controller(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if self.flg_write_data:
                    self.read_data = ""
                    print(self.write_protocol)
                    self.temp_write_protocol = Modbus().ConvertToHex(ModbusProtocols.read_app_config_all)
                    GlobalVariable.Serial_Port.write(self.temp_write_protocol)
                    self.flg_write_data = False
                    self.flg_read_data = True
                elif self.flg_write_data_all:
                    self.read_data = ""
                    print(self.write_protocol)
                    self.temp_write_protocol = Modbus().ConvertToHex(self.write_protocol)
                    GlobalVariable.Serial_Port.write(self.temp_write_protocol)
                    time.sleep(0.5)
                    self.temp_write_protocol = ""
                    if self.flg_write_all_params:
                        self.flg_updated_successfully = True
                        self.flg_write_all_params = False
                    self.flg_write_data_all = False

        except Exception as e:
            print(e)

    def update_status(self):
        try:
            if self.flg_updated_successfully:
                if self.flg_write_adc_filter:
                    self.flg_write_moving_average = True
                    self.flg_write_adc_filter = False
                    self.flg_updated_successfully = False
                    self.lbl_adc_filter_status.setVisible(True)
                    UiComponents.update_verified_status(self, self.lbl_adc_filter_status, True)
                    self.flg_write_all = True
                elif self.flg_write_moving_average:
                    self.flg_write_auto_zero = True
                    self.flg_write_moving_average = False
                    self.flg_updated_successfully = False
                    UiComponents.update_verified_status(self,self.lbl_moving_average_status, True)
                    self.flg_write_all = True
                elif self.flg_write_auto_zero:
                    self.flg_write_auto_zero = False
                    self.flg_updated_successfully = False
                    UiComponents.update_verified_status(self,self.lbl_auto_zero_status, True)
                    self.flg_write_all = False
                    self.flg_write_data = True
                    AppConfig.update_app_config_control_state(self, False)
                    MessagePopup.setting_msg_popup(self, "correct", "Saved Success")
        except Exception as e:
            print(e)

    def read_data_from_controller(self):
        try:
            self.ResponseData = ""
            if not GlobalVariable.Serial_Port is None:
                if self.flg_read_data:
                    self.read_data = ""
                    self.read_data = GlobalVariable.Serial_Port.read_all().hex()
                    print(self.read_data)
                    if not self.read_data is None and not self.read_data == "" and not self.flg_write_data_all:
                        if len(self.read_data) == 22:
                            self.ResponseData = self.read_data
                            self.flg_read_data = False
                            AppConfig.SubString_All_Parameters(self, self.ResponseData)
                            self.ResponseData = ""
                        else:
                            self.flg_write_data = True
                    else:
                        if self.read_data.__contains__("0106"):
                            pass
        except Exception as e:
            print(e)

    def SubString_All_Parameters(self, ResponseData):
        try:
            self.list_split_received_data = []
            self.list_return_actual_data = []
            self.get_adc_filter = ResponseData[6:10]
            print(self.get_adc_filter)
            self.list_split_received_data.append(self.get_adc_filter)
            self.get_moving_average = ResponseData[10:14]
            print(self.get_moving_average)
            self.list_split_received_data.append(self.get_moving_average)
            self.get_auto_zero = ResponseData[14:18]
            print(self.get_auto_zero)
            self.list_split_received_data.append(self.get_auto_zero)
            for i in range(len(self.list_split_received_data)):
                self.temp_converted_data = Modbus.ConvertToInt(self, self.list_split_received_data[i])
                self.list_return_actual_data.append(self.temp_converted_data)
            AppConfig.display_received_data(self)
            self.list_split_received_data.clear()
            self.list_return_actual_data.clear()
            self.flg_write_data = False
        except OSError as e:
            print(e)

    def display_received_data(self):
        try:
            if len(self.list_return_actual_data) > 0:
                self.txt_moving_average.setText(str((self.list_return_actual_data[1])))
                self.txt_auto_zero.setText(str((self.list_return_actual_data[2])))
                self.cmb_adc_filter.setCurrentText(str(self.list_return_actual_data[0]))
        except OSError as e:
            print(e)

    def display_data(self):
        try:
            pass
        except Exception as e:
            print(e)

    def download_auto_zero(self):
        try:
            self.auto_zero = self.txt_auto_zero.text()
            if not self.auto_zero == "" and 0 <= int(self.auto_zero) <= 9:
                self.data = Modbus().StringtoHex(ModbusProtocols.auto_zero_write_address)
                if len(self.auto_zero) == 1:
                    self.auto_zero = "000" + self.auto_zero
                self.string_to_hex_auto_zero = Modbus().StringtoHex(self.auto_zero)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.string_to_hex_auto_zero
                self.hex_write_auto_zero = Modbus().ConvertToHex(self.address)
                self.get_auto_zero_crc = Modbus().CalculateCRC(self.hex_write_auto_zero)
                self.temp_protocol = self.address + self.get_auto_zero_crc
                self.write_protocol = self.temp_protocol
                self.flg_write_all_params = True
                self.flg_write_data_all = True
            else:
                UiComponents.update_verified_status(self,self.lbl_auto_zero_status, False)

        except Exception as e:
            print(e)

    def download_moving_average(self):
        try:
            self.moving_average = self.txt_moving_average.text()
            if not self.moving_average == "" and 1 <= int(self.moving_average) <= 100:
                self.data = Modbus().StringtoHex(ModbusProtocols.moving_average_write_address)
                if len(self.moving_average) == 1:
                    self.moving_average = "000" + self.moving_average
                elif len(self.moving_average) == 2:
                    self.moving_average = "00" + self.moving_average
                elif len(self.moving_average) == 3:
                    self.moving_average = "0" + self.moving_average
                self.string_to_hex_moving_avearge = Modbus().StringtoHex(self.moving_average)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.string_to_hex_moving_avearge
                self.hex_write_moving_average = Modbus().ConvertToHex(self.address)
                self.get_moving_average_crc = Modbus().CalculateCRC(self.hex_write_moving_average)
                self.temp_protocol = self.address + self.get_moving_average_crc
                self.write_protocol = self.temp_protocol
                self.flg_write_all_params = True
                self.flg_write_data_all = True
            else:
                UiComponents.update_verified_status(self,self.lbl_moving_average_status, False)
        except Exception as e:
            print(e)

    def download_adc_filter(self):
        try:
            self.adc_filter = self.cmb_adc_filter.currentText()
            if not self.adc_filter == "":
                self.data = Modbus().StringtoHex(ModbusProtocols.adc_filter_write_address)
                if len(self.adc_filter) == 1:
                    self.adc_filter = "000" + self.adc_filter
                self.string_to_hex_adc_filter = Modbus().StringtoHex(self.adc_filter)
                self.address = ModbusProtocols.WriteAddress + str(self.data) + self.string_to_hex_adc_filter
                self.hex_write_adc_filter = Modbus().ConvertToHex(self.address)
                self.get_adc_filter_crc = Modbus().CalculateCRC(self.hex_write_adc_filter)
                self.temp_protocol = self.address + self.get_adc_filter_crc
                self.write_protocol = self.temp_protocol
                self.flg_write_all_params = True
                self.flg_write_data_all = True
            else:
                UiComponents.update_verified_status(self, self.lbl_adc_filter_status, False)
        except Exception as e:
            print(e)

    def disable_verified_status(self):
        try:
            for index in range(len(self.label_status)):
                self.label_status[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def update_app_config_control_state(self, state):
        try:
            for line_edit in self.frm_app_config.findChildren(QLineEdit):
                line_edit.setEnabled(state)
            self.btn_app_edit.setEnabled(not state)
            self.btn_app_save.setEnabled(state)
            self.cmb_adc_filter.setEnabled(state)
            pass
        except Exception as e:
            print(e)

    def fetch_app_configurations(self):
        try:
            self.app_config = AppConfigBL().fetch_app_config()
            if len(self.app_config) > 0:
                self.txt_auto_zero.setText(str(self.app_config[0]))
                self.txt_moving_average.setText(str(self.app_config[1]))
            pass
        except Exception as e:
            print(e)

    def save_app_configuration(self):
        try:
            if AppConfig.validate_app_configuration(self):
                self.app_config = [self.txt_auto_zero.text(), self.txt_moving_average.text(),
                                   self.cmb_adc_filter.currentText()]
                AppConfig.update_app_configuration_db(self, self.app_config)
                self.flg_write_all = True
                self.flg_write_adc_filter = True
            pass
        except Exception as e:
            print(e)

    def validate_app_configuration(self):
        try:
            self.text_box_count = 0
            for text_box in self.frm_app_config.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
            pass
        except Exception as e:
            print(e)

    def update_app_configuration_db(self, app_config):
        try:
            self.result_count = AppConfigBL().fetch_app_config_count()
            if self.result_count == "0":
                self.result = AppConfigBL().save_app_config(app_config)
            else:
                self.result = AppConfigBL().update_app_config(app_config)
            pass

        except Exception as e:
            print(e)

    def disable_app_config_timers(self):
        try:
            if GlobalVariable.Serial_Port is not None:
                GlobalVariable.Serial_Port.close()
                GlobalVariable.Serial_Port = None
            self.timer_read_app_config.stop()
            self.timer_write_app_config.stop()
            self.timer_display_app_config.stop()
            self.timer_write_all_app_config.stop()
            self.timer_update_status.stop()
        except Exception as e:
            print(e)
