import os
import re
import shutil

from PyQt5 import QtCore
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import QLineEdit, QPushButton, QFileDialog, QTableWidgetItem, QComboBox

from BusinessLogic.LoginBL import LoginBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH, PathConfig
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Utilities.GlobalVariable import GlobalVariable


class ProfileInfo:
    def __init__(self):
        super().__init__()

    def init_profile_info(self):
        try:
            ProfileInfo.retrieve_activated_profile_info_parameters(self)
            ProfileInfo.update_profile_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def update_profile_controls_state(self, state):
        try:
            for text_box in self.frmProfileDetails.findChildren(QLineEdit):
                text_box.setEnabled(state)
            for button in self.frmProfileDetails.findChildren(QPushButton):
                button.setEnabled(state)
            self.btnProfileDetailsEdit.setEnabled(not state)
            self.btnProfileDetailsSave.setEnabled(state)
            self.txtUserRole.setEnabled(False)
            pass
        except Exception as e:
            print(e)

    def save_profile_info(self):
        try:
            ProfileInfo.UpdateProfileDetails(self)
            if GlobalVariable.flgProfileInfoSave:
                ProfileInfo.ProfileDetailsSave(self)
                ProfileInfo.retrieve_activated_profile_info_parameters(self)
            pass
        except Exception as e:
            print(e)

    def retrieve_activated_profile_info_parameters(self):
        try:

            self.Activated_profile_list = LoginBL().get_Activated_Profile_info()
            if not len(self.Activated_profile_list) == 0:
                self.txtUsername.setText(self.Activated_profile_list[0])
                self.txtProfileInfoUserName.setText(self.Activated_profile_list[0])
                self.txtProfileInfoEmailId.setText(self.Activated_profile_list[1])
                self.txtProfileInfoPhoneNumber.setText(self.Activated_profile_list[2])
                ProfilePicture = self.Activated_profile_list[3]
                if not ProfilePicture == "":
                    self.lblProfileinfoPic.setStyleSheet("QLabel"
                                                         "{"
                                                         "background-image :url(" + ROOT_PATH + "Images/ProfilePicture/" + ProfilePicture + "); "
                                                                                                                                            "border : none "
                                                                                                                                            "}"
                                                         )
                else:
                    self.lblProfileinfoPic.setStyleSheet("QLabel"
                                                         "{"
                                                         "background-image :url(" + ROOT_PATH + "Images/ProfilePicture/DefaultPic.png);"
                                                                                                "border : none "
                                                                                                "}"
                                                         )
                if self.Activated_profile_list[4] == "1":
                    self.txtUserRole.setText("Admin")
                elif self.Activated_profile_list[4] == "2":
                    self.txtUserRole.setText("Operator")
                elif self.Activated_profile_list[4] == "3":
                    self.txtUserRole.setText("Supervisor")
            else:
                pass
        except Exception as e:
            print(e)

    def ProfilePictureEdit(self):
        try:
            from Presentation.Utilities.GlobalVariable import GlobalVariable
            device_list = os.listdir('/media/lcs/')

            if device_list:
                for i, drive_name in enumerate(device_list):
                    if drive_name:
                        GetDevice_name = drive_name
                self.filename = QFileDialog.getOpenFileName(self, 'Select a file', '/media/lcs/' + GetDevice_name,
                                                            "Image files (*.png *.jpg *.gif)")
                image_path = self.filename[0]
                ImageName = os.path.basename(image_path).split('/')[-1]
                GlobalVariable.edited_profile_picture_name = ImageName
                shutil.copy(image_path, PathConfig.Logo.PROFILE_PATH)
                UiComponents.Set_Profile_Info(self, ImageName)
            else:
                MessagePopup.setting_msg_popup(self, "error", "  No Device Found !!!")
        except OSError as e:
            MessagePopup.setting_msg_popup(self, "error", "  No Device Found !!!")

    def UpdateProfileDetails(self):
        try:
            self.Emailid = ""
            from Presentation.Utilities.GlobalVariable import GlobalVariable
            GlobalVariable.ListUpdateProfileDetails.clear()
            if not self.txtProfileInfoUserName.text() == "" and not self.txtProfileInfoEmailId.text() == "" and not self.txtProfileInfoPhoneNumber.text() == "" and not len(
                    self.txtProfileInfoPhoneNumber.text()) < 10:
                GlobalVariable.ListUpdateProfileDetails.append(self.txtProfileInfoUserName.text())
                GlobalVariable.ListUpdateProfileDetails.append(self.txtProfileInfoEmailId.text())
                GlobalVariable.ListUpdateProfileDetails.append(self.txtProfileInfoPhoneNumber.text())
                GlobalVariable.ListUpdateProfileDetails.append(GlobalVariable.edited_profile_picture_name)
                GlobalVariable.ListUpdateProfileDetails.append(str(GlobalVariable.time))
                self.Emailid = GlobalVariable.ListUpdateProfileDetails[1]
                regex = re.compile("[_!#$%^&*()<>?/}{~:]+")
                if not self.Emailid.__contains__("@") or regex.search(self.txtProfileInfoEmailId.text()) is not None:
                    MessagePopup.setting_msg_popup(self, "error", " Enter Valid Email Address!!!")
                    self.StatusLabel = [self.lblProfileEmailStatus]
                    for i in range(len(self.StatusLabel)):
                        UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    GlobalVariable.flgProfileInfoSave = False
                else:
                    GlobalVariable.flgProfileInfoSave = True
            else:
                MessagePopup.setting_msg_popup(self, "error", " Enter Valid Details!!!")
                if self.txtProfileInfoUserName.text() == "":
                    self.StatusLabel = [self.lblProfileUserNameStatus]
                    for i in range(len(self.StatusLabel)):
                        UiComponents.Error_Status(self, self.StatusLabel[i], True)
                if self.txtProfileInfoPhoneNumber.text() == "" or len(self.txtProfileInfoPhoneNumber.text()) < 10:
                    self.StatusLabel = [self.lblProfilePhoneNumber]
                    for i in range(len(self.StatusLabel)):
                        UiComponents.Error_Status(self, self.StatusLabel[i], True)
                if self.txtProfileInfoEmailId.text() == "":
                    self.StatusLabel = [self.lblProfileEmailStatus]
                    for i in range(len(self.StatusLabel)):
                        UiComponents.Error_Status(self, self.StatusLabel[i], True)

                GlobalVariable.flgProfileInfoSave = False
        except Exception as e:
            print(e)

    def ProfileDetailsSave(self):
        try:
            from Presentation.Utilities.GlobalVariable import GlobalVariable

            Result = LoginBL().Set_Editted_Profile_info(GlobalVariable.ListUpdateProfileDetails)
            MessagePopup.setting_msg_popup(self, "correct", "Saved Successfully")
            self.btnProfileDetailsEdit.setEnabled(True)
            self.btnProfilePictureEdit.setEnabled(True)
            ProfileInfo.update_profile_controls_state(self, False)

            self.StatusLabel = [self.lblProfileUserNameStatus, self.lblProfilePhoneNumber, self.lblProfileEmailStatus,
                                self.lblProfileRoleStatus]
            for i in range(len(self.StatusLabel)):
                UiComponents.update_verified_status(self, self.StatusLabel[i], True)

            self.btnProfileDetailsEdit.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Edit.png); "
                                                                                            "border : none ;"
                                                                                            "background-color:transparent;"
                                                                                            "}"

                                                                                            "QPushButton::disabled"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "
                                                                                                                                   "background-color:transparent;"
                                                                                                                                   "}"
                                                     )
        except Exception as e:
            print(e)

    '''Create User Logic'''

    def init_create_user(self):
        try:
            ProfileInfo.update_create_user_controls_state(self,False)
            pass
        except Exception as e:
            print(e)

    def update_create_user_controls_state(self, state):
        try:
            for text_box in self.frmCreateNewUser.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for button in self.frmCreateNewUser.findChildren(QPushButton):
                button.setEnabled(state)
            self.btnProfileDetailsEdit.setEnabled(not state)
            self.btnProfileDetailsSave.setEnabled(state)
            pass
        except Exception as e:
            print(e)

    def CreateNewUser(self):
        try:
            from Presentation.Utilities.GlobalVariable import GlobalVariable
            GlobalVariable.listSignupInfo.clear()
            GlobalVariable.listSignupInfo.append(self.txtUserName.text())
            GlobalVariable.listSignupInfo.append(self.txtDesignation.text())
            GlobalVariable.listSignupInfo.append(self.txtEmailId.text())
            GlobalVariable.listSignupInfo.append(self.txtCreatePassword.text())
            GlobalVariable.listSignupInfo.append(self.txtConformPassword.text())
            GlobalVariable.listSignupInfo.append(self.txtPhoneNumber.text())
            GlobalVariable.listSignupInfo.append(GlobalVariable.profile_picture_name)
            GlobalVariable.listSignupInfo.append("0")
            GlobalVariable.listSignupInfo.append("0")
            GlobalVariable.listSignupInfo.append(str(GlobalVariable.time))
            GlobalVariable.listSignupInfo.append(str(GlobalVariable.time))
            GlobalVariable.listSignupInfo.append("3")
        except Exception as e:
            print(e)

    def ProfileSave(self):
        try:
            Result = LoginBL().user_already_exist(GlobalVariable.listSignupInfo)
            if str(Result) >= "0":
                Result = LoginBL().CreateNewUser(GlobalVariable.listSignupInfo)
                if Result == 1:
                    MessagePopup.setting_msg_popup(self, "error", "Enter Valid Details!")
                    if self.txtUserName.text() == "":
                        self.StatusLabel = [self.lblNewUserNameStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    if self.txtPhoneNumber.text() == "" or len(self.txtPhoneNumber.text()) < 10:
                        self.StatusLabel = [self.lblNewUserPhoneNoStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    if self.txtCreatePassword.text() == "":
                        self.StatusLabel = [self.lblCreateUserPassword]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    if self.txtEmailId.text() == "":
                        self.StatusLabel = [self.lblNewUserEmailIdStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    if self.txtDesignation.text() == "":
                        self.StatusLabel = [self.lblNewUserDesignationStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    if self.txtConformPassword.text() == "":
                        self.StatusLabel = [self.lblNewUserConformPasswordStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.Error_Status(self, self.StatusLabel[i], True)
                    regex = re.compile("[_!#$%^&*()<>?/}{~:]+")
                    if not str(self.txtEmailId.text()).__contains__("@") or regex.search(
                            self.txtEmailId.text()) is not None:
                        MessagePopup.setting_msg_popup(self, "error", "Enter valid EmailAddress!")
                        self.StatusLabel = [self.lblNewUserEmailIdStatus]
                        for i in range(len(self.StatusLabel)):
                            UiComponents.update_verified_status(self, self.StatusLabel[i], False)

                elif Result == 2:
                    MessagePopup.setting_msg_popup(self, "error", "Password Doesn't match")

                    self.StatusLabel = [self.lblCreateUserPassword, self.lblNewUserConformPasswordStatus]
                    for i in range(len(self.StatusLabel)):
                        self.StatusLabel[i].setVisible(True)
                        UiComponents.update_verified_status(self, self.StatusLabel[i], False)
                elif Result == 3:
                    MessagePopup.setting_msg_popup(self, "correct", "User Created Successfully!")

                    self.StatusLabel = [self.lblNewUserNameStatus, self.lblNewUserPhoneNoStatus,
                                        self.lblCreateUserPassword,
                                        self.lblNewUserEmailIdStatus, self.lblNewUserDesignationStatus,
                                        self.lblNewUserConformPasswordStatus]
                    for i in range(len(self.StatusLabel)):
                        self.StatusLabel[i].setVisible(True)
                        UiComponents.update_verified_status(self, self.StatusLabel[i], True)
                    ProfileInfo.update_create_user_controls_state(self, False)
                    self.btnProfileDetailsEdit.setStyleSheet("QPushButton"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                             "/Edit.png); "
                                                                                             "border : none; "
                                                                                             "background-color:transparent;"
                                                                                             "}"

                                                                                             "QPushButton::disabled"
                                                                                             "{"
                                                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "
                                                                                                                                    "background-color:transparent;"
                                                                                                                                    "}"

                                                      )
                pass
            else:
                MessagePopup.setting_msg_popup(self, "error", "User Already Exists!")
        except OSError as e:
            print(e)
        pass

    def Browse_ProfilePicture(self):  # Copy Profile Picture using USB
        try:
            self.User_Image = ""
            self.filename = ""
            self.image_path = ""
            from Presentation.Utilities.GlobalVariable import GlobalVariable
            device_list = os.listdir('/media/lcs/')
            if device_list:
                for i, drive_name in enumerate(device_list):
                    if drive_name:
                        GetDevice_name = drive_name
                self.filename = QFileDialog.getOpenFileName(self, 'Select a file',
                                                            '/media/lcs/' + GetDevice_name,
                                                            "Image files (*.png *.jpg *.gif)")

                image_path = self.filename[0]
                self.User_Image = os.path.basename(image_path).split('/')[-1]
                GlobalVariable.profile_picture_name = self.User_Image
                shutil.copy(image_path, PathConfig.Logo.PROFILE_PATH)
                self.lblProfilePic.setStyleSheet("QLabel"
                                                 "{"
                                                 "background-image :url( " + ROOT_PATH + "Images/ProfilePicture/" + self.User_Image + ");"
                                                                                                                                      "border : none "
                                                                                                                                      "}"
                                                 )

            else:
                MessagePopup.setting_msg_popup(self, "error", "No Device Found!")
        except OSError as e:
            MessagePopup.setting_msg_popup(self, "error", "No Device Found!")
            print(e)


    '''Assign Role logic'''
    def init_assign_role(self):
        try:
            pass
        except Exception as e:
            print(e)

    def fill_Roles(self):
        try:
            ProfileInfo.fetch_available_roles(self)
            self.dgvDisplayUserDetails.setEnabled(False)

            self.dgvDisplayUserDetails.setRowCount(0)
            self.result = LoginBL().get_Users()
            self.dgvDisplayUserDetails.setColumnCount(3)
            self.dgvDisplayUserDetails.setStyleSheet("font: 18px Regular Inter;")
            header = self.dgvDisplayUserDetails.verticalHeader()
            header.setVisible(False)

            # Get the horizontal header
            self.dgvDisplayUserDetails.setHorizontalHeaderLabels(
                ['Name', 'Status ', 'Role'])
            header = self.dgvDisplayUserDetails.horizontalHeader()
            header.setStyleSheet(
                "QHeaderView::section { background-color: rgba(238,242,255,255); }")
            header.setFixedHeight(50)
            font = QFont("Arial", 14)
            header.setFont(font)

            self.dgvDisplayUserDetails.setRowCount(0)
            for row_number, row_data in enumerate(self.result):
                self.dgvDisplayUserDetails.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.dgvDisplayUserDetails.setColumnWidth(column_number, 160)
                    self.dgvDisplayUserDetails.setRowHeight(row_number, 50)
                    if column_number == 2:
                        self.combobox = QComboBox()
                        '''Background color for Combobox'''
                        for row in range(self.dgvDisplayUserDetails.rowCount()):
                            if row % 2 == 0:
                                UiComponents.StyleSheet_For_EvenRowCombobox(self)
                            else:
                                UiComponents.StyleSheet_For_OddRowCombobox(self)

                        if not len(self.lst_available_roles) <= 0:
                            self.combobox.addItems(self.lst_available_roles)
                        if not data == "Pending":
                            self.combobox.setCurrentText(data)
                            Status = QTableWidgetItem("Active")
                            Status.setTextAlignment(QtCore.Qt.AlignCenter)
                            self.dgvDisplayUserDetails.setItem(
                                row_number, 1, Status)
                        else:
                            self.combobox.setCurrentIndex(-1)
                            Status = QTableWidgetItem("Pending")
                            Status.setTextAlignment(QtCore.Qt.AlignCenter)
                            self.dgvDisplayUserDetails.setItem(
                                row_number, 1, Status)
                        self.combobox.currentTextChanged.connect(
                            self.combo_box_changed)
                        self.dgvDisplayUserDetails.setCellWidget(
                            row_number, column_number, self.combobox)
                    else:
                        item = QTableWidgetItem(str(data))
                        item.setTextAlignment(
                            QtCore.Qt.AlignCenter)  # Qt.AlignCenter
                        self.dgvDisplayUserDetails.setItem(
                            row_number, column_number, item)
                '''To Set Background color for table widget'''
                for row in range(self.dgvDisplayUserDetails.rowCount()):
                    if row % 2 == 0:
                        for column in range(
                                self.dgvDisplayUserDetails.columnCount()):
                            item = self.dgvDisplayUserDetails.item(row, column)
                            if item is not None:
                                item.setBackground(
                                    QColor(254, 254, 254))  # Light blue
                    else:
                        for column in range(
                                self.dgvDisplayUserDetails.columnCount()):
                            item = self.dgvDisplayUserDetails.item(row, column)
                            if item is not None:
                                item.setBackground(
                                    QColor(244, 246, 252, 255))  # Light blue
        except Exception as e:
            print(e)

    def combo_box_changed(self, text):
        try:
            from BusinessLogic.AccountSettingBL import AccountSettingBL
            self.role_id = ""
            combo_box = self.sender()
            selected_row = self.dgvDisplayUserDetails.indexAt(
                combo_box.pos()).row()
            Status = QTableWidgetItem("Active")
            Status.setTextAlignment(QtCore.Qt.AlignCenter)
            value = self.dgvDisplayUserDetails.item(selected_row, 0).text()
            self.dgvDisplayUserDetails.setItem(selected_row, 1, Status)
            self.role_id = AccountSettingBL().fetch_selected_roles(str(text))
            self.user_id = AccountSettingBL().fetch_selected_userID(value)
            self.Result = AccountSettingBL().Update_AssignRoles(self.user_id,
                                                                str(self.role_id), str(GlobalVariable.time))
            MessagePopup.setting_msg_popup(self, "correct", "Saved Successfully !! ")
        except Exception as e:
            print(e)
    def fetch_available_roles(self):
        try:
            self.lst_available_roles = []
            self.lst_available_roles = LoginBL().FetchAvailableRoles()
            pass
        except Exception as e:
            print(e)
        finally:
            pass

    def assign_user_roles(self,text):
        try:
            self.role_id = ""
            combo_box = self.sender()
            selected_row = self.dgvDisplayUserDetails.indexAt(
                combo_box.pos()).row()
            Status = QTableWidgetItem("Active")
            Status.setTextAlignment(QtCore.Qt.AlignCenter)
            value = self.dgvDisplayUserDetails.item(selected_row, 0).text()
            self.dgvDisplayUserDetails.setItem(selected_row, 1, Status)
            self.role_id = LoginBL().fetch_selected_roles(str(text))
            self.user_id = LoginBL().fetch_selected_userID(value)
            self.Result = LoginBL().Update_AssignRoles(self.user_id,
                                                                str(self.role_id), str(GlobalVariable.time))
            MessagePopup.setting_msg_popup(self, "correct", "Saved Successfully !! ")
            pass
        except Exception as e:
            print(e)
