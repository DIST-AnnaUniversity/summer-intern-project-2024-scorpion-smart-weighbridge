from PyQt5.QtCore import Qt
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow
from Presentation.Bundles.UiConfiguration import PathConfig
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Utilities.ThreadProgress import ThreadProgress


class SplashScreen(QMainWindow, PathConfig.UI.FROM_SPLASH):
    def __init__(self, parent=None):
        super(SplashScreen, self).__init__(parent)
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_SPLASH)
        self.splash_image.setPixmap(pixmap.scaled(800, 480))
        self.lbl_version.setText(GlobalVariable.app_version)
        self.progress_thread = ThreadProgress(self)
        self.progress_thread.signal.connect(self.progress)
        self.progress_thread.start()
        UiComponents.SplashUiComponents(self)

    @pyqtSlot(int)
    def progress(self, i):
        try:
            self.pbLoading.setValue(i)
            if i >= 100:
                self.progress_thread.terminate()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen_obj = MainScreen(self)
                self.main_screen_obj.show()
                self.hide()
        except OSError as e:
            print(e)
