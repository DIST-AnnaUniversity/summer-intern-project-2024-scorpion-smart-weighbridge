import platform
from datetime import datetime
import serial
import os
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, QTimer, QTime, QRegExp, QDateTime, pyqtSlot
from PyQt5.QtGui import QPixmap, QFont, QRegExpValidator
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QMainWindow, QGraphicsDropShadowEffect, QLabel, QLineEdit, QComboBox, QSizePolicy
from decimal import Decimal
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.ReEntryCamera import Preview
from Presentation.Py.extended_combobox import ExtendedComboBox
from BusinessLogic.CloudStorageBL import CloudStorageBL
from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols


class ModelReentry:
    SerialNo = ""

    Code1 = ""
    Code2 = ""
    Code3 = ""
    Code4 = ""
    Code5 = ""
    code1_value = ""
    code2_value = ""
    code3_value = ""
    code4_value = ""
    code5_value = ""
    Field1 = ""
    Field2 = ""
    Field3 = ""
    Field4 = ""
    Field5 = ""
    gunny_status = ""
    CurrentWt = ""
    GrossWt = ""
    TareWt = ""
    NetWt = ""
    GrossDate = ""
    TareDate = ""
    Amount = ""
    Unit = ""
    report_date = ""
    report_time = ""
    CustCode = ""
    DeviceId = ""
    entry_amount = 0
    manual_entry_status = ""


class VehicleReEntry(QMainWindow, PathConfig.UI.FROM_REENTRY):
    def __init__(self, parent=None):
        super(VehicleReEntry, self).__init__(parent)
        QMainWindow.__init__(self)
        self.selected_code_3 = None
        self.selected_code_4 = None
        self.selected_code_5 = None
        self.selected_code_2 = None
        self.selected_code_1 = None
        self.selected_serial_no = None
        self.selected_vehicle = None
        self.converted_negative_status = ""
        self.negative_sign = ""
        self.gunny_status = ""
        self.manual_entry_status = ""
        self.camera_obj = None
        self.current_entry = None
        self.previous_entry = None
        self.main_screen = None
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_ReEntry)
        self.main_screen_bg.setPixmap(pixmap.scaled(800, 480))
        self.create_custom_combobox()
        UiComponents.VehicleReEntryUiComponents(self)
        UiComponents.set_text_box_active_style(self, self.txt_amount)
        UiComponents.shortcuts(self)
        self.event_handlers()
        self.model = ModelReentry
        self.fetch_header_settings()
        'Declarations'
        self.tool_tip.setVisible(False)
        self.current_serial_no = None
        self.flg_code1 = False
        self.flg_code2 = False
        self.flg_code3 = False
        self.flg_code4 = False
        self.flg_code5 = False
        self.flg_header1 = False
        self.flg_header2 = False
        self.flg_header3 = False
        self.flg_header4 = False
        self.flg_gunny_bag = False
        self.flg_gunny_bag_enabled = False
        self.flg_header5 = False
        self.flg_gross_weight = False
        self.flg_save = False
        self.flg_save_enabled = False
        self.flg_manual_mode = False
        GlobalVariable.FlagWriteDecimal = True
        self.header_enable = False
        self.code_display = False
        self.code_enable = False
        self.count = 0
        self.code_count = 0
        self.header_count = 0
        self.code_display_count = 0
        self.FlagTare = False
        self.PortNo = ""
        self.GetLoad = ""
        self.FlagTare = False
        self.PortNo = ""
        self.Tempdisplaydata = ""
        self.TempDisplay = ""
        self.DisplayData = ""
        self.DecimalPoint = ""

        self.GetComSettings()
        self.is_validation_error = False
        self.gunny = None
        self.timerWriteData = QTimer(self)
        self.timerWriteData.timeout.connect(self.WriteToController)
        self.timerWriteData.start(100)
        self.timerReadData = QTimer(self)
        self.timerReadData.timeout.connect(self.ReadControllerData)
        self.timerReadData.start(100)
        self.timerShowData = QTimer(self)
        self.timerShowData.timeout.connect(self.DisplayReceivedData)
        self.timerShowData.start(100)
        self.timerdatetime = QTimer(self)
        self.timerdatetime.timeout.connect(self.date_time)
        self.timerdatetime.start(100)

        self.tmr_msg = QTimer()
        self.tmr_msg.setSingleShot(True)
        self.tmr_msg.setInterval(2000)
        self.tmr_error_msg = QTimer()
        self.tmr_error_msg.timeout.connect(self.display_msg)
        # self.tmr_check_wifi = QTimer(self)
        # self.tmr_check_wifi.timeout.connect(self.update_cloud_to_local)
        # self.tmr_check_wifi.start(100)
        '''Wifi Status'''
        if not platform.system() == "Windows":
            WifiConfiguration.start_thread_for_wifi_status(self)
        self.on_load_event()
        self.key_actions = {
            Qt.Key_Escape: self.on_click_home,
            Qt.Key_P: self.on_click_print,
            Qt.Key_S: self.on_click_save,
            Qt.Key_G: self.on_click_gross,
            Qt.Key_T: self.on_click_tare,
            Qt.Key_A: self.on_press_key_A,
            Qt.Key_D: self.on_click_delete,
            Qt.Key_C: self.on_click_cancel,
            Qt.Key_F4: self.on_click_entry,
            Qt.Key_F5: self.header_back,
            Qt.Key_F6: self.header_next,
            Qt.Key_F7: self.code_back,
            Qt.Key_F8: self.code_next,
            Qt.Key_Return: self.on_click_enter,
            # Qt.Key_Backspace: self.on_click_back
            Qt.Key_Y: self.on_click_y_key,
            Qt.Key_N: self.on_click_N_key


        }

    def on_click_y_key(self):
        try:
            if self.pnl_save_confirm.isVisible():
                self.on_click_save_confirm_ok()
            elif self.pnl_gunny_bag.isVisible():
                self.on_click_gunnyBag_OK()
        except Exception as e:
            print(e)

    def on_click_N_key(self):
        try:
            if self.pnl_save_confirm.isVisible():
                self.on_click_save_confirm_cancel()
            elif self.pnl_gunny_bag.isVisible():
                self.on_click_gunnyBag_Cancel()
        except Exception as e:
            print(e)

    def display_msg(self):
        try:
            if self.txt_gross_weight.text() and self.txt_tare_weight.text() == '0':
                text = """
                                                      <p>Press <span style="font-size:16pt;">T</span> for Tare </p>
                                                      """
                self.lbl_msg.setText(text)
                UiComponents.set_text_box_focus_style(self, self.txt_tare_weight)
                UiComponents.set_text_box_normal_style(self, self.txt_gross_weight)
                self.lbl_msg.setVisible(not self.lbl_msg.isVisible())
            elif self.txt_tare_weight.text() and self.txt_gross_weight.text() == '0':
                text = """
                                                                     <p>Press <span style="font-size:16pt;">G</span> for Gross </p>
                                                                     """
                self.lbl_msg.setText(text)
                UiComponents.set_text_box_focus_style(self, self.txt_gross_weight)
                UiComponents.set_text_box_normal_style(self, self.txt_tare_weight)
                self.lbl_msg.setVisible(not self.lbl_msg.isVisible())
            else:
                self.lbl_msg.setVisible(False)
                UiComponents.set_text_box_normal_style(self, self.txt_gross_weight)
                UiComponents.set_text_box_normal_style(self, self.txt_tare_weight)

        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        UiComponents.set_combo_box(self, self.list_cmb_code_names)
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def mousePressEvent(self, event):
        UiComponents.set_combo_box(self, self.list_cmb_code_names)

    def event_handlers(self):
        try:

            self.btn_save.clicked.connect(self.on_click_save)
            self.btn_entry.clicked.connect(self.on_click_entry)
            self.btn_print.clicked.connect(self.on_click_print)
            self.btn_cancel.clicked.connect(self.on_click_cancel)
            self.btn_tare_weight.clicked.connect(self.on_click_tare)
            self.btn_gross_weight.clicked.connect(self.on_click_gross)
            self.btn_home.clicked.connect(self.on_click_home)
            self.btn_gross_weight_delete.clicked.connect(self.on_click_gross_wt_clr)
            self.btn_tare_weight_delete.clicked.connect(self.on_click_tare_wt_clr)
            self.btn_next.clicked.connect(self.on_click_next)
            self.btn_gunny_bag_ok.clicked.connect(self.on_click_gunnyBag_OK)
            self.btn_gunny_bag_cancel.clicked.connect(self.on_click_gunnyBag_Cancel)
            self.btn_gunny_bag.clicked.connect(self.GunnyBag_StateChange)
            self.btn_close_preview.clicked.connect(self.on_click_close_preview)
            self.btn_print_preview.clicked.connect(self.on_click_print)
            self.btn_header_next.clicked.connect(self.header_next)
            self.btn_header_back.clicked.connect(self.header_back)
            self.btn_code_next.clicked.connect(self.code_next)
            self.btn_code_back.clicked.connect(self.code_back)
            self.btn_save_confirm_cancel.clicked.connect(self.on_click_save_confirm_cancel)
            self.btn_save_confirm_ok.clicked.connect(self.on_click_save_confirm_ok)
            self.txt_amount.textChanged.connect(self.amount_text_changed)
            self.btn_preview.clicked.connect(self.on_click_preview)
            self.txt_bag_count.textChanged.connect(self.bag_count_text_changed)
            self.cmb_code1.currentIndexChanged.connect(self.on_code1_index_changed)
            self.cmb_code2.currentIndexChanged.connect(self.on_code2_index_changed)
            self.cmb_code3.currentIndexChanged.connect(self.on_code3_index_changed)
            self.cmb_code4.currentIndexChanged.connect(self.on_code4_index_changed)
            self.cmb_code5.currentIndexChanged.connect(self.on_code5_index_changed)
            self.cmb_serial_no.currentIndexChanged.connect(self.on_serial_no_index_changed)
            self.cmb_header1.currentIndexChanged.connect(self.on_vehicle_no_index_changed)
        except Exception as e:
            print(e)

    def on_code1_index_changed(self, index):
        index = self.cmb_code1.currentIndex()
        self.selected_code_1 = self.cmb_code1.itemText(index)

    def on_code2_index_changed(self, index):
        index = self.cmb_code2.currentIndex()
        self.selected_code_2 = self.cmb_code2.itemText(index)

    def on_code3_index_changed(self, index):
        index = self.cmb_code3.currentIndex()
        self.selected_code_3 = self.cmb_code3.itemText(index)

    def on_code4_index_changed(self, index):
        index = self.cmb_code4.currentIndex()
        self.selected_code_4 = self.cmb_code4.itemText(index)

    def on_code5_index_changed(self, index):
        index = self.cmb_code5.currentIndex()
        self.selected_code_5 = self.cmb_code5.itemText(index)

    def on_serial_no_index_changed(self, index):
        try:
            index = self.cmb_serial_no.currentIndex()
            self.get_selected_serial_no = self.cmb_serial_no.itemText(index)
            GlobalVariable.Bill_index = self.get_selected_serial_no
        except Exception as e:
            print(e)

    def on_vehicle_no_index_changed(self, index):
        try:
            index = self.cmb_header1.currentIndex()
            self.get_selected_vehicle = self.cmb_header1.itemText(index)
        except Exception as e:
            print(e)

    def bag_count_text_changed(self, text):
        try:
            cleaned_text1 = text.replace('Y', '').replace('y', '')
            cleaned_text2 = text.replace('N', '').replace('n', '')
            if 'Y' in text or 'y' in text:
                self.txt_bag_count.setText(cleaned_text1)
                self.on_click_gunnyBag_OK()
            elif 'N' in text or 'n' in text:
                self.txt_bag_count.setText(cleaned_text2)
                self.on_click_gunnyBag_Cancel()
        except Exception as e:
            print(e)

    def on_click_gunnyBag_OK(self):
        try:
            if self.txt_bag_weight.text() != "" and self.txt_bag_count.text() != "" and self.txt_gross_weight.text() != "":
                self.bagweight = int(self.txt_bag_weight.text())
                self.bagcount = int(self.txt_bag_count.text())
                self.grosswt = int(self.txt_gross_weight.text()) - int(self.bagweight * self.bagcount)
                self.txt_gross_weight.setText(str(round(self.grosswt, 6)))
                self.model.GrossWt = self.txt_gross_weight.text()
                self.netwt_calculation()
                self.btn_gunny_bag.setEnabled(False)
                self.pnl_gunny_bag.setVisible(False)
            else:
                self.gunny_bag_validation()
            self.txt_amount.setFocus()

        except OSError as e:
            print(e)

    def GunnyBag_StateChange(self):
        try:
            if not self.txt_gross_weight.text() or str(self.txt_gross_weight.text()) == '0':
                self.is_validation_error = True
                self.pnl_gunny_bag.setVisible(False)
                self.setToolTipMessage("enter gross weight !!")
                return self.is_validation_error
            else:
                self.flg_gunny_bag = True
                self.txt_bag_weight.clear()
                self.txt_bag_count.clear()
                self.pnl_gunny_bag.setVisible(True)
                self.txt_bag_weight.setFocus()
        except OSError as e:
            print(e)

    def on_click_gunnyBag_Cancel(self):
        try:
            self.txt_bag_weight.setText("")
            self.txt_bag_count.setText("")
            self.pnl_gunny_bag.setVisible(False)
            self.flg_gunny_bag = False
            self.txt_amount.setFocus()
        except OSError as e:
            print(e)

    def amount_text_changed(self, text):
        try:
            cleaned_text = text.replace('D', '').replace('d', '')
            cleaned_text_save = text.replace('S', '').replace('s', '')
            if 'D' in text or 'd' in text:
                self.txt_amount.setText(cleaned_text)
                self.txt_amount.clear()
                self.on_click_delete()
            elif 'S' in text or 's' in text:
                self.txt_amount.setText(cleaned_text_save)
                if self.txt_amount.text() and not self.flg_save and not self.flg_save_enabled and self.btn_save.isEnabled():
                    self.on_click_save()
        except Exception as e:
            print(e)

    def on_click_delete(self):
        try:
            self.txt_amount.clear()
            self.txt_amount.clearFocus()
            if self.flg_gross_weight:
                self.on_click_gross_wt_clr()
            else:
                self.on_click_tare_wt_clr()
        except Exception as e:
            print(e)

    def header_next(self):
        try:
            if self.count_of_ones == 5:
                self.display_header_count5()
            elif self.count_of_ones == 4:
                self.display_header_count4()
            elif self.count_of_ones == 3:
                self.display_header_count3()
            elif self.count_of_ones == 2:
                self.display_header_count2()
        except Exception as e:
            print(e)

    def header_back(self):
        try:
            self.display_back_header()
        except Exception as e:
            print(e)

    def code_next(self):
        try:
            if self.code_count_of_ones == 5:
                self.display_code_count5()
            elif self.code_count_of_ones == 4:
                self.display_code_count4()
            elif self.code_count_of_ones == 3:
                self.display_code_count3()
            elif self.code_count_of_ones == 2:
                self.display_code_count2()
        except Exception as e:
            print(e)

    def code_back(self):
        try:
            self.display_back_code()
        except Exception as e:
            print(e)

    def on_changed_vehicle(self):
        try:
            current_text = self.cmb_header1.currentText()
            if current_text:
                index = self.cmb_header1.findText(current_text)
                if index != -1:
                    self.cmb_header1.setCurrentIndex(index)
                    self.selected_vehicle = self.cmb_header1.itemText(index)
                    selected_vehicles = VehicleReEntryBL().get_selected_vehicle(self.selected_vehicle)
                    if selected_vehicles:
                        self.lbl_vehicle_no.setText(str(self.selected_vehicle))
                        self.fill_model(selected_vehicles)
                    else:
                        pass
                    self.flg_save_enabled = False
        except OSError as e:
            print(e)

    def get_all_serial_no(self):
        try:
            self.cmb_serial_no.clear()
            entrylist = VehicleReEntryBL().get_all_entries()
            for row_data in entrylist:
                self.cmb_serial_no.addItem(row_data)
            self.cmb_serial_no.setCurrentIndex(-1)
            # self.on_changed_serial_no()
        except OSError as e:
            print(e)

    def on_click_recall(self):
        try:
            print("on_click_recall")
            pass
        except OSError as e:
            print(e)

    def on_press_key_A(self):
        try:
            if self.txt_amount.isEnabled():
                self.txt_amount.setFocus()
                UiComponents.set_text_box_active_style(self, self.txt_amount)
            else:
                print("txt_amount_is_disabled")
            pass
        except OSError as e:
            print(e)

    def on_changed_serial_no(self):
        try:
            current_text = self.cmb_serial_no.currentText()
            if current_text:
                index = self.cmb_serial_no.findText(current_text)
                if index != -1:
                    self.cmb_serial_no.setCurrentIndex(index)
                    self.selected_serial_no = self.cmb_serial_no.itemText(index)
                    selected_entries = VehicleReEntryBL().get_selected_entries(self.selected_serial_no)
                    if selected_entries:
                        self.fill_model(selected_entries)
                    else:
                        # Handle case where no entry data is returned
                        self.lbl_serial_no.setText("No data found")
                    self.btn_save.setEnabled(True)
                    self.flg_save_enabled = False
                else:
                    # Handle case where the text is not found in the combo box
                    self.lbl_serial_no.setText("Invalid selection")
                    self.btn_save.setEnabled(False)
            else:
                # Handle case where no item is selected
                self.lbl_serial_no.setText("")
                self.btn_save.setEnabled(False)
        except OSError as e:
            print(e)

    def validate_default(self, mvalue):
        try:
            return str(mvalue) if mvalue is not None else ""
        except OSError as e:
            print(e)

    def fill_model(self, mdata):
        try:
            self.model.SerialNo = self.validate_default(mdata[0][0])
            self.model.Field1 = self.validate_default(mdata[0][1])
            self.model.Field2 = self.validate_default(mdata[0][2])
            self.model.Field3 = self.validate_default(mdata[0][3])
            self.model.Field4 = self.validate_default(mdata[0][4])
            self.model.Field5 = self.validate_default(mdata[0][5])
            self.model.Code1 = self.validate_default(mdata[0][6])
            self.model.Code2 = self.validate_default(mdata[0][7])
            self.model.Code3 = self.validate_default(mdata[0][8])
            self.model.Code4 = self.validate_default(mdata[0][9])
            self.model.Code5 = self.validate_default(mdata[0][10])
            self.model.code1_value = self.validate_default(mdata[0][11])
            self.model.code2_value = self.validate_default(mdata[0][12])
            self.model.code3_value = self.validate_default(mdata[0][13])
            self.model.code4_value = self.validate_default(mdata[0][14])
            self.model.code5_value = self.validate_default(mdata[0][15])
            self.model.GrossWt = self.validate_default(mdata[0][16])
            self.model.Unit = self.validate_default(mdata[0][17])
            self.model.GrossDate = self.validate_default(mdata[0][19])
            self.model.TareWt = self.validate_default(mdata[0][20])
            self.model.TareDate = self.validate_default(mdata[0][23])
            self.model.entry_amount = self.validate_default(mdata[0][25])
            self.model.gunny_status = self.validate_default(mdata[0][32])
            self.model.manual_entry_status = self.validate_default(mdata[0][33])
            self.model.NetWt = self.netwt_calculation()
            self.cmb_serial_no.clearFocus()
            self.assign_entries()
        except OSError as e:
            print(e)

    def assign_entries(self):
        try:
            self.fill_code_items()
            self.cmb_serial_no.setCurrentText(self.model.SerialNo)
            self.lbl_vehicle_no.setText(str(self.model.Field1))
            self.cmb_header1.setCurrentText(self.model.Field1)
            current_vehicle_text = self.cmb_header1.currentText()
            current_serial_no_text = self.cmb_serial_no.currentText()
            if current_vehicle_text:
                vehicle_index = self.cmb_header1.findText(current_vehicle_text)
                if vehicle_index != -1:
                    self.cmb_header1.setCurrentIndex(vehicle_index)
                    self.selected_vehicle = self.cmb_header1.itemText(vehicle_index)
            if current_serial_no_text:
                serial_no_index = self.cmb_serial_no.findText(current_serial_no_text)
                if serial_no_index != -1:
                    self.cmb_serial_no.setCurrentIndex(serial_no_index)
                    self.selected_serial_no = self.cmb_serial_no.itemText(serial_no_index)
            self.txt_header2.setText(self.model.Field2)
            self.txt_header3.setText(self.model.Field3)
            self.txt_header4.setText(self.model.Field4)
            self.txt_header5.setText(self.model.Field5)
            self.cmb_code1.setCurrentText(self.model.Code1)
            self.cmb_code2.setCurrentText(self.model.Code2)
            self.cmb_code3.setCurrentText(self.model.Code3)
            self.cmb_code4.setCurrentText(self.model.Code4)
            self.cmb_code5.setCurrentText(self.model.Code5)
            self.lbl_code_value1.setText(self.model.code1_value)
            self.lbl_code_value2.setText(self.model.code2_value)
            self.lbl_code_value3.setText(self.model.code3_value)
            self.lbl_code_value4.setText(self.model.code4_value)
            self.lbl_code_value5.setText(self.model.code5_value)
            self.txt_gross_weight.setText(self.model.GrossWt)
            self.txt_tare_weight.setText(self.model.TareWt)
            self.txt_net_weight.setText(self.model.NetWt)
            self.txt_gross_date_time.setText(self.model.GrossDate)
            self.txt_tare_date_time.setText(self.model.TareDate)
            if self.model.GrossWt:
                if str(self.model.GrossWt) == '0':
                    self.btn_gross_weight.setEnabled(True)
                    self.btn_gross_weight_delete.setEnabled(True)
                if not str(self.model.GrossWt) == '0':
                    self.btn_gross_weight.setEnabled(False)
                    self.btn_gross_weight_delete.setEnabled(False)
                    self.lbl_header.setText(self.model.GrossWt)
                    self.previous_entry = "Gross Amount"
                    self.btn_gunny_bag.setEnabled(False)
                    self.current_entry = "Tare Amount"
                    if self.model.gunny_status == '1':
                        self.gunny_status = "#"
            if self.model.TareWt:
                if str(self.model.TareWt) == '0':
                    self.btn_tare_weight.setEnabled(True)
                    self.btn_tare_weight_delete.setEnabled(True)
                if not str(self.model.TareWt) == '0':
                    self.btn_tare_weight.setEnabled(False)
                    self.btn_tare_weight_delete.setEnabled(False)
                    self.lbl_header.setText(self.model.TareWt)
                    self.previous_entry = "Tare Amount"
                    self.current_entry = "Gross Amount"
                    if self.model.manual_entry_status == '1':
                        self.manual_entry_status = "*"
                    if self.flg_gunny_bag_enabled:
                        self.btn_gunny_bag.setEnabled(True)
            self.tmr_error_msg.start(1000)
            self.btn_save.setEnabled(True)
        except OSError as e:
            print(e)

    def on_changed_code1(self):
        try:
            self.model.Code1 = self.cmb_code1.currentText()
            code1name_value = VehicleReEntryBL().get_code1name(self.cmb_code1.currentText())
            if code1name_value:
                self.lbl_code_value1.setText(code1name_value[0][0])
        except OSError as e:
            print(e)

    def get_all_product(self):
        try:
            entrylist = VehicleReEntryBL().get_all_entries()
            for row_data in entrylist:
                self.cmb_serialno.addItem(row_data)
            self.on_changed_entries()
        except OSError as e:
            print(e)

    def on_changed_code2(self):
        try:
            self.model.Code2 = self.cmb_code2.currentText()
            code2name_value = VehicleReEntryBL().get_code2name(self.cmb_code2.currentText())
            if code2name_value:
                self.lbl_code_value2.setText(code2name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code3(self):
        try:
            self.model.Code3 = self.cmb_code3.currentText()
            code3name_value = VehicleReEntryBL().get_code3name(self.cmb_code3.currentText())
            if code3name_value:
                self.lbl_code_value3.setText(code3name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code4(self):
        try:
            self.model.Code4 = self.cmb_code4.currentText()
            code4name_value = VehicleReEntryBL().get_code4name(self.cmb_code4.currentText())
            if code4name_value:
                self.lbl_code_value4.setText(code4name_value[0][0])
        except OSError as e:
            print(e)

    def on_changed_code5(self):
        try:
            self.model.Code5 = self.cmb_code5.currentText()
            code5name_value = VehicleReEntryBL().get_code5name(self.cmb_code5.currentText())
            if code5name_value:
                self.lbl_code_value5.setText(code5name_value[0][0])
        except OSError as e:
            print(e)

    def date_time(self):
        try:
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_current_time.setText(formatted_datetime)
        except Exception as e:
            print(e)

    def GetComSettings(self):
        try:
            self.OpenCommunicationPort()
            pass
        except OSError as e:
            print(e)

    def OpenCommunicationPort(self):
        try:
            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    GlobalVariable.Serial_Port = None
                    GlobalVariable.Serial_Port = serial.Serial(GlobalVariable.get_com_port,
                                                               GlobalVariable.get_baud_rate,
                                                               timeout=0)
                    GlobalVariable.Serial_Port.close()
                    GlobalVariable.Serial_Port.open()
                    self.FlagCheckComm = True
                else:
                    self.FlagCheckComm = False
            else:
                self.FlagCheckComm = False
        except Exception as e:
            print(e)

    def WriteToController(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagWriteDecimal:
                    GlobalVariable.TempDecimalWriteProtocol = bytes.fromhex(ModbusProtocols.DecimalWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempDecimalWriteProtocol)
                    GlobalVariable.TempDecimalWriteProtocol = ""
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadDecimal = True
                    GlobalVariable.FlagReadLoad = False
                    GlobalVariable.FlagWriteDecimal = False
                elif GlobalVariable.FlagWriteLoad:
                    GlobalVariable.TempLoadWriteProtocol = bytes.fromhex(ModbusProtocols.CurrentLoadWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempLoadWriteProtocol)
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagStartRead = True
                    GlobalVariable.FlagReadLoad = True
                    pass
                elif GlobalVariable.FlagWriteTare:
                    GlobalVariable.TempTareProtocol = bytes.fromhex(ModbusProtocols.TareWriteProtocol)
                    GlobalVariable.Serial_Port.write(GlobalVariable.TempTareProtocol)
                    GlobalVariable.FlagWriteTare = False
                    GlobalVariable.FlagWriteDecimal = False
                    GlobalVariable.FlagWriteLoad = True
                    self.FlagTare = True
                    pass

        except Exception as e:
            print(e)

    def ReadControllerData(self):
        try:
            if not GlobalVariable.Serial_Port is None:
                if GlobalVariable.FlagStartRead:
                    self.ReadData = GlobalVariable.Serial_Port.read_all().hex()
                    if not self.ReadData is None:
                        if GlobalVariable.FlagReadDecimal:
                            self.DecimalReadData = self.ReadData
                            if len(self.DecimalReadData) == ModbusProtocols.DecimalReadProtocolLength:
                                GlobalVariable.DecimalPoint = self.DecimalReadData[6: 10]
                                GlobalVariable.DecimalPoint = Modbus.ConvertToInt(self, GlobalVariable.DecimalPoint)
                                GlobalVariable.FlagReadDecimal = False
                                GlobalVariable.FlagWriteLoad = True
                                pass
                        if GlobalVariable.FlagReadLoad:  # 01030a00010c41000000d4000035df
                            self.LoadReadData = self.ReadData
                            if len(self.LoadReadData) == ModbusProtocols.LoadReadProtocolLength:
                                self.negative_sign = self.LoadReadData[6:10]
                                self.converted_negative_status = Modbus.ConvertToInt(self, self.negative_sign)
                                self.GetLoad = self.LoadReadData[22:26] + self.LoadReadData[18:22]  # 000002d4
                                self.Tempdisplaydata = Modbus.ConvertToInt(self, self.GetLoad)
                                self.TempDisplay = str(self.Tempdisplaydata)
                                if len(self.TempDisplay) == 4:
                                    self.TempDisplay = "0" + self.TempDisplay
                                elif len(self.TempDisplay) == 3:
                                    self.TempDisplay = "00" + self.TempDisplay
                                elif len(self.TempDisplay) == 2:
                                    self.TempDisplay = "000" + self.TempDisplay
                                elif len(self.TempDisplay) == 1:
                                    self.TempDisplay = "0000" + self.TempDisplay
                                if GlobalEntities.remote_config_status == '1':
                                    self.write_data_to_remote_config_port(self.TempDisplay)
                                N = 5 - int(GlobalVariable.DecimalPoint)
                                if not N == 5:
                                    self.DisplayData = str(self.TempDisplay)[:N] + "." + str(self.TempDisplay)[
                                                                                         N:]
                                else:
                                    self.DisplayData = str(self.TempDisplay)
                                GlobalVariable.FlagDisplayData = True
        except Exception as e:
            print(e)

    def DisplayReceivedData(self):
        try:
            if GlobalVariable.FlagDisplayData:
                if not self.DisplayData == "":
                    self.Display(self.DisplayData, self.TempDisplay)
        except Exception as e:
            print(e)

    def Display(self, displayData, checkStatusDisplayData):
        try:
            if not displayData == "":
                if checkStatusDisplayData.__contains__("99999"):
                    self.lbl_weight.setText(str("-OR-"))
                elif checkStatusDisplayData.__contains__("77777"):
                    self.lbl_weight.setText(str("-UR-"))
                elif checkStatusDisplayData.__contains__("88888"):
                    self.lbl_weight.setText(str("-OC-"))
                else:
                    if str(self.converted_negative_status) == '1' or str(self.converted_negative_status) == '3':
                        self.lbl_weight.setText(str('-' + str(Decimal(displayData))))
                    else:
                        self.lbl_weight.setText(str(Decimal(displayData)))
        except OSError as e:
            print(e)

    def on_click_save(self):
        try:
            self.btn_save_confirm_ok.setEnabled(True)
            self.btn_save_confirm_ok.setFocus()
            self.flg_save = True
            self.pnl_save_confirm.setVisible(True)
        except Exception as e:
            print(e)

    def on_click_save_confirm_cancel(self):
        try:
            self.flg_save = False
            self.btn_save_confirm_ok.setEnabled(True)
            self.flg_save_enabled = False
            self.pnl_save_confirm.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_save_confirm_ok(self):
        try:
            self.btn_save_confirm_ok.setEnabled(False)
            self.pnl_save_confirm.setVisible(False)
            self.save()            
            self.btn_print.setFocus()
            self.camera = SystemConfigBL.get_camera_status(self)
            if not GlobalVariable.ActiveUser == "" and self.camera == 1:
                if self.camera_obj is None:
                    from Presentation.Py.ReEntryCamera import Preview
                    self.disable_timers()
                    self.camera_obj = Preview(self)
                    self.camera_obj.show()
        except Exception as e:
            print(e)

    def save(self):
        try:
            UiComponents.shortcuts(self)
            self.pnl_save_confirm.setVisible(False)
            self.btn_home.setEnabled(False)
            self.flg_save_enabled = True
            if self.input_validation_error():
                self.btn_home.setEnabled(True)
                self.pnl_save_confirm.setVisible(False)
            else:
                if self.flg_code1:
                    self.model.Code1 = self.selected_code_1
                    self.model.code1_value = self.lbl_code_value1.text()
                else:
                    self.model.code1 = ""
                    self.model.code1_value = ""
                if self.flg_code2:
                    self.model.Code2 = self.selected_code_2
                    self.model.code2_value = self.lbl_code_value2.text()
                else:
                    self.model.Code2 = ""
                    self.model.code2_value = ""
                if self.flg_code3:
                    self.model.Code3 = self.selected_code_3
                    self.model.code3_value = self.lbl_code_value3.text()
                else:
                    self.model.Code3 = ""
                    self.model.code3_value = ""
                if self.flg_code4:
                    self.model.Code4 = self.selected_code_4
                    self.model.code4_value = self.lbl_code_value4.text()
                else:
                    self.model.Code4 = ""
                    self.model.code4_value = ""
                if self.flg_code5:
                    self.model.Code5 = self.selected_code_5
                    self.model.code5_value = self.lbl_code_value5.text()
                else:
                    self.model.Code5 = ""
                    self.model.code5_value = ""
                self.model.grossunit = self.lbl_unit.text()
                self.model.tareunit = self.lbl_unit.text()
                self.model.SerialNo = self.selected_serial_no
                self.model.GrossWt = self.txt_gross_weight.text()
                if self.model.GrossWt == "":
                    self.model.GrossWt = 0
                if self.model.TareWt == "":
                    self.model.TareWt = 0
                if self.flg_gunny_bag:
                    self.model.gunny_status = '1'
                else:
                    self.model.gunny_status = '0'
                self.model.GrossDate = self.txt_gross_date_time.text()
                self.model.TareWt = self.txt_tare_weight.text()
                self.model.TareDate = self.txt_tare_date_time.text()
                self.model.Amount = self.txt_amount.text()
                self.model.NetWt = self.txt_net_weight.text()
                self.model.Field1 = self.selected_vehicle
                self.model.Field2 = self.txt_header2.text()
                self.model.Field3 = self.txt_header3.text()
                self.model.Field4 = self.txt_header4.text()
                self.model.Field5 = self.txt_header5.text()
                date = datetime.now()
                self.model.report_date = (date.strftime("%Y-%m-%d"))
                time = QTime.currentTime()
                self.model.report_time = (time.toString())
                VehicleReEntryBL().update_entry_details(self.model)
                # from Presentation.Py.CloudStorage import CloudStorage
                # if GlobalEntities.cloud_storage_status:
                #     self.model.CustCode = GlobalEntities.cust_code
                #     self.model.DeviceId = GlobalEntities.device_id
                #     CloudStorage.save_re_entry_details(self, self.model)
                self.print_data()
                self.update_transaction_details()
                # self.lbl_header.setText(self.txt_gross_weight.text())
                self.btn_print.setEnabled(True)
                self.enable_controls(False)
                self.btn_save.setEnabled(False)
                self.btn_home.setEnabled(True)
                self.btn_preview.setEnabled(True)
                self.setToolTipCorrectMessage("saved successfully !!")
                # from Services.mobile_notification_services import Mobile_Notifications
                transaction_details = VehicleEntryBL().fetch_transaction_details_param()
                # Mobile_Notifications.send_data_to_firestore_db(self, transaction_details)
                self.btn_print.setFocus()
                self.btn_save_confirm_ok.setEnabled(True)
            self.flg_save = False
            self.flg_save_enabled = False
        except Exception as e:
            print(e)

    def update_cloud_to_local(self):
        try:
            from Presentation.Py.CloudStorage import CloudStorage
            if GlobalVariable.wifi_status:
                self.cloud_storage_count = CloudStorageBL().get_cloud_storage_report_count()
                if self.cloud_storage_count > 0:
                    self.local_report = CloudStorageBL().get_cloud_local_storage()
                    for each_record in self.local_report:
                        self.result = CloudStorage.update_local_to_cloud_data(self, each_record)
                    CloudStorageBL().delete_cloud_local_storage()
            pass
        except Exception as e:
            print(e)

    def netwt_calculation(self):
        try:
            self.model.GrossWt = '0' if self.model.GrossWt == "" else self.model.GrossWt
            self.model.TareWt = '0' if self.model.TareWt == "" else self.model.TareWt
            if self.model.GrossWt != '0' and self.model.TareWt != '0':
                if '.' in self.model.GrossWt and '.' in self.model.TareWt:
                    self.net_weight = float(self.model.GrossWt) - float(self.model.TareWt)
                elif not '.' in self.model.GrossWt and not '.' in self.model.TareWt:
                    self.net_weight = int(self.model.GrossWt) - int(self.model.TareWt)
                elif '.' in self.model.GrossWt and not '.' in self.model.TareWt:
                    self.net_weight = float(self.model.GrossWt) - int(self.model.TareWt)
                elif not '.' in self.model.GrossWt and '.' in self.model.TareWt:
                    self.net_weight = int(self.model.GrossWt) - float(self.model.TareWt)
                self.txt_net_weight.setText(str(self.net_weight))
                return str(self.net_weight)
        except Exception as e:
            print(e)

    def input_validation_error(self):
        try:
            self.is_validation_error = False
            if self.flg_header1 and not self.cmb_header1.currentText():
                self.is_validation_error = True
                self.setToolTipMessage("enter header 1 !!")
                return self.is_validation_error
            else:
                if self.flg_header2 and len(str(self.txt_header2.text()).strip(" ")) == 0:
                    self.is_validation_error = True
                    self.setToolTipMessage("enter header 2 !!")
                    return self.is_validation_error
                else:
                    if self.flg_header3 and len(str(self.txt_header3.text()).strip(" ")) == 0:
                        self.is_validation_error = True
                        self.setToolTipMessage("enter header 3 !!")
                        return self.is_validation_error
                    else:
                        if self.flg_header4 and len(str(self.txt_header4.text()).strip(" ")) == 0:
                            self.is_validation_error = True
                            self.setToolTipMessage("enter header 4 !!")
                            return self.is_validation_error
                        else:
                            if self.flg_header5 and len(str(self.txt_header5.text()).strip(" ")) == 0:
                                self.is_validation_error = True
                                self.setToolTipMessage("enter header 5 !!")
                                return self.is_validation_error
                            else:
                                if self.flg_code1 and not self.lbl_code_value1.text():
                                    self.is_validation_error = True
                                    self.setToolTipMessage("select code 1 !!")
                                    return self.is_validation_error
                                else:
                                    if self.flg_code2 and len(str(self.lbl_code_value2.text()).strip(" ")) == 0:
                                        self.is_validation_error = True
                                        self.setToolTipMessage("select code 2 !!")
                                        return self.is_validation_error
                                    else:
                                        if self.flg_code3 and len(str(self.lbl_code_value3.text()).strip(" ")) == 0:
                                            self.is_validation_error = True
                                            self.setToolTipMessage("select code 3 !!")
                                            return self.is_validation_error
                                        else:
                                            if self.flg_code4 and len(str(self.lbl_code_value4.text()).strip(" ")) == 0:
                                                self.is_validation_error = True
                                                self.setToolTipMessage("select code 4 !!")
                                                return self.is_validation_error
                                            else:
                                                if self.flg_code5 and len(
                                                        str(self.lbl_code_value5.text()).strip(" ")) == 0:
                                                    self.is_validation_error = True
                                                    self.setToolTipMessage("select code 5 !!")
                                                    return self.is_validation_error
                                                else:
                                                    if str(
                                                            self.txt_gross_weight.text()) == '0' or self.txt_gross_weight.text() == "":
                                                        self.is_validation_error = True
                                                        self.setToolTipMessage("enter gross weight !!")
                                                        return self.is_validation_error
                                                    else:
                                                        if str(
                                                                self.txt_tare_weight.text()) == '0' or self.txt_tare_weight.text() == "":
                                                            self.is_validation_error = True
                                                            self.setToolTipMessage("enter tare weight !!")
                                                            return self.is_validation_error
                                                        else:
                                                            if self.txt_amount.isVisible() and len(
                                                                    str(self.txt_amount.text()).strip(" ")) == 0:
                                                                self.is_validation_error = True
                                                                self.setToolTipMessage("enter amount !!")
                                                                return self.is_validation_error
                                                            else:
                                                                if self.flg_gunny_bag and len(
                                                                        str(self.txt_bag_weight.text()).strip(
                                                                            " ")) == 0:
                                                                    self.is_validation_error = True
                                                                    self.setToolTipMessage(
                                                                        "enter bag weight !!")
                                                                    self.txt_bag_weight.setFocus()
                                                                    UiComponents.set_text_box_active_style(self,
                                                                                                           self.txt_bag_weight)
                                                                    self.btn_home.setEnabled(True)
                                                                    return self.is_validation_error
                                                                else:
                                                                    if self.flg_gunny_bag and len(
                                                                            str(self.txt_bag_count.text()).strip(
                                                                                " ")) == 0:
                                                                        self.is_validation_error = True
                                                                        self.txt_bag_count.setFocus()
                                                                        UiComponents.set_text_box_active_style(self,
                                                                                                               self.txt_bag_count)
                                                                        self.setToolTipMessage("enter bag count !!")
                                                                        self.btn_home.setEnabled(True)
                                                                        return self.is_validation_error
        except OSError as e:
            print(e)

    def on_click_cancel(self):
        try:
            UiComponents.shortcuts(self)
            self.lbl_msg.setVisible(False)
            self.tmr_error_msg.stop()
            UiComponents.set_text_box_normal_style(self, self.txt_gross_weight)
            UiComponents.set_text_box_normal_style(self, self.txt_tare_weight)
            UiComponents.ok_default(self, self.btn_tare_weight)
            UiComponents.ok_default(self, self.btn_gross_weight)
            self.clear_all_fields()
            self.fill_code_items()
            self.btn_save.setEnabled(True)
            self.txt_amount.setEnabled(False)
            self.flg_save_enabled = False
            self.pnl_save_confirm.setVisible(False)
            self.count = 0
            self.lbl_header.setText("")
            self.code_count = 0
            self.move_header_locations()
            self.move_code_locations()
            self.list_label_header_names[0].move(4, 10)
            self.list_text_header_names[0].move(197, 4)
            self.list_text_header_names[0].setFocus()
            self.list_label_code_names[0].move(5, 67)
            self.list_cmb_code_names[0].move(200, 62)
            self.list_cmb_code_names[0].setFocus()
            self.list_label_code_value_names[0].move(430, 62)
            self.header_enable = False
            self.code_enable = False
            self.btn_save_confirm_ok.setEnabled(True)
            self.cmb_serial_no.setFocus()
            self.btn_tare_weight.setEnabled(False)
            self.btn_gross_weight.setEnabled(False)
            self.btn_tare_weight_delete.setEnabled(False)
            self.btn_gross_weight_delete.setEnabled(False)
        except Exception as e:
            print(e)

    def on_click_entry(self):
        try:
            UiComponents.ok_default(self, self.btn_gross_weight)
            UiComponents.ok_default(self, self.btn_tare_weight)
            self.btn_preview.setEnabled(False)
            self.enable_controls(True)
            self.txt_tare_weight.setEnabled(False)
            self.btn_save.setEnabled(False)
            self.btn_entry.setEnabled(False)
            self.txt_tare_date_time.setEnabled(False)
            self.txt_gross_date_time.setEnabled(False)
            self.txt_gross_weight.setEnabled(False)
            self.btn_print.setEnabled(False)
            self.txt_net_weight.setEnabled(False)
            self.clear_all_fields()
            self.fill_code_items()
            self.input_char_validation()
            self.flg_save_enabled = False
            self.btn_gross_weight.setEnabled(False)
            self.btn_tare_weight.setEnabled(False)
            self.btn_tare_weight_delete.setEnabled(False)
            self.btn_gross_weight_delete.setEnabled(False)
            self.lbl_header.setText("")
        except Exception as e:
            print(e)

    def on_click_home(self):
        try:
            if self.main_screen is None:
                self.disable_timers()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen = MainScreen(self)
                self.main_screen.show()
                self.hide()
        except Exception as e:
            print(e)

    def disable_timers(self):
        try:
            # self.tmr_check_wifi.stop()
            self.timerShowData.stop()
            self.timerReadData.stop()
            self.timerWriteData.stop()
            self.timerdatetime.stop()
            self.tmr_error_msg.stop()
            self.Start = False
            self.flgread = False
            WifiConfiguration.stop_wifi_thread(self)
        except Exception as e:
            print(e)

    def enable_controls(self, isEnabled):
        try:
            self.btn_save.setProperty("enabled", isEnabled)
            self.btn_cancel.setProperty("enabled", isEnabled)
            self.btn_gross_weight.setProperty("enabled", isEnabled)
            self.btn_tare_weight.setProperty("enabled", isEnabled)
            self.btn_gross_weight_delete.setProperty("enabled", isEnabled)
            self.btn_tare_weight_delete.setProperty("enabled", isEnabled)
            for each_txtbox in self.findChildren(QLineEdit):
                each_txtbox.setProperty("enabled", isEnabled)
            for each_cmbbox in self.findChildren(QComboBox):
                each_cmbbox.setProperty("enabled", isEnabled)
            self.txt_amount.setEnabled(False)
        except Exception as e:
            print(e)

    def on_load_event(self):
        try:
            self.pnl_gunny_bag.setVisible(False)
            self.enable_controls(False)
            self.btn_gross_weight.setEnabled(False)
            self.btn_save.setEnabled(False)
            self.btn_preview.setEnabled(False)
            self.btn_tare_weight.setEnabled(False)
            self.btn_tare_weight_delete.setEnabled(False)
            self.btn_gross_weight_delete.setEnabled(False)
            self.pnl_save_confirm.setVisible(False)
            self.txt_tare_weight.setEnabled(False)
            self.txt_gross_weight.setEnabled(False)
            self.btn_print.setEnabled(False)
            self.btn_gunny_bag.setEnabled(False)
            self.set_label_values()
            self.on_click_entry()
            self.fill_code_items()
            Helper.fetch_device_details(self)
            Helper.get_cloud_storage_status(self)
            Helper.get_remote_config_status(self)
            if GlobalEntities.remote_config_status == '1':
                self.open_remote_config_port()
            self.combo_box_styles()
            self.cmb_serial_no.setFocus()
            # self.on_changed_serial_no()
            # self.on_changed_vehicle()
            self.setTabOrder(self.cmb_serial_no, self.cmb_header1)
        except Exception as e:
            print(e)

    def open_remote_config_port(self):
        try:
            self.remote_port_details = SystemConfigBL().get_remote_protocol_port()
            if not len(self.remote_port_details) == 0:
                self.remote_port = self.remote_port_details[0]
                self.remote_baud = self.remote_port_details[1]
            # GlobalVariable.GetCOMPortNo = '\\\\.\\COM3'  # Port HardCoded for checking in Windows
            available_ports = QSerialPortInfo.availablePorts()
            serialports = [serialport.systemLocation() for serialport in available_ports]
            if serialports:
                if serialports.__contains__(GlobalVariable.get_com_port):
                    self.remote_config_port = None
                    self.remote_config_port = serial.Serial(self.remote_port,
                                                            self.remote_baud,
                                                            timeout=0)
                    self.remote_config_port.close()
                    self.remote_config_port.open()
        except Exception as e:
            print(e)

    def combo_box_styles(self):
        try:
            self.cmb_input_names = [self.cmb_header1, self.cmb_serial_no, self.cmb_code1, self.cmb_code2,
                                    self.cmb_code3, self.cmb_code4, self.cmb_code5,
                                    ]
            for i in range(len(self.cmb_input_names)):
                UiComponents.set_bordered_combo_box(self, self.cmb_input_names[i])
        except Exception as e:
            print(e)

    def get_all_vehicle(self):
        try:
            self.cmb_header1.clear()
            vehicleList = VehicleReEntryBL().get_all_vehicles()
            for row_data in vehicleList:
                self.cmb_header1.addItems(row_data)
            self.cmb_header1.setCurrentIndex(-1)
        # self.on_changed_vehicle()
        except OSError as e:
            print(e)

    def set_label_values(self):
        try:
            self.set_header_details()
            self.set_code_details()
            # self.get_type_details("Amount", self.lbl_amount_header, self.txt_amount)
            self.get_type_details("DateTime", self.lbl_current_time, self.lbl_current_time)
            self.get_type_details("GunnyBag", self.btn_gunny_bag, self.btn_gunny_bag)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:
            if 'code' in type or 'header' in type:
                type_row = VehicleReEntryBL().get_code_and_header(type)
            else:
                type_row = VehicleReEntryBL().get_other_settings(type)
            isVisible = True if int(type_row[0][1]) else False
            if type == 'GunnyBag':
                lbldisplay.setEnabled(isVisible)
                if isVisible:
                    self.flg_gunny_bag_enabled = True
                else:
                    self.flg_gunny_bag_enabled = False
            else:
                lbldisplay.setText(type_row[0][0])
                lbldisplay.setVisible(isVisible)
                valdisplay.setVisible(isVisible)
            self.set_unit_display()
        except Exception as e:
            print(e)

    def set_unit_display(self):
        try:
            unit_row = VehicleEntryBL().get_unit()
            self.lbl_unit.setText(unit_row[0][1])
            self.lbl_gross_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
            self.lbl_tare_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
            self.lbl_net_weight_unit.setText("(" + str(unit_row[0][1]) + ")")
        except OSError as e:
            print(e)

    def set_header_details(self):
        try:
            self.list_header_count = []
            self.lst_header_data = []
            self.lst_header_data.clear()
            self.lst_header_data = VehicleEntryBL().Get_header()
            if not len(self.lst_header_data) == 0:
                self.lbl_header1.setText(self.lst_header_data[0])
                self.lbl_header2.setText(self.lst_header_data[1])
                self.lbl_header3.setText(self.lst_header_data[2])
                self.lbl_header4.setText(self.lst_header_data[3])
                self.lbl_header5.setText(self.lst_header_data[4])
                if self.lst_header_data[10] == '1':
                    self.lbl_header1.setVisible(True)
                    self.cmb_header1.setVisible(True)
                    self.flg_header1 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header1.setVisible(False)
                    self.cmb_header1.setVisible(False)
                    self.flg_header1 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[11] == '1':
                    self.lbl_header2.setVisible(True)
                    self.txt_header2.setVisible(True)
                    self.flg_header2 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header2.setVisible(False)
                    self.txt_header2.setVisible(False)
                    self.flg_header2 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[12] == '1':
                    self.lbl_header3.setVisible(True)
                    self.txt_header3.setVisible(True)
                    self.flg_header3 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header3.setVisible(False)
                    self.txt_header3.setVisible(False)
                    self.flg_header3 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[13] == '1':
                    self.lbl_header4.setVisible(True)
                    self.txt_header4.setVisible(True)
                    self.flg_header4 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header4.setVisible(False)
                    self.txt_header4.setVisible(False)
                    self.flg_header4 = False
                    self.list_header_count.append('0')
                if self.lst_header_data[14] == '1':
                    self.lbl_header5.setVisible(True)
                    self.txt_header5.setVisible(True)
                    self.flg_header5 = True
                    self.list_header_count.append('1')
                else:
                    self.lbl_header5.setVisible(False)
                    self.txt_header5.setVisible(False)
                    self.flg_header5 = False
                    self.list_header_count.append('0')
            self.assign_header_control_names()
        except Exception as e:
            print(e)

    def gunny_bag_validation(self):
        try:
            if not self.txt_gross_weight.text():
                self.is_validation_error = True
                self.pnl_gunny_bag.setVisible(False)
                self.setToolTipMessage("enter gross weight !!")
                return self.is_validation_error
            else:
                if self.flg_gunny_bag and len(str(self.txt_bag_count.text()).strip(" ")) == 0:
                    self.is_validation_error = True
                    self.setToolTipMessage("enter bag count !!")
                    return self.is_validation_error
                else:
                    if self.flg_gunny_bag and len(str(self.txt_bag_weight.text()).strip(" ")) == 0:
                        self.is_validation_error = True
                        self.setToolTipMessage("enter bag weight !!")
                        return self.is_validation_error
        except Exception as e:
            print(e)

    def assign_header_control_names(self):
        try:
            self.list_label_header_names = []
            self.list_text_header_names = []
            self.count_of_ones = self.list_header_count.count('1')
            if self.list_header_count[0] == '1':
                self.list_label_header_names.append(self.lbl_header1)
                self.list_text_header_names.append(self.cmb_header1)
            if self.list_header_count[1] == '1':
                self.list_label_header_names.append(self.lbl_header2)
                self.list_text_header_names.append(self.txt_header2)
            if self.list_header_count[2] == '1':
                self.list_label_header_names.append(self.lbl_header3)
                self.list_text_header_names.append(self.txt_header3)
            if self.list_header_count[3] == '1':
                self.list_label_header_names.append(self.lbl_header4)
                self.list_text_header_names.append(self.txt_header4)
            if self.list_header_count[4] == '1':
                self.list_label_header_names.append(self.lbl_header5)
                self.list_text_header_names.append(self.txt_header5)
            self.list_text_header_names[0].setPlaceholderText("Enter Vehicle Number")
            self.list_label_header_names[0].move(4, 10)
            self.list_text_header_names[0].move(197, 4)
            self.list_text_header_names[0].setFocus()
        except Exception as e:
            print(e)

    def assign_code_control_names(self):
        self.list_label_code_names = []
        self.list_label_code_value_names = []
        self.list_cmb_code_names = []
        self.code_count_of_ones = self.list_code_count.count('1')
        if self.list_code_count[0] == '1':
            self.list_label_code_names.append(self.lbl_code1)
            self.list_cmb_code_names.append(self.cmb_code1)
            self.list_label_code_value_names.append(self.lbl_code_value1)
        if self.list_code_count[1] == '1':
            self.list_label_code_names.append(self.lbl_code2)
            self.list_cmb_code_names.append(self.cmb_code2)
            self.list_label_code_value_names.append(self.lbl_code_value2)
        if self.list_code_count[2] == '1':
            self.list_label_code_names.append(self.lbl_code3)
            self.list_cmb_code_names.append(self.cmb_code3)
            self.list_label_code_value_names.append(self.lbl_code_value3)
        if self.list_code_count[3] == '1':
            self.list_label_code_names.append(self.lbl_code4)
            self.list_cmb_code_names.append(self.cmb_code4)
            self.list_label_code_value_names.append(self.lbl_code_value4)
        if self.list_code_count[4] == '1':
            self.list_label_code_names.append(self.lbl_code5)
            self.list_cmb_code_names.append(self.cmb_code5)
            self.list_label_code_value_names.append(self.lbl_code_value5)
        self.list_label_code_names[0].move(5, 67)
        self.list_cmb_code_names[0].move(200, 62)
        self.list_cmb_code_names[0].setFocus()
        self.list_label_code_value_names[0].move(430, 62)

    def on_click_next(self):
        current_index = self.sw_entry_details.currentIndex()
        if current_index == 1:
            self.sw_entry_details.setCurrentIndex(2)
        elif current_index == 0:
            self.sw_entry_details.setCurrentIndex(1)
        elif current_index == 2:
            self.sw_entry_details.setCurrentIndex(0)

    def set_code_details(self):
        try:
            self.list_code_count = []
            self.lst_code_details = []
            self.lst_code_details.clear()
            self.lst_code_details = VehicleReEntryBL().get_code()
            if not len(self.lst_code_details) == 0:
                self.lbl_code1.setText(self.lst_code_details[0])
                self.lbl_code2.setText(self.lst_code_details[1])
                self.lbl_code3.setText(self.lst_code_details[2])
                self.lbl_code4.setText(self.lst_code_details[3])
                self.lbl_code5.setText(self.lst_code_details[4])
                if self.lst_code_details[10] == '1':
                    self.lbl_code1.setVisible(True)
                    self.cmb_code1.setVisible(True)
                    self.flg_code1 = True
                    self.lbl_code_value1.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code1.setVisible(False)
                    self.cmb_code1.setVisible(False)
                    self.flg_code1 = False
                    self.lbl_code_value1.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[11] == '1':
                    self.lbl_code2.setVisible(True)
                    self.cmb_code2.setVisible(True)
                    self.flg_code2 = True
                    self.lbl_code_value2.setVisible(True)
                    self.list_code_count.append('1')

                else:
                    self.lbl_code2.setVisible(False)
                    self.cmb_code2.setVisible(False)
                    self.flg_code2 = False
                    self.lbl_code_value2.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[12] == '1':
                    self.lbl_code3.setVisible(True)
                    self.cmb_code3.setVisible(True)
                    self.flg_code3 = True
                    self.lbl_code_value3.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code3.setVisible(False)
                    self.cmb_code3.setVisible(False)
                    self.flg_code3 = False
                    self.list_code_count.append('0')
                    self.lbl_code_value3.setVisible(False)
                if self.lst_code_details[13] == '1':
                    self.lbl_code4.setVisible(True)
                    self.cmb_code4.setVisible(True)
                    self.flg_code4 = True
                    self.lbl_code_value4.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code4.setVisible(False)
                    self.cmb_code4.setVisible(False)
                    self.flg_code4 = False
                    self.lbl_code_value4.setVisible(False)
                    self.list_code_count.append('0')
                if self.lst_code_details[14] == '1':
                    self.lbl_code5.setVisible(True)
                    self.cmb_code4.setVisible(True)
                    self.flg_code5 = True
                    self.lbl_code_value5.setVisible(True)
                    self.list_code_count.append('1')
                else:
                    self.lbl_code5.setVisible(False)
                    self.cmb_code5.setVisible(False)
                    self.flg_code5 = False
                    self.lbl_code_value5.setVisible(False)
                    self.list_code_count.append('0')

            self.assign_code_control_names()

        except Exception as e:
            print(e)

    def fill_code_items(self):
        try:
            cmb_code_names = [self.cmb_code1, self.cmb_code2, self.cmb_code3, self.cmb_code4, self.cmb_code5]
            for i, cmb in enumerate(cmb_code_names):
                cmb.clear()
            # self.clear_all_fields()
            code_list1 = VehicleEntryBL().get_code1()
            code_list2 = VehicleEntryBL().get_code2()
            code_list3 = VehicleEntryBL().get_code3()
            code_list4 = VehicleEntryBL().get_code4()
            code_list5 = VehicleEntryBL().get_code5()

            code_lists = [code_list1, code_list2, code_list3, code_list4, code_list5]
            for i in range(len(cmb_code_names)):
                self.add_combobox_items(cmb_code_names[i], code_lists[i])
            self.get_all_vehicle()
            self.get_all_serial_no()
        except OSError as e:
            print(e)

    def clear_all_fields(self):
        try:
            for each_txtbox in self.findChildren(QLineEdit):
                each_txtbox.setText("")
            for each_cmbbox in self.findChildren(QComboBox):
                if each_cmbbox.objectName() != "cmb_serialno" and each_cmbbox.objectName() != "cmb_input1":
                    each_cmbbox.clear()
        except OSError as e:
            print(e)

    def add_combobox_items(self, cmb, codes):
        try:
            for row_data in codes:
                cmb.addItems(row_data)
        except OSError as e:
            print(e)

    def input_char_validation(self):
        try:
            reg_ex = QRegExp("[a-zA-Z0-9]+")
            input_validator = QRegExpValidator(reg_ex, self.cmb_header1)
            self.cmb_header1.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header2)
            self.txt_header2.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header3)
            self.txt_header3.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header4)
            self.txt_header4.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_ex, self.txt_header5)
            self.txt_header5.setValidator(input_validator)
            reg_ex = QRegExp("[0-9]{,6}")
            input_validator = QRegExpValidator(reg_ex, self.txt_bag_weight)
            self.txt_bag_weight.setValidator(input_validator)
            reg_ex_bag_count = QRegExp("[0-YyNn]{,6}")
            input_validator = QRegExpValidator(reg_ex_bag_count, self.txt_bag_count)
            self.txt_bag_count.setValidator(input_validator)
            reg_num = QRegExp("^[1-9]\d*(\.\d+)?$")
            input_validator = QRegExpValidator(reg_num, self.txt_gross_weight)
            self.txt_gross_weight.setValidator(input_validator)
            input_validator = QRegExpValidator(reg_num, self.txt_tare_weight)
            self.txt_tare_weight.setValidator(input_validator)
            reg_ex = QRegExp("[0-9]{,7}")
            reg_ex_amount = QRegExp("[0-9DdSs]{,7}")
            input_validator = QRegExpValidator(reg_ex_amount, self.txt_amount)
            self.txt_amount.setValidator(input_validator)
        except Exception as e:
            print(e)

    def on_click_gross(self):
        try:
            if self.btn_gross_weight.isEnabled():
                if self.DisplayData:
                    self.flg_gross_weight = True
                    self.model.GrossWt = str(Decimal(self.DisplayData))
                    self.txt_gross_date_time.setText(str(datetime.now().strftime("%d-%m-%Y %H:%M:%S")))
                    if self.model.GrossWt:
                        self.txt_gross_weight.setText(str(self.model.GrossWt))
                    UiComponents.gross_correct_image(self)
                    self.txt_amount.setEnabled(True)
                    self.netwt_calculation()
                    self.txt_amount.setFocus()
                    UiComponents.set_text_box_active_style(self, self.txt_amount)
        except OSError as e:
            print(e)

    def on_click_tare(self):
        try:
            if self.btn_tare_weight.isEnabled():
                if self.DisplayData:
                    self.flg_gross_weight = False
                    self.model.TareWt = str(Decimal(self.DisplayData))
                    self.txt_tare_date_time.setText(str(datetime.now().strftime("%d-%m-%Y %H:%M:%S")))
                    if self.model.TareWt:
                        self.txt_tare_weight.setText(str(self.model.TareWt))
                    UiComponents.tare_correct_image(self)
                    self.netwt_calculation()
                    self.txt_amount.setEnabled(True)
                    self.txt_amount.setFocus()
                    UiComponents.set_text_box_active_style(self, self.txt_amount)
        except OSError as e:
            print(e)

    def on_click_gross_wt_clr(self):
        try:
            if self.btn_gross_weight_delete.isEnabled():
                self.txt_amount.setEnabled(False)
                self.flg_gross_weight = False
                UiComponents.ok_default(self, self.btn_gross_weight)
                self.txt_gross_date_time.clear()
                self.txt_gross_weight.clear()
                self.txt_amount.clear()
                self.model.GrossWt = self.txt_gross_weight.text()
                self.model.TareWt = self.txt_tare_weight.text()
                self.netwt_calculation()
        except Exception as e:
            print(e)

    def on_click_tare_wt_clr(self):
        try:
            if self.btn_tare_weight_delete.isEnabled():
                self.txt_amount.setEnabled(False)
                UiComponents.ok_default(self, self.btn_tare_weight)
                self.txt_tare_date_time.clear()
                self.txt_tare_weight.clear()
                self.txt_amount.clear()
                self.model.GrossWt = self.txt_gross_weight.text()
                self.model.TareWt = self.txt_tare_weight.text()
                self.netwt_calculation()
        except Exception as e:
            print(e)

    def print_data(self):
        try:
            self.lstValueBillGross = []
            self.lstValue_NetTareWt = []
            self.PdfHeader1 = []
            self.PdfHeader2 = []
            self.PdfInputData1 = []
            self.PdfInputData2 = []
            self.PdfHeader1.append("Bill No")
            self.PdfInputData1.append(self.selected_serial_no)
            self.lst_fetch_Enable_Code = []
            self.print_details = SystemConfigBL().get_printer_configuration()
            self.return_header = GeneralSettingsBL().get_Parameters()
            if not len(self.print_details) == 0:
                if self.print_details[15] == '1':
                    self.PdfHeader2.append(self.print_details[0])
                    self.PdfInputData2.append(self.selected_vehicle)
                else:
                    pass
                if self.print_details[16] == '1':
                    self.PdfHeader2.append(self.print_details[1])
                    self.PdfInputData2.append(self.txt_header2.text())
                else:
                    pass
                if self.print_details[17] == '1':
                    self.PdfHeader2.append(self.print_details[2])
                    self.PdfInputData2.append(self.txt_header3.text())
                else:
                    pass
                if self.print_details[18] == '1':
                    self.PdfHeader2.append(self.print_details[3])
                    self.PdfInputData2.append(self.txt_header4.text())
                else:
                    pass
                if self.print_details[19] == '1':
                    self.PdfHeader2.append(self.print_details[4])
                    self.PdfInputData2.append(self.txt_header5.text())
                else:
                    pass
            self.PdfHeader2.append(self.previous_entry)
            self.PdfInputData2.append(self.model.entry_amount)
            self.PdfHeader2.append(self.current_entry)
            self.PdfInputData2.append(self.txt_amount.text())
            self.PdfHeader2.append("Net Amount")
            self.PdfInputData2.append(str(int(self.model.entry_amount) + int(self.txt_amount.text())))
            self.PdfHeader2.append("Tare Date/Time")
            self.PdfInputData2.append(self.txt_tare_date_time.text())
            self.PdfHeader2.append("Gross Date/Time")
            self.PdfInputData2.append(self.txt_gross_date_time.text())
            self.lst_fetch_Enable_Code = VehicleReEntryBL().get_code()
            if not len(self.print_details) == 0:
                if self.print_details[25] == '1':
                    self.PdfHeader1.append(self.print_details[5])
                    self.PdfInputData1.append(self.selected_code_1)
                else:
                    pass
                if self.print_details[26] == '1':
                    self.PdfHeader1.append(self.print_details[6])
                    self.PdfInputData1.append(self.selected_code_2)
                else:
                    pass
                if self.print_details[27] == '1':
                    self.PdfHeader1.append(self.print_details[7])
                    self.PdfInputData1.append(self.selected_code_3)
                else:
                    pass
                if self.print_details[28] == '1':
                    self.PdfHeader1.append(self.print_details[8])
                    self.PdfInputData1.append(self.selected_code_4)
                else:
                    pass
                if self.print_details[29] == '1':
                    self.PdfHeader1.append(self.print_details[9])
                    self.PdfInputData1.append(self.selected_code_5)
                else:
                    pass
            self.PdfHeader1.append("Net Wt  (" + self.lbl_unit.text() + ")")
            self.PdfHeader1.append("Tare Wt (" + self.lbl_unit.text() + ")" + self.manual_entry_status)
            if self.flg_gunny_bag:
                self.PdfHeader1.append("Gross Wt(" + self.lbl_unit.text() + ") #")
            else:
                self.PdfHeader1.append("Gross Wt(" + self.lbl_unit.text() + ")" + self.gunny_status)
            self.PdfInputData1.append(self.txt_net_weight.text())
            self.PdfInputData1.append(self.txt_tare_weight.text())
            self.PdfInputData1.append(self.txt_gross_weight.text())
            self.tableWidget.clear()
            self.tableWidget.horizontalHeader().setVisible(False)
            self.tableWidget.verticalHeader().setVisible(False)
            self.tableWidget.setColumnCount(8)
            count = 0
            max_length = max(len(self.PdfHeader1), len(self.PdfHeader2))

            for idx in range(max_length):
                self.tableWidget.setColumnWidth(0, 10)
                self.tableWidget.setColumnWidth(1, 10)
                self.tableWidget.setColumnWidth(2, 10)
                self.tableWidget.setColumnWidth(3, 10)
                self.tableWidget.setColumnWidth(4, 10)
                self.tableWidget.setColumnWidth(5, 10)
                self.tableWidget.insertRow(idx)
                self.tableWidget.setRowHeight(idx, 65)
                # Check if index exists in the first list
                if idx < len(self.PdfHeader1):
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem(self.PdfHeader1[idx].rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem(self.PdfInputData1[idx].ljust(16)))
                else:
                    self.tableWidget.setItem(idx, 0, QtWidgets.QTableWidgetItem("".rjust(16)))
                    self.tableWidget.setItem(idx, 1, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 2, QtWidgets.QTableWidgetItem("".ljust(19)))
                # Check if index exists in the second list
                if idx < len(self.PdfHeader2) and count < len(self.PdfInputData2):
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem(self.PdfHeader2[count].rjust(18)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(" : "))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem(self.PdfInputData2[count].ljust(18)))
                    count += 1
                else:
                    self.tableWidget.setItem(idx, 3, QtWidgets.QTableWidgetItem("".rjust(18)))
                    self.tableWidget.setItem(idx, 4, QtWidgets.QTableWidgetItem(""))
                    self.tableWidget.setItem(idx, 5, QtWidgets.QTableWidgetItem("".ljust(18)))

            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.header1 = self.return_header[0]
            self.header2 = self.return_header[1]
            self.header3 = self.return_header[2]
            width = 80
            self.serial_print_data = ""
            self.serial_print_data += f"{self.header1.center(width)}\n"
            self.serial_print_data += f"{self.header2.center(width)}\n"
            self.serial_print_data += f"{self.header3.center(width)}\n"
            self.serial_print_data += f"Vehicle ReEntry Bill                             DateTime:{date_string}" + "\n"
            self.serial_print_data += "==============================================================================" + "\n"
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += self.get_table_data_as_string(self.tableWidget)
            self.serial_print_data += "                                                                              " + "\n"
            self.serial_print_data += "signature of the operator                               signature of the party" + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "                                                                               " + "\n"
            self.serial_print_data += "===============================================================================" + "\n"
            self.serial_print_data += "                         LCS-for all your weighing needs                       " + "\n"
            print(self.serial_print_data)
            self.create_print_format()
        except Exception as e:
            print(e)

    def create_print_format(self):
        try:
            self.dashed_line = ""
            self.empty_space = " "
            self.span_space = "&nbsp;" * 80  # Create 20 non-breaking spaces
            self.dashed_line = self.dashed_line.ljust(80, "=")
            self.empty_space = self.empty_space.ljust(80, " ")
            current_datetime = QDateTime.currentDateTime()
            date_string = current_datetime.toString('dd/MM/yy hh:mm:ss')
            self.table_data = "<p>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[0] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[1] + "</h6>"
            self.table_data += "<h6 style='text-align: center;'>" + self.return_header[2] + "</h6>"
            self.table_data += "<div>"
            self.table_data += "<span>Vehicle ReEntry Bill</span>"
            self.table_data += " <span>{}</span>".format("&nbsp;" * 40)
            self.table_data += "<span>DateTime: {}</span>".format(date_string)
            self.table_data += "</div>"
            self.table_data += self.dashed_line + "\n"
            # self.table_data += "<br>"
            self.table_data += Helper.get_table_data_as_string(self, self.tableWidget)
            self.table_data += "<br>"
            self.table_data += "<div>"
            self.table_data += "<span>signature of the operator</span>"
            self.table_data += " <span>{}</span>".format(self.span_space)
            self.table_data += "<span>signature of the party</span>"
            self.table_data += "</div>"
            self.table_data += "<br>"
            self.table_data += self.dashed_line + "\n"
            self.table_data += "<div style='text-align: center;'>LCS-for all your weighing needs</div>"
            self.table_data += "</p>"
            return self.table_data
        except Exception as e:
            print(e)

    def on_click_print(self):
        try:
            self.print_pdf(GlobalVariable.Bill_index)
            self.print_details = SystemConfigBL().get_printer_port()
            import cups
            import serial
            # Recall
            # Open a connection to the printer on the specified serial port
            ser = serial.Serial(self.print_details[0], self.print_details[1], timeout=1)
            self.bytes_to_send = bytes(self.serial_print_data, "utf-8")
            ser.write(self.bytes_to_send)
            ser.close()
            self.setToolTipCorrectMessage("printed successfully !!")
            self.bytes_to_send = ""
            self.serial_print_data = ""
            if self.bytes_to_send == "":
                self.disable_timers()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen = MainScreen(self)
                self.main_screen.show()
                self.hide()
        except OSError as e:
            print(e)

    def get_table_data_as_string(self, table_widget):
        data = ""
        # Iterate over rows
        for i in range(table_widget.rowCount()):
            # Iterate over columns
            for j in range(table_widget.columnCount()):
                item = table_widget.item(i, j)
                if item is not None:
                    data += item.text() + ""
                else:
                    data += ""
            data += "\n"
        return data

    def update_transaction_details(self):
        try:
            self.return_transaction_details = VehicleEntryBL().get_transaction_details(self.model.report_date)
            if len(self.return_transaction_details) > 0:
                VehicleEntryBL().update_transaction_details(self.return_transaction_details)
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_app_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lblLogo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            pass

    def on_click_back(self):
        try:
            if not self.code_enable:
                self.display_back_header()
            else:
                self.display_back_code()
        except Exception as e:
            print(e)

    def on_click_enter(self):
        try:
            self.cmb_serial_no.clearFocus()
            self.cmb_header1.clearFocus()
            self.btn_gross_weight.setFocus()
            self.btn_tare_weight.setFocus()
            if self.txt_amount.text() and not self.flg_save and not self.flg_save_enabled:
                self.on_click_save()
            elif self.flg_save and not self.flg_save_enabled:
                self.on_click_save_confirm_ok()
                self.flg_save = False
            elif not self.header_enable:
                if self.count_of_ones == 5 and not self.code_enable:
                    self.display_header_count5()
                elif self.count_of_ones == 4 and not self.code_enable:
                    self.display_header_count4()
                elif self.count_of_ones == 3 and not self.code_enable:
                    self.display_header_count3()
                elif self.count_of_ones == 2 and not self.code_enable:
                    self.display_header_count2()
                self.code_enable = False
            else:
                self.code_enable = False
                if self.code_count_of_ones == 5 and self.header_enable:
                    self.display_code_count5()
                elif self.code_count_of_ones == 4 and self.header_enable:
                    self.display_code_count4()
                elif self.code_count_of_ones == 3 and self.header_enable:
                    self.display_code_count3()
                elif self.code_count_of_ones == 2 and self.header_enable:
                    self.display_code_count2()
        except Exception as e:
            print(e)

    '''if 5 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count5(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].currentText():
                    self.move_header_locations()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(4, 10)
                    self.list_text_header_names[1].move(197, 4)
                    self.list_text_header_names[1].setFocus()
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[2].text()))
                    self.list_label_header_names[2].move(4, 10)
                    self.list_text_header_names[2].move(197, 4)
                    self.list_text_header_names[2].setFocus()
                    self.count += 1
            elif self.count == 2:
                if self.list_text_header_names[2].text():
                    self.move_header_locations()
                    self.list_text_header_names[3].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[3].text()))
                    self.list_label_header_names[3].move(4, 10)
                    self.list_text_header_names[3].move(197, 4)
                    self.list_text_header_names[3].setFocus()
                    self.count += 1
            elif self.count == 3:
                if self.list_text_header_names[3].text():
                    self.move_header_locations()
                    self.list_text_header_names[4].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[4].text()))
                    self.list_label_header_names[4].move(4, 10)
                    self.list_text_header_names[4].move(197, 4)
                    self.list_text_header_names[4].setFocus()
                    self.count += 1
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    def move_header_locations(self):
        try:
            for i in range(len(self.list_text_header_names)):
                self.list_text_header_names[i].move(3535, 454)
                self.list_label_header_names[i].move(3535, 454)
        except Exception as e:
            print(e)

    def move_code_locations(self):
        try:
            for i in range(len(self.list_label_code_names)):
                self.list_label_code_names[i].move(35635, 454)
                self.list_cmb_code_names[i].move(35356, 454)
                self.list_label_code_value_names[i].move(36535, 454)
        except Exception as e:
            print(e)

    def display_back_header(self):
        try:
            self.count = 0
            if self.header_count == 0:
                self.move_header_locations()
                self.list_label_header_names[0].move(4, 10)
                self.list_text_header_names[0].move(197, 4)
                self.list_text_header_names[0].setFocus()
            elif self.header_count == 1:
                self.move_header_locations()
                self.list_label_header_names[0].move(4, 10)
                self.list_text_header_names[0].move(197, 4)
                self.list_text_header_names[0].setFocus()
            elif self.header_count == 2:
                self.move_header_locations()
                self.list_label_header_names[1].move(4, 10)
                self.list_text_header_names[1].move(197, 4)
                self.list_text_header_names[1].setFocus()
            elif self.header_count == 3:
                self.move_header_locations()
                self.list_label_header_names[2].move(4, 10)
                self.list_text_header_names[2].move(197, 4)
                self.list_text_header_names[2].setFocus()
            elif self.header_count == 4:
                self.move_header_locations()
                self.list_label_header_names[3].move(4, 10)
                self.list_text_header_names[3].move(197, 4)
                self.list_text_header_names[3].setFocus()
            self.header_count = self.header_count - 1
            self.header_enable = False
            self.code_enable = False
        except Exception as e:
            print(e)

    '''if 4 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count4(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].currentText():
                    self.move_header_locations()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(4, 10)
                    self.list_text_header_names[1].move(197, 4)
                    self.list_text_header_names[1].setFocus()
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[2].text()))
                    self.list_label_header_names[2].move(4, 10)
                    self.list_text_header_names[2].move(197, 4)
                    self.list_text_header_names[2].setFocus()
                    self.count += 1
            elif self.count == 2:
                if self.list_text_header_names[2].text():
                    self.move_header_locations()
                    self.list_text_header_names[3].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[3].text()))
                    self.list_label_header_names[3].move(4, 10)
                    self.list_text_header_names[3].move(197, 4)
                    self.list_text_header_names[3].setFocus()
                    self.count += 1
                    self.header_enable = True
            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 3 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count3(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].currentText():
                    self.move_header_locations()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(4, 10)
                    self.list_text_header_names[1].move(197, 4)
                    self.list_text_header_names[1].setFocus()
                    self.count += 1
            elif self.count == 1:
                if self.list_text_header_names[1].text():
                    self.move_header_locations()
                    self.list_text_header_names[2].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[2].text()))
                    self.list_label_header_names[2].move(4, 10)
                    self.list_text_header_names[2].move(197, 4)
                    self.list_text_header_names[2].setFocus()
                    self.header_enable = True
                    self.count += 1

            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 2 headers is selected in parameters settings headers will be displayed accordingly'''

    def display_header_count2(self):
        try:
            if self.count == 0:
                if self.list_text_header_names[0].currentText():
                    self.move_header_locations()
                    self.list_text_header_names[1].setPlaceholderText(
                        "Enter " + str(self.list_label_header_names[1].text()))
                    self.list_label_header_names[1].move(4, 10)
                    self.list_text_header_names[1].move(197, 4)
                    self.list_text_header_names[1].setFocus()
                    self.header_enable = True
                    self.count += 1

            self.header_count = self.count
        except Exception as e:
            print(e)

    '''if 5 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count5(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_label_code_names[1].move(5, 67)
                    self.list_cmb_code_names[1].move(200, 62)
                    self.list_cmb_code_names[1].setFocus()
                    self.list_label_code_value_names[1].move(430, 62)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[0].text():
                    if self.list_label_code_value_names[1].text():
                        self.move_code_locations()
                        self.list_label_code_names[2].move(5, 67)
                        self.list_cmb_code_names[2].move(200, 62)
                        self.list_cmb_code_names[2].setFocus()
                        self.list_label_code_value_names[2].move(430, 62)
                        self.code_count += 1
            elif self.code_count == 2:
                if self.list_label_code_value_names[2].text():
                    self.move_code_locations()
                    self.list_label_code_names[3].move(5, 67)
                    self.list_cmb_code_names[3].move(200, 62)
                    self.list_cmb_code_names[3].setFocus()
                    self.list_label_code_value_names[3].move(430, 62)
                    self.code_count += 1
            elif self.code_count == 3:
                if self.list_label_code_value_names[3].text():
                    self.move_code_locations()
                    self.list_label_code_names[4].move(5, 67)
                    self.list_cmb_code_names[4].move(200, 62)
                    self.list_cmb_code_names[4].setFocus()
                    self.list_label_code_value_names[4].move(430, 62)
                    self.code_count += 1
                    self.code_enable = True
            self.code_display_count = self.code_count

        except Exception as e:
            print(e)

    def display_back_code(self):
        try:
            self.code_count = 0
            if self.code_display_count == 0:
                self.move_code_locations()
                self.list_label_code_names[0].move(5, 67)
                self.list_cmb_code_names[0].move(200, 62)
                self.list_cmb_code_names[0].setFocus()
                self.list_label_code_value_names[0].move(430, 62)
            elif self.code_display_count == 1:
                self.move_code_locations()
                self.list_label_code_names[0].move(5, 67)
                self.list_cmb_code_names[0].move(200, 62)
                self.list_cmb_code_names[0].setFocus()
                self.list_label_code_value_names[0].move(430, 62)
            elif self.code_display_count == 2:
                self.move_code_locations()
                self.list_label_code_names[1].move(5, 67)
                self.list_cmb_code_names[1].move(200, 62)
                self.list_cmb_code_names[1].setFocus()
                self.list_label_code_value_names[1].move(430, 62)
            elif self.code_display_count == 3:
                self.move_code_locations()
                self.list_label_code_names[2].move(5, 67)
                self.list_cmb_code_names[2].move(200, 62)
                self.list_cmb_code_names[2].setFocus()
                self.list_label_code_value_names[2].move(430, 62)
            elif self.code_display_count == 4:
                self.move_code_locations()
                self.list_label_code_names[3].move(5, 67)
                self.list_cmb_code_names[3].move(200, 62)
                self.list_cmb_code_names[3].setFocus()
                self.list_label_code_value_names[3].move(430, 62)
            self.code_display_count = self.code_display_count - 1
            self.header_enable = False

        except Exception as e:
            print(e)

    '''if 4 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count4(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_label_code_names[1].move(5, 67)
                    self.list_cmb_code_names[1].move(200, 62)
                    self.list_cmb_code_names[1].setFocus()
                    self.list_label_code_value_names[1].move(430, 62)
                    self.code_count += 1
            elif self.code_count == 1:
                if self.list_label_code_value_names[1].text():
                    self.move_code_locations()
                    self.list_label_code_names[2].move(5, 67)
                    self.list_cmb_code_names[2].move(200, 62)
                    self.list_cmb_code_names[2].setFocus()
                    self.list_label_code_value_names[2].move(430, 62)
                    self.code_count += 1
            elif self.code_count == 2:
                if self.list_label_code_value_names[2].text():
                    self.move_code_locations()
                    self.list_label_code_names[3].move(5, 67)
                    self.list_cmb_code_names[3].move(200, 62)
                    self.list_cmb_code_names[3].setFocus()
                    self.list_label_code_value_names[3].move(430, 62)
                    self.code_enable = True
                    self.code_count += 1
            self.code_display_count = self.code_count

        except Exception as e:
            print(e)

    '''if 3 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count3(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_label_code_names[1].move(5, 67)
                    self.list_cmb_code_names[1].move(200, 62)
                    self.list_cmb_code_names[1].setFocus()
                    self.list_label_code_value_names[1].move(430, 62)
                    self.code_count += 1
            elif self.code_count == 0:
                if self.list_label_code_value_names[1].text():
                    self.move_code_locations()
                    self.list_label_code_names[2].move(5, 67)
                    self.list_cmb_code_names[2].move(200, 62)
                    self.list_cmb_code_names[2].setFocus()
                    self.list_label_code_value_names[2].move(430, 62)
                    self.code_enable = True
                    self.code_count += 1
            self.code_display_count = self.code_count
        except Exception as e:
            print(e)

    '''if 2 code is selected in parameters settings codes will be displayed accordingly'''

    def display_code_count2(self):
        try:
            if self.code_count == 0:
                if self.list_label_code_value_names[0].text():
                    self.move_code_locations()
                    self.list_label_code_names[1].move(5, 67)
                    self.list_cmb_code_names[1].move(200, 62)
                    self.list_cmb_code_names[1].setFocus()
                    self.list_label_code_value_names[1].move(430, 62)
                    self.code_enable = True
                    self.code_count += 1
                self.code_display_count = self.code_count
        except Exception as e:
            print(e)

    def setToolTipCorrectMessage(self, msg):
        try:
            self.lbl_tool_tip_bg.setStyleSheet("QLabel"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Message.png); "
                                                                                      "border : none "
                                                                                      "}")
            self.lblToolTipMsg.setText("")
            self.tool_tip.setVisible(True)
            self.lblToolTipMsg.setText(str(msg))
            self.tool_tip.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def setToolTipMessage(self, msg):
        try:
            self.lbl_tool_tip_bg.setStyleSheet("QLabel"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/LeftRedMessage.png); "
                                                                                      "border : none "
                                                                                      "}")
            self.lblToolTipMsg.setText("")
            self.tool_tip.setVisible(True)
            self.lblToolTipMsg.setText(str(msg))
            self.tool_tip.raise_()
            self.tmr_msg.start()
            self.tmr_msg.timeout.connect(self.tool_tip.hide)
        except Exception as e:
            print(e)

    def write_data_to_remote_config_port(self, read_data):  # %01[1 34567]&
        try:
            self.assign_protocol_format = GlobalVariable.start_char + GlobalVariable.device_id + GlobalVariable.open_brace + str(
                GlobalVariable.DecimalPoint) + " " + str(
                read_data) + GlobalVariable.close_brace + GlobalVariable.end_char
            if self.assign_protocol_format:
                self.bytes_to_send = bytes(self.assign_protocol_format, "utf-8")
                self.remote_config_port.write(self.bytes_to_send)
        except Exception as e:
            print(e)

    def create_custom_combobox(self):
        try:
            self.cmb_header1 = ExtendedComboBox(self.widget)
            self.cmb_header1.setParent(self.widget)
            self.cmb_header1.setGeometry(197, 4, 451, 41)
            self.cmb_header1.setMaxVisibleItems(5)
            self.cmb_serial_no = ExtendedComboBox(self.base_serial_no)
            self.cmb_serial_no.setParent(self.base_serial_no)
            self.cmb_serial_no.setGeometry(6, 8, 211, 41)
            self.cmb_serial_no.setMaxVisibleItems(5)
            self.cmb_code1 = ExtendedComboBox(self.widget)
            self.cmb_code1.setParent(self.widget)
            self.cmb_code1.setGeometry(2060, 200, 221, 41)
            self.cmb_code1.setMaxVisibleItems(5)
            self.cmb_code2 = ExtendedComboBox(self.widget)
            self.cmb_code2.setParent(self.widget)
            self.cmb_code2.setGeometry(20650, 26300, 221, 41)
            self.cmb_code2.setMaxVisibleItems(5)
            self.cmb_code3 = ExtendedComboBox(self.widget)
            self.cmb_code3.setParent(self.widget)
            self.cmb_code3.setGeometry(29800, 20560, 221, 41)
            self.cmb_code3.setMaxVisibleItems(5)
            self.cmb_code4 = ExtendedComboBox(self.widget)
            self.cmb_code4.setParent(self.widget)
            self.cmb_code4.setGeometry(27600, 26070, 221, 41)
            self.cmb_code4.setMaxVisibleItems(5)
            self.cmb_code5 = ExtendedComboBox(self.widget)
            self.cmb_code5.setParent(self.widget)
            self.cmb_code5.setGeometry(25600, 20360, 221, 41)
            self.cmb_code5.setMaxVisibleItems(5)
            self.cmb_serial_no.activated[str].connect(self.on_changed_serial_no)
            self.cmb_header1.activated[str].connect(self.on_changed_vehicle)
            self.cmb_code1.activated[str].connect(self.on_changed_code1)
            self.cmb_code2.activated[str].connect(self.on_changed_code2)
            self.cmb_code3.activated[str].connect(self.on_changed_code3)
            self.cmb_code4.activated[str].connect(self.on_changed_code4)
            self.cmb_code5.activated[str].connect(self.on_changed_code5)

        except Exception as e:
            print(e)

    @pyqtSlot(int)
    def update_wifi_status(self, status_code):
        try:
            self.wifi_status_code = status_code
            if self.wifi_status_code == 1:
                # self.lblWifiStatus.setStyleSheet("background-color:green;")
                UiComponents.wifi_status_on(self)
            elif self.wifi_status_code == 0:
                # self.lblWifiStatus.setStyleSheet("background-color:red;")
                UiComponents.wifi_status_off(self)
        except Exception as e:
            print(e)

    def on_click_preview(self):
        try:
            self.pnl_max_preview.move(0, 36)
            self.display_preview()
            pass
        except Exception as e:
            print(e)

    def on_click_close_preview(self):
        try:
            self.pnl_max_preview.move(50000000, 36)
            pass
        except Exception as e:
            print(e)

    def display_preview(self):
        try:
            self.print_result = ""
            if self.table_data:
                self.lbl_max_preview.clear()
                self.lbl_max_preview.setText(str(self.table_data))
                font = self.lbl_max_preview.font()
                font.setPointSize(10)
                self.lbl_max_preview.setFont(font)
                self.lbl_max_preview.setWordWrap(True)
                self.lbl_max_preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                self.lbl_max_preview.adjustSize()
            pass
        except Exception as e:
            print(e)

    def print_pdf(self, index):
        conn = cups.Connection()

        # Get a list of available printers
        printers = conn.getPrinters()
        print(printers)
        printer_name = 'HP_LaserJet_Pro_M202dw_08F066_'
        from BusinessLogic.MainScreenBL import MainScreenBL
        self.bill_data = MainScreenBL().get_bill_data(index)
        pdf_path = os.path.join(r'pdf_reports\2024\July\11-07-2024',  f"BILL No_{self.bill_data[0]}_Time_{time}.pdf")
        if not os.path.exists(pdf_path):
            print(f"Error: The file {pdf_path} does not exist.")
            return

        if not printers:
            print("Error: No printers found.")
            return

        # If no printer name is provided, use the default printer
        if printer_name is None:
            printer_name = conn.getDefault()

        if printer_name not in printers:
            print(f"Error: The printer {printer_name} is not available.")
            return

        # Print the PDF file
        try:
            print(f"Printing {pdf_path} on printer {printer_name}...")
            conn.printFile(printer_name, pdf_path, "PDF Print Job", {})
            print("Print job submitted successfully.")
        except Exception as e:
            print(f"Error: Failed to print the file. {str(e)}")


