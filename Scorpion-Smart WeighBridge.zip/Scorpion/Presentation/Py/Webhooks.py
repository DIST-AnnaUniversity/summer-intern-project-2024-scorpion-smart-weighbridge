import glob
import os
import shutil

from PyQt5.QtCore import QDateTime
from PyQt5.QtWidgets import QLineEdit

from BusinessLogic.WebhooksBL import WebhooksBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig
from Presentation.Py.MessagePopup import MessagePopup


class Webhooks:
    def __init__(self):
        super().__init__()

    def disable_verified_status(self):
        try:
            for index in range(len(self.label_status)):
               self.label_status[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def init_cloud_settings(self):
        try:
            Webhooks.display_cloud_configuration(self)
            Webhooks.update_cloud_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def update_cloud_controls_state(self, state):
        try:
            for text_box in self.frm_cloud_settings.findChildren(QLineEdit):
                text_box.setEnabled(state)

            self.btn_cloud_edit.setEnabled(not state)
            self.btn_cloud_save.setEnabled(state)
            pass
        except Exception as e:
            print(e)

    def validate_cloud_setings(self):
        try:
            self.text_box_count = 0
            for text_box in self.frm_cloud_settings.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True

            pass
        except Exception as e:
            print(e)

    def save_cloud_storage_to_db(self):
        try:
            if Webhooks.validate_cloud_setings(self):
                self.cloud_config = [self.txt_customer_name.text(), self.txt_domain_name.text(),
                                     self.txt_customer_code.text(), self.txt_device_id.text(),
                                     self.txt_server_hostname.text(), self.txt_server_db_name.text(),
                                     self.txt_server_password.text(), self.txt_server_port.text()]
                self.result_count = WebhooksBL().get_cloud_storage_count()
                if self.result_count == "0":
                    self.result = WebhooksBL().insert_cloud_storage_data(self.cloud_config)
                else:
                    self.result = WebhooksBL().update_cloud_storage_data(self.cloud_config)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                Webhooks.init_cloud_settings(self)
            pass
        except Exception as e:
            print(e)

    def display_cloud_configuration(self):
        try:
            self.cloud_config = WebhooksBL().get_cloud_storage_data()
            if len(self.cloud_config) > 0:
                self.txt_customer_name.setText(self.cloud_config[1])
                self.txt_domain_name.setText(self.cloud_config[2])
                self.txt_customer_code.setText(self.cloud_config[3])
                self.txt_device_id.setText(self.cloud_config[4])
                self.txt_server_hostname.setText(self.cloud_config[5])
                self.txt_server_db_name.setText(self.cloud_config[6])
                self.txt_server_password.setText(self.cloud_config[7])
                self.txt_server_port.setText(self.cloud_config[8])
            pass
        except Exception as e:
            print(e)

    ''''Db Backup'''
    def export_db_backup_usb(self):
        try:
            from Presentation.Bundles.UiConfiguration import USB_PATH
            self.get_device_list = os.listdir(USB_PATH)
            if self.get_device_list:
                print(self.get_device_list)
                for i, drive_name in enumerate(self.get_device_list):
                    if drive_name:
                        GetDevice_name = drive_name
                        for j, path_name in enumerate(glob.glob(USB_PATH + GetDevice_name)):
                            time = QDateTime.currentDateTime()
                            Date = time.toString("dd-MM-yyyy")
                            DesPath = path_name + PathConfig.Logo.DES_PATH + '/' + Date + '/'
                            if os.path.isdir(DesPath):
                                shutil.copy2(PathConfig.Logo.SRC_PATH, DesPath)
                            else:
                                os.makedirs(DesPath)
                                shutil.copy2(PathConfig.Logo.SRC_PATH, DesPath)
                            WebhooksBL().delete_db_backup()
                            MessagePopup.setting_msg_popup(self, "correct", "Data Saved Successfully !! ")
                            self.pnl_db_alert.move(50000, 800000)
                            pass
            else:
                self.pnl_db_msg.move(50, 80)
                self.pnl_db_alert.move(50000, 800000)
            pass
        except Exception as e:
            print(e)
            self.pnl_db_msg.move(50, 80)
            self.pnl_db_alert.move(50000, 800000)
