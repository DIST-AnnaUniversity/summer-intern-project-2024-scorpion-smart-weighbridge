from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QComboBox, QCheckBox, QLineEdit, QPushButton, QLabel

from BusinessLogic.SystemConfigBL import SystemConfigBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities


class SystemConfig:
    def __init__(self):
        self.disable_ethernet()
        super().__init__()
        self.index = 1

    def init_rs_232_settings(self):
        try:
            SystemConfig.update_rs_232_controls_state(self, False)
            SystemConfig.load_baud_rate(self)
            SystemConfig.display_configured_baud_rates(self)
            pass
        except Exception as e:
            print(e)

    def disable_verified_status(self):
        try:
            for index in range(len(self.label_status)):
                self.label_status[index].setVisible(False)
            pass
        except Exception as e:
            print(e)

    def update_rs_232_controls_state(self, state):
        try:
            for combo_box in self.frmRS232Comm.findChildren(QComboBox):
                combo_box.setEnabled(state)
            self.btnComEdit.setEnabled(not state)
            self.btnComSave.setEnabled(state)
            pass
        except Exception as e:
            print(e)

    def load_baud_rate(self):
        try:
            self.baud_rates = [
                "4800",
                "9600",
                "14400",
                "19200",
                "38400",
                "56000",
                "57600",
                "115200"]
            self.cmbCom1Baudrate.addItems(self.baud_rates)
            self.cmbCom2Baudrate.addItems(self.baud_rates)
            self.cmbCom3Baudrate.addItems(self.baud_rates)
            pass
        except Exception as e:
            print(e)

    def update_com_port_to_db(self):
        try:
            self.selected_baud_rates = [self.cmbCom1Baudrate.currentText(), self.cmbCom2Baudrate.currentText(),
                                        self.cmbCom3Baudrate.currentText()]
            SystemConfigBL().update_com_baudrates(baud_rates=self.selected_baud_rates)
            for index in range(len(self.label_status)):
                UiComponents.update_verified_status(self, self.label_status[index], True)
            self.cmb_input_names = [self.cmbCom1Baudrate, self.cmbCom2Baudrate, self.cmbCom3Baudrate]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])
            SystemConfig.init_rs_232_settings(self)
            pass
        except Exception as e:
            print(e)

    def display_configured_baud_rates(self):
        try:
            self.baud_rates = []
            self.baud_rates = SystemConfigBL().get_configured_baud_rates()
            if len(self.baud_rates) > 0:
                self.cmbCom1Baudrate.setCurrentText(self.baud_rates[0])
                self.cmbCom2Baudrate.setCurrentText(self.baud_rates[1])
                self.cmbCom3Baudrate.setCurrentText(self.baud_rates[2])
            pass
        except Exception as e:
            print(e)

    '''Peripherals business logic'''

    def init_peripherals_settings(self):
        try:
            SystemConfig.update_peripherals_controls_state(self, False)
            SystemConfig.load_port_no(self)
            SystemConfig.get_printer_port(self)
            SystemConfig.get_remote_protocol_port(self)
            pass
        except Exception as e:
            print(e)

    def load_port_no(self):
        try:
            self.cmbPeripherals1.clear()
            self.cmbPeripherals2.clear()
            self.port_no = ["COM1", "COM2", "COM3"]
            self.cmbPeripherals1.addItems(self.port_no)
            self.cmbPeripherals2.addItems(self.port_no)
            pass
        except Exception as e:
            print(e)

    def update_peripherals_controls_state(self, state):
        try:
            for combo_box in self.frmPeripherals.findChildren(QComboBox):
                combo_box.setEnabled(state)
            self.btnPeripheralsEdit.setEnabled(not state)
            self.btnPeripheralsSave.setEnabled(state)
            pass
        except Exception as e:
            print(e)

    def update_peripherals_comport_db(self):
        try:
            self.printer_port = SystemConfig.get_selected_com_ports(self, self.cmbPeripherals1.currentText())
            self.remote_protocol_port = SystemConfig.get_selected_com_ports(self, self.cmbPeripherals2.currentText())
            if not self.printer_port == self.remote_protocol_port:
                self.result = SystemConfigBL().update_printer_port("Printer", self.printer_port)
                self.result = SystemConfigBL().update_printer_port("RemoteProtocol", self.remote_protocol_port)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                self.cmb_input_names = [self.cmbPeripherals1, self.cmbPeripherals2]
                for i in range(len(self.cmb_input_names)):
                    UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])

                self.HorizontalLyt.addWidget(self.frmPeripherals)
                SystemConfig.init_peripherals_settings(self)
            else:
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], False)
            pass
        except Exception as e:
            print(e)

    def get_selected_com_ports(self, selected_port):
        try:
            self.CheckPortNo = " "
            if selected_port == 'COM1':
                self.CheckPortNo = '/dev/ttyAMA0'
            elif selected_port == 'COM2':
                self.CheckPortNo = '/dev/ttyAMA1'
            elif selected_port == 'COM3':
                self.CheckPortNo = '/dev/ttyAMA3'
            else:
                self.CheckPortNo = selected_port
            self.getcmbPortNo = str(self.CheckPortNo)
            return self.getcmbPortNo
            pass
        except Exception as e:
            print(e)

    def assign_port_name(self, port_no):
        try:
            self.AssignPortNo = ""
            if port_no == '/dev/ttyAMA0':
                self.AssignPortNo = 'COM1'
            elif port_no == '/dev/ttyAMA1':
                self.AssignPortNo = 'COM2'
            elif port_no == '/dev/ttyAMA3':
                self.AssignPortNo = 'COM3'
            return self.AssignPortNo
            pass
        except Exception as e:
            print(e)

    def get_printer_port(self):
        try:
            self.port_no = SystemConfigBL().get_printer_port()
            if len(self.port_no) > 0:
                self.printer_port_no = SystemConfig.assign_port_name(self, self.port_no[0])
                self.cmbPeripherals1.setCurrentText(str(self.printer_port_no))
                pass
        except Exception as e:
            print(e)

    def get_remote_protocol_port(self):
        try:
            self.port_no = SystemConfigBL().get_remote_protocol_port()
            if len(self.port_no) > 0:
                self.remote_protocol_port_no = SystemConfig.assign_port_name(self, self.port_no[0])
                self.cmbPeripherals2.setCurrentText(str(self.remote_protocol_port_no))
            pass
        except Exception as e:
            print(e)

    '''Printer Configuration logic'''

    def init_print_config(self):
        try:
            SystemConfig.update_print_controls_state(self, False)
            SystemConfig.fetch_display_print_configurations(self)
            pass
        except Exception as e:
            print(e)

    def update_print_controls_state(self, state):
        try:
            for check_box in self.frmPrinter.findChildren(QCheckBox):
                check_box.setEnabled(state)
            self.btn_printer_edit.setEnabled(not state)
            self.btn_printer_save.setEnabled(state)
            self.btn_entry.setEnabled(state)
            self.btn_re_entry.setEnabled(state)

            self.chk_header1.setEnabled(False)
            self.chk_re_header1.setEnabled(False)

            self.chk_code1.setEnabled(False)
            self.chk_re_code1.setEnabled(False)
            self.lst_header_data = VehicleEntryBL().Get_header()
            if len(self.lst_header_data) > 0:
                if self.lst_header_data[6] == '0':
                    self.chk_header2.setEnabled(False)
                if self.lst_header_data[7] == '0':
                    self.chk_header3.setEnabled(False)
                if self.lst_header_data[8] == '0':
                    self.chk_header4.setEnabled(False)
                if self.lst_header_data[9] == '0':
                    self.chk_header5.setEnabled(False)
                if self.lst_header_data[11] == '0':
                    self.chk_re_header2.setEnabled(False)
                if self.lst_header_data[12] == '0':
                    self.chk_re_header3.setEnabled(False)
                if self.lst_header_data[13] == '0':
                    self.chk_re_header4.setEnabled(False)
                if self.lst_header_data[14] == '0':
                    self.chk_re_header5.setEnabled(False)
            self.lst_code_details = VehicleReEntryBL().get_code()
            if len(self.lst_code_details) > 0:
                if self.lst_code_details[6] == '0':
                    self.chk_code2.setEnabled(False)
                if self.lst_code_details[7] == '0':
                    self.chk_code3.setEnabled(False)
                if self.lst_code_details[8] == '0':
                    self.chk_code4.setEnabled(False)
                if self.lst_code_details[9] == '0':
                    self.chk_code5.setEnabled(False)
                if self.lst_code_details[11] == '0':
                    self.chk_re_code2.setEnabled(False)
                if self.lst_code_details[12] == '0':
                    self.chk_re_code3.setEnabled(False)
                if self.lst_code_details[13] == '0':
                    self.chk_re_code4.setEnabled(False)
                if self.lst_code_details[14] == '0':
                    self.chk_re_code5.setEnabled(False)

        except Exception as e:
            print(e)

    def save_print_configuration_db(self):
        try:
            SystemConfig.get_check_box_select_status(self)
            self.print_configurations = []
            for count, items in enumerate(GlobalEntities.header_params_checkbox.items()):
                self.print_configurations.append(items[1])
            self.result_count = SystemConfigBL().get_print_config_count()
            if self.result_count == "0":
                self.result = SystemConfigBL().insert_print_config(self.print_configurations)
            else:
                self.result = SystemConfigBL().update_print_config(self.print_configurations)
            for index in range(len(self.label_status)):
                UiComponents.update_verified_status(self, self.label_status[index], True)
            self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                            "{"
                                            "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_entry.setStyleSheet("QPushButton::disabled"
                                         "{"
                                         "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                         "}"
                                         )
            SystemConfig.init_print_config(self)
            pass
        except Exception as e:
            print(e)

    def get_check_box_select_status(self):
        try:
            for index in range(len(GlobalEntities.print_entry_header)):
                self.check_box_name = GlobalEntities.print_entry_header[index].objectName()
                if GlobalEntities.print_entry_header[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})

            for index in range(len(GlobalEntities.print_reentry_header)):
                self.check_box_name = GlobalEntities.print_reentry_header[index].objectName()
                if GlobalEntities.print_reentry_header[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})

            for index in range(len(GlobalEntities.print_entry_code)):
                self.check_box_name = GlobalEntities.print_entry_code[index].objectName()
                if GlobalEntities.print_entry_code[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})

            for index in range(len(GlobalEntities.print_reentry_code)):
                self.check_box_name = GlobalEntities.print_reentry_code[index].objectName()
                if GlobalEntities.print_reentry_code[index].isChecked():
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "1"})
                else:
                    GlobalEntities.header_params_checkbox.update({self.check_box_name: "0"})
            pass
        except Exception as e:
            print(e)

    def fetch_display_print_configurations(self):
        try:
            self.lst_header_parameters = SystemConfigBL().get_printer_configuration()
            if self.lst_header_parameters is not None and len(self.lst_header_parameters) > 0:
                SystemConfig.assign_print_parameter_status(self, self.lst_header_parameters)
                self.lbl_header1.setText(str(self.lst_header_parameters[0]))
                self.lbl_header2.setText(str(self.lst_header_parameters[1]))
                self.lbl_header3.setText(str(self.lst_header_parameters[2]))
                self.lbl_header4.setText(str(self.lst_header_parameters[3]))
                self.lbl_header5.setText(str(self.lst_header_parameters[4]))
                self.lbl_code1.setText(str(self.lst_header_parameters[5]))
                self.lbl_code2.setText(str(self.lst_header_parameters[6]))
                self.lbl_code3.setText(str(self.lst_header_parameters[7]))
                self.lbl_code4.setText(str(self.lst_header_parameters[8]))
                self.lbl_code5.setText(str(self.lst_header_parameters[9]))
            pass
        except Exception as e:
            print(e)

    def assign_print_parameter_status(self, lst_parameters):
        try:
            for count, item in enumerate(GlobalEntities.header_params_checkbox.items()):
                GlobalEntities.header_params_checkbox.update({item[0]: lst_parameters[count + 10]})
            for count, item in enumerate(GlobalEntities.header_params_checkbox.items()):
                if count <= 4:
                    if item[1] == "1":
                        GlobalEntities.print_entry_header[count].setChecked(True)
                    else:
                        GlobalEntities.print_entry_header[count].setChecked(False)
                elif 9 >= count >= 5:
                    if item[1] == "1":
                        GlobalEntities.print_reentry_header[count - 5].setChecked(True)
                    else:
                        GlobalEntities.print_reentry_header[count - 5].setChecked(False)
                elif 14 >= count >= 10:
                    if item[1] == "1":
                        GlobalEntities.print_entry_code[count - 10].setChecked(True)
                    else:
                        GlobalEntities.print_entry_code[count - 10].setChecked(False)
                elif count >= 15:
                    if item[1] == "1":
                        GlobalEntities.print_reentry_code[count - 15].setChecked(True)
                    else:
                        GlobalEntities.print_reentry_code[count - 15].setChecked(False)

        except Exception as e:
            print(e)

    '''Ethernet+camera Configuration logic'''

    def init_Ethernet_communication(self, index):
        try:
            self.cam_count = SystemConfigBL().get_camera_Quantity()
            if len(self.cam_count) > 0:
                self.cmbCameraQuantity.setCurrentText(self.cam_count[0])
            if index == 1:
                SystemConfig.update_ethernet_controls_state(self, False)
                SystemConfig.on_loading_ethernet_settings(self, index)
            elif index == 2 or index == 3 or index == 4:
                SystemConfig.update_ethernet_controls_state(self, True)
                SystemConfig.on_loading_ethernet_settings(self, index)
            else:
                SystemConfig.update_ethernet_controls_state(self, False)

            pass
        except Exception as e:
            print(e)

    def on_loading_ethernet_settings(self, index):
        try:
            self.ethernet_data = SystemConfigBL().get_Ethernet(index)
            if len(self.ethernet_data) > 0:
                self.txtEthernetIpAddress.setText(self.ethernet_data[0])
                self.txtEthernetPortNumber.setText(self.ethernet_data[1])
                self.txtUsername.setText(self.ethernet_data[2])
                self.txtPassword.setText(self.ethernet_data[3])
        except Exception as e:
            print(e)

    def on_loading_URL1(self):
        try:
            self.URL_data = SystemConfigBL().get_url1()
            if self.URL_data:
                self.url = f'{self.URL_data}'
            return self.url
        except Exception as e:
            print(e)

    def on_loading_URL2(self):
        try:
            self.URL_data = SystemConfigBL().get_url2()
            if self.URL_data:
                self.url = f'{self.URL_data}'
            return self.url
        except Exception as e:
            print(e)

    def on_loading_URL3(self):
        try:
            self.URL_data = SystemConfigBL().get_url3()
            if self.URL_data:
                self.url = f'{self.URL_data}'
            return self.url
        except Exception as e:
            print(e)

    def on_loading_URL4(self):
        try:
            self.URL_data = SystemConfigBL().get_url4()
            if self.URL_data:
                self.url = f'{self.URL_data}'
            return self.url
        except Exception as e:
            print(e)

    def update_ethernet_controls_state(self, state):
        try:
            for text_box in self.frmEthernet.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for button in self.frmEthernet.findChildren(QPushButton):
                button.setEnabled(state)

            for combo_box in self.frmEthernet.findChildren(QComboBox):
                combo_box.setEnabled(state)

            self.btnEthernetEdit.setEnabled(not state)
            pass
        except Exception as e:
            print(e)
    def validate_ethernet_communication(self):
        try:
            self.text_box_count = 0
            for text_box in self.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
        except Exception as e:
            print(e)

    def save_ethernet_values(self, index):
        try:
            print(index)
            if SystemConfig.validate_ethernet_communication(self):

                self.ethernet_list = []
                self.ethernet_list = [self.txtEthernetIpAddress.text(), self.txtEthernetPortNumber.text(),
                                      self.txtUsername.text(), self.txtPassword.text()]
                print(self.ethernet_list)

                SystemConfig.update_ethernet_settings(self, self.ethernet_list, index)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                SystemConfig.update_ethernet_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def update_ethernet_settings(self, ethernet_list, index):
        try:
            Result = SystemConfigBL().Get_ethernet_Count()
            print(f"Get_ethernet_Count Result: {Result}")
            if Result == '0':  # Insert the Column
                self.Result = SystemConfigBL().Save_Ethernet(ethernet_list, index)
                print(f"Save_Ethernet Result: {self.Result}")
            elif Result == '1' or '2' or '3' or '4':  # Update the Column
                self.Result = SystemConfigBL().Update_Ethernet(ethernet_list, index)
                self.url = SystemConfigBL().Update_url(ethernet_list, index)
                print(f"Update_Ethernet Result: {self.Result}")
                print(f"Update_Ethernet Result: {self.url}")
        except Exception as e:
            print(e)

    def save_camera_quantity(self):
        try:
            if SystemConfig.validate_ethernet_communication(self):

                self.count = self.cmbCameraQuantity.currentText()

                print(self.count)

                SystemConfig.Update_Camera_Quantity(self, self.count)
                SystemConfig.init_Ethernet_communication(self, index)
                SystemConfig.update_ethernet_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def Update_Camera_Quantity(self, count):
        try:
            Result = SystemConfigBL().get_camera_Quantity()
            if Result == '0':  # Insert the Column
                self.Result = SystemConfigBL().save_camera_quantity(count)
            elif Result == '1' or '2' or '3' or '4':  # Update the Column
                self.Result = SystemConfigBL().Update_Camera_Quantity(count)
            SystemConfig.init_Ethernet_communication(self, index)
        except Exception as e:
            print(e)







