import random
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, QTime
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.VehicleReEntryBL import VehicleReEntryBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig


class HelpScreen(QMainWindow, PathConfig.UI.FROM_HELP):
    def __init__(self, parent=None):
        super(HelpScreen, self).__init__(parent)
        QMainWindow.__init__(self)
        self.main_screen = None
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        pixmap = QPixmap(PathConfig.IMG.IMAGE_HELP)
        UiComponents.help_screen(self)
        self.lbl_bg.setPixmap(pixmap.scaled(800, 480))
        self.images = [PathConfig.IMG.IMAGE_IMAGE1, PathConfig.IMG.IMAGE_IMAGE2, PathConfig.IMG.IMAGE_IMAGE3]
        self.load_images()
        self.tmr_shuffle_images = QTimer(self)
        self.tmr_shuffle_images.timeout.connect(self.shuffle_images)
        self.tmr_shuffle_images.start(1800)
        self.tmr_date_time = QTimer(self)
        self.tmr_date_time.timeout.connect(self.date_time)
        self.tmr_date_time.start(100)
        self.btn_next.clicked.connect(self.move_images)
        self.btn_home.clicked.connect(self.on_click_home)
        self.fetch_header_settings()
        self.set_label_values()
        self.key_actions = {
            Qt.Key_Escape: self.on_click_home


        }


    def shuffle_images(self):
        try:
            random.shuffle(self.images)
            for i in range(len(self.images)):
                pixmap = QPixmap(self.images[i])
                self.lbl_page1.setPixmap(pixmap)
        except Exception as e:
            print(e)

    def load_images(self):
        try:
            pixmap = QPixmap(self.images[0])
            self.lbl_page1.setPixmap(pixmap)
        except Exception as e:
            print(e)

    def set_label_values(self):
        try:
            self.get_type_details("DateTime", self.lbl_current_time, self.lbl_current_time)
        except Exception as e:
            print(e)

    def move_images(self):
        try:
            self.tmr_shuffle_images.stop()
            random.shuffle(self.images)
            pixmap = QPixmap(self.images[0])
            self.lbl_page1.setPixmap(pixmap)
        except Exception as e:
            print(e)

    def get_type_details(self, type, lbldisplay, valdisplay):
        try:
            type_row = VehicleReEntryBL().get_other_settings(type)
            lbldisplay.setText(type_row[0][0])
            isVisible = True if int(type_row[0][1]) else False
            lbldisplay.setVisible(isVisible)
            valdisplay.setVisible(isVisible)
        except Exception as e:
            print(e)

    def fetch_header_settings(self):
        try:
            self.lst_headers = GeneralSettingsBL().get_Parameters()
            if not len(self.lst_headers) < 0:
                self.lbl_app_header.setText(str(self.lst_headers[0]))
                UiComponents.update_header_logo(self, self.lblLogo, str(self.lst_headers[3]), 71, 41)
        except Exception as e:
            print(e)

    def date_time(self):
        try:
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%d-%m-%Y   %H:%M:%S %p")
            self.lbl_current_time.setText(formatted_datetime)
        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def on_click_home(self):
        try:
            if self.main_screen is None:
                self.disable_timers()
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen = MainScreen(self)
                self.main_screen.show()
                self.hide()
        except Exception as e:
            print(e)

    def disable_timers(self):
        try:
            self.tmr_shuffle_images.stop()
            self.tmr_date_time.stop()
        except Exception as e:
            print(e)

