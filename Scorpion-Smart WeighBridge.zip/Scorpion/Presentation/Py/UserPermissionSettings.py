from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidgetItem, QHBoxLayout, QPushButton, QVBoxLayout

from BusinessLogic.UserPermissionBL import UserPermissionBL


class UserPermissionSettings:
    def __init__(self):
        super().__init__()

    def SaveUserPermissionSettings(self, dictUserAccess,flgEditUserPermission):
        try:
            if not dictUserAccess is None:
                if not flgEditUserPermission:
                    self.Result = UserPermissionBL().FetchUserRoleStatus(dictUserAccess["UserName"])
                    if self.Result == 0:
                        UserPermissionBL().InsertUserRoles(dictUserAccess["UserName"])
                        self.RoleId = UserPermissionBL().GetUserRoleId(dictUserAccess["UserName"])
                        dictUserAccess.update({"UserName": str(self.RoleId)})
                        UserPermissionBL().InsertUserAccessStatus(dictUserAccess)
                    else:

                        self.RoleId = UserPermissionBL().GetUserRoleId(dictUserAccess["UserName"])
                        dictUserAccess.update({"UserName": str(self.RoleId)})
                        UserPermissionBL().InsertUserAccessStatus(dictUserAccess)
                else:
                    self.RoleId = UserPermissionBL().GetUserRoleId(dictUserAccess["UserName"])
                    dictUserAccess.update({"UserName": str(self.RoleId)})
                    UserPermissionBL().UpdateUserPermissionSettings(dictUserAccess)
        except Exception as e:
            print(e)

    def FetchAvailableRoles(self):
        try:
            self.lstAvailableRoles = []
            return UserPermissionBL().FetchAvailableRoles()
        except Exception as e:
            return self.lstAvailableRoles
            print(e)

    def FetchMaximumRoleCount(self):
        try:
            return UserPermissionBL().FetchMaximumCustomRoleCount()
        except Exception as e:
            print(e)

    def FetchStatusofSelectedRole(self, RoleName):
        try:
            self.lstRolesStatus = []
            self.lstRolesStatus = UserPermissionBL().FetchSelectedRoleStatus(RoleName)
            return self.lstRolesStatus
            pass
        except Exception as e:
            print(e)
            return self.lstRolesStatus
        pass

    def FetchActiveUserDetails(self):
        try:
            self.lstActiveUser = []
            self.lstActiveUser = UserPermissionBL().FetchActiveUserDetails()
            if not len(self.lstActiveUser) <= 0:
                return self.lstActiveUser
        except Exception as e:
            print(e)
            return self.lstActiveUser

    def delete_selected_role(self,username):
        try:
            self.RoleId = ""
            self.RoleId = UserPermissionBL().GetUserRoleId(username)
            UserPermissionBL().delete_selected_user_role(self.RoleId)
            UserPermissionBL().delete_selected_user_permission(self.RoleId)
            UserPermissionBL().Update_Role_ID(self.RoleId)
        except Exception as e:
            print(e)
        pass



