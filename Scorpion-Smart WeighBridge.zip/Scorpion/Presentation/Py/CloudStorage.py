from BusinessLogic.CloudStorageBL import CloudStorageBL
from BusinessLogic.MySQLCloudBL import MySQLCloudBL
from BusinessLogic.VehicleEntryBL import VehicleEntryBL
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable


class CloudStorage:
    def __init__(self):
        super().__init__()

    def store_data_cloud(self, param_tuple, type):
        try:
            param_tuple = param_tuple + (GlobalEntities.cust_code, GlobalEntities.device_id)
            if not GlobalVariable.wifi_status:
                if type == "Gunny":
                    self.result = CloudStorageBL().insert_entry_gunnydetails_cloud(param_tuple)
                else:
                    self.result = CloudStorageBL().insert_entry_details_cloud(param_tuple)
            else:
                if type == "Gunny":
                    self.result = MySQLCloudBL().insert_cloud_gunny_entry_details(param_tuple)
                else:
                    self.result = MySQLCloudBL().insert_cloud_entry_details(param_tuple)
                pass
        except Exception as e:
            print(e)

    def update_local_to_cloud_data(self, param_tuple):
        try:
            self.result = MySQLCloudBL().insert_cloud_from_local_details(param_tuple)
            pass
        except Exception as e:
            print(e)

    def save_re_entry_details(self, param):
        try:
            if not GlobalVariable.wifi_status:
                self.result = CloudStorageBL().update_re_entry_cloud_storage(param)
            else:
                self.result = MySQLCloudBL().update_re_entry_cloud_details(param)
            pass
        except Exception as e:
            print(e)
