import os

import pytz
from PyQt5.QtWidgets import QComboBox, QLineEdit, QPushButton

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Py.MessagePopup import MessagePopup
from Presentation.Utilities.GlobalVariable import GlobalVariable


class GeneralSettings:
    def __init__(self):
        super().__init__()

    def disable_verified_status(self):
        try:
            self.lbl_ip_status.setVisible(False)
            self.lbl_port_status.setVisible(False)
            pass
        except Exception as e:
            print(e)

    def init_date_time_configuration(self):
        try:
            self.flg_manual_enable = False
            GeneralSettings.assign_continent_values(self)
            GeneralSettings.update_date_time_controls_state(self, False)
            GeneralSettings.GetSavedRegion(self)
            pass
        except Exception as e:
            print(e)

    def update_date_time_controls_state(self, state):
        try:
            for combo_box in self.findChildren(QComboBox):
                combo_box.setEnabled(state)
                self.txt_date.setEnabled(state)
                self.txt_time.setEnabled(state)

            self.btnDateTimeEdit.setEnabled(not state)
            self.btnDateTimeSave.setEnabled(state)

            pass
        except Exception as e:
            print(e)

    def assign_continent_values(self):
        try:
            self.Asia_timezones = [timezone for timezone in pytz.all_timezones if "Asia" in timezone]
            self.Africa_timezones = [timezone for timezone in pytz.all_timezones if "Africa" in timezone]
            self.America_timezones = [timezone for timezone in pytz.all_timezones if "America" in timezone]
            self.Europe_timezones = [timezone for timezone in pytz.all_timezones if "Europe" in timezone]
            self.Australia_timezones = [timezone for timezone in pytz.all_timezones if "Australia" in timezone]
            self.cmbContinent.addItem('Asia', self.Asia_timezones)
            self.cmbContinent.addItem('Africa', self.Africa_timezones)
            self.cmbContinent.addItem('America', self.America_timezones)
            self.cmbContinent.addItem('Europe', self.Europe_timezones)
            self.cmbContinent.addItem('Australia', self.Australia_timezones)
            pass
        except Exception as e:
            print(e)

    def save_date_time_configurations(self):
        try:
            if self.flg_manual_enable:
                self.date = self.txt_date.text()
                self.time = self.txt_time.text()

                if not self.time == ":" and not self.date == "--" and len(self.time) == 5 and len(
                        self.date) == 10 and not self.time == "00:00" and not self.date == "00-00-0000":
                    self.get_date_time_manual_entries()
                    self.date_time = ""
                    self.date_time = str(self.month) + str(self.day) + str(self.hour) + str(self.minute) + str(
                        self.year)

                    self.false_ntp = "sudo timedatectl set-ntp false"
                    os.system(self.false_ntp)

                    self.date_and_time_command = "sudo date " + "" + self.date_time
                    print(self.date_and_time_command)
                    os.system(self.date_and_time_command)

                    self.write_date_time_to_hw_clock = "sudo hwclock -w"
                    print(self.write_date_time_to_hw_clock)
                    os.system(self.write_date_time_to_hw_clock)

                    GeneralSettingsBL().update_manual_entry(self.date, self.time)
                    GeneralSettings.update_date_time_controls_state(self, False)
                    # MessagePopup.setting_msg_popup(self, "correct", "Saved Successfully !! ")
                    UiComponents.update_verified_status(self, self.lbl_region_status, True)
                    UiComponents.update_verified_status(self, self.lbl_continent_status, True)
                else:
                    """ time validation """
                    if self.time == "::" or len(self.time) < 8 or self.time == "00:00":
                        self.lbl_region_status.setVisible(True)
                        UiComponents.update_verified_status(self, self.lbl_region_status, False)
                    """ date validation """
                    if self.date == "--" or len(self.date) < 10 or self.date == "00-00-0000":
                        self.lbl_continent_status.setVisible(True)
                        UiComponents.update_verified_status(self, self.lbl_continent_status, False)

            else:
                self.true_ntp = "sudo timedatectl set-ntp true"
                os.system(self.true_ntp)

                self.selected_region = self.cmbRegion.currentText()
                self.selected_continent = self.cmbContinent.currentText()
                self.setTimeZone = "sudo timedatectl set-timezone " + "" + self.selected_region

                os.system(self.setTimeZone)

                GeneralSettings.UpdateRegion(self, self.selected_region, self.selected_continent)
                GeneralSettings.update_date_time_controls_state(self, False)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
            pass
        except Exception as e:
            print(e)

    def UpdateRegion(self, region, continent):
        try:
            Result = GeneralSettingsBL().Get_GeneralSettings_Count()
            if Result == '0':  # Insert the Column
                self.Result = GeneralSettingsBL().Save_Region(region, continent)
            elif Result == '1':  # Update the Column
                self.Result = GeneralSettingsBL().Update_Region(region, continent)
        except Exception as e:
            print(e)

    def Update_date_time(self, date, time):
        try:
            Result = GeneralSettingsBL().Get_GeneralSettings_Count()
            if Result == '0':  # Insert the Column
                self.Result = GeneralSettingsBL().save_date_time(date, time)
            elif Result == '1':  # Update the Column
                self.Result = GeneralSettingsBL().update_date_time(date, time)
        except Exception as e:
            print(e)

    def GetSavedRegion(self):
        try:
            self.Region = GeneralSettingsBL().GetSavedRegion()
            if len(self.Region) > 0:
                self.cmbContinent.setCurrentText(self.Region[0][0])
                self.cmbRegion.setCurrentText(self.Region[0][1])
                self.txt_date.setText(self.Region[0][2])
                self.txt_time.setText(self.Region[0][3])
                if self.Region[0][4] == "Auto":
                    self.on_click_date_time_auto()
                else:
                    self.on_click_date_time_manual()
        except OSError as e:
            print(e)

    '''Header Configuration logic'''

    def init_header_config(self):
        try:
            GeneralSettings.GetDBHeaders(self)
            GeneralSettings.update_header_config_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def GetDBHeaders(self):
        try:
            self.DBHeaders = GeneralSettingsBL().get_Parameters()
            if len(self.DBHeaders) > 0:
                self.txtHeader1.setText(self.DBHeaders[0])
                self.txtHeader2.setText(self.DBHeaders[1])
                self.txtHeader3.setText(self.DBHeaders[2])
                self.logo_image = str(self.DBHeaders[3])
                UiComponents.update_header_logo(self, self.lblLogo, self.logo_image, 111, 111)
        except Exception as e:
            print(e)

    def update_header_config_controls_state(self, state):
        try:
            for text_box in self.frmHeader.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for button in self.frmHeader.findChildren(QPushButton):
                button.setEnabled(state)

            self.btnHeaderEdit.setEnabled(not state)
            pass
        except Exception as e:
            print(e)

    def validate_header_configurations(self):
        try:
            self.text_box_count = 0
            for text_box in self.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
        except Exception as e:
            print(e)

    def save_Header_values(self):
        try:
            if GeneralSettings.validate_header_configurations(self):
                self.headers_list = []
                self.headers_list = [self.txtHeader1.text(), self.txtHeader2.text(), self.txtHeader3.text(),
                                     GlobalVariable.Logo]
                GeneralSettings.UpdateDBHeaders(self, self.headers_list)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                GeneralSettings.init_header_config(self)
            pass
        except Exception as e:
            print(e)

    def UpdateDBHeaders(self, listofheaders):
        try:
            Result = GeneralSettingsBL().Get_GeneralSettings_Count()
            if Result == '0':  # Insert the Column
                self.Result = GeneralSettingsBL().Save_Headers(listofheaders)
            elif Result == '1':  # Update the Column
                self.Result = GeneralSettingsBL().Update_Headers(listofheaders)
        except Exception as e:
            print(e)

    '''Footer Configuration logicv'''

    def init_footer_config(self):
        try:
            GeneralSettings.get_footer_configurations(self)
            GeneralSettings.update_footer_config_controls_state(self, False)
            pass
        except Exception as e:
            print(e)

    def update_footer_config_controls_state(self, state):
        try:
            for text_box in self.frmFooter.findChildren(QLineEdit):
                text_box.setEnabled(state)

            for button in self.frmFooter.findChildren(QPushButton):
                button.setEnabled(state)

            self.btnFooterEdit.setEnabled(not state)
            pass
        except Exception as e:
            print(e)

    def get_footer_configurations(self):
        try:
            self.DBHeaders = GeneralSettingsBL().get_footer_Parameters()
            if len(self.DBHeaders) > 0:
                self.txtFooter1.setText(self.DBHeaders[0])
                self.txtFooter2.setText(self.DBHeaders[1])
                self.txtFooter3.setText(self.DBHeaders[2])
        except Exception as e:
            print(e)

    def validate_footer_configurations(self):
        try:
            self.text_box_count = 0
            for text_box in self.frmFooter.findChildren(QLineEdit):
                if text_box.text() == "":
                    UiComponents.update_verified_status(self, self.label_status[self.text_box_count], False)
                    return False
                self.text_box_count += 1
            return True
        except Exception as e:
            print(e)

    def save_Footer_values(self):
        try:
            if GeneralSettings.validate_footer_configurations(self):
                self.headers_list = []
                self.headers_list = [self.txtFooter1.text(), self.txtFooter2.text(), self.txtFooter3.text()]
                GeneralSettings.update_footer_values(self, self.headers_list)
                for index in range(len(self.label_status)):
                    UiComponents.update_verified_status(self, self.label_status[index], True)
                GeneralSettings.init_footer_config(self)
            pass
        except Exception as e:
            print(e)

    def update_footer_values(self, listofheaders):
        try:
            Result = GeneralSettingsBL().Get_GeneralSettings_Count()
            if Result == '0':  # Insert the Column
                self.Result = GeneralSettingsBL().Save_Footer(listofheaders)
            elif Result == '1':  # Update the Column
                self.Result = GeneralSettingsBL().Update_Footer(listofheaders)
        except Exception as e:
            print(e)

    '''     '''



    def Get_datetime(self):
        self.datetime = datetime.now()
        self.Current_datetime = self.datetime.strftime("%d/%m/%Y %H:%M:%S")