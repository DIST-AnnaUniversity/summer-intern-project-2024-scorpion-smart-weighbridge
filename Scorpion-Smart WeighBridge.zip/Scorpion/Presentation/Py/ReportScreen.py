
import csv
import os

from PyQt5.QtCore import Qt, QDateTime
from PyQt5 import QtWidgets
from datetime import datetime, timedelta, date

from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem

from BusinessLogic.GeneralSettingsBL import GeneralSettingsBL
from BusinessLogic.ReportBL import ReportBL
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH, USB_PATH
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image, Paragraph, Spacer
import glob

from Presentation.Py.extended_combobox import ExtendedComboBox
from Presentation.Utilities.GlobalVariable import GlobalVariable
from models.ExportCSV import ExportCSV
from models.ExportPDF import ExportPDF


class ReportScreen(QMainWindow, PathConfig.UI.FROM_REPORT):
    def __init__(self, parent=None):
        super(ReportScreen, self).__init__(parent)
        QMainWindow.__init__(self)
        self.sub_folder_name = ""
        self.flg_tare_log = False
        self.flg_cal_log = False
        self.csv_result = None
        self.pdf_result = None
        self.main_screen_obj = None
        self.flg_code = False
        self.flg_header = True
        self.flg_monthly = False
        self.flg_daily = True
        self.setupUi(self)
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.create_combo_boxes()
        UiComponents.ReportScreenUiComponents(self)
        self.report_screen_load_event()
        self.on_load_report_data()
        self.event_handlers()
        self.combo_box_styles()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.on_click_close()

    def report_screen_load_event(self):
        try:
            self.sub_folder_name = ""
            self.btn_download.setEnabled(False)
            self.gbMsgPanel.setVisible(False)
            self.dtp_to_date.setVisible(False)
            self.lbl_to_date.setVisible(False)
            UiComponents.daily_toggle(self)
            UiComponents.header_toggle(self)

            self.lst_headers = []
            self.table_headers = []
            self.lst_code = []
            self.enableField = []
            self.table_headers = ["SerialNo", "Report Date", "Report Time"]
            self.fetch_headers = ReportBL().get_headers_fields()
            self.fetch_code = ReportBL().get_codes_fields()
            if self.flg_monthly and self.flg_code:
                self.fetch_and_add_items(self.fetch_code, self.lst_code, self.cmb_code)
                self.fetch_and_add_items(self.fetch_headers, self.lst_headers, self.cmb_header)
            else:
                self.fetch_and_add_items(self.fetch_headers, self.lst_headers, self.cmb_header)
                self.fetch_and_add_items(self.fetch_code, self.lst_code, self.cmb_code)
            self.table_headers.extend(["Gross wt", "Tare wt", "Net wt", "Entry Amt", "ReEntry Amt", "Total Amt"])
            for i in range(6, 11):
                self.enableField.extend([int(self.fetch_headers[i]), int(self.fetch_code[i])])

            time = QDateTime.currentDateTime()
            self.dtp_from_date.setDateTime(QDateTime.currentDateTime())
            self.dtp_from_date.setDisplayFormat("dd/MM/yyyy")
            self.selectedvalue = self.dtp_from_date.dateTime()
            self.selectedfromdate = self.selectedvalue.toString("yyyy-MM-dd")
            self.dtp_to_date.setDateTime(QDateTime.currentDateTime())
            self.dtp_to_date.setDisplayFormat("dd/MM/yyyy")
            self.selectedtovalue = self.dtp_from_date.dateTime()
            self.selectedtodate = self.selectedtovalue.toString("yyyy-MM-dd")

            if self.flg_code:
                self.on_select_code_combobox_changed()
            else:
                self.on_select_header_combobox_changed()
        except Exception as err:
            print(err)

    def fetch_and_add_items(self, fetch_list, target_list, combobox):
        try:
            items = []
            for i in range(6, 11):
                if fetch_list[i] == "1":
                    items.append(fetch_list[i - 5])
                    self.table_headers.append(fetch_list[i - 5])
            target_list.extend(items)
            combobox.clear()
            combobox.addItems(items)

        except Exception as err:
            print(err)

    def event_handlers(self):
        try:
            self.btn_ok.clicked.connect(self.on_click_ok)
            self.btn_code.clicked.connect(self.on_click_code)
            self.btn_apply.clicked.connect(self.on_click_apply)
            self.btn_close.clicked.connect(self.on_click_close)
            self.btn_daily.clicked.connect(self.on_click_daily)
            self.btn_cal_log.clicked.connect(self.on_click_cal_log)
            self.btn_tare_log.clicked.connect(self.on_click_tare_log)
            self.btn_header.clicked.connect(self.on_click_header)
            self.btn_monthly.clicked.connect(self.on_click_monthly)
            self.btn_download.clicked.connect(self.on_click_download)
            self.dtp_to_date.dateChanged.connect(self.get_monthly_to_date)
            self.dtp_from_date.dateChanged.connect(self.get_monthly_from_date)
            self.cmb_code.currentIndexChanged.connect(self.on_select_code_combobox_changed)
            self.cmb_header.currentIndexChanged.connect(self.on_select_header_combobox_changed)
            self.cmb_code.activated[str].connect(self.on_select_code_combobox_changed)
            self.cmb_header.activated[str].connect(self.on_select_header_combobox_changed)
            self.cmb_header_data.setEditable(True)
            self.cmb_header_data.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
            self.cmb_header_data.completer().setCompletionMode(QtWidgets.QCompleter.PopupCompletion)
            self.cmb_code_data.setEditable(True)
            self.cmb_code_data.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
            self.cmb_code_data.completer().setCompletionMode(QtWidgets.QCompleter.PopupCompletion)


        except Exception as e:
            print(e)

    def on_select_header_combobox_changed(self):
        try:
            header_names = {
                0: "header1",
                1: "header2",
                2: "header3",
                3: "header4",
                4: "header5"
            }

            header_current_index = self.cmb_header.currentIndex()
            header_name = header_names.get(header_current_index)
            self.cmb_header_data.setCurrentIndex(0)
            if header_name is not None:
                self.cmb_header_data.clear()
                if self.flg_daily:
                    header_data = ReportBL().get_header_daily_data(header_name, self.selectedfromdate)
                else:
                    header_data = ReportBL().get_header_monthly_data(header_name, self.selectedfromdate,
                                                                     self.selectedtodate)
                self.cmb_header_data.addItems(header_data)
                if self.cmb_header_data.count() > 0:
                    self.cmb_header_data.setCurrentIndex(0)
                current_index = self.cmb_header_data.currentIndex()
                if self.cmb_header_data.count() > 1:
                    self.cmb_header_data.addItem("All")
                    self.cmb_header_data.setCurrentText("All")
                self.value = header_name
                print(self.cmb_header_data.currentText())
        except Exception as err:
            print(err)

    def on_select_code_combobox_changed(self):
        try:
            code_names = {
                0: "code1_no",
                1: "code2_no",
                2: "code3_no",
                3: "code4_no",
                4: "code5_no"
            }

            code_current_index = self.cmb_code.currentIndex()
            code_name = code_names.get(code_current_index)

            if code_name is not None:
                self.cmb_code_data.clear()

                if self.flg_daily:
                    code_data = ReportBL().get_code_daily_data(code_name, self.selectedfromdate)
                else:
                    code_data = ReportBL().get_code_monthly_data(code_name, self.selectedfromdate, self.selectedtodate)

                self.cmb_code_data.addItems(code_data)
                if self.cmb_code_data.count() > 1:
                    self.cmb_code_data.addItem("All")
                    self.cmb_code_data.setCurrentText("All")
                if code_name == 'code1_no':
                    self.value = 'code1'
                elif code_name == 'code2_no':
                    self.value = 'code2'
                elif code_name == 'code3_no':
                    self.value = 'code3'
                elif code_name == 'code4_no':
                    self.value = 'code4'
                elif code_name == 'code5_no':
                    self.value = 'code5'
        except Exception as err:
            print(err)

    def on_click_ok(self):
        try:
            self.DisableMessagePanel()
        except OSError as e:
            print(e)

    def on_click_apply(self):
        try:
            self.sub_folder_name = ""
            if self.flg_daily:
                self.ReportTable.clear()
                selecteddate = self.selectedfromdate
                if not self.flg_code:
                    sortname = self.cmb_header_data.currentText()
                    self.on_select_header_combobox_changed()
                    self.cmb_header_data.setCurrentText(sortname)
                else:
                    sortname = self.cmb_code_data.currentText()
                    self.on_select_code_combobox_changed()
                    self.cmb_code_data.setCurrentText(sortname)

                sortusing = self.value
                mapping = {
                    'code1': 'code1_no',
                    'code2': 'code2_no',
                    'code3': 'code3_no',
                    'code4': 'code4_no',
                    'code5': 'code5_no'
                }

                if sortusing in mapping:
                    sortusing = mapping[sortusing]

                self.flagData = False
                self.pdfTableData = []
                if self.flg_header:
                    if self.cmb_header_data.currentText() == "All":
                        result = ReportBL().on_load_daily_products(str(selecteddate))
                    else:
                        result = ReportBL().get_daily_products(str(selecteddate), str(sortname), str(sortusing))
                elif self.flg_code:
                    if self.cmb_code_data.currentText() == "All":
                        result = ReportBL().on_load_daily_products(str(selecteddate))
                    else:
                        result = ReportBL().get_daily_products(str(selecteddate), str(sortname), str(sortusing))

                nwen = [1, 1, 1] + self.enableField[0:] + [1, 1, 1, 1]
                nwen += [1, 1]
                self.pdfTableData.append(self.table_headers)
                self.ReportTable.setRowCount(0)
                self.ReportTable.setColumnCount(len(self.table_headers))
                self.ReportTable.setHorizontalHeaderLabels(self.table_headers)
                header = self.ReportTable.horizontalHeader()
                for rownumber, rowdata in enumerate(result):
                    self.flagData = True
                    self.DisableMessagePanel()
                    self.btn_download.setEnabled(True)
                    self.ReportTable.insertRow(rownumber)
                    rowdata = list(rowdata)
                    row = []
                    for i in range(len(rowdata)):
                        if nwen[i] == 1:
                            row.append(rowdata[i])
                    self.pdfTableData.append(row)
                    for i in range(len(row)):
                        self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                if not self.flagData:
                    self.btn_download.setEnabled(False)
                    self.gbMsgPanel.setVisible(True)
                    self.btn_ok.setVisible(True)
                    self.lblMsg.setVisible(True)
                    self.lblMsgbg.setVisible(True)
                    self.lblMsg.setText("Data not Available")
                else:
                    self.btn_download.setEnabled(True)
            elif self.flg_monthly:

                self.flagData = False
                self.ReportTable.clear()

                self.selectedvalue = self.dtp_from_date.dateTime()
                self.selectedfromdate = self.selectedvalue.toString("yyyy-MM-dd")
                self.selectedtovalue = self.dtp_to_date.dateTime()
                self.selectedtodate = self.selectedtovalue.toString("yyyy-MM-dd")

                sortusing = self.value
                mapping = {
                    'code1': 'code1_no',
                    'code2': 'code2_no',
                    'code3': 'code3_no',
                    'code4': 'code4_no',
                    'code5': 'code5_no'
                }

                if sortusing in mapping:
                    self.table_header = mapping[sortusing]

                if self.flg_code == False:
                    sortname = self.cmb_header_data.currentText()
                    self.on_select_header_combobox_changed()
                    self.cmb_header_data.setCurrentText(sortname)
                else:
                    sortname = self.cmb_code_data.currentText()
                    self.on_select_code_combobox_changed()
                    self.cmb_code_data.setCurrentText(sortname)

                nwen = [1, 1, 1] + self.enableField[0:] + [1, 1, 1, 1]
                nwen += [1, 1]

                self.pdfTableData = []
                self.pdfTableData.append(self.table_headers)
                self.ReportTable.setRowCount(0)
                self.ReportTable.setColumnCount(len(self.table_headers))
                self.ReportTable.setHorizontalHeaderLabels(self.table_headers)
                header = self.ReportTable.horizontalHeader()

                from datetime import datetime, timedelta

                start_date = datetime.strptime(self.selectedfromdate, '%Y-%m-%d')
                end_date = datetime.strptime(self.selectedtodate, '%Y-%m-%d')

                dates_list = []

                current_date = start_date
                while current_date <= end_date:
                    dates_list.append(current_date.strftime('%Y-%m-%d'))
                    current_date += timedelta(days=1)
                if self.flg_code:
                    if self.cmb_code_data.currentText() == "All":
                        sortusing = ''
                elif self.flg_header:
                    if self.cmb_header_data.currentText() == "All":
                        sortusing = ''

                for d in dates_list:
                    if sortusing == '':
                        if self.cmb_header_data.currentText() == "All" or self.cmb_code_data.currentText() == "All":
                            result = ReportBL().on_load_daily_products(d)
                        else:
                            if self.flg_code == False:
                                result = ReportBL().GetMonthlyProducts(d, self.table_header,
                                                                       self.cmb_header_data.currentText())
                            else:
                                result = ReportBL().GetMonthlyProducts(d, self.table_header,
                                                                       self.cmb_code_data.currentText())
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):
                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'header1':
                        result = ReportBL().GetHeader1Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'header2':
                        result = ReportBL().GetHeader2Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):
                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'header3':
                        result = ReportBL().GetHeader3Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'header4':
                        result = ReportBL().GetHeader4Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'header5':
                        result = ReportBL().GetHeader5Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'code1':
                        result = ReportBL().GetCode1Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'code2':
                        result = ReportBL().GetCode2Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'code3':
                        result = ReportBL().GetCode3Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'code4':
                        result = ReportBL().GetCode4Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):
                                if nwen[i] == 1:
                                    row.append(rowdata[i])
                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                    elif sortusing == 'code5':
                        result = ReportBL().GetCode5Data(d, sortname)
                        for rownumber, rowdata in enumerate(result):
                            self.flagData = True
                            self.DisableMessagePanel()
                            self.ReportTable.insertRow(rownumber)
                            rowdata = list(rowdata)
                            row = []
                            for i in range(len(rowdata)):

                                if nwen[i] == 1:
                                    row.append(rowdata[i])

                            self.pdfTableData.append(row)
                            for i in range(len(row)):
                                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
                if not self.flagData:
                    self.btn_download.setEnabled(False)
                    self.gbMsgPanel.setVisible(True)
                    self.btn_ok.setVisible(True)
                    self.lblMsg.setVisible(True)
                    self.lblMsgbg.setVisible(True)
                    self.lblMsg.setText("Data not Available")
                else:
                    self.btn_download.setEnabled(True)
        except Exception as e:
            print(e)

    def on_click_download(self):
        try:
            self.get_headers = GeneralSettingsBL().get_Parameters()
            if self.cmb_export_type.currentText() == "PDF":
                self.pdf_result = ExportPDF.export_to_pdf(self, self.pdfTableData, "WEIGHBRIDGE", "PDF",
                                                          self.sub_folder_name,
                                                          self.get_headers[0], self.get_headers[1], self.get_headers[2],
                                                          self.get_headers[3])
                if self.pdf_result:
                    self.display_msg(self.pdf_result)
                    self.pdf_result = ""
            elif self.cmb_export_type.currentText() == "CSV":
                self.csv_result = ExportCSV.export_to_csv(self, self.ReportTable, "WEIGHBRIDGE", "CSV",
                                                          self.sub_folder_name, "WEIGHBRIDGE")
                if self.csv_result:
                    self.display_msg(self.csv_result)
                    self.csv_result = ""

        except Exception as e:
            print(e)

    def display_msg(self, msg):
        try:
            self.gbMsgPanel.setVisible(True)
            self.btn_ok.setVisible(True)
            self.lblMsg.setVisible(True)
            self.lblMsgbg.setVisible(True)
            self.lblMsg.setText(str(msg))
        except Exception as e:
            print(e)

    def on_click_daily(self):
        try:
            UiComponents.daily_toggle(self)
            self.flg_daily = True
            self.flg_monthly = False
            self.dtp_to_date.setVisible(False)
            self.lbl_to_date.setVisible(False)
        except Exception as e:
            print(e)

    def on_click_monthly(self):
        try:
            UiComponents.monthly_toggle(self)
            self.flg_monthly = True
            self.flg_daily = False
            self.dtp_to_date.setVisible(True)
            self.lbl_to_date.setVisible(True)
        except Exception as e:
            print(e)

    def on_click_header(self):
        try:
            UiComponents.header_toggle(self)
            self.lbl_code.move(3578, 656)
            self.cmb_code.move(3578, 4747)
            self.lbl_code_data.move(35778, 4747)
            self.cmb_code_data.move(5256455, 109)
            self.lbl_header.move(355, 74)
            self.cmb_header.move(2, 5)
            self.lbl_header_data.move(525, 74)
            self.cmb_header_data.move(175, 5)
            self.flg_code = False
            self.flg_header = True
        except Exception as e:
            print(e)

    def on_click_code(self):
        try:
            UiComponents.code_toggle(self)
            self.lbl_header.move(3578, 656)
            self.cmb_header.move(3578, 4747)
            self.lbl_header_data.move(35778, 4747)
            self.cmb_header_data.move(5256455, 109)
            self.lbl_code.move(355, 74)
            self.cmb_code.move(2, 5)
            self.lbl_code_data.move(525, 74)
            self.cmb_code_data.move(175, 5)
            self.flg_code = True
            self.flg_header = False
            self.on_select_code_combobox_changed()
        except Exception as e:
            print(e)

    def on_click_close(self):
        try:
            if self.main_screen_obj is None:
                from Presentation.Py.MainScreen import MainScreen
                self.main_screen_obj = MainScreen(self)
                self.main_screen_obj.show()
                self.hide()
        except Exception as e:
            print(e)

    def get_monthly_from_date(self, from_date):
        try:
            self.selectedfromdate = ""
            self.selectedfromdate = from_date.toString("yyyy-MM-dd")
            if self.flg_code:
                self.on_select_code_combobox_changed()
            else:
                self.on_select_header_combobox_changed()
        except OSError as e:
            print(e)

    def get_monthly_to_date(self, to_date):
        try:
            self.selectedtodate = ""
            self.selectedtodate = to_date.toString("yyyy-MM-dd")
            if self.flg_code:
                self.on_select_code_combobox_changed()
            else:
                self.on_select_header_combobox_changed()
        except OSError as e:
            print(e)

    def on_load_report_data(self):
        UiComponents.default_style_for_cal_tare(self)
        self.ReportTable.clear()
        selecteddate = self.selectedfromdate
        self.flagData = False
        self.pdfTableData = []
        result = ReportBL().on_load_daily_products(str(selecteddate))
        nwen = [1, 1, 1] + self.enableField[0:] + [1, 1, 1, 1]
        nwen += [1, 1]
        self.pdfTableData.append(self.table_headers)
        self.ReportTable.setRowCount(0)
        self.ReportTable.setColumnCount(len(self.table_headers))
        self.ReportTable.setHorizontalHeaderLabels(self.table_headers)
        header = self.ReportTable.horizontalHeader()
        header.setStyleSheet(
            "QHeaderView::section { background-color:rgb(231, 231, 231); }")
        for rownumber, rowdata in enumerate(result):
            self.flagData = True
            self.DisableMessagePanel()
            self.ReportTable.insertRow(rownumber)
            rowdata = list(rowdata)
            row = []
            for i in range(len(rowdata)):
                if nwen[i] == 1:
                    row.append(rowdata[i])
            self.pdfTableData.append(row)
            for i in range(len(row)):
                self.ReportTable.setItem(rownumber, i, QTableWidgetItem(str(row[i])))
        if not self.flagData:
            self.gbMsgPanel.setVisible(True)
            self.btn_ok.setVisible(True)
            self.lblMsg.setVisible(True)
            self.lblMsgbg.setVisible(True)
            self.lblMsg.setText("Data not Available")
        if self.cmb_header_data.count() > 1:
            self.cmb_header_data.setCurrentText("All")
        if self.cmb_code_data.count() > 1:
            self.cmb_code_data.setCurrentText("All")

    def DisableMessagePanel(self):
        try:
            self.gbMsgPanel.setVisible(False)
            self.lblMsgbg.setVisible(False)
            self.btn_ok.setVisible(False)
            self.lblMsg.setVisible(False)
        except OSError as e:
            print(e)

    def on_click_cal_log(self):
        try:
            self.sub_folder_name = "CALIBRATION"
            self.pdfTableData = []
            self.gbMsgPanel.setVisible(False)
            UiComponents.cal_toggle(self)
            self.flg_cal_log = True
            self.flg_tare_log = False
            self.ReportTable.setColumnCount(0)
            self.ReportTable.setRowCount(0)
            header = self.ReportTable.horizontalHeader()
            header.setFixedHeight(40)
            self.ReportTable.setColumnCount(10)
            self.cal_log_headers = ['SI.NO','User', 'Calibrated Date Time', 'Decimal Point', 'Resolution', 'Cal Zero',
                                    'Cal Span',
                                    'Cal Capacity',
                                    'Max Capacity', 'Unit']
            self.ReportTable.setHorizontalHeaderLabels(self.cal_log_headers
                                                       )
            self.pdfTableData.append(self.cal_log_headers)
            self.get_calibration_log = ReportBL().get_calibration_record()
            if len(self.get_calibration_log) > 0:
                self.btn_download.setEnabled(True)
                self.ReportTable.setRowCount(0)
                for row_number, row_data in enumerate(self.get_calibration_log):
                    self.ReportTable.insertRow(row_number)
                    # Insert serial number
                    serial_number_item = QTableWidgetItem(str(row_number + 1))
                    serial_number_item.setFont(QFont('Arial', 12))
                    serial_number_item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                    self.ReportTable.setItem(row_number, 0, serial_number_item)
                    # Insert other row data
                    for column_number, data in enumerate(row_data, start=1):
                        self.ReportTable.setColumnWidth(column_number, 375)
                        self.ReportTable.setRowHeight(row_number, 30)
                        item = QTableWidgetItem(str(data))
                        item.setFont(QFont('Arial', 12))
                        item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                        self.ReportTable.setItem(row_number, column_number, item)
                    self.pdfTableData.append(row_data)
            else:
                self.sub_folder2_name = ""
                self.flg_cal_log = False
                self.gbMsgPanel.setVisible(True)
                self.btn_ok.setVisible(True)
                self.lblMsg.setVisible(True)
                self.lblMsgbg.setVisible(True)
                self.lblMsg.setText("Data not Available")
        except Exception as e:
            print(e)

    def on_click_tare_log(self):
        try:
            self.sub_folder_name = "TARE"
            self.pdfTableData = []
            self.gbMsgPanel.setVisible(False)
            UiComponents.tare_toggle(self)
            self.flg_tare_log = True
            self.flg_cal_log = False
            self.ReportTable.setColumnCount(0)
            self.ReportTable.setRowCount(0)
            header = self.ReportTable.horizontalHeader()
            header.setFixedHeight(40)
            self.ReportTable.setColumnCount(4)
            self.tare_log_headers = ['SI.NO', 'User', 'Tared Date Time','Unit']
            self.ReportTable.setHorizontalHeaderLabels(self.tare_log_headers)
            self.pdfTableData.append(self.tare_log_headers)
            self.get_tare_log = ReportBL().get_tare_record()
            if len(self.get_tare_log) > 0:
                self.btn_download.setEnabled(True)
                self.ReportTable.setRowCount(0)
                for row_number, row_data in enumerate(self.get_tare_log):
                    self.ReportTable.insertRow(row_number)
                    # Insert serial number
                    serial_number_item = QTableWidgetItem(str(row_number + 1))
                    serial_number_item.setFont(QFont('Arial', 12))
                    serial_number_item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                    self.ReportTable.setItem(row_number, 0, serial_number_item)
                    # Insert other row data
                    for column_number, data in enumerate(row_data, start=1):
                        self.ReportTable.setColumnWidth(column_number, 250)
                        self.ReportTable.setRowHeight(row_number, 30)
                        item = QTableWidgetItem(str(data))
                        item.setFont(QFont('Arial', 12))
                        item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                        self.ReportTable.setItem(row_number, column_number, item)
                    self.pdfTableData.append(row_data)
            else:
                self.sub_folder2_name = ""
                self.flg_tare_log = False
                self.gbMsgPanel.setVisible(True)
                self.btn_ok.setVisible(True)
                self.lblMsg.setVisible(True)
                self.lblMsgbg.setVisible(True)
                self.lblMsg.setText("Data not Available")
        except Exception as e:
            print(e)

    def create_combo_boxes(self):
        try:
            self.cmb_header = ExtendedComboBox(self.pnl_base)
            self.cmb_header.setParent(self.pnl_base)
            self.cmb_header.setGeometry(2, 5, 161, 41)
            self.cmb_header.setMaxVisibleItems(5)
            self.cmb_header_data = ExtendedComboBox(self.pnl_base)
            self.cmb_header_data.setParent(self.pnl_base)
            self.cmb_header_data.setGeometry(175, 5, 161, 41)
            self.cmb_header_data.setMaxVisibleItems(5)
            self.cmb_code = ExtendedComboBox(self.pnl_base)
            self.cmb_code.setParent(self.pnl_base)
            self.cmb_code.setGeometry(26568, 5, 161, 41)
            self.cmb_code.setMaxVisibleItems(5)
            self.cmb_code_data = ExtendedComboBox(self.pnl_base)
            self.cmb_code_data.setParent(self.pnl_base)
            self.cmb_code_data.setGeometry(1778675, 5, 161, 41)
            self.cmb_code_data.setMaxVisibleItems(5)
        except Exception as e:
            print(e)

    def combo_box_styles(self):
        try:
            self.cmb_input_names = [self.cmb_header, self.cmb_header_data, self.cmb_code, self.cmb_code_data
                                    ]
            for i in range(len(self.cmb_input_names)):
                UiComponents.set_report_bordered_combo_box(self, self.cmb_input_names[i])
        except Exception as e:
            print(e)
