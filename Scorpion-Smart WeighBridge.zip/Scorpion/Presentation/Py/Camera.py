import platform
import sys
import os

from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QDialog, QMessageBox, QGridLayout
from PyQt5.QtCore import QTime, pyqtSlot, QEvent
from PyQt5 import uic
from datetime import datetime
import PyQt5
import serial
from PyQt5.QtGui import QPixmap, QFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from PyQt5.QtSerialPort import QSerialPortInfo
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView
from PyQt5.QtCore import pyqtSignal

from Presentation.Bundles.Helper import Helper
from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import PathConfig, ROOT_PATH
from Presentation.Py.SystemConfig import SystemConfig
from Presentation.Py.WifiConfiguration import WifiConfiguration
from Presentation.Py.SettingScreen import SettingScreen, ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.Modbus import Modbus
from Presentation.Utilities.ModbusProtocols import ModbusProtocols
from Presentation.Utilities.GlobalVariable import GlobalVariable
import cv2

class CameraScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        ui_file = os.path.join(ROOT_PATH, 'UI', 'camera.ui')

        # Load the UI file
        uic.loadUi(ui_file, self)

        self.setWindowTitle("Camera Feed")

        self.setWindowFlag(Qt.FramelessWindowHint)

        # Initialize camera labels and buttons from UI
        self.camera_1 = self.findChild(QLabel, 'camera_1')
        self.camera_2 = self.findChild(QLabel, 'camera_2')
        self.camera_3 = self.findChild(QLabel, 'camera_3')
        self.camera_4 = self.findChild(QLabel, 'camera_4')

        self.close_camera_button = self.findChild(QPushButton, 'close_camera_button')

        self.camera_labels = {
            "camera_1": self.camera_1,
            "camera_2": self.camera_2,
            "camera_3": self.camera_3,
            "camera_4": self.camera_4,
        }

        self.full_screen_dialogs = {}


        # Mouse Press
        self.camera_1.mousePressEvent = lambda event: self.display_full_screen(self.camera_1)
        self.camera_2.mousePressEvent = lambda event: self.display_full_screen(self.camera_2)
        self.camera_3.mousePressEvent = lambda event: self.display_full_screen(self.camera_3)
        self.camera_4.mousePressEvent = lambda event: self.display_full_screen(self.camera_4)

        # Shortcut Key
        self.key_actions = {
            Qt.Key_Escape: lambda: self.go_home(),
            Qt.Key_1: lambda: self.display_full_screen(self.camera_1),
            Qt.Key_2: lambda: self.display_full_screen(self.camera_2),
            Qt.Key_3: lambda: self.display_full_screen(self.camera_3),
            Qt.Key_4: lambda: self.display_full_screen(self.camera_4),
            Qt.Key_QuoteLeft: lambda: self.close_full_screen()
        }

        self.close_camera_button.clicked.connect(self.go_home)

        # self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.datetime_timer = QTimer(self)
        self.datetime_timer.timeout.connect(self.update_datetime)
        self.datetime_timer.start(1000)

        self.current_datetime = ""

        #Focus Policy to enable key events
        self.setFocusPolicy(Qt.StrongFocus)
        self.setFocus()


    def keyPressEvent(self, event):
        if event.key() in self.key_actions:
            self.key_actions[event.key()]()

    def close_full_screen(self):
        for dialog in self.full_screen_dialogs.values():
            dialog.close()

    def go_home(self):
        # Release the camera resources
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        if self.cap_3 is not None:
            self.cap_3.release()
        if self.cap_4 is not None:
            self.cap_4.release()
        # Stop the timer
        self.timer.stop()
        # Close the window
        self.close()

    def closeEvent(self, event):
        if self.cap_1 is not None:
            self.cap_1.release()
        if self.cap_2 is not None:
            self.cap_2.release()
        if self.cap_3 is not None:
            self.cap_3.release()
        if self.cap_4 is not None:
            self.cap_4.release()
        self.timer.stop()
        event.accept()

    def show_camera_boxes(self):
        self.camera_screen = CameraScreen(self)
        self.camera_screen.show()

    def update_camera_feed(self):
        from BusinessLogic.SystemConfigBL import SystemConfigBL
        (self.count) = SystemConfigBL().get_camera_Quantity()

        print(self.count)

        self.rtsp_urls = []
        self.caps = []

        if int(self.count) >= 1:
            self.rtsp_urls.append(SystemConfig.on_loading_URL1(self))
        if int(self.count) >= 2:
            self.rtsp_urls.append(SystemConfig.on_loading_URL2(self))
        if int(self.count) >= 3:
            self.rtsp_urls.append(SystemConfig.on_loading_URL3(self))
        if int(self.count) >= 4:
            self.rtsp_urls.append(SystemConfig.on_loading_URL4(self))

        for url in self.rtsp_urls:
            self.caps.append(cv2.VideoCapture(url))

        camera_caps = [self.cap_1, self.cap_2, self.cap_3, self.cap_4] = self.caps + [None] * (4 - len(self.caps))

        for idx, (camera_name, camera_label) in enumerate(self.camera_labels.items()):
            cap = camera_caps[idx]
            if cap is not None:
                ret, frame = cap.read()
                if ret:
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    height, width, channel = frame.shape
                    bytesPerLine = 3 * width
                    qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

                    painter = QPainter(qImg)
                    painter.setPen(QColor(Qt.white))
                    painter.setFont(QFont("Arial", 12))
                    painter.drawText(10, 20, self.current_datetime)
                    painter.end()

                    pixmap = QPixmap.fromImage(qImg)
                    camera_label.setPixmap(pixmap)
                else:
                    self.show_no_camera_feed(camera_label)
            else:
                self.show_no_camera_feed(camera_label)

    def show_no_camera_feed(self, camera_label):
        camera_label.setText("No Camera Feed")
        camera_label.setAlignment(Qt.AlignCenter)
        camera_label.setStyleSheet("color: white; background-color: black;")

    def update_datetime(self):
        self.current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")

    def display_full_screen(self, label):
        if isinstance(label, QLabel) and label.pixmap():
            camera_name = next(key for key, value in self.camera_labels.items() if value is label)
            cap = getattr(self, f"cap_{camera_name[-1]}")
            if camera_name not in self.full_screen_dialogs:
                self.full_screen_dialogs[camera_name] = FullScreenDialog(cap, camera_name, self)
            self.full_screen_dialogs[camera_name].showFullScreen()
class FullScreenDialog(QWidget):
    def __init__(self, cap, camera_name, parent=None):
        super(FullScreenDialog, self).__init__(parent)
        self.setWindowModality(Qt.ApplicationModal)
        self.cap = cap
        self.camera_name = camera_name

        self.setGeometry(-15, -85, 1000, 700)  # Adjust the geometry as needed

        self.layout = QVBoxLayout(self)

        self.close_button = QPushButton("back", self)
        self.close_button.setFixedSize(840, 10)
        font = QFont()
        font.setPointSize(24)  # Set font size
        self.close_button.setFont(font)
        self.close_button.clicked.connect(self.close)
        self.layout.addWidget(self.close_button)

        self.camera_label = QLabel(self)
        self.layout.addWidget(self.camera_label)

        self.setLayout(self.layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_camera_feed)
        self.timer.start(1000 // 30)

        self.captured_images = []

    def keyPressEvent(self, event):
        self.close()

    def update_camera_feed(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)

            painter = QPainter(qImg)
            painter.setPen(QColor(Qt.white))
            painter.setFont(QFont("Arial", 12))
            current_datetime = QDateTime.currentDateTime().toString("HH:mm:ss dd-MM-yyyy")
            painter.drawText(10, 20, current_datetime)
            painter.end()

            qImg_scaled = qImg.scaled(self.camera_label.size(), Qt.KeepAspectRatio)
            pixmap = QPixmap.fromImage(qImg_scaled)
            self.camera_label.setPixmap(pixmap)

    def mousePressEvent(self, event):
        self.close()


class MainScreen(QMainWindow):
    def __init__(self, parent=None):
        super(MainScreen, self).__init__(parent)
        self.setWindowTitle("Main Screen")
        self.setGeometry(100, 100, 800, 600)

        self.btn_camera = QPushButton("Open Camera", self)
        self.btn_camera.clicked.connect(self.show_camera_boxes)

        self.voice_button = self.findChild(QPushButton, 'voice_button')
        self.voice_button.clicked.connect(self.activate_voice_command)

        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.btn_camera)
        self.layout.addWidget(self.voice_button)

        central_widget = QWidget()
        central_widget.setLayout(self.layout)
        self.setCentralWidget(central_widget)

        self.cap = None  # Placeholder for camera capture object

    def show_camera_boxes(self):
        camera_screen = CameraScreen(self, self.cap)
        camera_screen.show()

    def activate_voice_command(self):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            QMessageBox.information(self, "Voice Command", "Speak now...")
            audio = recognizer.listen(source)

        try:
            command = recognizer.recognize_google(audio)
            if "open camera" in command.lower():
                self.show_camera_boxes()
            else:
                QMessageBox.warning(self, "Voice Command", f"Command '{command}' not recognized.")
        except sr.UnknownValueError:
            QMessageBox.warning(self, "Voice Command", "Sorry, I didn't catch that.")
        except sr.RequestError:
            QMessageBox.warning(self, "Voice Command", "Speech recognition service is unavailable.")

# Create an instance of the MainScreen class and run the application
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainScreen()
    window.show()
    sys.exit(app.exec_())
