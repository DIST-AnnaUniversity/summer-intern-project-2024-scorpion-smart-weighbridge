from PyQt5.QtGui import QPixmap

from Presentation.Bundles.UiConfiguration import ROOT_PATH


class MessagePopup:
    def setting_msg_popup(self, pixmap_type, txt_msg):
        self.pnl_message_popup.setVisible(True)
        self.pnl_message_popup.raise_()
        if pixmap_type == "error":
            self.lbl_popup_color.setPixmap(QPixmap("" + ROOT_PATH + "Images/SettingScreenImages/RedMessage.png"))
        elif pixmap_type == "correct":
            self.lbl_popup_color.setPixmap(QPixmap("" + ROOT_PATH + "Images/SettingScreenImages/Message.png"))
        self.lbl_popup_text.setText(txt_msg)
        self.tmr_msg_popup.start()
        self.tmr_msg_popup.timeout.connect(self.pnl_message_popup.hide)



