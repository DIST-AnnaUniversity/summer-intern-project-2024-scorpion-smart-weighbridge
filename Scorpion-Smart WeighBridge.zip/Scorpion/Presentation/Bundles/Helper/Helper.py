import re

from PyQt5.QtGui import QTextDocument, QTextDocumentWriter
from PyQt5.QtPrintSupport import QPrinter
from PyQt5.QtWidgets import QFileDialog

from BusinessLogic.CloudStorageBL import CloudStorageBL
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities


def fetch_device_details(self):
    try:
        self.cloud_details = CloudStorageBL().get_cloud_storage_bl()
        if self.cloud_details is not None and len(self.cloud_details) > 0:
            GlobalEntities.cust_code = self.cloud_details[2]
            GlobalEntities.device_id = self.cloud_details[3]
        pass
    except Exception as e:
        print(e)


def get_cloud_storage_status(self):
    try:
        GlobalEntities.cloud_storage_status = CloudStorageBL().get_app_features_status("CloudStorage")
        pass
    except Exception as e:
        print(e)

def get_remote_config_status(self):
    try:
        GlobalEntities.remote_config_status = CloudStorageBL().get_app_features_status("RemoteConfig")
        pass
    except Exception as e:
        print(e)


def get_table_data_as_string_old(table_widget):
    try:
        entry_data = ""
        # Iterate over rows
        for i in range(table_widget.rowCount()):
            # Iterate over columns
            for j in range(table_widget.columnCount()):
                item = table_widget.item(i, j)
                if item is not None:
                    entry_data += item.text() + ""  # Tab-separated format
                else:
                    entry_data += ""  # If item is None, append empty cell
            entry_data += "\n"  # Move to the next row
        return entry_data.center(100)
    except Exception as e:
        print(e)


def get_table_data_as_string(self, table_widget):
    data = "<div style='text-align: center;'><table>"
    empty_space = "&nbsp;" * 20  # Create 20 non-breaking spaces
    extra_data = "<tr><td>{}</td>".format(empty_space)
    extra_data += "<td>{}</td></tr>".format(empty_space)
    # Iterate over rows
    for i in range(table_widget.rowCount()):
        data += "<tr>"
        # Iterate over columns
        for j in range(table_widget.columnCount()):
            item = table_widget.item(i, j)
            if item is not None:
                cell_data = "<td>" + item.text() + "</td>"
            else:
                # If item is None, use empty cell with width of at least 30 pixels
                if j == 3 or j == 4:
                    cell_data = "<td>{}</td>".format(empty_space)
                else:
                    cell_data = ""
            data += cell_data
        data += "</tr>"  # Close row
    data += "</table>"  # Close table
    data = data.replace(extra_data, "")
    return data + "</div>"


def remove_html_tags(html):
    # Remove HTML tags using regular expressions
    clean_text = re.sub(r'<[^>]*>', '', html)
    clean_text = re.sub(r'&nbsp;', '', clean_text)
    return clean_text


def write_to_serial_with_styles(html_string):
    # Create a QTextDocument to parse the HTML string
    doc = QTextDocument()
    doc.setHtml(html_string)

    # Get the plain text representation of the document with formatting
    plain_text_with_styles = doc.toPlainText()
    return plain_text_with_styles


def string_to_pdf(text, filename):
    try:
        # Create a QTextDocument
        document = QTextDocument()
        document.setHtml(text)

        # Create a QPrinter
        printer = QPrinter()
        printer.setOutputFormat(QPrinter.PdfFormat)
        output_filename = ROOT_PATH + filename
        printer.setOutputFileName(output_filename)

        # Print the document to the printer
        document.print_(printer)
        return document
    except Exception as e:
        print(e)


def html_to_string(html, document):
    # Convert QTextDocument's HTML content to string
    cursor = document(html).find("body")
    if cursor.isNull():
        return ""
    cursor.beginEditBlock()
    text = cursor.selection().toHtml()
    cursor.endEditBlock()
    return text
