from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPixmap, QIcon

from Presentation.Bundles.UiConfiguration import ROOT_PATH


class UiComponents:

    def __init__(self):
        super().__init__()
        self.pbLoading = None

    def ComboBox_Style(self, controlname):
        controlname.setStyleSheet("QComboBox"
                                  "{"
                                  "border: 0px;"
                                  "border-bottom:1px solid black;"
                                  "font: 24px Regular Inter;"
                                  "color:black;"
                                  "}"
                                  "QComboBox:focus"
                                  "{"
                                  "border-bottom:1px solid #17a2b8;"
                                  "font: 18px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::drop-down"
                                  "{"
                                  "width: 10px;"
                                  "background-color:white;"
                                  "border-left-width: 0px;"
                                  "border-left-color: lightgrey;"
                                  "border-left-style: solid;"
                                  "padding-right: 8px;"
                                  "font: 24px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::disabled"
                                  "{"
                                  "color:black;"
                                  "}"
                                  "QComboBox::down-arrow"
                                  "{"
                                  "width: 20px;"
                                  "height:20px;"
                                  "font: 24px Regular Inter;"
                                  "font-weight:bold;"
                                  "background-repeat: no-repeat;"
                                  "background-position: center center;"
                                  "background-color:white;"
                                  "background-image-width: 50px;"
                                  "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                     "border: 0px;"
                                                                     "}"
                                  )

    def set_bordered_combo_box(self, controlname):
        controlname.setStyleSheet("QComboBox"
                                  "{"
                                  "border: 0px;"
                                  "border:1px solid lightgrey;"
                                  "font: 24px Regular Inter;"
                                  "color:black;"
                                  "}"
                                  "QComboBox:focus"
                                  "{"
                                  "border-bottom:1px solid #17a2b8;"
                                  "font: 18px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::drop-down"
                                  "{"
                                  "width: 10px;"
                                  "background-color:white;"
                                  "border-left-width: 0px;"
                                  "border-left-color: lightgrey;"
                                  "border-left-style: solid;"
                                  "padding-right: 8px;"
                                  "font: 24px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::disabled"
                                  "{"
                                  "color:black;"
                                  "}"
                                  "QComboBox::down-arrow"
                                  "{"
                                  "width: 20px;"
                                  "height:20px;"
                                  "font: 24px Regular Inter;"
                                  "font-weight:bold;"
                                  "background-repeat: no-repeat;"
                                  "background-position: center center;"
                                  "background-color:white;"
                                  "background-image-width: 50px;"
                                  "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                     "border: 0px;"
                                                                     "}"
                                  )

    def set_report_bordered_combo_box(self, controlname):
        controlname.setStyleSheet("QComboBox"
                                  "{"
                                  "border: 0px;"
                                  "border:1px solid lightgrey;"
                                  "font: 15px Regular Inter;"
                                  "color:black;"
                                  "}"
                                  "QComboBox:focus"
                                  "{"
                                  "border-bottom:1px solid #17a2b8;"
                                  "font: 15px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::drop-down"
                                  "{"
                                  "width: 10px;"
                                  "background-color:white;"
                                  "border-left-width: 0px;"
                                  "border-left-color: lightgrey;"
                                  "border-left-style: solid;"
                                  "padding-right: 8px;"
                                  "font: 15px Regular Inter;"
                                  "font-weight:bold;"
                                  "}"
                                  "QComboBox::disabled"
                                  "{"
                                  "color:black;"
                                  "}"
                                  "QComboBox::down-arrow"
                                  "{"
                                  "width: 20px;"
                                  "height:20px;"
                                  "font: 15px Regular Inter;"
                                  "font-weight:bold;"
                                  "background-repeat: no-repeat;"
                                  "background-position: center center;"
                                  "background-color:white;"
                                  "background-image-width: 50px;"
                                  "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                     "border: 0px;"
                                                                     "}"
                                  )


    def set_combo_box(self, controlname):
        for i in range(len(controlname)):
            controlname[i].setStyleSheet("QComboBox"
                                         "{"
                                         "border: 0px;"
                                         "border:1px solid lightgrey;"
                                         "font: 24px Regular Inter;"
                                         "color:black;"
                                         "}"
                                         "QComboBox:focus"
                                         "{"
                                         "border-bottom:1px solid #17a2b8;"
                                         "font: 18px Regular Inter;"
                                         "font-weight:bold;"
                                         "}"
                                         "QComboBox::drop-down"
                                         "{"
                                         "width: 10px;"
                                         "background-color:white;"
                                         "border-left-width: 0px;"
                                         "border-left-color: lightgrey;"
                                         "border-left-style: solid;"
                                         "padding-right: 8px;"
                                         "font: 24px Regular Inter;"
                                         "font-weight:bold;"
                                         "}"
                                         "QComboBox::disabled"
                                         "{"
                                         "color:black;"
                                         "}"
                                         "QComboBox::down-arrow"
                                         "{"
                                         "width: 20px;"
                                         "height:20px;"
                                         "font: 24px Regular Inter;"
                                         "font-weight:bold;"
                                         "background-repeat: no-repeat;"
                                         "background-position: center center;"
                                         "background-color:white;"
                                         "background-image-width: 50px;"
                                         "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                            "border: 0px;"
                                                                            "}"
                                         )

    def update_header_logo(self, lblImage, ImageName, image_width, image_height):
        if not ImageName == "" and ImageName is not None:
            pixmap = QPixmap(ROOT_PATH + "Images/Logo/" + ImageName)
            lblImage.setPixmap(pixmap.scaled(image_width, image_height))
        else:
            pixmap = QPixmap(ROOT_PATH + "Images/Logo/Default.png")
            lblImage.setPixmap(pixmap.scaled(image_width, image_height))

    def update_stamping_image(self, lblImage, ImageName, image_width, image_height):
        if not ImageName == "" and ImageName is not None:
            pixmap = QPixmap(ROOT_PATH + "Images/StampingImage/" + ImageName)
            lblImage.setPixmap(pixmap.scaled(image_width, image_height))

    def SplashUiComponents(self):
        self.pbLoading.setStyleSheet("QProgressBar"
                                     "{"
                                     "border: solid grey;"
                                     "border-radius: 5px;"
                                     "color: black; "
                                     "}"
                                     "QProgressBar::chunk "
                                     "{background-color: green;"
                                     "border-radius :5px;"
                                     "}")
        self.pbLoading.setAlignment(Qt.AlignCenter)
        self.pbLoading.setFont(QFont('MS Shell Dlg 2', 12))

    def MainScreenUiComponents(self):
        try:
            self.btn_settings.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Settings.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/SettingsHover.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/SettingsDisabled.png); "
                                                                                                                                                                 "}"

                                            )

            self.btn_report.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Report.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/ReportHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/ReportDisabled.png); "
                                                                                                                                                               "}"

                                          )
            self.btn_help.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/help.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/helphover.png); "
                                                                                                                      "}"

                                        )

            # self.btn_login.setStyleSheet("QPushButton"
            #                              "{"
            #                              "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Login.png); "
            #                                                                     "border : none "
            #                                                                     "}"
            #                                                                     "QPushButton::hover"
            #                                                                     "{"
            #                                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/LoginHover.png); "
            #                                                                                                            "}"
            #                                                                                                            "QPushButton::disabled"
            #                                                                                                            "{"
            #                                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/LoginDisabled.png); "
            #                                                                                                                                                   "}"
            #
            #                              )

            self.btn_tare.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Tare.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/TareHover.png); "
                                                                                                                      "}"
                                                                                                                      "QPushButton::disabled"
                                                                                                                      "{"
                                                                                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/TareDisabled.png); "
                                                                                                                                                             "}"

                                        )

            self.btn_entry.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Entry.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EntryHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EntryDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_re_entry.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/ReEntry.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/ReEntryHover.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EntryDisabled.png); "
                                                                                                                                                                 "}"

                                            )
            self.btn_recall.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Recall.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/RecallHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/RecallDisabled.png); "
                                                                                                                                                               "}"

                                          )

            self.btn_login_close.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/btn_close.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/btn_close.png); "
                                                                                                                             "}"
                                               )

            self.btn_forgot_pwd_close.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                           "/btn_close.png);"
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/btn_close.png); "
                                                                                                                                  "}"
                                                    )
            self.btn_show_password.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                                                               "}"
                                                 )
            self.btn_show_new_password.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                                                                   "}"
                                                     )
            self.btn_show_confirm_new_password.setStyleSheet("QPushButton"
                                                             "{"
                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                                    "border : none "
                                                                                                    "}"
                                                                                                    "QPushButton::hover"
                                                                                                    "{"
                                                                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/visible.png); "
                                                                                                                                           "}"
                                                             )
            self.btn_hide_password.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                                                               "}"
                                                 )

            self.btn_hide_new_password.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                                                                   "}"
                                                     )

            self.btn_hide_confirm_new_password.setStyleSheet("QPushButton"
                                                             "{"
                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                                    "border : none "
                                                                                                    "}"
                                                                                                    "QPushButton::hover"
                                                                                                    "{"
                                                                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/unvisible.png); "
                                                                                                                                           "}"
                                                             )
        except Exception as e:
            print(e)

    def VehicleEntryUiComponents(self):
        try:
            self.btn_print_preview.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreview.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewHover.png); "
                                                                                                                               "}"
                                                                                                                               "QPushButton::disabled"
                                                                                                                               "{"
                                                                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewDisable.png); "
                                                                                                                                                                      "}"
                                                 )
            self.btn_close_preview.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Close.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                 )
            self.lbl_manual_bg.setStyleSheet("QLabel"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/pnl_manual.png); "
                                                                                    "border : none "
                                                                                    "}"
                                             )

            self.lbl_save_confirm_bg.setStyleSheet("QLabel"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/save_panel.png); "
                                                                                          "}"
                                                   )

            self.lbl_manual_entry_bg.setStyleSheet("QLabel"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/pnl_manual_bg.png); "
                                                                                          "}"
                                                   )

            self.lbl_discard_changes_bg.setStyleSheet("QLabel"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/discard_panel.png); "

                                                                                             "border : none "
                                                                                             "}"

                                                      )

            self.lbl_gunny_bag_bg.setStyleSheet("QLabel"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/pnl_gunny_bag.png); "
                                                                                       "border : none "
                                                                                       "}"

                                                )
            self.btn_entry.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Entry.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/EntryHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/EntryDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_cancel.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelDisabled.png); "
                                                                                                                                                               "}"
                                          )

            self.btn_preview.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Preview.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PreviewHover.png); "
                                                                                                                         "}"
                                                                                                                         "QPushButton::disabled"
                                                                                                                         "{"
                                                                                                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PreviewDisabled.png); "
                                                                                                                                                                "}"
                                           )

            self.btn_gunny_bag_ok.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgok.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgokhover.png); "
                                                                                                                              "}"
                                                )
            self.btn_gunny_bag_cancel.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                  "}"
                                                    )

            self.btn_discard_changes_ok.setStyleSheet("QPushButton"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgok.png); "
                                                                                             "border : none "
                                                                                             "}"
                                                                                             "QPushButton::hover"
                                                                                             "{"
                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgokhover.png); "
                                                                                                                                    "}"
                                                      )
            self.btn_discard_changes_cancel.setStyleSheet("QPushButton"
                                                          "{"
                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                                 "border : none "
                                                                                                 "}"
                                                                                                 "QPushButton::hover"
                                                                                                 "{"
                                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                        "}"
                                                          )
            self.btn_save_confirm_ok.setStyleSheet("QPushButton"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Yes.png); "
                                                                                          "border : none "
                                                                                          "}"
                                                                                          "QPushButton::hover"
                                                                                          "{"
                                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/YesHover.png); "
                                                                                                                                 "}"
                                                   )
            self.btn_save_confirm_cancel.setStyleSheet("QPushButton"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/No.png); "
                                                                                              "border : none "
                                                                                              "}"
                                                                                              "QPushButton::hover"
                                                                                              "{"
                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/NoHover.png); "
                                                                                                                                     "}"
                                                       )

            self.btn_manual_entry_ok.setStyleSheet("QPushButton"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Yes.png); "
                                                                                          "border : none "
                                                                                          "}"
                                                                                          "QPushButton::hover"
                                                                                          "{"
                                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/YesHover.png); "
                                                                                                                                 "}"
                                                   )
            self.btn_manual_entry_cancel.setStyleSheet("QPushButton"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/No.png); "
                                                                                              "border : none "
                                                                                              "}"
                                                                                              "QPushButton::hover"
                                                                                              "{"
                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/NoHover.png); "
                                                                                                                                     "}"
                                                       )

            self.btn_gunny_bag_ok.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgok.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgokhover.png); "
                                                                                                                              "}"
                                                )
            self.btn_gunny_bag_cancel.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                  "}"
                                                    )

            self.btn_discard_changes_ok.setStyleSheet("QPushButton"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgok.png); "
                                                                                             "border : none "
                                                                                             "}"
                                                                                             "QPushButton::hover"
                                                                                             "{"
                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgokhover.png); "
                                                                                                                                    "}"
                                                      )
            self.btn_discard_changes_cancel.setStyleSheet("QPushButton"
                                                          "{"
                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                                 "border : none "
                                                                                                 "}"
                                                                                                 "QPushButton::hover"
                                                                                                 "{"
                                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                        "}"
                                                          )

            self.btn_manual.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Manual.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ManualHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ManualDisabled.png); "
                                                                                                                                                               "}"
                                          )

            self.btn_gunny_bag.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBag.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBagHover.png); "
                                                                                                                           "}"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBagDisabled.png); "
                                                                                                                                                                  "}"
                                             )

            self.btn_manual_close.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/close.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                )

            self.btn_recall.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Recall.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/RecallHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/RecallDisabled.png); "
                                                                                                                                                               "}"

                                          )

            self.btn_tare_weight_delete.setStyleSheet("QPushButton"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                             "border : none "
                                                                                             "}"
                                                                                             "QPushButton::hover"
                                                                                             "{"
                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/DeleteHover.png); "
                                                                                                                                    "}"
                                                                                                                                    "QPushButton::disabled"
                                                                                                                                    "{"
                                                                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/DeleteDisabled.png); "
                                                                                                                                                                           "}"

                                                      )
            self.btn_tare_weight.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                                                                    "}"

                                               )
            self.btn_gross_weight_delete.setStyleSheet("QPushButton"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                              "border : none "
                                                                                              "}"
                                                                                              "QPushButton::hover"
                                                                                              "{"
                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/DeleteHover.png); "
                                                                                                                                     "}"
                                                                                                                                     "QPushButton::disabled"
                                                                                                                                     "{"
                                                                                                                                     "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/DeleteDisabled.png); "
                                                                                                                                                                            "}"

                                                       )
            self.btn_gross_weight.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                              "}"
                                                                                                                              "QPushButton::disabled"
                                                                                                                              "{"
                                                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                                                                     "}"

                                                )

            self.btn_save.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Save.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SaveHover.png); "
                                                                                                                      "}"
                                                                                                                      "QPushButton::disabled"
                                                                                                                      "{"
                                                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SaveDisabled.png); "
                                                                                                                                                             "}"

                                        )

            self.btn_print.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Print.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_home.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Home.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HomeHover.png); "
                                                                                                                      "}"

                                        )
        except Exception as e:
            print(e)

    def calibration_completed_status(self, btn_name):
        try:
            btn_name.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/completed.png); "
                                                                          "border : none "
                                                                          "}"
                                                                          "QPushButton::hover"
                                                                          "{"
                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/completed.png); "
                                                                                                                 "}"
                                   )

        except Exception as e:
            print(e)

    def shortcuts(self):
        try:
            self.btn_header_back.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HeaderBack.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HeaderBackHover.png); "
                                                                                                                             "}"
                                               )
            self.btn_code_back.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CodeBack.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CodeBackHover.png); "
                                                                                                                           "}"
                                             )
            self.btn_code_next.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CodeNext.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CodeNextHover.png); "
                                                                                                                           "}"
                                             )

            self.btn_header_next.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HeaderNext.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HeaderNextHover.png); "
                                                                                                                             "}"
                                               )
        except Exception as e:
            print(e)

    def header_next(self):
        try:
            self.btn_header_next.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/next.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/nexthover.png); "
                                                                                                                             "}"
                                               )
        except Exception as e:
            print(e)

    def code_next(self):
        try:
            self.btn_code_next.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/next.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/nexthover.png); "
                                                                                                                           "}"
                                             )
        except Exception as e:
            print(e)

    def VehicleReEntryUiComponents(self):
        try:
            self.lbl_save_confirm_bg.setStyleSheet("QLabel"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/save_panel.png); "
                                                                                          "border : none "
                                                                                          "}"

                                                   )
            self.btn_print_preview.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreview.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewHover.png); "
                                                                                                                               "}"
                                                                                                                               "QPushButton::disabled"
                                                                                                                               "{"
                                                                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewDisable.png); "
                                                                                                                                                                      "}"
                                                 )
            self.btn_save_confirm_ok.setStyleSheet("QPushButton"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Yes.png); "
                                                                                          "border : none "
                                                                                          "}"
                                                                                          "QPushButton::hover"
                                                                                          "{"
                                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/YesHover.png); "
                                                                                                                                 "}"
                                                   )

            self.btn_gunny_bag_ok.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgok.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/msgokhover.png); "
                                                                                                                              "}"
                                                )
            self.btn_gunny_bag_cancel.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                  "}"
                                                    )
            self.btn_close_preview.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Close.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                 )
            self.btn_save_confirm_cancel.setStyleSheet("QPushButton"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/No.png); "
                                                                                              "border : none "
                                                                                              "}"
                                                                                              "QPushButton::hover"
                                                                                              "{"
                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/NoHover.png); "
                                                                                                                                     "}"
                                                       )

            self.btn_gunny_bag.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBag.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBagHover.png); "
                                                                                                                           "}"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/GunnyBagDisabled.png); "
                                                                                                                                                                  "}"
                                             )

            self.btn_preview.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Preview.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PreviewHover.png); "
                                                                                                                         "}"
                                                                                                                         "QPushButton::disabled"
                                                                                                                         "{"
                                                                                                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PreviewDisabled.png); "
                                                                                                                                                                "}"
                                           )

            self.btn_code_next.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/next.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/nexthover.png); "
                                                                                                                           "}"
                                             )
            self.btn_header_next.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/next.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/nexthover.png); "
                                                                                                                             "}"
                                               )
            self.btn_header_back.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/back.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/backhover.png); "
                                                                                                                             "}"
                                               )
            self.btn_code_back.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/back.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/backhover.png); "
                                                                                                                           "}"
                                             )
            self.btn_entry.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ReEntry.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ReEntryHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ReEntryDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_cancel.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelDisabled.png); "
                                                                                                                                                               "}"
                                          )

            self.btn_recall.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Recall.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/RecallHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/RecallDisabled.png); "
                                                                                                                                                               "}"

                                          )

            self.btn_tare_weight_delete.setStyleSheet("QPushButton"
                                                      "{"
                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                             "border : none "
                                                                                             "}"
                                                                                             "QPushButton::hover"
                                                                                             "{"
                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                                                                    "}"
                                                                                                                                    "QPushButton::disabled"
                                                                                                                                    "{"
                                                                                                                                    "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                                                                                                           "}"

                                                      )
            self.btn_tare_weight.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                                                                    "}"

                                               )
            self.btn_gross_weight_delete.setStyleSheet("QPushButton"
                                                       "{"
                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                              "border : none "
                                                                                              "}"
                                                                                              "QPushButton::hover"
                                                                                              "{"
                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                                                                     "}"
                                                                                                                                     "QPushButton::disabled"
                                                                                                                                     "{"
                                                                                                                                     "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Delete.png); "
                                                                                                                                                                            "}"

                                                       )
            self.btn_gross_weight.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                              "}"
                                                                                                                              "QPushButton::disabled"
                                                                                                                              "{"
                                                                                                                              "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                                                                     "}"

                                                )

            self.btn_save.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Save.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SaveHover.png); "
                                                                                                                      "}"
                                                                                                                      "QPushButton::disabled"
                                                                                                                      "{"
                                                                                                                      "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SaveDisabled.png); "
                                                                                                                                                             "}"

                                        )

            self.btn_print.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Print.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_home.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Home.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HomeHover.png); "
                                                                                                                      "}"

                                        )
        except Exception as e:
            print(e)

    def SystemConfigButton(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.SystemConfig.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:11px;border-radius:3px; }")

        self.RS232.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfigWhite.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
      #  self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon.png"))

    def ParametersButton(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Parameters.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")

        self.HeaderSettings.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:11px; }")
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIconWhite.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
       # self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def General(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.General.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")

        self.DateTime.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralWhite.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
     #   self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def wifi_status_on(self):
        self.lbl_wifi_status.setStyleSheet("QLabel"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/wifi_on.png); "
                                                                                  "border : none "
                                                                                  "}"
                                           )

    def pnl_turn_ON_wifi(self):
        self.lblMsgPanel.setStyleSheet("QLabel"
                                       "{"
                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/TurnONWifi.png); "
                                                                              "border : none "
                                                                              "}"
                                       )

    def wifi_status_off(self):
        self.lbl_wifi_status.setStyleSheet("QLabel"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/wifi_off.png); "
                                                                                  "border : none "
                                                                                  "}"
                                           )

    def AppConfigButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.AppConfig.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/WebhooksWhite.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
      #  self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def Webhooks(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Webhooks.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")

        self.Cloud.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/WebhooksWhite.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
      #  self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def StampingDue(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
     #   self.stamping_due.setStyleSheet(
          #  "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
          #  "lightgrey;padding-left:10px;border-radius:3px; }")
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))

    def NotificationButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Notification.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Email.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
      #  self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def UserInfoButtons(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.UserInformation.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid lightgrey;color:#4d4d4d;padding-left:11px;border-radius:3px; }")

        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
       # self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def ProfileButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.UserProfile.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.Profile.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
      #  self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon"))

    def PreferencesButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Language.setStyleSheet(
            "QPushButton { text-align:left;border:0px solid "
            "lightgrey;background-color:black;color:white;border-radius:3px;padding-left:10px; }")
        self.Preferences.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))

    def WifiSettingsUiComponents(self):
        self.btnWifiON.setStyleSheet("QPushButton"
                                     "{"
                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                            "border : none "
                                                                            "}"
                                     )
        self.btnWifiOFF.setStyleSheet("QPushButton"
                                      "{"
                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                             "border : none "
                                                                             "}"
                                      )

    def CreateUserButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.CreateNewUser.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))

    def AdvantagesButtonStyles(self):
        for item_count, labels in enumerate(self.dict_main_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:#f4f6fc;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        for item_count, labels in enumerate(self.dict_sub_menu.items()):
            labels[1].setStyleSheet(
                "QPushButton { text-align: left;background-color:white;border :0px solid "
                "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
        self.Advantages.setStyleSheet(
            "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
            "lightgrey;padding-left:10px;border-radius:3px; }")
        self.General.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/GeneralIcon.png"))
        self.Parameters.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/ProductIcon.png"))
        self.AppConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.Webhooks.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/Webhooks.png"))
        self.SystemConfig.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/SystemConfig.png"))
       # self.stamping_due.setIcon(QIcon("" + ROOT_PATH + "/Images/MainScreenImages/AccountIcon.png"))

    def update_sub_menu_components(self, selected_menu):
        try:
            for item_count, labels in enumerate(self.dict_sub_menu.items()):
                labels[1].setStyleSheet(
                    "QPushButton { text-align: left;background-color:white;border :0px solid "
                    "lightgrey;color:#4d4d4d;padding-left:10px;border-radius:3px; }")
            selected_menu.setStyleSheet(
                "QPushButton { text-align: left;background-color:black;color:white;border :0px solid "
                "lightgrey;padding-left:10px;border-radius:3px; }")
            pass
        except Exception as e:
            print(e)

    def ReportScreenUiComponents(self):
        try:
            self.btn_apply.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Apply.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/ApplyHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/ApplyDisabled.png); "
                                                                                                                                                              "}"
                                         )

            self.btn_download.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Download.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/DownloadHover.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/DownloadDisabled.png); "
                                                                                                                                                                 "}"

                                            )

            self.btn_close.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Close.png); "
                                                                                "border : none "
                                                                                "}"

                                         )

            self.lblMsgbg.setStyleSheet("QLabel"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/msg.png); "
                                                                               "border : none "
                                                                               "}"

                                        )
            self.btn_ok.setStyleSheet("QPushButton"
                                      "{"
                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Ok.png); "
                                                                             "border : none "
                                                                             "}"
                                                                             "QPushButton::hover"
                                                                             "{"
                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OkHover.png);"
                                                                                                                    "}"

                                      )

        except Exception as e:
            print(e)

    def help_screen(self):
        try:
            self.btn_next.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/next.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/nexthover.png); "
                                                                                                                      "}"
                                        )
            self.btn_home.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Home.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HomeHover.png); "
                                                                                                                      "}"

                                        )
        except Exception as e:
            print(e)

    def daily_toggle(self):
        try:
            self.btn_daily.setStyleSheet("QPushButton"
                                         "{"
                                         "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                         "}"
                                         )
            self.btn_monthly.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                           "}"
                                           )
            self.btn_daily.raise_()

        except Exception as e:
            print(e)

    def monthly_toggle(self):
        try:
            self.btn_monthly.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                           "}"
                                           )
            self.btn_daily.setStyleSheet("QPushButton"
                                         "{"
                                         "background-color:#ededed; color:black;border: 0px solid grey;border-radius : 20px;"
                                         "}"
                                         )
            self.btn_monthly.raise_()

        except Exception as e:
            print(e)

    def cal_toggle(self):
        try:
            self.btn_cal_log.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:black; color:white;border-radius : 15px;border: 0px solid grey;"
                                           "}"
                                           )
            self.btn_tare_log.setStyleSheet("QPushButton"
                                            "{"
                                            "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 15px;"
                                            "}"
                                            )
            self.btn_cal_log.raise_()

        except Exception as e:
            print(e)

    def tare_toggle(self):
        try:
            self.btn_tare_log.setStyleSheet("QPushButton"
                                            "{"
                                            "background-color:black; color:white;border-radius : 15px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_cal_log.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:#ededed; color:black;border: 0px solid grey;border-radius : 15px;"
                                           "}"
                                           )
            self.btn_tare_log.raise_()

        except Exception as e:
            print(e)

    def default_style_for_cal_tare(self):
        try:
            self.btn_tare_log.setStyleSheet("QPushButton"
                                            "{"
                                            "background-color:#ededed; color:black;border: 0px solid grey;border-radius : 15px;"
                                            "}"
                                            )
            self.btn_cal_log.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:#ededed; color:black;border: 0px solid grey;border-radius : 15px;"
                                           "}"
                                           )
            self.btn_cal_log.raise_()

        except Exception as e:
            print(e)

    def header_toggle(self):
        try:
            self.btn_header.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                          "}"
                                          )
            self.btn_code.setStyleSheet("QPushButton"
                                        "{"
                                        "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                        "}"
                                        )
            self.btn_header.raise_()
        except Exception as e:
            print(e)

    def code_toggle(self):
        try:
            self.btn_code.setStyleSheet("QPushButton"
                                        "{"
                                        "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                        "}"
                                        )
            self.btn_header.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                          "}"
                                          )
            self.btn_code.raise_()
        except Exception as e:
            print(e)

    def ComboBoxDefault_Style(self, controlname):
        controlname.setStyleSheet("QComboBox"
                                  "{"
                                  "border:1px solid lightgrey;"
                                  "border-radius:3px;"
                                  "font: 24px Inter;"
                                  "}"
                                  "QComboBox::drop-down"
                                  "{"
                                  "font: 24px Inter;"
                                  "width: 10px;"
                                  "background-color:white;"
                                  "border-left-width: 0px;"
                                  "border-left-color: lightgrey;"
                                  "border-left-style: solid;"
                                  "padding-right: 8px;"
                                  "}"
                                  "QComboBox::disabled"
                                  "{"
                                  "color:black;"
                                  "}"
                                  "QComboBox::down-arrow"
                                  "{"
                                  "font: 24px Inter;"
                                  "width: 20px;"
                                  "height:20px;"
                                  "background-repeat: no-repeat;"
                                  "background-position: center center;"
                                  "background-color:white;"
                                  "background-image-width: 50px;"
                                  "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                     "border: 0px;"
                                                                     "}"
                                  )

    def textbox_default_stylesheet(controlnames):
        controlnames.setStyleSheet("QLineEdit"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   "QLineEdit:focus"
                                   "{"
                                   "border-bottom:1px solid #17a2b8;"
                                   "}"
                                   "QLineEdit::disabled"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )

    def set_text_box_active_style(self, txt_name):
        try:
            txt_name.setStyleSheet("QLineEdit"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   "QLineEdit:focus"
                                   "{"
                                   "background-color: yellow;"

                                   "border-bottom:1px solid #17a2b8;"
                                   "}"
                                   "QLineEdit::disabled"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )
        except Exception as e:
            print(e)

    def set_text_box_focus_style(self, txt_name):
        try:
            txt_name.setStyleSheet("QLineEdit"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black;"
                                   "background-color: yellow;"
                                   "}"
                                   "QLineEdit::disabled"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )
        except Exception as e:
            print(e)

    def set_text_box_normal_style(self, txt_name):
        try:
            txt_name.setStyleSheet("QLineEdit"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black;"
                                   "}"
                                   "QLineEdit::disabled"
                                   "{"
                                   "font: 24px Inter;"
                                   "border : 1px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )
        except Exception as e:
            print(e)

    def set_combo_box_active_style(self, combo_name):
        try:
            if combo_name.hasFocus():
                combo_name.setStyleSheet(
                    "QComboBox"
                    "{"
                    "border:1px solid lightgrey;"
                    "border-radius:3px;"
                    "font: 24px Inter;"
                    "background-color:yellow;"
                    "border-bottom:1px solid #17a2b8;"
                    "}"

                    "QComboBox::drop-down"
                    "{"
                    "font: 24px Inter;"
                    "width: 10px;"
                    "background-color:yellow;"
                    "border-left-width: 0px;"
                    "border-left-color: lightgrey;"
                    "border-left-style: solid;"
                    "padding-right: 8px;"
                    "}"
                    "QComboBox::disabled"
                    "{"
                    "color:black;"
                    "}"
                    "QComboBox::down-arrow"
                    "{"
                    "font: 24px Inter;"
                    "width: 20px;"
                    "height:20px;"
                    "background-repeat: no-repeat;"
                    "background-position: center center;"
                    "background-color:yellow;"
                    "background-image-width: 50px;"
                    "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                       "border: 0px;"
                                                       "}"
                )
        except Exception as e:
            print(e)

    def textbox_parameters_stylesheet(controlnames):
        controlnames.setStyleSheet("QLineEdit"
                                   "{"
                                   "font: 15px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   "QLineEdit:focus"
                                   "{"
                                   "border-bottom:1px solid #17a2b8;"
                                   "}"
                                   "QLineEdit::disabled"
                                   "{"
                                   "font: 15px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )

    def label_default_stylesheet(controlnames):
        controlnames.setStyleSheet("QLabel"
                                   "{"
                                   "font: 12px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   "QLabel:focus"
                                   "{"
                                   "border-bottom:1px solid #17a2b8;"
                                   "}"
                                   "QLabel::disabled"
                                   "{"
                                   "font: 12px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )

    def plaintext_default_stylesheet(controlnames):
        controlnames.setStyleSheet("QPlainTextEdit"
                                   "{"
                                   "font: 18px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   "QPlainTextEdit:focus"
                                   "{"
                                   "border-bottom:1px solid #17a2b8;"
                                   "}"
                                   "QPlainTextEdit::disabled"
                                   "{"
                                   "font: 18px Inter;"
                                   "border : 0px solid lightgrey;"
                                   "border-bottom:1px solid lightgrey;"
                                   "color:black"
                                   "}"
                                   )

    def SupportUi(self):
        self.btnSubmit.setStyleSheet("QPushButton"
                                     "{"
                                     "background-color:white;"
                                     "color:black;"
                                     "border : 1px solid lightgrey;"
                                     "border-radius : 4px;"
                                     "font-weight:bold;"
                                     "}"
                                     "QPushButton::hover"
                                     "{"
                                     "background-color:black;"
                                     "color:white;"
                                     "border : 1px solid lightgrey;"
                                     "border-radius : 4px;"
                                     "font-weight:bold;"
                                     "}"
                                     "QPushButton::disabled"
                                     "{"
                                     "background-color:white;"
                                     "color:solid lightgrey;"
                                     "border : 1px solid lightgrey;"
                                     "border-radius : 4px;"
                                     "font-weight:bold;"
                                     "}"
                                     )

        self.txt_support_feedback.setStyleSheet("border: 1px solid grey;"
                                                "border-bottom:1px solid grey;"
                                                "border-right:1px solid white;"
                                                "border-left:1px solid white;"
                                                "border-top:1px solid white;")

        self.cmbSupportType.setStyleSheet("QComboBox"
                                          "{"
                                          "border: 0px;"
                                          "border-bottom:1px solid gray;"
                                          "}"
                                          "QComboBox::drop-down"
                                          "{"
                                          "width: 10px;"
                                          "background-color:white;"
                                          "border-left-width: 0px;"
                                          "border-left-color: darkgray;"
                                          "border-left-style: solid;"
                                          "padding-right: 8px;"
                                          "}"
                                          "QComboBox::down-arrow"
                                          "{"
                                          "width: 20px;"
                                          "height:20px;"
                                          "background-repeat: no-repeat;"
                                          "background-position: center center;"
                                          "background-color:white;"
                                          "background-image-width: 50px;"
                                          "border-image: url(" + ROOT_PATH + "Images/SettingScreenImages/down.png); "
                                                                             "border: 0px;"
                                                                             "}"
                                          )

        self.txt_support_receiver_email.setStyleSheet("border: 1px solid grey;"
                                                      "border-bottom:1px solid grey;"
                                                      "border-right:1px solid white;"
                                                      "border-left:1px solid white;"
                                                      "border-top:1px solid white;")

        self.txt_support_sender_name.setStyleSheet("border: 1px solid grey;"
                                                   "border-bottom:1px solid grey;"
                                                   "border-right:1px solid white;"
                                                   "border-left:1px solid white;"
                                                   "border-top:1px solid white;")
        self.txt_support_sender_name.setFont(QFont('Inter', 14))

        self.lblContact.setText("Contact Us")
        self.lblContact.setFont(QFont('MS Shell Dlg 2', 15))
        self.lblContact.setStyleSheet("text-align: left;border:0px solid grey;")

        self.lblContactMsg.setText(
            "Please use the form below if you have any questions, suggestions, or need help with \nthe products. Our team will be happy to provide all the information you need.")
        self.lblContactMsg.setFont(QFont('Inter', 10))
        self.lblContactMsg.setStyleSheet("text-align: left;border:0px solid grey;color:#1132ee;")

    def set_checkbox_style_sheet(self, checkbox):
        try:
            checkbox.setStyleSheet("QCheckBox::indicator"
                                   "{"
                                   "width:50px;"
                                   "height:50px;"
                                   "}")
            pass
        except Exception as e:
            print(e)

    def update_toggle_style_sheet(self, selected_menu, unselected_menu):
        try:
            selected_menu.setStyleSheet("QPushButton"
                                        "{"
                                        "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                        "}"
                                        )

            unselected_menu.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                          "}"
                                          )
            selected_menu.raise_()
            pass
        except Exception as e:
            print(e)

    def update_verified_status(self, label_name, status):
        try:
            label_name.setVisible(True)
            if status:
                label_name.setStyleSheet("QLabel"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Correct.png); "
                                                                                "border : none "
                                                                                "}")
            else:
                label_name.setStyleSheet("QLabel"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Error.png); "
                                                                                "border : none "
                                                                                "}")
            pass
        except Exception as e:
            print(e)

    def StyleSheet_For_EvenRowCombobox(self):
        self.combobox.setStyleSheet("QComboBox"
                                    "{"
                                    "background-color:rgb(254, 254, 254);"
                                    "color:rgb(0,0,0);"
                                    "border: 0px;"
                                    "}"
                                    "QComboBox QAbstractItemView"
                                    "{"
                                    "background-color: rgb(254, 254, 254);"
                                    "selection-background-color: rgb(170, 170, 255);"
                                    "color:rgb(0,0,0);"
                                    "}"
                                    "QComboBox::drop-down"
                                    "{"
                                    "border-left-width: 0px;"
                                    "border-left-color: darkgray;"
                                    "border-left-style: solid;"
                                    "padding-right: 8px;"
                                    "}"
                                    "QComboBox::down-arrow"
                                    "{"
                                    "width: 20px;"
                                    "height:20px;"
                                    "background-repeat: no-repeat;"
                                    "background-position: center center;"
                                    "background-color:rgb(254, 254, 254);"
                                    "background-image-width: 70px;"
                                    "border-image: url(" + ROOT_PATH + "Images/ReportScreenImages/Down.png); "
                                                                       "border: 0px;"
                                                                       "}"
                                    )

    def StyleSheet_For_OddRowCombobox(self):
        self.combobox.setStyleSheet("QComboBox"
                                    "{"
                                    "background-color:rgba(244, 246, 252, 255);"
                                    "border: 0px;"
                                    "}"
                                    "QComboBox QAbstractItemView"
                                    "{"
                                    # "background-color: rgba(244, 246, 252, 255);"
                                    "}"
                                    "QComboBox::item:selected"
                                    "{"
                                    "color: rgb(0, 0, 0);"
                                    "}"
                                    "QComboBox::drop-down"
                                    "{"
                                    "border-left-width: 0px;"
                                    "border-left-color: darkgray;"
                                    "border-left-style: solid;"
                                    "padding-right: 8px;"
                                    "}"
                                    "QComboBox::down-arrow"
                                    "{"
                                    "width: 20px;"
                                    "height:20px;"
                                    "background-repeat: no-repeat;"
                                    "background-position: center center;"
                                    "background-color:rgba(244, 246, 252, 255);"
                                    "background-image-width: 70px;"
                                    "border-image: url(" + ROOT_PATH + "Images/ReportScreenImages/Down.png); "
                                                                       "border: 0px;"
                                                                       "}"
                                    )

    def tare_correct_image(self):
        self.btn_tare_weight.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                                                         "}"
                                                                                                                         "QPushButton::disabled"
                                                                                                                         "{"
                                                                                                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                                                                                                "}"

                                           )

    def ok_default(self, control_name):
        control_name.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                          "border : none "
                                                                          "}"
                                                                          "QPushButton::hover"
                                                                          "{"
                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                 "}"
                                                                                                                 "QPushButton::disabled"
                                                                                                                 "{"
                                                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Ok.png); "
                                                                                                                                                        "}"

                                   )

    def complete_image(self, control_name):
        control_name.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/complete.png); "
                                                                          "border : none "
                                                                          "}"

                                   )

    def gross_correct_image(self):
        self.btn_gross_weight.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/ok_done.png); "
                                                                                                                                                                 "}"

                                            )

    def RecallUiComponents(self):
        try:
            self.btn_print_preview.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreview.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewHover.png); "
                                                                                                                               "}"
                                                                                                                               "QPushButton::disabled"
                                                                                                                               "{"
                                                                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintPreviewDisable.png); "
                                                                                                                                                                      "}"
                                                 )
            self.btn_maximize.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Maximize.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/MaximizeHover.png); "
                                                                                                                          "}")
            self.btn_print.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Print.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/PrintDisabled.png); "
                                                                                                                                                              "}"

                                         )

            self.btn_search.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Search.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SearchHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/SearchDisabled.png); "
                                                                                                                                                               "}"

                                          )
            self.btn_back.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Home.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/HomeHover.png); "
                                                                                                                      "}"
                                        )
            self.btn_vehicle.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/vehicle_unselected.png); "
                                                                                  "border : none "
                                                                                  "}"
                                           )
            self.btn_bill.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/bill_selected.png); "
                                                                               "border : none "
                                                                               "}"
                                        )
            self.btn_close.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/ReportScreenImages/Close.png); "
                                                                                "border : none "
                                                                                "}"
                                         )
            self.btn_bill.raise_()
        except Exception as e:
            print(e)

    def update_bill_toggle_style_sheet(self):
        self.btn_vehicle.setStyleSheet("QPushButton"
                                       "{"
                                       "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/vehicle_unselected.png); "
                                                                              "border : none "
                                                                              "}"
                                       )
        self.btn_bill.setStyleSheet("QPushButton"
                                    "{"
                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/bill_selected.png); "
                                                                           "border : none "
                                                                           "}"
                                    )
        self.btn_bill.raise_()

    def update_vehicle_toggle_style_sheet(self):
        self.btn_vehicle.setStyleSheet("QPushButton"
                                       "{"
                                       "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/vehicle_selected.png); "
                                                                              "border : none "
                                                                              "}"
                                       )
        self.btn_bill.setStyleSheet("QPushButton"
                                    "{"
                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/bill_unselected.png); "
                                                                           "border : none "
                                                                           "}"
                                    )
        self.btn_vehicle.raise_()

    def auto_toggle(self):
        self.btn_auto.setStyleSheet(" QPushButton"
                                    "{"
                                    "background-color:black;"
                                    "border-radius:6px;"
                                    "color: rgb(255, 255, 255);"
                                    "}")
        self.btn_manual.setStyleSheet(" QPushButton"
                                      "{"
                                      "background-color:rgb(255,255,255);"
                                      "color: rgb(0, 0, 0);"
                                      "border:0px"
                                      "}")

    def manual_toggle(self):
        self.btn_manual.setStyleSheet(" QPushButton"
                                      "{"
                                      "background-color:black;"
                                      "border-radius:6px;"
                                      "color: rgb(255, 255, 255);"
                                      "}")
        self.btn_auto.setStyleSheet(" QPushButton"
                                    "{"
                                    "background-color:rgb(255,255,255);"
                                    "color: rgb(0, 0, 0);"
                                    "border:0px"
                                    "}")

    def UserPermissionAccessControls(self):
        self.lblCreateNewRole.setStyleSheet("QLabel"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/CreateNewRoleCard.png); "
                                                                                   "border : none "
                                                                                   "}")
        self.lblAssignAccessBg.setStyleSheet("QLabel"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/AssignAccessBg.png); "
                                                                                    "border : none "
                                                                                    "}")
        self.btnReadSysConfig.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Read.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                          "/ReadHover.png); "
                                                                                                                          "}"
                                            )
        self.btnWriteSysConfig.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Write.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/WriteHover.png); "
                                                                                                                           "}"
                                             )
        self.btnVisibleSysConfig.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Hide.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                             "/HideHover.png); "
                                                                                                                             "}"
                                               )
        self.btnReadAppConfig.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Read.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                          "/ReadHover.png); "
                                                                                                                          "}"
                                            )
        self.btnWriteAppConfig.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Write.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/WriteHover.png); "
                                                                                                                           "}"
                                             )
        self.btnVisibleAppConfig.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Hide.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                             "/HideHover.png); "
                                                                                                                             "}"
                                               )
        self.btnReadGeneral.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                 "/Read.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                        "/ReadHover.png); "
                                                                                                                        "}"
                                          )
        self.btnWriteGeneral.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                  "/Write.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                         "/WriteHover.png); "
                                                                                                                         "}"
                                           )
        self.btnVisibleGeneral.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Hide.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/HideHover.png); "
                                                                                                                           "}"
                                             )
        self.btnReadWebhooks.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                  "/Read.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                         "/ReadHover.png); "
                                                                                                                         "}"
                                           )
        self.btnWriteWebhooks.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Write.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                          "/WriteeHover.png); "
                                                                                                                          "}"
                                            )
        self.btnVisibleWebhooks.setStyleSheet("QPushButton"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                     "/Hide.png); "
                                                                                     "border : none "
                                                                                     "}"
                                                                                     "QPushButton::hover"
                                                                                     "{"
                                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                            "/HideHover.png); "
                                                                                                                            "}"
                                              )
        self.btnReadParameter.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Read.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                          "/ReadHover.png); "
                                                                                                                          "}"
                                            )
        self.btnWriteParameter.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Write.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/WriteHover.png); "
                                                                                                                           "}"
                                             )
        self.btnVisibleParameter.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Hide.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                             "/HideHover.png); "
                                                                                                                             "}"
                                               )
        self.btnReadProfile.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                 "/Read.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                        "/ReadHover.png); "
                                                                                                                        "}"
                                          )
        self.btnWriteProfile.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                  "/Write.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                         "/WriteHover.png); "
                                                                                                                         "}"
                                           )
        self.btnVisibleProfile.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Hide.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/HideHover.png); "
                                                                                                                           "}"
                                             )
        self.btnReadNotification.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Read.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                             "/ReadHover.png); "
                                                                                                                             "}"
                                               )
        self.btnWriteNotification.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                       "/Write.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                              "/WriteHover.png); "
                                                                                                                              "}"
                                                )
        self.btnVisibleNotification.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                         "/Hide.png); "
                                                                                         "border : none "
                                                                                         "}"
                                                                                         "QPushButton::hover"
                                                                                         "{"
                                                                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                                "/HideHover.png); "
                                                                                                                                "}"
                                                  )
        self.btnReadAdvantages.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Read.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                           "/ReadHover.png); "
                                                                                                                           "}"
                                             )
        self.btnWriteAdvantages.setStyleSheet("QPushButton"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                     "/Write.png); "
                                                                                     "border : none "
                                                                                     "}"
                                                                                     "QPushButton::hover"
                                                                                     "{"
                                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                            "/WriteHover.png); "
                                                                                                                            "}"
                                              )
        self.btnVisibleAdvantages.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                       "/Hide.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                              "/HideHover.png); "
                                                                                                                              "}"
                                                )

        pass

    def calibration_normal_state(self):
        try:
            self.btnApplyCalZero.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Download.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadDisable.png); "
                                                                                                                                                                    "}"

                                               )
            self.btnApplyCalSpan.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Download.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadDisable.png); "
                                                                                                                                                                    "}"
                                               )
        except Exception as e:
            print(e)

    def UserPermissionControls(self):
        self.pnlCreateNewRole.move(1600000, 50)
        self.pnlAssignAccess.move(1600000, 50)
        self.btnCreateRoles.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                 "/CreateRole.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CreateRoleHover.png); "
                                                                                                                        "}"
                                          )
        self.btnAccessCancel.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalCancel.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalCancelHover.png); "
                                                                                                                         "}"
                                                                                                                         "QPushButton::disabled"
                                                                                                                         "{"
                                                                                                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalCancelDisable.png); "
                                                                                                                                                                "}"

                                           )
        self.btnSaveAccess.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSave.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSaveHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSaveDisable.png); "
                                                                                                                                                              "}"
                                         )
        self.btnNext.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Next.png); "
                                                                          "border : none "
                                                                          "}"
                                                                          "QPushButton::hover"
                                                                          "{"
                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/NextHover.png); "
                                                                                                                 "}"
                                                                                                                 "QPushButton::disabled"
                                                                                                                 "{"
                                                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/NextDisable.png); "
                                                                                                                                                        "}"

                                   )
        self.btnCancel.setStyleSheet("QPushButton"
                                     "{"
                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                            "/UPCancel.png); "
                                                                            "border : none "
                                                                            "}"
                                                                            "QPushButton::hover"
                                                                            "{"
                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UPCancelHover.png); "
                                                                                                                   "}"
                                                                                                                   "QPushButton::disabled"
                                                                                                                   "{"
                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UPCancelDisable.png); "
                                                                                                                                                          "}"
                                     )
        self.btnRoleDelete.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Delete.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DeleteHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DeleteDisable.png); "
                                                                                                                                                              "}"

                                         )

    def UpdateReadSelectedUserPermissionStatus(self, btnRead, Status):
        if str(Status) == "1":
            btnRead.setStyleSheet("QPushButton"
                                  "{"
                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                         "/ReadHover.png); "
                                                                         "border : none "
                                                                         "}"
                                                                         "QPushButton::hover"
                                                                         "{"
                                                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                "/ReadHover.png); "
                                                                                                                "}"
                                  )
        else:
            btnRead.setStyleSheet("QPushButton"
                                  "{"
                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                         "/Read.png); "
                                                                         "border : none "
                                                                         "}"
                                                                         "QPushButton::hover"
                                                                         "{"
                                                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                "/ReadHover.png); "
                                                                                                                "}"
                                  )

    def UpdateWriteSelectedUserPermissionStatus(self, btnWrite, Status):
        if str(Status) == "1":
            btnWrite.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                          "/WriteHover.png); "
                                                                          "border : none "
                                                                          "}"
                                                                          "QPushButton::hover"
                                                                          "{"
                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                 "/WriteHover.png); "
                                                                                                                 "}"
                                   )
        else:
            btnWrite.setStyleSheet("QPushButton"
                                   "{"
                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                          "/Write.png); "
                                                                          "border : none "
                                                                          "}"
                                                                          "QPushButton::hover"
                                                                          "{"
                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                 "/WriteHover.png); "
                                                                                                                 "}"
                                   )

    def UpdateVisibleSelectedUserPermissionStatus(self, btnVisible, Status):
        if str(Status) == "1":
            btnVisible.setStyleSheet("QPushButton"
                                     "{"
                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                            "/HideHover.png); "
                                                                            "border : none "
                                                                            "}"
                                                                            "QPushButton::hover"
                                                                            "{"
                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                   "/HideHover.png); "
                                                                                                                   "}"
                                     )
        else:
            btnVisible.setStyleSheet("QPushButton"
                                     "{"
                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                            "/Hide.png); "
                                                                            "border : none "
                                                                            "}"
                                                                            "QPushButton::hover"
                                                                            "{"
                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                                   "/HideHover.png); "
                                                                                                                   "}"
                                     )

    def UpdateSelectedReadAccessButton(self, btnRead, btnWrite, btnVisible):
        btnRead.setStyleSheet("QPushButton"
                              "{"
                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                     "/ReadHover.png); "
                                                                     "border : none "
                                                                     "}"
                              )
        btnWrite.setStyleSheet("QPushButton"
                               "{"
                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                      "/Write.png); "
                                                                      "border : none "
                                                                      "}"
                                                                      "QPushButton::hover"
                                                                      "{"
                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                             "/WriteHover.png); "
                                                                                                             "}"
                               )
        btnVisible.setStyleSheet("QPushButton"
                                 "{"
                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                        "/Hide.png); "
                                                                        "border : none "
                                                                        "}"
                                                                        "QPushButton::hover"
                                                                        "{"
                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                               "/HideHover.png); "
                                                                                                               "}"
                                 )

    def UpdateSelectedWriteAccessButton(self, btnRead, btnWrite, btnVisible):
        btnRead.setStyleSheet("QPushButton"
                              "{"
                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                     "/Read.png); "
                                                                     "border : none "
                                                                     "}"
                                                                     "QPushButton::hover"
                                                                     "{"
                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                            "/ReadHover.png); "
                                                                                                            "}"
                              )
        btnWrite.setStyleSheet("QPushButton"
                               "{"
                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                      "/WriteHover.png); "
                                                                      "border : none "
                                                                      "}"
                                                                      "QPushButton::hover"
                                                                      "{"
                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                             "/WriteHover.png); "
                                                                                                             "}"
                               )
        btnVisible.setStyleSheet("QPushButton"
                                 "{"
                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                        "/Hide.png); "
                                                                        "border : none "
                                                                        "}"
                                                                        "QPushButton::hover"
                                                                        "{"
                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                               "/HideHover.png); "
                                                                                                               "}"
                                 )

    def UpdateSelectedVisibleAccessButton(self, btnRead, btnWrite, btnVisible):
        btnRead.setStyleSheet("QPushButton"
                              "{"
                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                     "/Read.png); "
                                                                     "border : none "
                                                                     "}"
                                                                     "QPushButton::hover"
                                                                     "{"
                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                            "/ReadHover.png); "
                                                                                                            "}"
                              )
        btnWrite.setStyleSheet("QPushButton"
                               "{"
                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                      "/Write.png); "
                                                                      "border : none "
                                                                      "}"
                                                                      "QPushButton::hover"
                                                                      "{"
                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                             "/WriteHover.png); "
                                                                                                             "}"
                               )
        btnVisible.setStyleSheet("QPushButton"
                                 "{"
                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                        "/HideHover.png); "
                                                                        "border : none "
                                                                        "}"
                                                                        "QPushButton::hover"
                                                                        "{"
                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                                               "/HideHover.png); "
                                                                                                               "}"
                                 )

    def update_com_config_status(self, button, status):
        if 'successful' in status:
            button.setStyleSheet("QPushButton"
                                 "{"
                                 "background-color:#2C6E49;"
                                 "color:black;"
                                 "border : 2px solid #ffa31a;"
                                 "border-radius : 4px;"
                                 "font-weight:bold;"
                                 "}"
                                 "QPushButton::disabled"
                                 "{"
                                 "background-color:#f5f5f0;"
                                 "color:solid lightgrey;"
                                 "border : 2px solid #ffa31a;"
                                 "border-radius : 4px;"
                                 "font-weight:bold;"
                                 "}"
                                 )
        else:
            button.setStyleSheet("QPushButton"
                                 "{"
                                 "background-color:#c1121f;"
                                 "color:black;"
                                 "border : 2px solid #ffa31a;"
                                 "border-radius : 4px;"
                                 "font-weight:bold;"
                                 "}"
                                 "QPushButton::disabled"
                                 "{"
                                 "background-color:#f5f5f0;"
                                 "color:solid lightgrey;"
                                 "border : 2px solid #ffa31a;"
                                 "border-radius : 4px;"
                                 "font-weight:bold;"
                                 "}"
                                 )

    def calibration_auto_toggle(self):
        self.btn_auto.setStyleSheet(" QPushButton"
                                    "{"
                                    "background-color:black;"
                                    "border-radius:17px;"
                                    "color: rgb(255, 255, 255);"
                                    "}")
        self.btn_manual.setStyleSheet(" QPushButton"
                                      "{"
                                      "background-color:#dedede;"
                                      "color: rgb(0, 0, 0);"
                                      "border-radius:17px;"
                                      "}")
        self.btn_auto.raise_()

    def calibration_manual_toggle(self):
        self.btn_manual.setStyleSheet(" QPushButton"
                                      "{"
                                      "background-color:black;"
                                       "border-radius:17px;"
                                      "color: rgb(255, 255, 255);"
                                      "}")
        self.btn_auto.setStyleSheet(" QPushButton"
                                    "{"
                                    "background-color:#dedede;"
                                    "color: rgb(0, 0, 0);"
                                     "border-radius:17px;"
                                    "}")
        self.btn_manual.raise_()

