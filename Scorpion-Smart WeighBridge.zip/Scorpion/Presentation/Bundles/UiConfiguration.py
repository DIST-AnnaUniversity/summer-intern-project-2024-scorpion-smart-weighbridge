import os

from PyQt5.QtCore import QDateTime
from PyQt5.uic import loadUiType
from pathlib import Path

# ROOT_PATH = "/home/lcs/Scorpion_WeighBridge/Presentation/"
# DB_BACKUP_PATH = "/home/lcs/Scorpion_WeighBridge/"
# RESOLUTION_PATH = "/home/lcs/Scorpion_WeighBridge/LcsScorpion/JSON/settings_resolution.json"
# FIREBASE_JSON = "/home/lcs/Scorpion_WeighBridge/LcsScorpion/JSON/firebase.json"

ROOT_PATH = "Presentation/"
PDF_PATH = ""
DB_BACKUP_PATH = ""
RESOLUTION_PATH = "LcsScorpion/JSON/settings_resolution.json"
FIREBASE_JSON = "LcsScorpion/JSON/firebase.json"

time = QDateTime.currentDateTime()
date = time.toString('dd')
month = time.toString('MMM')
year = time.toString('yyyy')
month_name = time.toString('MMMM')

USB_PATH = "/media/lcs/"


def ui_path(path):
    return loadUiType(os.path.join(Path(__file__).parent.parent, path))


def image_path(path):
    return os.path.join(ROOT_PATH, path)


def DB_path(path):
    return os.path.join(DB_BACKUP_PATH, path)


def JSON_path(path):
    return os.path.join(ROOT_PATH, path)


class ReadBoardInfo:
    bg_X = 1280
    bg_Y = 800


class PathConfig:
    class UI:
        FROM_SPLASH, _ = ui_path("UI/SplashScreen.ui")
        FROM_MAIN, _ = ui_path("UI/MainScreen.ui")
        FROM_ENTRY, _ = ui_path("UI/VehicleEntryScreen.ui")
        FROM_REENTRY, _ = ui_path("UI/VehicleReEntryScreen.ui")
        FROM_REPORT, _ = ui_path("UI/ReportScreen.ui")
        FROM_RECALL, _ = ui_path("UI/RecallScreen.ui")
        FROM_HELP, _ = ui_path("UI/HelpScreen.ui")
        FROM_CAMERA, _ = ui_path("UI/camera.ui")

    class IMG:
        IMAGE_SPLASH = image_path("Images/SplashScreenImages/splashscreen.png")
        IMAGE_MAIN = image_path("Images/MainScreenImages/MainScreenBg.png")
        IMAGE_HELP = image_path("Images/MainScreenImages/empty_bg.png")
        IMAGE_EMPTY = image_path("Images/MainScreenImages/EmptyBg.png")
        IMAGE_Entry = image_path("Images/VehicleEntryImages/VehicleEntryBg.png")
        IMAGE_ReEntry = image_path("Images/VehicleEntryImages/VehicleReEntryBg.png")
        IMAGE_ERROR = image_path("Images/SettingScreenImages/Error.png")
        IMAGE_VERIFIED = image_path("Images/SettingScreenImages/Correct.png")
        IMAGE_RED_BG = image_path("Images/SettingScreenImages/RedMessage.png")
        IMAGE_VERIFIED_BG = image_path("Images/SettingScreenImages/Message.png")
        IMAGE_RECALL = image_path("Images/MainScreenImages/recall_panel.png")
        IMAGE_IMAGE1 = image_path("Images/MainScreenImages/img1.png")
        IMAGE_IMAGE2 = image_path("Images/MainScreenImages/img2.png")
        IMAGE_IMAGE3 = image_path("Images/MainScreenImages/img3.png")

    class JSONPath:
        wifi_commands_path = DB_path(
            "LcsScorpion/JSON/wifi_commands.json")

    class Logo:
        LOGO_PATH = image_path("Images/Logo")
        STAMPING_IMAGE_PATH = image_path("Images/StampingImage")
        DES_PATH = DB_path("/AppData/BackUp")
        SRC_PATH = DB_path("AppData/Database/WeighBridge.db")
