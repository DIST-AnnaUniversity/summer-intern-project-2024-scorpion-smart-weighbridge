from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect

from Presentation.Utilities.py_toggle import SwitchControl


class SettingsDiagnosticsUi:
    def __init__(self):
        super().__init__()

    def create_diagnostics_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.diagnostics_base_frame = QFrame()
            self.diagnostics_base_frame.setFixedWidth(760)
            self.diagnostics_base_frame.setFixedHeight(693)
            self.diagnostics_base_frame.setFrameShape(QFrame.NoFrame)
            self.diagnostics_base_frame.setFrameShadow(QFrame.Raised)
            self.diagnostics_base_frame.setGeometry(0, 0, 760, 693)
            # self.diagnostics_base_frame.setParent(self._parent)

            self.lbl_diagnostics_header = QLabel(self.diagnostics_base_frame)
            self.lbl_diagnostics_header.setFixedWidth(561)
            self.lbl_diagnostics_header.setFixedHeight(41)
            self.lbl_diagnostics_header.setText("IO Diagnostics")
            self.lbl_diagnostics_header.setGeometry(10, 10, 430, 41)
            self.lbl_diagnostics_header.setFont(QFont('Inter', 15))
            self.lbl_diagnostics_header.setStyleSheet("text-align: left;border:0px solid black;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lbl_diagnostics_header.setGraphicsEffect(shadow)

            self.lbl_diagnostics_header.setParent(self.diagnostics_base_frame)

            self.lbl_input_header = QLabel(self.diagnostics_base_frame)
            self.lbl_input_header.setFixedWidth(261)
            self.lbl_input_header.setFixedHeight(41)
            self.lbl_input_header.setText("Input")
            self.lbl_input_header.setGeometry(25, 63, 261, 41)
            self.lbl_input_header.setFont(QFont('Inter', 15, QFont.Bold))
            self.lbl_input_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input_header.setParent(self.diagnostics_base_frame)

            self.lbl_output_header = QLabel(self.diagnostics_base_frame)
            self.lbl_output_header.setFixedWidth(261)
            self.lbl_output_header.setFixedHeight(41)
            self.lbl_output_header.setText("Output")
            self.lbl_output_header.setGeometry(250, 63, 261, 41)
            self.lbl_output_header.setFont(QFont('Inter', 15, QFont.Bold))
            self.lbl_output_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_output_header.setParent(self.diagnostics_base_frame)

            self.lbl_base1 = QLabel(self.diagnostics_base_frame)
            self.lbl_base1.setFixedWidth(721)
            self.lbl_base1.setFixedHeight(61)
            self.lbl_base1.setGeometry(10, 118, 721, 61)
            self.lbl_base1.setStyleSheet("QLabel"
                                         "{"
                                         "background-color:rgba(244,246,252,255);"

                                         "}")
            self.lbl_base1.setParent(self.diagnostics_base_frame)

            self.lbl_base2 = QLabel(self.diagnostics_base_frame)
            self.lbl_base2.setFixedWidth(721)
            self.lbl_base2.setFixedHeight(61)
            self.lbl_base2.setGeometry(10, 240, 721, 61)
            self.lbl_base2.setStyleSheet("QLabel"
                                         "{"
                                         "background-color:rgba(244,246,252,255);"

                                         "}")
            self.lbl_base2.setParent(self.diagnostics_base_frame)

            # self.input_configs = IOParameterConfigBL().Get_Input_Settings()
            self.input_configs = ["IO1","IO1","IO1","IO1"]

            self.lbl_input1_header = QLabel(self.diagnostics_base_frame)
            self.lbl_input1_header.setFixedWidth(220)
            self.lbl_input1_header.setFixedHeight(31)
            self.lbl_input1_header.setGeometry(25, 130, 220, 21)
            self.lbl_input1_header.setText(self.input_configs[0])
            self.lbl_input1_header.setFont(QFont('Inter', 14))
            self.lbl_input1_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input1_header.setParent(self.diagnostics_base_frame)

            self.lbl_input2_header = QLabel(self.diagnostics_base_frame)
            self.lbl_input2_header.setFixedWidth(220)
            self.lbl_input2_header.setFixedHeight(31)
            self.lbl_input2_header.setGeometry(25, 195, 220, 21)
            self.lbl_input2_header.setText(self.input_configs[1])
            self.lbl_input2_header.setFont(QFont('Inter', 14))
            self.lbl_input2_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input2_header.setParent(self.diagnostics_base_frame)

            self.lbl_input3_header = QLabel(self.diagnostics_base_frame)
            self.lbl_input3_header.setFixedWidth(220)
            self.lbl_input3_header.setFixedHeight(31)
            self.lbl_input3_header.setGeometry(25, 255, 220, 21)
            self.lbl_input3_header.setText(self.input_configs[2])
            self.lbl_input3_header.setFont(QFont('Inter', 14))
            self.lbl_input3_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input3_header.setParent(self.diagnostics_base_frame)

            self.lbl_input4_header = QLabel(self.diagnostics_base_frame)
            self.lbl_input4_header.setFixedWidth(220)
            self.lbl_input4_header.setFixedHeight(31)
            self.lbl_input4_header.setGeometry(25, 320, 220, 21)
            self.lbl_input4_header.setText(self.input_configs[3])
            self.lbl_input4_header.setFont(QFont('Inter', 14))
            self.lbl_input4_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input4_header.setParent(self.diagnostics_base_frame)

            self.lblStatusInput1 = QLabel(self.diagnostics_base_frame)
            self.lblStatusInput1.setFixedWidth(30)
            self.lblStatusInput1.setFixedHeight(30)
            self.lblStatusInput1.setGeometry(120, 133, 30, 30)
            self.lblStatusInput1.setStyleSheet("background-color:red;border-radius:15px;border:1px solid black;")
            self.lblStatusInput1.setParent(self.diagnostics_base_frame)

            self.lblStatusInput2 = QLabel(self.diagnostics_base_frame)
            self.lblStatusInput2.setGeometry(120, 191, 30, 30)
            self.lblStatusInput2.setStyleSheet("background-color:red;border-radius:15px;border:1px solid black;")
            self.lblStatusInput2.setParent(self.diagnostics_base_frame)

            self.lblStatusInput3 = QLabel(self.diagnostics_base_frame)
            self.lblStatusInput3.setGeometry(120, 251, 30, 30)
            self.lblStatusInput3.setStyleSheet("background-color:red;border-radius:15px;border:1px solid black;")
            self.lblStatusInput3.setParent(self.diagnostics_base_frame)

            self.lblStatusInput4 = QLabel(self.diagnostics_base_frame)
            self.lblStatusInput4.setFixedWidth(30)
            self.lblStatusInput4.setFixedHeight(30)
            self.lblStatusInput4.setGeometry(120, 320, 30, 30)
            self.lblStatusInput4.setStyleSheet("background-color:red;border-radius:15px;border:1px solid black;")
            self.lblStatusInput4.setParent(self.diagnostics_base_frame)


            # self.output_configs = IOParameterConfigBL().Get_Output_Settings()
            self.output_configs = ["IO1","IO1","IO1","IO1"]

            self.lbl_output1_header = QLabel(self.diagnostics_base_frame)
            self.lbl_output1_header.setFixedWidth(170)
            self.lbl_output1_header.setFixedHeight(31)
            self.lbl_output1_header.setGeometry(220, 130, 59, 21)
            self.lbl_output1_header.setText(self.output_configs[0])
            self.lbl_output1_header.setFont(QFont('Inter', 14))
            self.lbl_output1_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_output1_header.setParent(self.diagnostics_base_frame)

            self.lbl_output2_header = QLabel(self.diagnostics_base_frame)
            self.lbl_output2_header.setFixedWidth(170)
            self.lbl_output2_header.setFixedHeight(31)
            self.lbl_output2_header.setGeometry(220, 195, 59, 21)
            self.lbl_output2_header.setText(self.output_configs[1])
            self.lbl_output2_header.setFont(QFont('Inter', 14))
            self.lbl_output2_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_output2_header.setParent(self.diagnostics_base_frame)

            self.lbl_output3_header = QLabel(self.diagnostics_base_frame)
            self.lbl_output3_header.setFixedWidth(170)
            self.lbl_output3_header.setFixedHeight(31)
            self.lbl_output3_header.setGeometry(220, 255, 59, 21)
            self.lbl_output3_header.setText(self.output_configs[2])
            self.lbl_output3_header.setFont(QFont('Inter', 14))
            self.lbl_output3_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_output3_header.setParent(self.diagnostics_base_frame)

            self.lbl_output4_header = QLabel(self.diagnostics_base_frame)
            self.lbl_output4_header.setFixedWidth(170)
            self.lbl_output4_header.setFixedHeight(31)
            self.lbl_output4_header.setGeometry(220, 320, 59, 21)
            self.lbl_output4_header.setText(self.output_configs[3])
            self.lbl_output4_header.setFont(QFont('Inter', 14))
            self.lbl_output4_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_output4_header.setParent(self.diagnostics_base_frame)

            self.lblStatusOutput1 = QLabel(self.diagnostics_base_frame)
            self.lblStatusOutput1.setFixedWidth(95)
            self.lblStatusOutput1.setFixedHeight(31)
            self.lblStatusOutput1.setGeometry(390, 134, 91, 31)
            self.lblStatusOutput1.setText("Status - OFF")
            self.lblStatusOutput1.setFont(QFont('Inter', 10, QFont.Bold))
            self.lblStatusOutput1.setStyleSheet("text-align: left;border:0px solid black;color:red;")
            self.lblStatusOutput1.setParent(self.diagnostics_base_frame)

            self.lblStatusOutput2 = QLabel(self.diagnostics_base_frame)
            self.lblStatusOutput2.setFixedWidth(95)
            self.lblStatusOutput2.setFixedHeight(31)
            self.lblStatusOutput2.setGeometry(390, 195, 91, 31)
            self.lblStatusOutput2.setText("Status - OFF")
            self.lblStatusOutput2.setFont(QFont('Inter', 10, QFont.Bold))
            self.lblStatusOutput2.setStyleSheet("text-align: left;border:0px solid black;color:red;")
            self.lblStatusOutput2.setParent(self.diagnostics_base_frame)

            self.lblStatusOutput3 = QLabel(self.diagnostics_base_frame)
            self.lblStatusOutput3.setFixedWidth(95)
            self.lblStatusOutput3.setFixedHeight(31)
            self.lblStatusOutput3.setGeometry(390, 258, 91, 31)
            self.lblStatusOutput3.setText("Status - OFF")
            self.lblStatusOutput3.setFont(QFont('Inter', 10, QFont.Bold))
            self.lblStatusOutput3.setStyleSheet("text-align: left;border:0px solid black;color:red;")
            self.lblStatusOutput3.setParent(self.diagnostics_base_frame)

            self.lblStatusOutput4 = QLabel(self.diagnostics_base_frame)
            self.lblStatusOutput4.setFixedWidth(95)
            self.lblStatusOutput4.setFixedHeight(31)
            self.lblStatusOutput4.setGeometry(390, 320, 91, 31)
            self.lblStatusOutput4.setText("Status - OFF")
            self.lblStatusOutput4.setFont(QFont('Inter', 10, QFont.Bold))
            self.lblStatusOutput4.setStyleSheet("text-align: left;border:0px solid black;color:red;")
            self.lblStatusOutput4.setParent(self.diagnostics_base_frame)

            self.toggles_base_frame = QFrame()
            self.toggles_base_frame.setFixedWidth(111)
            self.toggles_base_frame.setFixedHeight(511)
            self.toggles_base_frame.setFrameShape(QFrame.NoFrame)
            self.toggles_base_frame.setGeometry(520, 110, 111, 511)
            # self.toggles_base_frame.setParent(self._parent)

            self.btnOutput1 = SwitchControl()
            self.btnOutput2 = SwitchControl()
            self.btnOutput3 = SwitchControl()
            self.btnOutput4 = SwitchControl()
            self.btnOutput1.setChecked(True)

            self.btnOutput1.setGeometry(320, 134, 0, 0)
            self.btnOutput2.setGeometry(320, 198, 0, 0)
            self.btnOutput3.setGeometry(320, 258, 0, 0)
            self.btnOutput4.setGeometry(320, 320, 0, 0)

            self.btnOutput1.setParent(self.diagnostics_base_frame)
            self.btnOutput2.setParent(self.diagnostics_base_frame)
            self.btnOutput3.setParent(self.diagnostics_base_frame)
            self.btnOutput4.setParent(self.diagnostics_base_frame)


            # self.btnOutput1.stateChanged.connect(self.Output1Checked)
            # self.btnOutput2.stateChanged.connect(self.Output2Checked)
            # self.btnOutput3.stateChanged.connect(self.Output3Checked)
            # self.btnOutput4.stateChanged.connect(self.Output4Checked)

            self.HorizontalLyt.addWidget(self.diagnostics_base_frame)

            pass
        except Exception as e:
            print(e)
