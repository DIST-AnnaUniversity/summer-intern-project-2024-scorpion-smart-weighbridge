import json

from PyQt5 import QtCore
from PyQt5.QtGui import QPixmap, QIcon, QFont
from PyQt5.QtWidgets import QMainWindow, QFrame, QLabel, QVBoxLayout, QPushButton, QStackedWidget, QWidget, \
    QGraphicsDropShadowEffect, QHBoxLayout

from Presentation.Bundles.UiConfiguration import ROOT_PATH, DB_BACKUP_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable
from BusinessLogic.SystemConfigBL import SystemConfigBL

class SettingsMenuUi:
    def __init__(self):
        super().__init__()

    def create_main_window(self):
        try:
            """Set the Background Image for the QMainWindow Label which is in the frame """
            self.frm_window = QFrame(self)
            self.frm_window.resize(800, 480)
            lbl_window_bg = QLabel(self.frm_window)
            lbl_window_bg.setGeometry(0, 0, self.frm_window.width(), self.frm_window.height())
            lbl_window_bg.setStyleSheet("border:0px solid lightgrey;background-color:#ffffff;")
            self.lbl_windows_header = QLabel(self.frm_window)
            self.lbl_windows_header.move(0, 40)
            self.lbl_windows_header.resize(800, 1)
            self.lbl_windows_header.setStyleSheet("background-color:white;")
            effect = QGraphicsDropShadowEffect()
            effect.setOffset(0, 0)
            effect.setBlurRadius(15)
            self.lbl_windows_header.setGraphicsEffect(effect)
            self.lbl_windows_header.raise_()

            self.lbl_logo = QLabel(self.frm_window)
            self.lbl_logo.move(10, 2)
            self.lbl_logo.resize(71, 41)
            self.lbl_logo.setStyleSheet("border:0px solid lightgrey;")

            self.lbl_app_header = QLabel(self.frm_window)
            self.lbl_app_header.move(100, 1)
            self.lbl_app_header.resize(220, 41)
            self.lbl_app_header.setFont(QFont('MS Shell Dlg 2', 15))
            self.lbl_app_header.setStyleSheet("border:0px solid lightgrey;")
            # self.lbl_app_header.setText("LCS Controls Pvt")

            self.lbl_time = QLabel(self.frm_window)
            self.lbl_time.move(600, 1)
            self.lbl_time.resize(230, 41)
            self.lbl_time.setFont(QFont('MS Shell Dlg 2', 11))
            self.lbl_time.setStyleSheet("border:0px solid lightgrey;")
            # self.lbl_time.setText("10:30 AM")

            self.btn_notification = QPushButton(self.frm_window)
            self.btn_notification.move(600, 5)
            self.btn_notification.resize(21, 26)
            self.btn_notification.setStyleSheet("border:0px solid lightgrey;")
            self.btn_notification.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Notification.png); "
                                                                                       "border : none "
                                                                                       "}"

                                                )
            self.btn_notification.setVisible(False)

            self.lbl_wifi_status = QLabel(self.frm_window)
            self.lbl_wifi_status.move(550, 1)
            self.lbl_wifi_status.resize(41, 31)
            self.lbl_wifi_status.setFont(QFont('MS Shell Dlg 2', 14))
            self.lbl_wifi_status.setStyleSheet("border:0px solid lightgrey;")
            # self.lbl_wifi_status.setStyleSheet("QLabel"
            #                                    "{"
            #                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/wifi_on.png); "
            #                                                                           "border : none "
            #                                                                           "}"
            #
            #                                    )
            # self.lbl_wifi_status.setVisible(False)
            pass
        except Exception as e:
            print(e)

    def main_menu(self):
        try:
            """ Set the Background Image for the MainMenu Label which is in the main menu frame """
            self.frm_menu = QFrame(self)
            self.frm_menu.move(0, 45)
            self.frm_menu.resize(140, 430)
            shadow = QGraphicsDropShadowEffect(blurRadius=5, xOffset=3, yOffset=3)
            self.frm_menu.setGraphicsEffect(shadow)
            lbl_main_menu_bg = QLabel(self.frm_menu)
            lbl_main_menu_bg.setGeometry(0, 0, self.frm_menu.width(), self.frm_menu.height())
            lbl_main_menu_bg.setStyleSheet("border:0px solid lightgrey;background-color:#f4f6fc;")
            self.menu_button_y_position = 50
            self.submenu_button_y_position = 0
            self.general_button_y_position = 0
            self.webhooks_button_y_position = 0
            self.preference_button_y_position = 0
            self.notification_button_y_position = 0
            self.user_information_button_y_position = 0
        except Exception as e:
            print(e)

    def sub_menu(self):
        try:
            self.layout = QVBoxLayout()
            self.frm_sub_menu = QFrame(self)
            self.frm_sub_menu.move(141, 45)
            self.frm_sub_menu.resize(140, 430)
            self.frm_sub_menu.setStyleSheet("border :0px solid black;background-color:white;")
            self.frm_sub_menu.setLayout(self.layout)
            shadow = QGraphicsDropShadowEffect(blurRadius=5, xOffset=3, yOffset=3)
            self.frm_sub_menu.setGraphicsEffect(shadow)
        except Exception as e:
            print(e)

    def create_sub_widget(self):
        self.wgt = QWidget(self)
        self.wgt.resize(521, 430)
        self.wgt.move(280, 45)

        self.HorizontalLyt = QHBoxLayout(self.wgt)


    def create_main_widget(self):
        self.wgt_main = QWidget(self)
        self.wgt_main.resize(661, 429)
        self.wgt_main.move(142, 47)
        self.wgt_main.setStyleSheet("border:0px solid grey;background-color:white;")
        self.wgt_main.setStyleSheet("border:0px solid grey;background-color:white;")

        self.hlyt_main = QHBoxLayout(self.wgt_main)

    def access_denied(self):
        self.ToolTip = QWidget(self)
        self.ToolTip.resize(181, 54)
        self.ToolTip.move(50000, 20)

        self.lbl_tool_tip_bg = QLabel(self.ToolTip)
        self.lbl_tool_tip_bg.resize(169, 54)
        self.lbl_tool_tip_bg.move(0, 0)
        self.lbl_tool_tip_bg.setPixmap(QPixmap("" + ROOT_PATH + "Images/SettingScreenImages/LeftRedMessage.png"))
        self.lbl_tool_tip_bg.setParent(self.ToolTip)

        self.lblToolTipMsg = QLabel(self.ToolTip)
        self.lblToolTipMsg.resize(111, 31)
        self.lblToolTipMsg.move(24, 10)
        self.lblToolTipMsg.setText("Access Denied")
        self.lblToolTipMsg.setStyleSheet("color:white;border:0px solid grey;")
        self.lblToolTipMsg.setFont(QFont('Inter', 12))
        self.lblToolTipMsg.setParent(self.ToolTip)

    def no_network_found(self):
        self.NoNetworkToolTip = QWidget(self)
        self.NoNetworkToolTip.resize(181, 54)
        self.NoNetworkToolTip.move(50000, 20)

        self.lbl_tool_tip_bg = QLabel(self.NoNetworkToolTip)
        self.lbl_tool_tip_bg.resize(169, 54)
        self.lbl_tool_tip_bg.move(0, 0)
        self.lbl_tool_tip_bg.setPixmap(QPixmap("" + ROOT_PATH + "Images/SettingScreenButtons/LeftRedMessage.png"))
        self.lbl_tool_tip_bg.setParent(self.NoNetworkToolTip)

        self.lblToolTipMsg = QLabel(self.NoNetworkToolTip)
        self.lblToolTipMsg.resize(111, 31)
        self.lblToolTipMsg.move(24, 10)
        self.lblToolTipMsg.setText("  No Network  ")
        self.lblToolTipMsg.setStyleSheet("color:white;border:0px solid grey;")
        self.lblToolTipMsg.setFont(QFont('Inter', 16))
        self.lblToolTipMsg.setParent(self.NoNetworkToolTip)

    def setting_msg_popup(self):
        self.pnl_message_popup = QWidget(self.frm_window)
        self.pnl_message_popup.resize(181, 54)
        self.pnl_message_popup.move(400, 0)
        self.pnl_message_popup.raise_()

        self.lbl_popup_color = QLabel(self.pnl_message_popup)
        self.lbl_popup_color.resize(181, 54)
        self.lbl_popup_color.move(0, 0)
        self.lbl_popup_color.setParent(self.pnl_message_popup)

        self.lbl_popup_text = QLabel(self.pnl_message_popup)
        self.lbl_popup_text.resize(151, 31)
        self.lbl_popup_text.move(10, 10)
        self.lbl_popup_text.setStyleSheet("color:white;border:0px solid grey;")
        self.lbl_popup_text.setFont(QFont('Inter', 10))
        self.lbl_popup_text.setParent(self.pnl_message_popup)
        self.pnl_message_popup.setVisible(False)

    def display_menu_buttons_from_json(self):
        path = open("" + DB_BACKUP_PATH + "LcsScorpion/JSON/menu_icon.json")
        data = json.load(path)
        path.close()
        for key_language, value_language in GlobalVariable.language_setting_items["settings_main_menu_text"].items():
            if key_language == "profile":
                self.Profile = QPushButton(str(value_language), self)
                self.Profile.setObjectName("profile")
                self.Profile.setFont(QFont('Inter', 12))
                self.Profile.setStyleSheet(
                    "QPushButton { text-align:left;background-color:#f4f6fc;border:0px solid "
                    "lightgrey;color:#4d4d4d;padding-left:11px; }")
                self.Profile.setIcon(QIcon(ROOT_PATH + data[" Profile"]))
                self.Profile.clicked.connect(self.on_click_main_menu)
                self.Profile.resize(138, 35)
                self.Profile.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "preferences":
                self.Preferences = QPushButton(value_language, self)
                self.Preferences.setObjectName("preferences")
                self.Preferences.setFont(QFont('Inter', 12))
                self.Preferences.setStyleSheet(
                    "QPushButton { text-align:left;background-color:#f4f6fc;border:0px solid "
                    "lightgrey;color:#4d4d4d;padding-left:11px;}")
                self.Preferences.setIcon(QIcon(ROOT_PATH + data[" Preferences"]))
                self.Preferences.clicked.connect(self.on_click_main_menu)
                self.Preferences.resize(138, 35)
                self.Preferences.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "notification":
                if GlobalVariable.super_admin_login:
                    self.Notification = QPushButton(value_language, self)
                    self.Notification.setObjectName("notification")
                    self.Notification.setFont(QFont('Inter', 12))
                    self.Notification.setStyleSheet(
                        "QPushButton { text-align:left;background-color:#f4f6fc;border:0px solid "
                        "lightgrey;color:#4d4d4d;padding-left:11px;}")
                    self.Notification.setIcon(QIcon(ROOT_PATH + data[" Notification"]))
                    self.Notification.clicked.connect(self.on_click_main_menu)
                    self.Notification.resize(138, 35)
                    self.Notification.move(0, self.menu_button_y_position)
                    self.menu_button_y_position += 40
            elif key_language == "createnewuser":
                self.CreateNewUser = QPushButton(value_language, self)
                self.CreateNewUser.setObjectName("new_user")
                self.CreateNewUser.setFont(QFont('Inter', 12))
                self.CreateNewUser.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#f4f6fc;border:0px solid "
                    "lightgrey;color:#4d4d4d;padding-left:11px;}")
                self.CreateNewUser.setIcon(QIcon(ROOT_PATH + data[" Create New User"]))
                self.CreateNewUser.clicked.connect(self.on_click_main_menu)
                self.CreateNewUser.resize(138, 35)
                self.CreateNewUser.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "advantages":
                if GlobalVariable.super_admin_login:
                    self.Advantages = QPushButton(value_language, self)
                    self.Advantages.setObjectName("advantages")
                    self.Advantages.setFont(QFont('Inter', 12))
                    self.Advantages.setStyleSheet(
                        "QPushButton { text-align: left;background-color:#f4f6fc;border:0px solid "
                        "lightgrey;color:#4d4d4d;padding-left:11px;}")
                    self.Advantages.setIcon(QIcon(ROOT_PATH + data[" Advantages"]))
                    self.Advantages.clicked.connect(self.on_click_main_menu)
                    self.Advantages.resize(138, 35)
                    self.Advantages.move(0, self.menu_button_y_position)
                    self.menu_button_y_position += 40
            elif key_language == "userinformation":
                self.UserInformation = QPushButton(value_language, self)
                self.UserInformation.setObjectName("userinformation")
                self.UserInformation.setFont(QFont('Inter', 12))
                self.UserInformation.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#f4f6fc;border:0px solid "
                    "lightgrey;color:#4d4d4d;padding-left:11px;}")
                self.UserInformation.setIcon(QIcon(ROOT_PATH + data[" User Information"]))
                self.UserInformation.clicked.connect(self.on_click_main_menu)
                self.UserInformation.resize(138, 30)
                self.UserInformation.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40

            # elif key_language == "stampingdue":
            #     self.stamping_due = QPushButton(value_language, self)
            #     self.stamping_due.setObjectName("stampingdue")
            #     self.stamping_due.setFont(QFont('Inter', 12))
            #     self.stamping_due.setStyleSheet(
            #         "QPushButton { text-align: left;background-color:#f4f6fc;border:0px solid "
            #         "lightgrey;color:#4d4d4d;padding-left:11px;}")
            #     self.stamping_due.setIcon(QIcon(ROOT_PATH + data[" User Information"]))
            #     self.stamping_due.clicked.connect(self.on_click_main_menu)
            #     self.stamping_due.resize(138, 30)
            #     self.stamping_due.move(0, self.menu_button_y_position)
            #     self.menu_button_y_position += 40

            elif key_language == "home":
                self.Home = QPushButton(value_language, self)
                self.Home.setObjectName("home")
                self.Home.setFont(QFont('Inter', 12))
                self.Home.setStyleSheet(
                    "QPushButton"
                    "{"
                    " text-align: left;"
                    "background-color:#f4f6fc;"
                    "border:0px solid lightgrey;"
                    "padding-left:10px;"
                    "border-radius:3px;"

                    " } ")
                self.Home.setIcon(QIcon(ROOT_PATH + data[" Home"]))
                self.Home.clicked.connect(self.on_click_main_menu)
                self.Home.resize(138, 35)
                self.Home.move(0, 440)
            elif key_language == "systemconfig":
                self.SystemConfig = QPushButton(value_language, self)
                self.SystemConfig.setObjectName("system_config")
                self.SystemConfig.setFont(QFont('Inter', 12))
                self.SystemConfig.setStyleSheet(
                    "QPushButton { text-align: left;background-color:black;color:white;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.SystemConfig.setIcon(QIcon(ROOT_PATH+value))
                self.SystemConfig.clicked.connect(self.on_click_main_menu)
                self.SystemConfig.resize(138, 35)
                self.SystemConfig.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40

            elif key_language == "general":
                self.General = QPushButton(value_language, self)
                self.General.setObjectName("general")
                self.General.setFont(QFont('Inter', 12))
                self.General.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#eef2ff;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.General.setIcon(QIcon(ROOT_PATH+value))
                self.General.clicked.connect(self.on_click_main_menu)
                self.General.resize(138, 35)
                self.General.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "webhooks":
                self.Webhooks = QPushButton(value_language, self)
                self.Webhooks.setObjectName("webhooks")
                self.Webhooks.setFont(QFont('Inter', 12))
                self.Webhooks.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#eef2ff;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.Webhooks.setIcon(QIcon(ROOT_PATH+value))
                self.Webhooks.clicked.connect(self.on_click_main_menu)
                self.Webhooks.resize(138, 35)
                self.Webhooks.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "parameters":
                self.Parameters = QPushButton(value_language, self)
                self.Parameters.setObjectName("parameters")
                self.Parameters.setFont(QFont('Inter', 12))
                self.Parameters.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#eef2ff;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.Webhooks.setIcon(QIcon(ROOT_PATH+value))
                self.Parameters.clicked.connect(self.on_click_main_menu)
                self.Parameters.resize(138, 35)
                self.Parameters.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            elif key_language == "appconfig":
                self.AppConfig = QPushButton(value_language, self)
                self.AppConfig.setObjectName("app_config")
                self.AppConfig.setFont(QFont('Inter', 12))
                self.AppConfig.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#eef2ff;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.Webhooks.setIcon(QIcon(ROOT_PATH+value))
                self.AppConfig.clicked.connect(self.on_click_main_menu)
                self.AppConfig.resize(138, 35)
                self.AppConfig.move(0, self.menu_button_y_position)
                self.menu_button_y_position += 40
            else:
                self.dynamic_button = QPushButton(value_language, self)
                self.dynamic_button.setFont(QFont('Inter', 12))
                self.dynamic_button.setStyleSheet(
                    "QPushButton { text-align: left;background-color:#eef2ff;border:0px solid "
                    "lightgrey;padding-left:10px;}")
                # self.dynamic_button.setIcon(QIcon(ROOT_PATH+value))
                self.dynamic_button.clicked.connect(self.on_click_main_menu)
                self.dynamic_button.resize(138, 35)
                self.dynamic_button.move(1, self.menu_button_y_position)
                self.menu_button_y_position += 40

    def sys_config_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["systemconfig"].items():
            if key_language == "rs_232":
                self.RS232 = QPushButton(value_language)
                self.RS232.setObjectName("rs232")
                self.RS232.setFixedSize(135, 35)
                self.RS232.setFont(QFont('Inter', 11))
                self.RS232.clicked.connect(self.on_click_sys_config_menu)
                self.RS232.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.RS232)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.RS232.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")

            elif key_language == "input_settings":
                if GlobalVariable.super_admin_login:
                    self.InputSettings = QPushButton(value_language)
                    self.InputSettings.setObjectName("input_settings")
                    self.InputSettings.setFixedSize(135, 35)
                    self.InputSettings.setFont(QFont('Inter', 11))
                    self.InputSettings.clicked.connect(self.on_click_sys_config_menu)
                    self.InputSettings.move(0, self.submenu_button_y_position)
                    self.submenu_button_y_position += 40
                    # self.InputSettings.setParent(frmSysConfig)
                    self.layout.addWidget(self.InputSettings)
                    self.InputSettings.setStyleSheet(
                        "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "output_settings":
                if GlobalVariable.super_admin_login:
                    self.OutputSettings = QPushButton(value_language)
                    self.OutputSettings.setObjectName("output_settings")
                    self.OutputSettings.setFixedSize(135, 35)
                    self.OutputSettings.setFont(QFont('Inter', 11))
                    self.OutputSettings.clicked.connect(self.on_click_sys_config_menu)
                    self.OutputSettings.move(0, self.submenu_button_y_position)
                    self.submenu_button_y_position += 40
                    self.layout.addWidget(self.OutputSettings)
                    self.layout.setSpacing(2)
                    self.layout.setAlignment(QtCore.Qt.AlignTop)
                    self.OutputSettings.setStyleSheet(
                        "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")
            elif key_language == "calibration":
                if GlobalVariable.super_admin_login:
                    self.Calibration = QPushButton(value_language)
                    self.Calibration.setObjectName("calibration")
                    self.Calibration.setFixedSize(135, 35)
                    self.Calibration.setFont(QFont('Inter', 11))
                    self.Calibration.clicked.connect(self.on_click_sys_config_menu)
                    self.Calibration.move(0, self.submenu_button_y_position)
                    self.submenu_button_y_position += 40
                    self.layout.addWidget(self.Calibration)
                    self.layout.setSpacing(2)
                    self.layout.setAlignment(QtCore.Qt.AlignTop)
                    self.Calibration.setStyleSheet(
                        "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")
            elif key_language == "ethernet":
                self.camera =SystemConfigBL.get_camera_status(self)
                if GlobalVariable.super_admin_login and self.camera == 1:
                    self.Ethernet = QPushButton(value_language)
                    self.Ethernet.setObjectName("ethernet")
                    self.Ethernet.setFixedSize(135, 35)
                    self.Ethernet.setFont(QFont('Inter', 11))
                    self.Ethernet.clicked.connect(self.on_click_sys_config_menu)
                    self.Ethernet.move(0, self.submenu_button_y_position)
                    self.submenu_button_y_position += 40
                    self.layout.addWidget(self.Ethernet)
                    self.layout.setSpacing(2)
                    self.layout.setAlignment(QtCore.Qt.AlignTop)
                    self.Ethernet.setStyleSheet(
                        "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")
                else:
                    self.Ethernet = QPushButton(value_language)
                    self.Ethernet.setObjectName("ethernet")
                    self.Ethernet.setEnabled(False)
                    self.Ethernet.hide()
            elif key_language == "io_diagnostics":
                if GlobalVariable.super_admin_login:
                    self.Diagnostics = QPushButton(value_language)
                    self.Diagnostics.setObjectName("diagnostics")
                    self.Diagnostics.setFixedSize(135, 35)
                    self.Diagnostics.setFont(QFont('Inter', 11))
                    self.Diagnostics.clicked.connect(self.on_click_sys_config_menu)
                    self.Diagnostics.move(0, self.submenu_button_y_position)
                    self.submenu_button_y_position += 40
                    self.layout.addWidget(self.Diagnostics)
                    self.layout.setSpacing(2)
                    self.layout.setAlignment(QtCore.Qt.AlignTop)
                    self.Diagnostics.setStyleSheet(
                        "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")
                # self.layout.addWidget(self.Diagnostics)
            # elif key_language == "system_diagnostics":
            #     self.SystemDiagnostics = QPushButton(value_language)
            #     self.SystemDiagnostics.setObjectName("system_diagnostics")
            #     self.SystemDiagnostics.setFixedSize(135, 35)
            #     self.SystemDiagnostics.setFont(QFont('Inter', 12))
            #     self.SystemDiagnostics.clicked.connect(self.on_click_sys_config_menu)
            #     self.SystemDiagnostics.move(0, self.submenu_button_y_position)
            #     self.submenu_button_y_position += 40
            #     self.layout.addWidget(self.SystemDiagnostics)
            #     self.layout.setSpacing(2)
            #     self.layout.setAlignment(QtCore.Qt.AlignTop)
            #     self.SystemDiagnostics.setStyleSheet(
            #         "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")
            elif key_language == "printer_config":
                self.PrinterConfig = QPushButton(value_language)
                self.PrinterConfig.setObjectName("printer_config")
                self.PrinterConfig.setFixedSize(135, 35)
                self.PrinterConfig.setFont(QFont('Inter', 11))
                self.PrinterConfig.clicked.connect(self.on_click_sys_config_menu)
                self.PrinterConfig.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.PrinterConfig)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.PrinterConfig.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")

            elif key_language == "peripherals":
                self.Peripherals = QPushButton(value_language)
                self.Peripherals.setObjectName("peripherals")
                self.Peripherals.setFixedSize(135, 35)
                self.Peripherals.setFont(QFont('Inter', 11))
                self.Peripherals.clicked.connect(self.on_click_sys_config_menu)
                self.Peripherals.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Peripherals)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.Peripherals.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;color:#4d4d4d;background-color:white;border-radius:3px; }")

    def parameters_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["parameters"].items():
            if key_language == "header":
                self.HeaderSettings = QPushButton(value_language)
                self.HeaderSettings.setObjectName("header_settings")
                self.HeaderSettings.setFixedSize(135, 35)
                self.HeaderSettings.setFont(QFont('Inter', 11))
                self.HeaderSettings.clicked.connect(self.on_click_parameters_menu)
                self.HeaderSettings.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.HeaderSettings)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.HeaderSettings.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")

            elif key_language == "code":
                self.CodeSettings = QPushButton(value_language)
                self.CodeSettings.setObjectName("code_settings")
                self.CodeSettings.setFixedSize(135, 35)
                self.CodeSettings.setFont(QFont('Inter', 11))
                self.CodeSettings.clicked.connect(self.on_click_parameters_menu)
                self.CodeSettings.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                # self.InputSettings.setParent(frmSysConfig)
                self.layout.addWidget(self.CodeSettings)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.CodeSettings.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "other":
                self.OtherSettings = QPushButton(value_language)
                self.OtherSettings.setObjectName("other_settings")
                self.OtherSettings.setFixedSize(135, 35)
                self.OtherSettings.setFont(QFont('Inter', 11))
                self.OtherSettings.clicked.connect(self.on_click_parameters_menu)
                self.OtherSettings.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                # self.InputSettings.setParent(frmSysConfig)
                self.layout.addWidget(self.OtherSettings)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.OtherSettings.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

    def general_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["general"].items():
            if key_language == "datetime":
                self.DateTime = QPushButton(value_language)
                self.DateTime.setObjectName("datetime")
                self.DateTime.setFixedSize(135, 35)
                self.DateTime.setFont(QFont('Inter', 11))
                self.DateTime.clicked.connect(self.on_click_general_menu)
                self.DateTime.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.DateTime)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.DateTime.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")
            elif key_language == "wifi":
                self.Wifi = QPushButton(value_language)
                self.Wifi.setObjectName("wifi")
                self.Wifi.setFixedSize(135, 35)
                self.Wifi.move(0, self.general_button_y_position)
                self.Wifi.setFont(QFont('Inter', 11))
                self.Wifi.clicked.connect(self.on_click_general_menu)
                self.general_button_y_position += 40
                self.layout.addWidget(self.Wifi)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.Wifi.setStyleSheet(
                    "QPushButton { text-align:left;border:0px solid lightgrey;padding-left:11px;background-color:white;color:#4d4d4d;border-radius:3px; }")

            elif key_language == "header":
                self.Header = QPushButton(value_language)
                self.Header.setObjectName("header")
                self.Header.setFixedSize(135, 35)
                self.Header.setFont(QFont('Inter', 11))
                self.Header.clicked.connect(self.on_click_general_menu)
                self.Header.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Header)
                self.Header.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "footer":
                self.Footer = QPushButton(value_language)
                self.Footer.setObjectName("footer")
                self.Footer.setFixedSize(135, 35)
                self.Footer.setFont(QFont('Inter', 11))
                self.Footer.clicked.connect(self.on_click_general_menu)
                self.Footer.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Footer)
                self.Footer.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

    def weebhooks_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["webhooks"].items():
            if key_language == "cloud":
                self.Cloud = QPushButton(value_language)
                self.Cloud.setObjectName("cloud")
                self.Cloud.setFixedSize(135, 35)
                self.Cloud.setFont(QFont('Inter', 11))
                self.Cloud.clicked.connect(self.on_click_webhooks_menu)
                self.Cloud.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Cloud)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.Cloud.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")

            elif key_language == "domain":
                self.Domain = QPushButton(value_language)
                self.Domain.setObjectName("domain")
                self.Domain.setFixedSize(135, 35)
                self.Domain.setFont(QFont('Inter', 11))
                self.Domain.clicked.connect(self.on_click_webhooks_menu)
                self.Domain.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Domain)
                self.Domain.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "dbbackup":
                self.DbBackup = QPushButton(value_language)
                self.DbBackup.setObjectName("dbbackup")
                self.DbBackup.setFixedSize(135, 35)
                self.DbBackup.setFont(QFont('Inter', 11))
                self.DbBackup.clicked.connect(self.on_click_webhooks_menu)
                self.DbBackup.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.DbBackup)
                self.DbBackup.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

    def profile_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["profile"].items():
            if key_language == "profile":
                self.UserProfile = QPushButton(value_language)
                self.UserProfile.setObjectName("user_profile")
                self.UserProfile.setFixedSize(135, 35)
                self.UserProfile.setFont(QFont('Inter', 11))
                self.UserProfile.clicked.connect(self.on_click_profile_sub_menu)
                self.UserProfile.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.UserProfile)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.UserProfile.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")
            elif key_language == "new_user":
                self.CreateNewUser = QPushButton(value_language)
                self.CreateNewUser.setObjectName("new_user")
                self.CreateNewUser.setFixedSize(135, 35)
                self.CreateNewUser.setFont(QFont('Inter', 11))
                self.CreateNewUser.clicked.connect(self.on_click_profile_sub_menu)
                self.CreateNewUser.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.CreateNewUser)
                self.CreateNewUser.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "assign_role":
                self.AssignRole = QPushButton(value_language)
                self.AssignRole.setObjectName("assign_role")
                self.AssignRole.setFixedSize(135, 35)
                self.AssignRole.setFont(QFont('Inter', 11))
                self.AssignRole.clicked.connect(self.on_click_profile_sub_menu)
                self.AssignRole.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.AssignRole)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.AssignRole.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

            elif key_language == "user_permission":
                self.UserPermission = QPushButton(value_language)
                self.UserPermission.setObjectName("user_permission")
                self.UserPermission.setFixedSize(135, 35)
                self.UserPermission.setFont(QFont('Inter', 11))
                self.UserPermission.clicked.connect(self.on_click_profile_sub_menu)
                self.UserPermission.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.UserPermission)
                self.UserPermission.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

    def noification_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["notification"].items():
            if key_language == "email":
                self.Email = QPushButton(value_language)
                self.Email.setObjectName("email")
                self.Email.setFixedSize(135, 35)
                self.Email.setFont(QFont('Inter', 11))
                self.Email.clicked.connect(self.on_click_notification_menu)
                self.Email.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Email)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.Email.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")

            elif key_language == "support":
                self.Support = QPushButton(value_language)
                self.Support.setObjectName("support")
                self.Support.setFixedSize(135, 35)
                self.Support.setFont(QFont('Inter', 11))
                self.Support.clicked.connect(self.on_click_notification_menu)
                self.Support.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.Support)
                self.Support.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")
            elif key_language == "device_info":
                self.DeviceInfo = QPushButton(value_language)
                self.DeviceInfo.setObjectName("device_info")
                self.DeviceInfo.setFixedSize(135, 35)
                self.DeviceInfo.setFont(QFont('Inter', 11))
                self.DeviceInfo.clicked.connect(self.on_click_notification_menu)
                self.DeviceInfo.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.DeviceInfo)
                self.DeviceInfo.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid lightgrey;background-color:white;color:#4d4d4d;border-radius:3px; }")

    def preference_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        for key_language, value_language in GlobalVariable.language_setting_items["preferences"].items():
            if key_language == "language":
                self.Language = QPushButton(value_language)
                self.Language.setObjectName("language")
                self.Language.setFixedSize(135, 35)
                self.Language.move(0, self.preference_button_y_position)
                self.Language.setFont(QFont('Inter', 16))
                self.Language.clicked.connect(self.on_click_preference_menu)
                self.preference_button_y_position += 40
                self.layout.addWidget(self.Language)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.Language.setStyleSheet(
                    "QPushButton { text-align:left;border:0px solid lightgrey;background-color:black;padding-left:11px;color:white;border-radius:3px; }")

    def user_info_sub_menu(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for key_language, value_language in GlobalVariable.language_setting_items["userinformation"].items():
            if key_language == "assign_role":
                self.AssignRole = QPushButton(value_language)
                self.AssignRole.setObjectName("assign_role")
                self.AssignRole.setFixedSize(135, 35)
                self.AssignRole.setFont(QFont('Inter', 11))
                self.AssignRole.clicked.connect(self.on_click_user_info_menu)
                self.AssignRole.move(0, self.submenu_button_y_position)
                self.submenu_button_y_position += 40
                self.layout.addWidget(self.AssignRole)
                self.layout.setSpacing(2)
                self.layout.setAlignment(QtCore.Qt.AlignTop)
                self.AssignRole.setStyleSheet(
                    "QPushButton { text-align:left;padding-left:11px;border:0px solid "
                    "lightgrey;background-color:black;color:white;border-radius:3px; }")


