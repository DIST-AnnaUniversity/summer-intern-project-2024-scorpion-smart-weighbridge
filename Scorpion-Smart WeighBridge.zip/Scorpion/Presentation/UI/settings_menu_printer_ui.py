from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QLabel, QGraphicsDropShadowEffect, QPushButton, QPlainTextEdit, QComboBox, QLineEdit, \
    QFrame, QCheckBox

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable


class PrinterConfigUI:
    def __init__(self):
        super().__init__()

    def create_printer_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmPrinter = QFrame(self)

            lblPrinterBg = QLabel(self.frmPrinter)
            lblPrinterBg.resize(521, 429)
            lblPrinterBg.setParent(self.frmPrinter)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["printer_components"]["header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(250, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frmPrinter)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.btn_entry = QPushButton()
            self.btn_entry.setObjectName("Entry")
            self.btn_entry.setText(GlobalVariable.language_setting_items["printer_components"]["default"])
            self.btn_entry.setFont(QFont('Inter', 10))
            self.btn_entry.resize(80, 31)
            self.btn_entry.move(220, 5)
            self.btn_entry.clicked.connect(self.on_click_custom_printer)
            self.btn_entry.setParent(self.frmPrinter)

            self.btn_entry.setStyleSheet("QPushButton::disabled"
                                         "{"
                                         "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                         "}"
                                         )

            self.btn_re_entry = QPushButton()
            self.btn_re_entry.setObjectName("ReEntry")
            self.btn_re_entry.setText(GlobalVariable.language_setting_items["printer_components"]["custom"])
            self.btn_re_entry.setFont(QFont('Inter', 10))
            self.btn_re_entry.resize(80, 31)
            self.btn_re_entry.move(300, 5)
            self.btn_re_entry.clicked.connect(self.on_click_custom_printer)
            self.btn_re_entry.setParent(self.frmPrinter)

            self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                            "{"
                                            "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_re_entry.raise_()

            self.lbl_input1_header = QLabel(self.frmPrinter)
            self.lbl_input1_header.setFixedWidth(220)
            self.lbl_input1_header.setFixedHeight(31)
            self.lbl_input1_header.setGeometry(20, 50, 220, 21)
            self.lbl_input1_header.setText("Header1")
            self.lbl_input1_header.setFont(QFont('Inter', 14))
            self.lbl_input1_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input1_header.setParent(self.frmPrinter)

            self.lbl_header1 = QLabel(self.frmPrinter)
            self.lbl_header1.setFixedWidth(151)
            self.lbl_header1.setFixedHeight(21)
            self.lbl_header1.setGeometry(20, 83, 151, 21)
            self.lbl_header1.setText("Header1")
            self.lbl_header1.setFont(QFont('Inter', 14))
            self.lbl_header1.setParent(self.frmPrinter)

            self.chk_header1 = QCheckBox(self.frmPrinter)
            self.chk_header1.setFixedSize(65, 41)
            self.chk_header1.setObjectName("chk_header1")
            self.chk_header1.setText("Entry")
            self.chk_header1.move(190, 79)
            self.chk_header1.setParent(self.frmPrinter)

            self.chk_re_header1 = QCheckBox(self.frmPrinter)
            self.chk_re_header1.setFixedSize(65, 41)
            self.chk_re_header1.setObjectName("chk_re_header1")
            self.chk_re_header1.setText("ReEntry")
            self.chk_re_header1.move(185, 79)
            self.chk_re_header1.setParent(self.frmPrinter)
            self.chk_re_header1.setVisible(False)

            self.lbl_input2_header = QLabel(self.frmPrinter)
            self.lbl_input2_header.setFixedWidth(220)
            self.lbl_input2_header.setFixedHeight(31)
            self.lbl_input2_header.setGeometry(20, 122, 220, 21)
            self.lbl_input2_header.setText("Header2")
            self.lbl_input2_header.setFont(QFont('Inter', 14))
            self.lbl_input2_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input2_header.setParent(self.frmPrinter)

            self.lbl_header2 = QLabel(self.frmPrinter)
            self.lbl_header2.setFixedWidth(151)
            self.lbl_header2.setFixedHeight(21)
            self.lbl_header2.setGeometry(20, 155, 151, 21)
            self.lbl_header2.setText("Header1")
            self.lbl_header2.setFont(QFont('Inter', 14))
            self.lbl_header2.setParent(self.frmPrinter)

            self.chk_header2 = QCheckBox(self.frmPrinter)
            self.chk_header2.setFixedSize(65, 41)
            self.chk_header2.setObjectName("chk_header2")
            self.chk_header2.setText("Entry")
            self.chk_header2.move(190, 148)
            self.chk_header2.setParent(self.frmPrinter)

            self.chk_re_header2 = QCheckBox(self.frmPrinter)
            self.chk_re_header2.setFixedSize(65, 41)
            self.chk_re_header2.setObjectName("chk_re_header2")
            self.chk_re_header2.setText("ReEntry")
            self.chk_re_header2.move(185, 148)
            self.chk_re_header2.setParent(self.frmPrinter)
            self.chk_re_header2.setVisible(False)

            self.lbl_input3_header = QLabel(self.frmPrinter)
            self.lbl_input3_header.setFixedWidth(220)
            self.lbl_input3_header.setFixedHeight(31)
            self.lbl_input3_header.setGeometry(20, 193, 220, 21)
            self.lbl_input3_header.setText("Header3")
            self.lbl_input3_header.setFont(QFont('Inter', 14))
            self.lbl_input3_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input3_header.setParent(self.frmPrinter)

            self.lbl_header3 = QLabel(self.frmPrinter)
            self.lbl_header3.setFixedWidth(151)
            self.lbl_header3.setFixedHeight(21)
            self.lbl_header3.setGeometry(20, 227, 151, 21)
            self.lbl_header3.setText("Header1")
            self.lbl_header3.setFont(QFont('Inter', 14))
            self.lbl_header3.setParent(self.frmPrinter)

            self.chk_header3 = QCheckBox(self.frmPrinter)
            self.chk_header3.setFixedSize(65, 41)
            self.chk_header3.setObjectName("chk_header3")
            self.chk_header3.setText("Entry")
            self.chk_header3.move(190, 220)
            self.chk_header3.setParent(self.frmPrinter)

            self.chk_re_header3 = QCheckBox(self.frmPrinter)
            self.chk_re_header3.setFixedSize(65, 41)
            self.chk_re_header3.setObjectName("chk_re_header3")
            self.chk_re_header3.setText("ReEntry")
            self.chk_re_header3.move(185, 220)
            self.chk_re_header3.setParent(self.frmPrinter)
            self.chk_re_header3.setVisible(False)

            self.lbl_input4_header = QLabel(self.frmPrinter)
            self.lbl_input4_header.setFixedWidth(220)
            self.lbl_input4_header.setFixedHeight(31)
            self.lbl_input4_header.setGeometry(20, 265, 220, 21)
            self.lbl_input4_header.setText("Header4")
            self.lbl_input4_header.setFont(QFont('Inter', 14))
            self.lbl_input4_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input4_header.setParent(self.frmPrinter)

            self.lbl_header4 = QLabel(self.frmPrinter)
            self.lbl_header4.setFixedWidth(151)
            self.lbl_header4.setFixedHeight(21)
            self.lbl_header4.setGeometry(20, 294, 151, 21)
            self.lbl_header4.setText("Header1")
            self.lbl_header4.setFont(QFont('Inter', 14))
            self.lbl_header4.setParent(self.frmPrinter)

            self.chk_header4 = QCheckBox(self.frmPrinter)
            self.chk_header4.setFixedSize(65, 41)
            self.chk_header4.setObjectName("chk_header4")
            self.chk_header4.setText("Entry")
            self.chk_header4.move(190, 287)
            self.chk_header4.setParent(self.frmPrinter)

            self.chk_re_header4 = QCheckBox(self.frmPrinter)
            self.chk_re_header4.setFixedSize(65, 41)
            self.chk_re_header4.setObjectName("chk_re_header4")
            self.chk_re_header4.setText("ReEntry")
            self.chk_re_header4.move(185, 287)
            self.chk_re_header4.setParent(self.frmPrinter)
            self.chk_re_header4.setVisible(False)

            self.lbl_input5_header = QLabel(self.frmPrinter)
            self.lbl_input5_header.setFixedWidth(220)
            self.lbl_input5_header.setFixedHeight(31)
            self.lbl_input5_header.setGeometry(20, 332, 220, 21)
            self.lbl_input5_header.setText("Header5")
            self.lbl_input5_header.setFont(QFont('Inter', 14))
            self.lbl_input5_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input5_header.setParent(self.frmPrinter)

            self.lbl_header5 = QLabel(self.frmPrinter)
            self.lbl_header5.setFixedWidth(151)
            self.lbl_header5.setFixedHeight(21)
            self.lbl_header5.setGeometry(20, 363, 151, 21)
            self.lbl_header5.setText("Header1")
            self.lbl_header5.setFont(QFont('Inter', 14))
            self.lbl_header5.setParent(self.frmPrinter)

            self.chk_header5 = QCheckBox(self.frmPrinter)
            self.chk_header5.setFixedSize(65, 41)
            self.chk_header5.setObjectName("chk_header5")
            self.chk_header5.setText("Entry")
            self.chk_header5.move(190, 358)
            self.chk_header5.setParent(self.frmPrinter)

            self.chk_re_header5 = QCheckBox(self.frmPrinter)
            self.chk_re_header5.setFixedSize(65, 41)
            self.chk_re_header5.setObjectName("chk_re_header5")
            self.chk_re_header5.setText("ReEntry")
            self.chk_re_header5.move(185, 358)
            self.chk_re_header5.setParent(self.frmPrinter)
            self.chk_re_header5.setVisible(False)

            self.lbl_code1_header = QLabel(self.frmPrinter)
            self.lbl_code1_header.setFixedWidth(220)
            self.lbl_code1_header.setFixedHeight(31)
            self.lbl_code1_header.setGeometry(275, 50, 220, 21)
            self.lbl_code1_header.setText("Code1")
            self.lbl_code1_header.setFont(QFont('Inter', 14))
            self.lbl_code1_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code1_header.setParent(self.frmPrinter)

            self.lbl_code1 = QLabel(self.frmPrinter)
            self.lbl_code1.setFixedWidth(151)
            self.lbl_code1.setFixedHeight(21)
            self.lbl_code1.setGeometry(275, 83, 151, 21)
            self.lbl_code1.setText("Code1")
            self.lbl_code1.setFont(QFont('Inter', 14))
            self.lbl_code1.setParent(self.frmPrinter)

            self.chk_code1 = QCheckBox(self.frmPrinter)
            self.chk_code1.setFixedSize(65, 41)
            self.chk_code1.setObjectName("chk_code1")
            self.chk_code1.setText("Entry")
            self.chk_code1.move(440, 79)
            self.chk_code1.setParent(self.frmPrinter)

            self.chk_re_code1 = QCheckBox(self.frmPrinter)
            self.chk_re_code1.setFixedSize(68, 41)
            self.chk_re_code1.setObjectName("chk_re_code1")
            self.chk_re_code1.setText("ReEntry")
            self.chk_re_code1.move(435, 79)
            self.chk_re_code1.setParent(self.frmPrinter)
            self.chk_re_code1.setVisible(False)

            self.lbl_code2_header = QLabel(self.frmPrinter)
            self.lbl_code2_header.setFixedWidth(220)
            self.lbl_code2_header.setFixedHeight(31)
            self.lbl_code2_header.setGeometry(275, 122, 220, 21)
            self.lbl_code2_header.setText("Code2")
            self.lbl_code2_header.setFont(QFont('Inter', 14))
            self.lbl_code2_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code2_header.setParent(self.frmPrinter)

            self.lbl_code2 = QLabel(self.frmPrinter)
            self.lbl_code2.setFixedWidth(151)
            self.lbl_code2.setFixedHeight(21)
            self.lbl_code2.setGeometry(275, 155, 151, 21)
            self.lbl_code2.setText("Code2")
            self.lbl_code2.setFont(QFont('Inter', 14))
            self.lbl_code2.setParent(self.frmPrinter)

            self.chk_code2 = QCheckBox(self.frmPrinter)
            self.chk_code2.setFixedSize(65, 41)
            self.chk_code2.setObjectName("chk_code2")
            self.chk_code2.setText("Entry")
            self.chk_code2.move(440, 148)
            self.chk_code2.setParent(self.frmPrinter)

            self.chk_re_code2 = QCheckBox(self.frmPrinter)
            self.chk_re_code2.setFixedSize(68, 41)
            self.chk_re_code2.setObjectName("chk_re_code2")
            self.chk_re_code2.setText("ReEntry")
            self.chk_re_code2.move(435, 148)
            self.chk_re_code2.setParent(self.frmPrinter)
            self.chk_re_code2.setVisible(False)

            self.lbl_code3_header = QLabel(self.frmPrinter)
            self.lbl_code3_header.setFixedWidth(220)
            self.lbl_code3_header.setFixedHeight(31)
            self.lbl_code3_header.setGeometry(275, 193, 220, 21)
            self.lbl_code3_header.setText("Code3")
            self.lbl_code3_header.setFont(QFont('Inter', 14))
            self.lbl_code3_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code3_header.setParent(self.frmPrinter)

            self.lbl_code3 = QLabel(self.frmPrinter)
            self.lbl_code3.setFixedWidth(151)
            self.lbl_code3.setFixedHeight(21)
            self.lbl_code3.setGeometry(275, 227, 151, 21)
            self.lbl_code3.setText("Code3")
            self.lbl_code3.setFont(QFont('Inter', 14))
            self.lbl_code3.setParent(self.frmPrinter)

            self.chk_code3 = QCheckBox(self.frmPrinter)
            self.chk_code3.setFixedSize(65, 41)
            self.chk_code3.setObjectName("chk_code3")
            self.chk_code3.setText("Entry")
            self.chk_code3.move(440, 220)
            self.chk_code3.setParent(self.frmPrinter)

            self.chk_re_code3 = QCheckBox(self.frmPrinter)
            self.chk_re_code3.setFixedSize(68, 41)
            self.chk_re_code3.setObjectName("chk_re_code3")
            self.chk_re_code3.setText("ReEntry")
            self.chk_re_code3.move(435, 220)
            self.chk_re_code3.setParent(self.frmPrinter)
            self.chk_re_code3.setVisible(False)

            self.lbl_code4_header = QLabel(self.frmPrinter)
            self.lbl_code4_header.setFixedWidth(220)
            self.lbl_code4_header.setFixedHeight(31)
            self.lbl_code4_header.setGeometry(275, 265, 220, 21)
            self.lbl_code4_header.setText("Code4")
            self.lbl_code4_header.setFont(QFont('Inter', 14))
            self.lbl_code4_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code4_header.setParent(self.frmPrinter)

            self.lbl_code4 = QLabel(self.frmPrinter)
            self.lbl_code4.setFixedWidth(151)
            self.lbl_code4.setFixedHeight(21)
            self.lbl_code4.setGeometry(275, 294, 151, 21)
            self.lbl_code4.setText("Code4")
            self.lbl_code4.setFont(QFont('Inter', 14))
            self.lbl_code4.setParent(self.frmPrinter)

            self.chk_code4 = QCheckBox(self.frmPrinter)
            self.chk_code4.setFixedSize(65, 41)
            self.chk_code4.setObjectName("chk_code4")
            self.chk_code4.setText("Entry")
            self.chk_code4.move(440, 287)
            self.chk_code4.setParent(self.frmPrinter)

            self.chk_re_code4 = QCheckBox(self.frmPrinter)
            self.chk_re_code4.setFixedSize(68, 41)
            self.chk_re_code4.setObjectName("chk_re_code4")
            self.chk_re_code4.setText("ReEntry")
            self.chk_re_code4.move(435, 287)
            self.chk_re_code4.setParent(self.frmPrinter)
            self.chk_re_code4.setVisible(False)

            self.lbl_code5_header = QLabel(self.frmPrinter)
            self.lbl_code5_header.setFixedWidth(220)
            self.lbl_code5_header.setFixedHeight(31)
            self.lbl_code5_header.setGeometry(275, 332, 220, 21)
            self.lbl_code5_header.setText("Code5")
            self.lbl_code5_header.setFont(QFont('Inter', 14))
            self.lbl_code5_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code5_header.setParent(self.frmPrinter)

            self.lbl_code5 = QLabel(self.frmPrinter)
            self.lbl_code5.setFixedWidth(151)
            self.lbl_code5.setFixedHeight(21)
            self.lbl_code5.setGeometry(275, 363, 151, 21)
            self.lbl_code5.setText("Code5")
            self.lbl_code5.setFont(QFont('Inter', 14))
            self.lbl_code5.setParent(self.frmPrinter)

            self.chk_code5 = QCheckBox(self.frmPrinter)
            self.chk_code5.setFixedSize(65, 41)
            self.chk_code5.setObjectName("chk_code5")
            self.chk_code5.setText("Entry")
            self.chk_code5.move(440, 358)
            self.chk_code5.setParent(self.frmPrinter)

            self.chk_re_code5 = QCheckBox(self.frmPrinter)
            self.chk_re_code5.setFixedSize(68, 41)
            self.chk_re_code5.setObjectName("chk_re_code5")
            self.chk_re_code5.setText("ReEntry")
            self.chk_re_code5.move(435, 358)
            self.chk_re_code5.setParent(self.frmPrinter)
            self.chk_re_code5.setVisible(False)

            self.btn_printer_edit = QPushButton()
            self.btn_printer_edit.resize(42, 42)
            self.btn_printer_edit.move(395, 0)
            self.btn_printer_edit.clicked.connect(self.on_click_printer_edit)
            self.btn_printer_edit.setParent(self.frmPrinter)
            self.btn_printer_edit.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                       "/Edit.png); "
                                                                                       "border : none "
                                                                                       "}"

                                                                                       "QPushButton::disabled"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "

                                                )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_printer_edit.setGraphicsEffect(shadow)

            self.btn_printer_save = QPushButton()
            self.btn_printer_save.resize(42, 42)
            self.btn_printer_save.move(450, 0)
            self.btn_printer_save.clicked.connect(self.on_click_printer_save)
            self.btn_printer_save.setParent(self.frmPrinter)
            self.btn_printer_save.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                       "/Save.png); "
                                                                                       "border : none "
                                                                                       "}"
                                                                                       "QPushButton::hover"
                                                                                       "{"
                                                                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                              "}"
                                                                                                                              "QPushButton::disabled"
                                                                                                                              "{"
                                                                                                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                                )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_printer_save.setGraphicsEffect(shadow)
            self.btn_printer_save.raise_()

            self.label_controls = [self.lbl_header1, self.lbl_header2, self.lbl_header3, self.lbl_header4,
                                   self.lbl_header5,
                                   self.lbl_code1, self.lbl_code2, self.lbl_code3, self.lbl_code4, self.lbl_code5]
            for labels in range(len(self.label_controls)):
                UiComponents.label_default_stylesheet(self.label_controls[labels])

            self.lbl_header1_status = QLabel()
            self.lbl_header1_status.resize(21, 21)
            self.lbl_header1_status.move(150, 50)
            self.lbl_header1_status.setParent(self.frmPrinter)

            self.lbl_header2_status = QLabel()
            self.lbl_header2_status.resize(21, 21)
            self.lbl_header2_status.move(150, 122)
            self.lbl_header2_status.setParent(self.frmPrinter)

            self.lbl_header3_status = QLabel()
            self.lbl_header3_status.resize(21, 21)
            self.lbl_header3_status.move(150, 193)
            self.lbl_header3_status.setParent(self.frmPrinter)

            self.lbl_header4_status = QLabel()
            self.lbl_header4_status.resize(21, 21)
            self.lbl_header4_status.move(150, 265)
            self.lbl_header4_status.setParent(self.frmPrinter)

            self.lbl_header5_status = QLabel()
            self.lbl_header5_status.resize(21, 21)
            self.lbl_header5_status.move(150, 330)
            self.lbl_header5_status.setParent(self.frmPrinter)

            self.lbl_code1_status = QLabel()
            self.lbl_code1_status.resize(21, 21)
            self.lbl_code1_status.move(440, 50)
            self.lbl_code1_status.setParent(self.frmPrinter)

            self.lbl_code2_status = QLabel()
            self.lbl_code2_status.resize(21, 21)
            self.lbl_code2_status.move(440, 122)
            self.lbl_code2_status.setParent(self.frmPrinter)

            self.lbl_code3_status = QLabel()
            self.lbl_code3_status.resize(21, 21)
            self.lbl_code3_status.move(440, 193)
            self.lbl_code3_status.setParent(self.frmPrinter)

            self.lbl_code4_status = QLabel()
            self.lbl_code4_status.resize(21, 21)
            self.lbl_code4_status.move(440, 265)
            self.lbl_code4_status.setParent(self.frmPrinter)

            self.lbl_code5_status = QLabel()
            self.lbl_code5_status.resize(21, 21)
            self.lbl_code5_status.move(440, 330)
            self.lbl_code5_status.setParent(self.frmPrinter)

            self.label_status.clear()
            self.label_status.append(self.lbl_header1_status)
            self.label_status.append(self.lbl_header2_status)
            self.label_status.append(self.lbl_header3_status)
            self.label_status.append(self.lbl_header4_status)
            self.label_status.append(self.lbl_header5_status)

            self.label_status.append(self.lbl_code1_status)
            self.label_status.append(self.lbl_code2_status)
            self.label_status.append(self.lbl_code3_status)
            self.label_status.append(self.lbl_code4_status)
            self.label_status.append(self.lbl_code5_status)

            GlobalEntities.print_entry_header.clear()
            GlobalEntities.print_reentry_header.clear()
            GlobalEntities.print_entry_header.append(self.chk_header1)
            GlobalEntities.print_entry_header.append(self.chk_header2)
            GlobalEntities.print_entry_header.append(self.chk_header3)
            GlobalEntities.print_entry_header.append(self.chk_header4)
            GlobalEntities.print_entry_header.append(self.chk_header5)

            GlobalEntities.print_reentry_header.append(self.chk_re_header1)
            GlobalEntities.print_reentry_header.append(self.chk_re_header2)
            GlobalEntities.print_reentry_header.append(self.chk_re_header3)
            GlobalEntities.print_reentry_header.append(self.chk_re_header4)
            GlobalEntities.print_reentry_header.append(self.chk_re_header5)

            GlobalEntities.print_entry_code.clear()
            GlobalEntities.print_reentry_code.clear()
            GlobalEntities.print_entry_code.append(self.chk_code1)
            GlobalEntities.print_entry_code.append(self.chk_code2)
            GlobalEntities.print_entry_code.append(self.chk_code3)
            GlobalEntities.print_entry_code.append(self.chk_code4)
            GlobalEntities.print_entry_code.append(self.chk_code5)

            GlobalEntities.print_reentry_code.append(self.chk_re_code1)
            GlobalEntities.print_reentry_code.append(self.chk_re_code2)
            GlobalEntities.print_reentry_code.append(self.chk_re_code3)
            GlobalEntities.print_reentry_code.append(self.chk_re_code4)
            GlobalEntities.print_reentry_code.append(self.chk_re_code5)

            self.chk_header1.setChecked(True)
            self.chk_re_header1.setChecked(True)
            self.chk_code1.setChecked(True)
            self.chk_re_code1.setChecked(True)

            GlobalEntities.header_params_checkbox = {"chk_header1": "1", "chk_header2": "0", "chk_header3": "0",
                                                     "chk_header4": "0",
                                                     "chk_header5": "0", "chk_re_header1": "1", "chk_re_header2": "0",
                                                     "chk_re_header3": "0",
                                                     "chk_re_header4": "0",
                                                     "chk_re_header5": "0", "chk_code1": "1", "chk_code2": "0",
                                                     "chk_code3": "0",
                                                     "chk_code4": "0",
                                                     "chk_code5": "0", "chk_re_code1": "1", "chk_re_code2": "0",
                                                     "chk_re_code3": "0",
                                                     "chk_re_code4": "0",
                                                     "chk_re_code5": "0"}
            for i in range(len(GlobalEntities.print_entry_header)):
                GlobalEntities.print_entry_header[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )
            for i in range(len(GlobalEntities.print_reentry_header)):
                GlobalEntities.print_reentry_header[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )
            for i in range(len(GlobalEntities.print_entry_code)):
                GlobalEntities.print_entry_code[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )
            for i in range(len(GlobalEntities.print_reentry_code)):
                GlobalEntities.print_reentry_code[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )


            self.HorizontalLyt.addWidget(self.frmPrinter)
            pass
        except Exception as e:
            print(e)
