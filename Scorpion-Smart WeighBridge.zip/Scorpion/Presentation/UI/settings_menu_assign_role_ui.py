from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QAbstractItemView, QTableWidget, QLabel, QFrame

from Presentation.Bundles.UiConfiguration import ROOT_PATH


class SettingsAssignRole:
    def __init__(self):
        super().__init__()

    def create_assign_role_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmAssignRole = QFrame(self)

            self.lblProfileHeader1 = QLabel()
            self.lblProfileHeader1.setText("Assign User Role")
            self.lblProfileHeader1.move(10, 1)
            self.lblProfileHeader1.resize(261, 31)
            self.lblProfileHeader1.setParent(self.frmAssignRole)
            self.lblProfileHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;background-color:transparent")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblProfileHeader1.setGraphicsEffect(shadow)

            lblAssignRoleBg = QLabel(self.frmAssignRole)
            lblAssignRoleBg.resize(760, 693)
            lblAssignRoleBg.setParent(self.frmAssignRole)

            self.lblAssignRole = QLabel()
            self.lblAssignRole.setFont(QFont('Inter', 10))
            self.lblAssignRole.setStyleSheet("color:white;border:0px solid grey;")
            self.lblAssignRole.resize(135, 21)
            self.lblAssignRole.move(557, 20)
            self.lblAssignRole.setParent(self.frmAssignRole)
            self.lblAssignRole.raise_()

            self.lblAssignRoleMsg = QLabel()
            self.lblAssignRoleMsg.setFont(QFont('Inter', 10))
            self.lblAssignRoleMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblAssignRoleMsg.resize(151, 41)
            self.lblAssignRoleMsg.move(550, 10)
            self.lblAssignRoleMsg.setParent(self.frmAssignRole)
            self.lblAssignRoleMsg.raise_()

            self.dgvDisplayUserDetails = QTableWidget()
            self.dgvDisplayUserDetails.resize(490, 330)
            self.dgvDisplayUserDetails.move(10, 50)
            self.dgvDisplayUserDetails.setStyleSheet("border:1px solid lightgrey;")
            self.dgvDisplayUserDetails.setParent(self.frmAssignRole)
            self.dgvDisplayUserDetails.setEditTriggers(QAbstractItemView.NoEditTriggers)

            self.btnAssignRoleEdit = QPushButton()
            self.btnAssignRoleEdit.resize(42, 42)
            self.btnAssignRoleEdit.move(430, 0)
            self.btnAssignRoleEdit.clicked.connect(self.On_Click_AssignRoleEdit)
            self.btnAssignRoleEdit.setParent(self.frmAssignRole)
            self.btnAssignRoleEdit.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                        "/Edit.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditHover.png); "
                                                                                                                               "}"
                                                                                                                               "QPushButton::disabled"
                                                                                                                               "{"
                                                                                                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditDisable.png); "

                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnAssignRoleEdit.setGraphicsEffect(shadow)

            self.HorizontalLyt.addWidget(self.frmAssignRole)
            pass
        except Exception as e:
            print(e)