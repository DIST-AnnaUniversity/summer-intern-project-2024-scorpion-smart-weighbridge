from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QComboBox, QPlainTextEdit

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable

class SettingAdvantagesUi:
    def __init__(self):
        super().__init__()

    def create_advantages_ui(self):
        try:
            for i in reversed(range(self.hlyt_main.count())):
                self.hlyt_main.itemAt(i).widget().deleteLater()

            self.frmAdvantages = QFrame(self)

            self.lblAdvantageBg = QLabel(self.frmAdvantages)
            self.lblAdvantageBg.resize(980, 670)
            self.lblAdvantageBg.setParent(self.frmAdvantages)
            self.lblAdvantageBg.setStyleSheet("QLabel"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AdvantageBg.png); "
                                                                                     "border : none "
                                                                                     "}"
                                              )

            self.lblTruckLoading = QLabel()
            self.lblTruckLoading.setText(
                GlobalVariable.language_setting_items["advantage_components"]["advantage_header_4"])
            self.lblTruckLoading.setStyleSheet("border:0px solid lightgrey;color:black;font:25px Regular Inter;")
            self.lblTruckLoading.move(15, 17)
            self.lblTruckLoading.resize(250, 31)
            self.lblTruckLoading.setParent(self.frmAdvantages)

            self.btnMobileNotifON = QPushButton()
            self.btnMobileNotifON.resize(62, 32)
            self.btnMobileNotifON.setObjectName("MobileON")
            self.btnMobileNotifON.move(320, 17)
            self.btnMobileNotifON.clicked.connect(self.on_click_advantages_menu_status)
            self.btnMobileNotifON.setStyleSheet("border:0px solid lightgrey;")
            self.btnMobileNotifON.setParent(self.frmAdvantages)
            self.btnMobileNotifON.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                       "border : none ;"
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnMobileNotifON.setGraphicsEffect(shadow)

            self.btnMobileNotifOFF = QPushButton()
            self.btnMobileNotifOFF.resize(62, 32)
            self.btnMobileNotifOFF.setObjectName("MobileOFF")
            self.btnMobileNotifOFF.move(320, 17)
            self.btnMobileNotifOFF.clicked.connect(self.on_click_advantages_menu_status)
            self.btnMobileNotifOFF.setParent(self.frmAdvantages)
            self.btnMobileNotifOFF.setStyleSheet("border:0px solid lightgrey;")
            self.btnMobileNotifOFF.raise_()
            self.btnMobileNotifOFF.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnMobileNotifOFF.setGraphicsEffect(shadow)

            self.lbl_windows_header = QLabel()
            self.lbl_windows_header.move(8, 65)
            self.lbl_windows_header.resize(760, 1)
            self.lbl_windows_header.setStyleSheet("border-bottom:1px solid grey;border-style : dashed")
            self.lbl_windows_header.setParent(self.frmAdvantages)

            self.lblCloudStorage = QLabel()
            self.lblCloudStorage.setText(
                GlobalVariable.language_setting_items["advantage_components"]["advantage_header_1"])
            self.lblCloudStorage.setStyleSheet("border:0px solid lightgrey;color:black;font:25px Regular Inter;")
            self.lblCloudStorage.move(15, 90)
            self.lblCloudStorage.resize(221, 31)
            self.lblCloudStorage.setParent(self.frmAdvantages)

            self.btnCloudStorageON = QPushButton()
            self.btnCloudStorageON.resize(62, 32)
            self.btnCloudStorageON.setObjectName("CloudStorageON")
            self.btnCloudStorageON.move(320, 90)
            self.btnCloudStorageON.clicked.connect(self.on_click_advantages_menu_status)
            self.btnCloudStorageON.setParent(self.frmAdvantages)
            self.btnCloudStorageON.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCloudStorageON.setGraphicsEffect(shadow)
            self.btnCloudStorageON.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )

            self.btnCloudStorageOFF = QPushButton()
            self.btnCloudStorageOFF.resize(62, 32)
            self.btnCloudStorageOFF.setObjectName("CloudStorageOFF")
            self.btnCloudStorageOFF.move(320, 90)
            self.btnCloudStorageOFF.clicked.connect(self.on_click_advantages_menu_status)
            self.btnCloudStorageOFF.setParent(self.frmAdvantages)
            self.btnCloudStorageOFF.setStyleSheet("border:0px solid lightgrey;")
            self.btnCloudStorageOFF.raise_()
            self.btnCloudStorageOFF.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                         "border : none; "
                                                                                         "background-color:transparent;"
                                                                                         "}"
                                                  )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCloudStorageOFF.setGraphicsEffect(shadow)

            self.lbl2 = QLabel()
            self.lbl2.setText("No Network found ... ")
            self.lbl2.setStyleSheet("border:0px solid lightgrey;color:red;font: 14px Regular Inter;")
            self.lbl2.move(20, 152)
            self.lbl2.resize(221, 31)
            self.lbl2.setParent(self.frmAdvantages)
            self.lbl2.setVisible(False)

            self.lbl_windows_header = QLabel()
            self.lbl_windows_header.move(8, 140)
            self.lbl_windows_header.resize(760, 1)
            self.lbl_windows_header.setStyleSheet("border-bottom:1px solid grey;border-style : dashed")
            self.lbl_windows_header.setParent(self.frmAdvantages)

            self.lblRemoteConfig = QLabel()
            self.lblRemoteConfig.setText(
                GlobalVariable.language_setting_items["advantage_components"]["advantage_header_2"])
            self.lblRemoteConfig.setStyleSheet("border:0px solid lightgrey;color:black;font:25px Regular Inter;")
            self.lblRemoteConfig.move(15, 165)
            self.lblRemoteConfig.resize(221, 31)
            self.lblRemoteConfig.setParent(self.frmAdvantages)

            self.btnRemoteConfigON = QPushButton()
            self.btnRemoteConfigON.resize(62, 32)
            self.btnRemoteConfigON.setObjectName("RemoteConfigON")
            self.btnRemoteConfigON.move(320, 165)
            self.btnRemoteConfigON.clicked.connect(self.on_click_advantages_menu_status)
            self.btnRemoteConfigON.setParent(self.frmAdvantages)
            self.btnRemoteConfigON.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnRemoteConfigON.setGraphicsEffect(shadow)

            self.btnRemoteConfigOFF = QPushButton()
            self.btnRemoteConfigOFF.resize(62, 32)
            self.btnRemoteConfigOFF.setObjectName("RemoteConfigOFF")
            self.btnRemoteConfigOFF.move(320, 165)
            self.btnRemoteConfigOFF.clicked.connect(self.on_click_advantages_menu_status)
            self.btnRemoteConfigOFF.setParent(self.frmAdvantages)
            self.btnRemoteConfigOFF.raise_()
            self.btnRemoteConfigOFF.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                         "border : none; "
                                                                                         "background-color:transparent;"
                                                                                         "}"
                                                  )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnRemoteConfigOFF.setGraphicsEffect(shadow)

            self.lbl_windows_header = QLabel()
            self.lbl_windows_header.move(8, 215)
            self.lbl_windows_header.resize(760, 1)
            self.lbl_windows_header.setStyleSheet("border-bottom:1px solid grey;border-style : dashed")
            self.lbl_windows_header.setParent(self.frmAdvantages)

            self.lbl_voice_assist = QLabel()
            self.lbl_voice_assist.setText(
                GlobalVariable.language_setting_items["advantage_components"]["advantage_header_9"])
            self.lbl_voice_assist.setStyleSheet("border:0px solid lightgrey;color:black;font:25px Regular Inter;")
            self.lbl_voice_assist.move(15, 240)
            self.lbl_voice_assist.resize(221, 31)
            self.lbl_voice_assist.setParent(self.frmAdvantages)

            self.btn_voice_on = QPushButton()
            self.btn_voice_on.resize(62, 32)
            self.btn_voice_on.setObjectName("VoiceON")
            self.btn_voice_on.move(320, 240)
            self.btn_voice_on.clicked.connect(self.on_click_advantages_menu_status)
            self.btn_voice_on.setParent(self.frmAdvantages)
            self.btn_voice_on.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                   "border : none ;"
                                                                                   "background-color:transparent;"
                                                                                   "}"
                                            )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_voice_on.setGraphicsEffect(shadow)

            self.btn_voice_off = QPushButton()
            self.btn_voice_off.resize(62, 32)
            self.btn_voice_off.setObjectName("VoiceOFF")
            self.btn_voice_off.move(320, 240)
            self.btn_voice_off.clicked.connect(self.on_click_advantages_menu_status)
            self.btn_voice_off.setParent(self.frmAdvantages)
            self.btn_voice_off.raise_()
            self.btn_voice_off.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                    "border : none; "
                                                                                    "background-color:transparent;"
                                                                                    "}"
                                             )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_voice_off.setGraphicsEffect(shadow)

            self.lbl_windows_header = QLabel()
            self.lbl_windows_header.move(8, 285)
            self.lbl_windows_header.resize(760, 1)
            self.lbl_windows_header.setStyleSheet("border-bottom:1px solid grey;border-style : dashed")
            self.lbl_windows_header.setParent(self.frmAdvantages)

            self.lbl_camera = QLabel()
            self.lbl_camera.setText("Camera Settings")
            self.lbl_camera.setStyleSheet("border:0px solid lightgrey;color:black;font:25px Regular Inter;")
            self.lbl_camera.move(15, 310)
            self.lbl_camera.resize(221, 31)
            self.lbl_camera.setParent(self.frmAdvantages)

            self.btnCameraSetON = QPushButton()
            self.btnCameraSetON.resize(62, 32)
            self.btnCameraSetON.setObjectName("CameraON")
            self.btnCameraSetON.move(320, 310)
            self.btnCameraSetON.clicked.connect(self.on_click_advantages_menu_status)
            self.btnCameraSetON.setStyleSheet("border:0px solid lightgrey;")
            self.btnCameraSetON.setParent(self.frmAdvantages)
            self.btnCameraSetON.setStyleSheet("QPushButton"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                     "border : none ;"
                                                                                     "background-color:transparent;"
                                                                                     "}"
                                              )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCameraSetON.setGraphicsEffect(shadow)

            self.btnCameraSetOFF = QPushButton()
            self.btnCameraSetOFF.resize(62, 32)
            self.btnCameraSetOFF.setObjectName("CameraOFF")
            self.btnCameraSetOFF.move(320, 310)
            self.btnCameraSetOFF.clicked.connect(self.on_click_advantages_menu_status)
            self.btnCameraSetOFF.setParent(self.frmAdvantages)
            self.btnCameraSetOFF.setStyleSheet("border:0px solid lightgrey;")
            self.btnCameraSetOFF.raise_()
            self.btnCameraSetOFF.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                      "border : none ;"
                                                                                      "background-color:transparent;"
                                                                                      "}"
                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCameraSetOFF.setGraphicsEffect(shadow)

            self.hlyt_main.addWidget(self.frmAdvantages)
            pass
        except Exception as e:
            print(e)
