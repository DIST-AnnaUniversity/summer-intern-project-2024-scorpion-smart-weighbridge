from PyQt5 import QtCore
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QLabel, QComboBox, QLineEdit, QGraphicsDropShadowEffect, QPushButton, QFrame, QHBoxLayout, \
    QVBoxLayout

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable
from PyQt5.QtGui import QDoubleValidator


class CalibrationMenuUI:
    def __init__(self):
        super().__init__()

    def create_calibration_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            calibration_layout = QVBoxLayout()
            label = QLabel()
            label.resize(521, 693)
            label.move(510, 77)
            label.setStyleSheet("QLabel"
                                "{"
                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalibrationBg.png); "
                                                                       "border : none "
                                                                       "}"
                                )

            horizontalLayout = QHBoxLayout()
            self.frmCalibration = QFrame()
            self.frmCalibration.move(510, 77)
            self.frmCalibration.setFixedSize(521, 429)
            horizontalLayout.addWidget(self.frmCalibration)

            self.lblHeader = QLabel()
            self.lblHeader.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calibration_header"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(211, 31)
            self.lblHeader.move(0, 0)
            self.lblHeader.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)



            self.btnEditCalibration = QPushButton()
            self.btnEditCalibration.resize(42, 42)
            self.btnEditCalibration.move(270, 1)
            self.btnEditCalibration.clicked.connect(self.on_click_edit_calibration)
            self.btnEditCalibration.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnEditCalibration.setGraphicsEffect(shadow)

            self.btnCalReset = QPushButton()
            self.btnCalReset.resize(42, 42)
            self.btnCalReset.move(322, 1)
            self.btnCalReset.clicked.connect(self.on_click_reset_calibration)
            self.btnCalReset.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCalReset.setGraphicsEffect(shadow)

            self.btnCalSave = QPushButton()
            self.btnCalSave.resize(72, 42)
            self.btnCalSave.move(370, 1)
            self.btnCalSave.clicked.connect(self.on_click_save_calibration)
            self.btnCalSave.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCalSave.setGraphicsEffect(shadow)
            self.btnCalSave.setEnabled(False)

            self.lblDecimalPointStatus = QLabel()
            self.lblDecimalPointStatus.resize(31, 31)
            self.lblDecimalPointStatus.move(184, 60)
            self.lblDecimalPointStatus.setParent(self.frmCalibration)

            self.lblDecimalPoint = QLabel()
            self.lblDecimalPoint.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calib_header_1"])
            self.lblDecimalPoint.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblDecimalPoint.resize(161, 21)
            self.lblDecimalPoint.move(10, 60)
            self.lblDecimalPoint.setParent(self.frmCalibration)

            self.cmbDecimalPoint = QComboBox()
            self.cmbDecimalPoint.setFont(QFont('Inter', 12))
            self.cmbDecimalPoint.resize(171, 31)
            self.cmbDecimalPoint.move(10, 90)
            self.cmbDecimalPoint.setParent(self.frmCalibration)
            self.cmbDecimalPoint.activated[str].connect(self.on_changed_decimal)

            self.lblMaxCapacity = QLabel()
            self.lblMaxCapacity.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calib_header_2"])
            self.lblMaxCapacity.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblMaxCapacity.resize(161, 21)
            self.lblMaxCapacity.move(10, 123)
            self.lblMaxCapacity.setParent(self.frmCalibration)

            self.lblMaxCapacityStatus = QLabel()
            self.lblMaxCapacityStatus.resize(31, 31)
            self.lblMaxCapacityStatus.move(184, 130)
            self.lblMaxCapacityStatus.setParent(self.frmCalibration)

            self.txtMaxCapacity = QLineEdit()
            self.txtMaxCapacity.setFont(QFont('Inter', 12))
            self.txtMaxCapacity.setMaxLength(7)
            self.txtMaxCapacity.resize(171, 31)
            self.txtMaxCapacity.move(10, 150)
            self.txtMaxCapacity.setParent(self.frmCalibration)
            self.txtMaxCapacity.setValidator(QDoubleValidator())
            UiComponents.textbox_default_stylesheet(self.txtMaxCapacity)

            self.lblCalZeroStatus = QLabel()
            self.lblCalZeroStatus.resize(31, 31)
            self.lblCalZeroStatus.move(187, 198)
            self.lblCalZeroStatus.setParent(self.frmCalibration)

            self.lblCalZero = QLabel()
            self.lblCalZero.setText(GlobalVariable.language_setting_items["calibration_components"]["calib_header_3"])
            self.lblCalZero.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblCalZero.resize(161, 21)
            self.lblCalZero.move(20, 195)
            self.lblCalZero.setParent(self.frmCalibration)

            self.txtCalZero = QLineEdit()
            self.txtCalZero.setFont(QFont('Inter', 12))
            self.txtCalZero.setMaxLength(6)
            self.txtCalZero.resize(171, 31)
            self.txtCalZero.move(20, 221)
            self.txtCalZero.setParent(self.frmCalibration)
            UiComponents.textbox_default_stylesheet(self.txtCalZero)

            self.btnApplyCalZero = QPushButton()
            self.btnApplyCalZero.resize(42, 42)
            self.btnApplyCalZero.move(230, 210)
            self.btnApplyCalZero.clicked.connect(self.on_click_ApplyCalZero)
            self.btnApplyCalZero.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnApplyCalZero.setGraphicsEffect(shadow)

            self.lblCalSpanStatus = QLabel()
            self.lblCalSpanStatus.resize(31, 31)
            self.lblCalSpanStatus.move(190, 260)
            self.lblCalSpanStatus.setParent(self.frmCalibration)

            self.lblCalSpan = QLabel()
            self.lblCalSpan.setText(GlobalVariable.language_setting_items["calibration_components"]["calib_header_4"])
            self.lblCalSpan.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblCalSpan.resize(161, 21)
            self.lblCalSpan.move(20, 255)
            self.lblCalSpan.setParent(self.frmCalibration)

            self.txtCalSpan = QLineEdit()
            self.txtCalSpan.setFont(QFont('Inter', 12))
            self.txtCalSpan.setMaxLength(6)
            self.txtCalSpan.resize(171, 31)
            self.txtCalSpan.move(20, 281)
            self.txtCalSpan.setParent(self.frmCalibration)
            UiComponents.textbox_default_stylesheet(self.txtCalSpan)

            self.btnApplyCalSpan = QPushButton()
            self.btnApplyCalSpan.resize(42, 42)
            self.btnApplyCalSpan.move(230, 264)
            self.btnApplyCalSpan.clicked.connect(self.on_click_ApplyCalSpan)
            self.btnApplyCalSpan.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnApplyCalSpan.setGraphicsEffect(shadow)

            self.lblCalCapacityStatus = QLabel()
            self.lblCalCapacityStatus.resize(31, 31)
            self.lblCalCapacityStatus.move(190, 321)
            self.lblCalCapacityStatus.setParent(self.frmCalibration)

            self.lblCalCapacity = QLabel()
            self.lblCalCapacity.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calib_header_5"])
            self.lblCalCapacity.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblCalCapacity.resize(161, 21)
            self.lblCalCapacity.move(20, 320)
            self.lblCalCapacity.setParent(self.frmCalibration)

            self.txtCalCapacity = QLineEdit()
            self.txtCalCapacity.setFont(QFont('Inter', 12))
            self.txtCalCapacity.setMaxLength(7)
            self.txtCalCapacity.resize(171, 31)
            self.txtCalCapacity.move(20, 345)
            self.txtCalCapacity.setParent(self.frmCalibration)
            self.txtCalCapacity.setValidator(QDoubleValidator())
            UiComponents.textbox_default_stylesheet(self.txtCalCapacity)

            self.lblResolutionStatus = QLabel()
            self.lblResolutionStatus.resize(31, 31)
            self.lblResolutionStatus.move(477, 60)
            self.lblResolutionStatus.setParent(self.frmCalibration)

            self.lblResolution = QLabel()
            self.lblResolution.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calib_header_6"])
            self.lblResolution.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblResolution.resize(161, 21)
            self.lblResolution.move(298, 60)
            self.lblResolution.setParent(self.frmCalibration)

            self.cmbResolution = QComboBox()
            self.cmbResolution.setFont(QFont('Inter', 12))
            self.cmbResolution.resize(171, 31)
            self.cmbResolution.move(297, 89)
            self.cmbResolution.setParent(self.frmCalibration)

            self.lblUnit = QLabel()
            self.lblUnit.setText(GlobalVariable.language_setting_items["calibration_components"]["calib_header_7"])
            self.lblUnit.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblUnit.resize(161, 21)
            self.lblUnit.move(3000000, 123)
            self.lblUnit.setParent(self.frmCalibration)

            self.lblUnitStatus = QLabel()
            self.lblUnitStatus.resize(31, 31)
            self.lblUnitStatus.move(477, 130)
            self.lblUnitStatus.setParent(self.frmCalibration)

            self.cmbUnit = QComboBox()
            self.cmbUnit.setFont(QFont('Inter', 12))
            self.cmbUnit.resize(171, 31)
            self.cmbUnit.move(299000000, 150)
            self.cmbUnit.setParent(self.frmCalibration)

            self.lblBg = QLabel()
            self.lblBg.setFont(QFont('Inter', 30))
            self.lblBg.setStyleSheet("background-color:#f8f8f8;")
            self.lblBg.resize(502, 193)
            self.lblBg.move(10, 191)
            self.lblBg.setParent(self.frmCalibration)
            self.lblBg.lower()

            self.lblRawADC = QLabel()
            self.lblRawADC.setText(GlobalVariable.language_setting_items["calibration_components"]["calib_header_8"])
            self.lblRawADC.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblRawADC.resize(161, 21)
            self.lblRawADC.move(330, 195)
            self.lblRawADC.setParent(self.frmCalibration)
            self.lblRawADC.raise_()

            self.txtRawADC = QLabel()
            self.txtRawADC.setFont(QFont('Inter', 25))
            self.txtRawADC.setAlignment(QtCore.Qt.AlignCenter)
            self.txtRawADC.setStyleSheet("background-color:#ffffff;")
            self.txtRawADC.resize(161, 55)
            self.txtRawADC.move(318, 230)
            self.txtRawADC.setParent(self.frmCalibration)
            self.txtRawADC.raise_()

            self.lblCurrentLoad = QLabel()
            self.lblCurrentLoad.setText(
                GlobalVariable.language_setting_items["calibration_components"]["calib_header_9"])
            self.lblCurrentLoad.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCurrentLoad.resize(161, 21)
            self.lblCurrentLoad.move(318, 285)
            self.lblCurrentLoad.setParent(self.frmCalibration)
            self.lblCurrentLoad.raise_()

            self.txtCurrentLoad = QLabel()
            self.txtCurrentLoad.setFont(QFont('Inter', 30))
            self.txtCurrentLoad.setAlignment(QtCore.Qt.AlignCenter)
            self.txtCurrentLoad.setStyleSheet("background-color:#ffffff;")
            self.txtCurrentLoad.resize(161, 51)
            self.txtCurrentLoad.move(318, 315)
            self.txtCurrentLoad.setParent(self.frmCalibration)
            self.txtCurrentLoad.raise_()

            self.lblDate = QLabel()
            self.lblDate.setText(GlobalVariable.language_setting_items["calibration_components"]["calib_date_time"])
            self.lblDate.resize(161, 21)
            self.lblDate.setStyleSheet(
                "font: 12px Regular Inter;text-align:left;font-weight:bold;border:0px solid grey;")
            self.lblDate.move(110, 391)
            self.lblDate.setParent(self.frmCalibration)

            self.lblDateTime = QLabel()
            self.lblDateTime.resize(241, 21)
            self.lblDateTime.setStyleSheet(
                "font: 12px Regular Inter;text-align:left;font-weight:bold;border:0px solid grey;color:#1132ee;")
            self.lblDateTime.move(240, 391)
            self.lblDateTime.setParent(self.frmCalibration)

            self.lbl_mode_header = QLabel()
            self.lbl_mode_header.setText("Mode :")
            self.lbl_mode_header.resize(60, 21)
            self.lbl_mode_header.setStyleSheet(
                "font: 12px Regular Inter;text-align:left;font-weight:bold;border:0px solid grey;")
            self.lbl_mode_header.move(10, 391)
            self.lbl_mode_header.setParent(self.frmCalibration)

            self.lbl_mode = QLabel()
            self.lbl_mode.resize(50, 21)
            self.lbl_mode.setStyleSheet(
                "font: 12px Regular Inter;text-align:left;font-weight:bold;border:0px solid grey;color:#1132ee;")
            self.lbl_mode.move(60, 391)
            self.lbl_mode.setParent(self.frmCalibration)

            label.setLayout(horizontalLayout)
            calibration_layout.addWidget(label)

            self.btnEditCalibration.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/Edit.png); "
                                                                                         "border : none "
                                                                                         "}"
                                                                                         "QPushButton::disabled"
                                                                                         "{"
                                                                                         "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "
                                                                                                                                "}"
                                                  )
            self.btn_manual = QPushButton()
            self.btn_manual.setText(GlobalVariable.language_setting_items["calibration_components"]["manual_text"])
            self.btn_manual.resize(70, 35)
            self.btn_manual.move(185, 1)
            self.btn_manual.setFont(QFont('Inter', 11))
            self.btn_manual.clicked.connect(self.on_click_calibration_manual)
            self.btn_manual.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_manual.setGraphicsEffect(shadow)
            self.btn_manual.setStyleSheet("QPushButton"
                                            "{"
                                            "background-color: #dedede; color: black;border-radius : 17px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_auto = QPushButton()
            self.btn_auto.setText(GlobalVariable.language_setting_items["calibration_components"]["auto_text"])
            self.btn_auto.resize(70, 35)
            self.btn_auto.move(120, 1)
            self.btn_auto.setFont(QFont('Inter', 11))
            self.btn_auto.clicked.connect(self.on_click_calibration_auto)
            self.btn_auto.setParent(self.frmCalibration)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_auto.setGraphicsEffect(shadow)
            self.btn_auto.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color: #dedede; color: black;border-radius : 17px;border: 0px solid grey;"
                                          "}"
                                          )
            self.btnCalSave.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSave.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSaveHover.png); "
                                                                                                                        "}"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalSaveDisable.png); "
                                                                                                                                                               "}"
                                          )
            self.btnCalReset.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalReset.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/CalResetHover.png); "
                                                                                                                         "}"
                                           )


            self.btnApplyCalZero.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Download.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadDisable.png); "
                                                                                                                                                                    "}"

                                               )
            self.btnApplyCalSpan.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Download.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DownloadDisable.png); "
                                                                                                                                                                    "}"
                                               )

            self.HorizontalLyt.addWidget(self.frmCalibration)

            pass
        except Exception as e:
            print(e)