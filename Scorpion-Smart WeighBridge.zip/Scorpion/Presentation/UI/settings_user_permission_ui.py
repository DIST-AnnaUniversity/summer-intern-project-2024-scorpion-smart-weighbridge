from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QFrame, QLabel, QPushButton, QHBoxLayout, QLineEdit, QGroupBox, QRadioButton, \
    QGraphicsDropShadowEffect, QWidget, QVBoxLayout
from reportlab.graphics.shapes import Line

from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsUserPermissionUi:
    def __init__(self):
        super().__init__()
        self.on_click_ReadNewUser = None

    def UserPermission_Ui(self):
        for i in reversed(range(self.HorizontalLyt.count())):
            self.HorizontalLyt.itemAt(i).widget().deleteLater()

        self.frmUserPermission = QFrame(self)


        lblUserPermisssionBg = QLabel(self.frmUserPermission)
        lblUserPermisssionBg.resize(760, 693)
        lblUserPermisssionBg.setParent(self.frmUserPermission)

        self.lblRolesHeader = QLabel()
        self.lblRolesHeader.setText(
            GlobalVariable.language_setting_items["user_account_settings"]["user_permission_header_1"])
        self.lblRolesHeader.setFont(QFont('Inter', 18))
        self.lblRolesHeader.setStyleSheet("text-align: left;font: 24px Regular Inter;border:0px solid grey;")
        self.lblRolesHeader.resize(200, 40)
        self.lblRolesHeader.move(10, 15)
        self.lblRolesHeader.setParent(self.frmUserPermission)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.lblRolesHeader.setGraphicsEffect(shadow)

        self.lblCustomRolesHeader = QLabel()
        self.lblCustomRolesHeader.setText(
            GlobalVariable.language_setting_items["user_account_settings"]["user_permission_header_2"])
        self.lblCustomRolesHeader.setFont(QFont('Inter', 18))
        self.lblCustomRolesHeader.setStyleSheet("text-align: left; font: 24px Regular Inter; border:0px solid grey;")
        self.lblCustomRolesHeader.resize(200, 40)
        self.lblCustomRolesHeader.move(10, 170)
        self.lblCustomRolesHeader.setParent(self.frmUserPermission)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.lblCustomRolesHeader.setGraphicsEffect(shadow)

        self.lblLine = QLabel()
        self.lblLine.resize(721, 17)
        self.lblLine.move(15, 140)
        self.lblLine.setStyleSheet("border-bottom:2px solid lightgrey;"
                                   "border-right:0px solid white;"
                                   "border-left:0px solid white;"
                                   "border-top:0px solid white;")
        self.lblLine.setParent(self.frmUserPermission)

        self.btnAdmin = QPushButton()
        self.btnAdmin.setText("Admin")
        self.btnAdmin.resize(100, 40)
        self.btnAdmin.move(30, 88)
        self.btnAdmin.clicked.connect(self.on_click_Admin)
        self.btnAdmin.setParent(self.frmUserPermission)
        self.btnAdmin.setStyleSheet("QPushButton "
                                    "{"
                                    "border-radius:7px;"
                                    "font: 18px Regular Inter;"
                                    "color: black;"
                                    "background-color: white;"
                                    "border: 1px solid lightgrey;"
                                    "}"
                                    "QPushButton:hover "
                                    "{"
                                    "border-radius:7px;"
                                    "font: 18px Regular Inter;"
                                    "color: white;"
                                    "background-color: black;"
                                    "}"
                                    )
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnAdmin.setGraphicsEffect(shadow)

        self.btnSupervisor = QPushButton()
        self.btnSupervisor.setText("Supervisor")
        self.btnSupervisor.resize(100, 40)
        self.btnSupervisor.move(200, 88)
        self.btnSupervisor.clicked.connect(self.on_click_Supervisor)
        self.btnSupervisor.setParent(self.frmUserPermission)
        self.btnSupervisor.setStyleSheet("QPushButton "
                                         "{"
                                         "border-radius:7px;"
                                         "font: 18px Regular Inter;"
                                         "color: black;"
                                         "background-color: white;"
                                         "border: 1px solid lightgrey;"
                                         "}"
                                         "QPushButton:hover "
                                         "{"
                                         "border-radius:7px;"
                                         "font: 18px Regular Inter;"
                                         "color: white;"
                                         "background-color: black;"
                                         "}"
                                         )
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnSupervisor.setGraphicsEffect(shadow)

        self.btnOperator = QPushButton()
        self.btnOperator.setText("Operator")
        self.btnOperator.resize(100, 40)
        self.btnOperator.move(370, 88)
        self.btnOperator.clicked.connect(self.on_click_Operator)
        self.btnOperator.setParent(self.frmUserPermission)
        self.btnOperator.setStyleSheet("QPushButton "
                                       "{"
                                       "border-radius:7px;"
                                       "font: 18px Regular Inter;"
                                       "color: black;"
                                       "background-color: white;"
                                       "border: 1px solid lightgrey;"
                                       "}"
                                       "QPushButton:hover "
                                       "{"
                                       "border-radius:7px;"
                                       "font: 18px Regular Inter;"
                                       "color: white;"
                                       "background-color: black;"
                                       "}"
                                       )
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnOperator.setGraphicsEffect(shadow)

        self.btnCreateRoles = QPushButton()
        self.btnCreateRoles.resize(132, 33)
        self.btnCreateRoles.move(330, 170)
        self.btnCreateRoles.clicked.connect(self.on_click_CreateRoles)
        self.btnCreateRoles.setParent(self.frmUserPermission)
        self.btnCreateRoles.setEnabled(True)
        self.btnCreateRoles.raise_()
        # self.btnCreateRoles.setStyleSheet("QPushButton "
        #                                   "{"
        #                                   "border-radius:7px;"
        #                                   "font: 14px Regular Inter;"
        #                                   "color: black;"
        #                                   "background-color: white;"
        #                                   "border: 1px solid lightgrey;"
        #                                   "}"
        #                                   "QPushButton:hover "
        #                                   "{"
        #                                   "border-radius:7px;"
        #                                   "font: 14px Regular Inter;"
        #                                   "color: white;"
        #                                   "background-color: black;"
        #                                   "}"
        #                                   )



        self.frame = QFrame()
        self.frame.resize(500, 200)
        self.frame.move(1, 189)
        self.frame.setStyleSheet("border:0px solid grey;")
        self.frame.setParent(self.frmUserPermission)

        self.pnlCustomRoles = QHBoxLayout(self.frame)

        self.lblUserPermissionmsgbg = QLabel()
        self.lblUserPermissionmsgbg.setFont(QFont('Inter', 10))
        self.lblUserPermissionmsgbg.setStyleSheet("color:white;border:0px solid grey;  ")
        self.lblUserPermissionmsgbg.resize(151, 37)
        self.lblUserPermissionmsgbg.move(400, 175)
        self.lblUserPermissionmsgbg.setParent(self.frmUserPermission)
        self.lblUserPermissionmsgbg.raise_()

        self.lblUserPermission = QLabel()
        self.lblUserPermission.setFont(QFont('Inter', 10))
        self.lblUserPermission.setStyleSheet("color:white;border:0px solid grey;background-color:transparent")
        self.lblUserPermission.resize(121, 30)
        self.lblUserPermission.move(400, 0)
        self.lblUserPermission.setParent(self.frmUserPermission)
        self.lblUserPermission.raise_()

        """Assign Access Panel"""

        self.pnlAssignAccess = QWidget()
        self.pnlAssignAccess.resize(480, 400)
        self.pnlAssignAccess.move(1, 1)
        # self.pnlAssignAccess.setStyleSheet("border:0px solid grey;")
        self.pnlAssignAccess.setParent(self.frmUserPermission)
        # self.pnlAssignAccess.raise_()
        # shadow = QGraphicsDropShadowEffect()
        # shadow.setBlurRadius(13)
        # # self.pnlAssignAccess.setGraphicsEffect(shadow)

        self.lblAssignAccessBg = QLabel()
        self.lblAssignAccessBg.resize(480, 400)
        self.lblAssignAccessBg.move(0, 0)
        self.lblAssignAccessBg.setParent(self.pnlAssignAccess)
        self.lblAssignAccessBg.setStyleSheet("QLabel"
                                             "{"
                                             "background-color:grey;"
                                             "border-radius:10px;"
                                             "}"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AssignAccessBg.png); "
                                                                                    "border : none "
                                                                                    "}"

                                             )
        """System Config Button"""

        self.btnReadSysConfig = QPushButton()
        self.btnReadSysConfig.resize(73, 31)
        self.btnReadSysConfig.move(210, 50)
        self.btnReadSysConfig.setParent(self.pnlAssignAccess)

        self.btnWriteSysConfig = QPushButton()
        self.btnWriteSysConfig.resize(73, 31)
        self.btnWriteSysConfig.move(290, 50)
        self.btnWriteSysConfig.setParent(self.pnlAssignAccess)

        self.btnVisibleSysConfig = QPushButton()
        self.btnVisibleSysConfig.resize(73, 31)
        self.btnVisibleSysConfig.move(370, 50)
        self.btnVisibleSysConfig.setParent(self.pnlAssignAccess)

        """AppConfig Button"""
        self.btnReadAppConfig = QPushButton()
        self.btnReadAppConfig.resize(73, 31)
        self.btnReadAppConfig.move(210, 95)
        self.btnReadAppConfig.setParent(self.pnlAssignAccess)

        self.btnWriteAppConfig = QPushButton()
        self.btnWriteAppConfig.resize(73, 31)
        self.btnWriteAppConfig.move(290, 95)
        self.btnWriteAppConfig.setParent(self.pnlAssignAccess)

        self.btnVisibleAppConfig = QPushButton()
        self.btnVisibleAppConfig.resize(73, 31)
        self.btnVisibleAppConfig.move(370, 95)
        self.btnVisibleAppConfig.setParent(self.pnlAssignAccess)

        """Parameter Button"""
        self.btnReadParameter = QPushButton()
        self.btnReadParameter.resize(73, 31)
        self.btnReadParameter.move(210, 138)
        self.btnReadParameter.setParent(self.pnlAssignAccess)

        self.btnWriteParameter = QPushButton()
        self.btnWriteParameter.resize(73, 31)
        self.btnWriteParameter.move(290, 138)
        self.btnWriteParameter.setParent(self.pnlAssignAccess)

        self.btnVisibleParameter = QPushButton()
        self.btnVisibleParameter.resize(73, 31)
        self.btnVisibleParameter.move(370, 138)
        self.btnVisibleParameter.setParent(self.pnlAssignAccess)

        """General Button"""
        self.btnReadGeneral = QPushButton()
        self.btnReadGeneral.resize(73, 31)
        self.btnReadGeneral.move(210, 180)
        self.btnReadGeneral.setParent(self.pnlAssignAccess)

        self.btnWriteGeneral = QPushButton()
        self.btnWriteGeneral.resize(73, 31)
        self.btnWriteGeneral.move(290, 180)
        self.btnWriteGeneral.setParent(self.pnlAssignAccess)

        self.btnVisibleGeneral = QPushButton()
        self.btnVisibleGeneral.resize(73, 31)
        self.btnVisibleGeneral.move(370, 180)
        self.btnVisibleGeneral.setParent(self.pnlAssignAccess)

        """Webhooks Button"""
        self.btnReadWebhooks = QPushButton()
        self.btnReadWebhooks.resize(73, 31)
        self.btnReadWebhooks.move(210, 225)
        self.btnReadWebhooks.setParent(self.pnlAssignAccess)

        self.btnWriteWebhooks = QPushButton()
        self.btnWriteWebhooks.resize(73, 31)
        self.btnWriteWebhooks.move(290, 225)
        self.btnWriteWebhooks.setParent(self.pnlAssignAccess)

        self.btnVisibleWebhooks = QPushButton()
        self.btnVisibleWebhooks.resize(73, 31)
        self.btnVisibleWebhooks.move(370, 225)
        self.btnVisibleWebhooks.setParent(self.pnlAssignAccess)

        """Profile Button"""
        self.btnReadProfile = QPushButton()
        self.btnReadProfile.resize(73, 31)
        self.btnReadProfile.move(210, 268)
        self.btnReadProfile.setParent(self.pnlAssignAccess)

        self.btnWriteProfile = QPushButton()
        self.btnWriteProfile.resize(73, 31)
        self.btnWriteProfile.move(290, 268)
        self.btnWriteProfile.setParent(self.pnlAssignAccess)

        self.btnVisibleProfile = QPushButton()
        self.btnVisibleProfile.resize(73, 31)
        self.btnVisibleProfile.move(370, 268)
        self.btnVisibleProfile.setParent(self.pnlAssignAccess)

        """Notification Button"""
        self.btnReadNotification = QPushButton()
        self.btnReadNotification.resize(73, 31)
        self.btnReadNotification.move(210, 310)
        self.btnReadNotification.setParent(self.pnlAssignAccess)

        self.btnWriteNotification = QPushButton()
        self.btnWriteNotification.resize(73, 31)
        self.btnWriteNotification.move(290, 310)
        self.btnWriteNotification.setParent(self.pnlAssignAccess)

        self.btnVisibleNotification = QPushButton()
        self.btnVisibleNotification.resize(73, 31)
        self.btnVisibleNotification.move(370, 310)
        self.btnVisibleNotification.setParent(self.pnlAssignAccess)

        """Advantages Button"""
        self.btnReadAdvantages = QPushButton()
        self.btnReadAdvantages.resize(73, 31)
        self.btnReadAdvantages.move(2510, 320)
        self.btnReadAdvantages.setParent(self.pnlAssignAccess)

        self.btnWriteAdvantages = QPushButton()
        self.btnWriteAdvantages.resize(73, 31)
        self.btnWriteAdvantages.move(29780, 320)
        self.btnWriteAdvantages.setParent(self.pnlAssignAccess)

        self.btnVisibleAdvantages = QPushButton()
        self.btnVisibleAdvantages.resize(73, 31)
        self.btnVisibleAdvantages.move(377770, 320)
        self.btnVisibleAdvantages.setParent(self.pnlAssignAccess)

        self.btnSaveAccess = QPushButton()
        self.btnSaveAccess.setText("")
        self.btnSaveAccess.resize(72, 42)
        self.btnSaveAccess.move(100, 350)
        self.btnSaveAccess.clicked.connect(self.on_click_SaveAccess)
        self.btnSaveAccess.setParent(self.pnlAssignAccess)
        self.btnSaveAccess.setStyleSheet("QPushButton "
                                         "{"
                                         "border-radius:7px;"
                                         "font: 14px Regular Inter;"
                                         "color: black;"
                                         "background-color: white;"
                                         "border: 1px solid lightgrey;"
                                         "}"
                                         "QPushButton:hover "
                                         "{"
                                         "border-radius:7px;"
                                         "font: 14px Regular Inter;"
                                         "color: white;"
                                         "background-color: black;"
                                         "}"
                                         )

        self.btnAccessCancel = QPushButton()
        self.btnAccessCancel.resize(72, 42)
        self.btnAccessCancel.setText("")
        self.btnAccessCancel.move(200, 350)
        self.btnAccessCancel.clicked.connect(self.on_click_CancelAccess)
        self.btnAccessCancel.setParent(self.pnlAssignAccess)
        self.btnAccessCancel.setStyleSheet("QPushButton "
                                           "{"
                                           "border-radius:7px;"
                                           "font: 14px Regular Inter;"
                                           "color: black;"
                                           "background-color: white;"
                                           "border: 1px solid lightgrey;"
                                           "}"
                                           "QPushButton:hover "
                                           "{"
                                           "border-radius:7px;"
                                           "font: 14px Regular Inter;"
                                           "color: white;"
                                           "background-color: black;"
                                           "}"
                                           )
        self.btnAccessCancel.raise_()


        self.btnReadSysConfig.clicked.connect(self.on_click_ReadSysConfig)
        self.btnWriteSysConfig.clicked.connect(self.on_click_WriteSysConfig)
        self.btnVisibleSysConfig.clicked.connect(self.on_click_VisibleSysConfig)

        self.btnReadAppConfig.clicked.connect(self.on_click_ReadAppConfig)
        self.btnWriteAppConfig.clicked.connect(self.on_click_WriteAppConfig)
        self.btnVisibleAppConfig.clicked.connect(self.on_click_VisibleAppConfig)

        self.btnReadGeneral.clicked.connect(self.on_click_ReadGeneral)
        self.btnWriteGeneral.clicked.connect(self.on_click_WriteGeneral)
        self.btnVisibleGeneral.clicked.connect(self.on_click_VisibleGeneral)

        self.btnReadWebhooks.clicked.connect(self.on_click_ReadWebhooks)
        self.btnWriteWebhooks.clicked.connect(self.on_click_WriteWebhooks)
        self.btnVisibleWebhooks.clicked.connect(self.on_click_VisibleWebhooks)

        self.btnReadParameter.clicked.connect(self.on_click_ReadParameter)
        self.btnWriteParameter.clicked.connect(self.on_click_WriteParameter)
        self.btnVisibleParameter.clicked.connect(self.on_click_VisibleParameter)

        self.btnReadProfile.clicked.connect(self.on_click_ReadProfile)
        self.btnWriteProfile.clicked.connect(self.on_click_WriteProfile)
        self.btnVisibleProfile.clicked.connect(self.on_click_VisibleProfile)

        self.btnReadNotification.clicked.connect(self.on_click_ReadNotification)
        self.btnWriteNotification.clicked.connect(self.on_click_WriteNotification)
        self.btnVisibleNotification.clicked.connect(self.on_click_VisibleNotification)

        self.btnReadAdvantages.clicked.connect(self.on_click_ReadAdvantages)
        self.btnWriteAdvantages.clicked.connect(self.on_click_WriteAdvantages)
        self.btnVisibleAdvantages.clicked.connect(self.on_click_VisibleAdvantages)

        """Create New User Panel"""

        self.pnlCreateNewRole = QWidget()
        self.pnlCreateNewRole.resize(480, 680)
        self.pnlCreateNewRole.move(160000, 10)
        self.pnlCreateNewRole.setStyleSheet("border:0px solid grey;")
        self.pnlCreateNewRole.setParent(self.frmUserPermission)
        self.pnlCreateNewRole.raise_()
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.pnlCreateNewRole.setGraphicsEffect(shadow)

        self.lblCreateNewRole = QLabel()
        self.lblCreateNewRole.resize(480, 680)
        self.lblCreateNewRole.move(0, 0)
        self.lblCreateNewRole.setParent(self.pnlCreateNewRole)
        self.lblCreateNewRole.setStyleSheet("QLabel"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/CreateNewRoleCard.png); "
                                                                                   "border : none "
                                                                                   "}")

        self.btnRoleDelete = QPushButton()
        self.btnRoleDelete.resize(42, 42)
        self.btnRoleDelete.move(410, 240)
        self.btnRoleDelete.clicked.connect(self.on_click_delete_role)
        self.btnRoleDelete.setParent(self.pnlCreateNewRole)
        self.btnRoleDelete.setStyleSheet("QPushButton"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/ProductScreenImages/Delete.png); "
                                                                                "border : none "
                                                                                "}"
                                                                                "QPushButton::hover"
                                                                                "{"
                                                                                "background-image :url(" + ROOT_PATH + "Images/ProductScreenImages/DeleteHover.png); "
                                                                                                                       "}"
                                                                                                                       "QPushButton::disabled"
                                                                                                                       "{"
                                                                                                                       "background-image :url(" + ROOT_PATH + "Images/ProductScreenImages/DeleteDisable.png); "
                                                                                                                                                              "}"

                                         )

        self.btnNext = QPushButton()
        self.btnNext.setText("")
        self.btnNext.resize(72, 42)
        self.btnNext.move(141, 350)
        self.btnNext.clicked.connect(self.on_click_Next)
        self.btnNext.setParent(self.pnlCreateNewRole)
        self.btnNext.setStyleSheet("QPushButton "
                                   "{"
                                   "border-radius:7px;"
                                   "font: 14px Regular Inter;"
                                   "color: black;"
                                   "background-color: white;"
                                   "border: 1px solid lightgrey;"
                                   "}"
                                   "QPushButton:hover "
                                   "{"
                                   "border-radius:7px;"
                                   "font: 14px Regular Inter;"
                                   "color: white;"
                                   "background-color: black;"
                                   "}"
                                   )
        self.btnCancel = QPushButton()
        self.btnCancel.setText("")
        self.btnCancel.resize(72, 42)
        self.btnCancel.move(280, 350)
        self.btnCancel.clicked.connect(self.on_click_Cancel)
        self.btnCancel.setParent(self.pnlCreateNewRole)
        self.btnCancel.setStyleSheet("QPushButton "
                                     "{"
                                     "border-radius:7px;"
                                     "font: 14px Regular Inter;"
                                     "color: black;"
                                     "background-color: white;"
                                     "border: 1px solid lightgrey;"
                                     "}"
                                     "QPushButton:hover "
                                     "{"
                                     "border-radius:7px;"
                                     "font: 14px Regular Inter;"
                                     "color: white;"
                                     "background-color: black;"
                                     "}"
                                     )

        self.txtRoleName = QLineEdit()
        self.txtRoleName.setFont(QFont('Inter', 14))
        self.txtRoleName.setMaxLength(10)
        self.txtRoleName.setStyleSheet("border: 0px solid grey;")
        self.txtRoleName.move(40, 150)
        self.txtRoleName.resize(421, 41)
        self.txtRoleName.setParent(self.pnlCreateNewRole)

        """Group Box"""
        self.groupBox = QGroupBox()
        self.groupBox.setFont(QFont('Inter', 14))
        self.groupBox.setStyleSheet("border: 0px solid grey;")
        self.groupBox.move(20, 290)
        self.groupBox.resize(441, 61)
        self.groupBox.setParent(self.pnlCreateNewRole)

        self.rbAdmin = QRadioButton()
        self.rbAdmin.setText(GlobalVariable.language_setting_items["user_account_settings"]["role_name_1"])
        self.rbAdmin.setChecked(False)
        self.rbAdmin.setFont(QFont('Inter', 14))
        self.rbAdmin.setStyleSheet("border: 0px solid grey;")
        self.rbAdmin.move(20, 20)
        self.rbAdmin.resize(122, 21)
        self.rbAdmin.setParent(self.groupBox)

        self.rbSupervisor = QRadioButton()
        self.rbSupervisor.setText(GlobalVariable.language_setting_items["user_account_settings"]["role_name_2"])
        self.rbSupervisor.setChecked(False)
        self.rbSupervisor.setFont(QFont('Inter', 14))
        self.rbSupervisor.setStyleSheet("border: 0px solid grey;")
        self.rbSupervisor.move(160, 20)
        self.rbSupervisor.resize(122, 21)
        self.rbSupervisor.setParent(self.groupBox)

        self.rbOperator = QRadioButton()
        self.rbOperator.setText(GlobalVariable.language_setting_items["user_account_settings"]["role_name_3"])
        self.rbOperator.setChecked(False)
        self.rbOperator.setFont(QFont('Inter', 14))
        self.rbOperator.setStyleSheet("border: 0px solid grey;")
        self.rbOperator.move(320, 20)
        self.rbOperator.resize(132, 21)
        self.rbOperator.setParent(self.groupBox)

        self.HorizontalLyt.addWidget(self.frmUserPermission)
