from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QLabel, QComboBox, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsMenuInputUi:
    def __init__(self):
        super().__init__()

    def create_input_settings_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmInputSettings = QFrame(self)

            self.lblInputSettingsBg = QLabel(self.frmInputSettings)
            self.lblInputSettingsBg.resize(521, 429)
            self.lblInputSettingsBg.setParent(self.frmInputSettings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["input_config_components"]["input_config_header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(200, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frmInputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)


            self.btnInputEdit = QPushButton()
            self.btnInputEdit.resize(42, 42)
            self.btnInputEdit.move(360, 0)
            self.btnInputEdit.clicked.connect(self.on_click_input_edit)
            self.btnInputEdit.setParent(self.frmInputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnInputEdit.setGraphicsEffect(shadow)
            self.btnInputEdit.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                   "/Edit.png); "
                                                                                   "border : none; "
                                                                                   "}QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); }"

                                                                                   "QPushButton::disabled"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); }"

                                            )

            self.btnInputSave = QPushButton()
            self.btnInputSave.resize(42, 42)
            self.btnInputSave.move(420, 0)
            self.btnInputSave.clicked.connect(self.on_click_input_edit)
            self.btnInputSave.setParent(self.frmInputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnInputSave.setGraphicsEffect(shadow)
            self.btnInputSave.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Save.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                     "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                   "QPushButton::disabled"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                            )
            self.lbl_header_position = 50

            for i in range(4):
                self.lbl_header = QLabel()
                self.lbl_header.setText(
                    GlobalVariable.language_setting_items["input_config_components"]["input_header"] +str(i+1))
                self.lbl_header.setStyleSheet(
                    "border:0px solid lightgrey;font: 18px Regular Inter;color:#696667;text-align:left;")
                self.lbl_header.resize(111, 31)
                self.lbl_header.move(15, self.lbl_header_position)
                self.lbl_header.setParent(self.frmInputSettings)
                self.lbl_header_position += 80

            self.CmbInput1 = QComboBox()
            self.CmbInput1.setFont(QFont('Inter', 12))
            self.CmbInput1.move(20, 80)
            self.CmbInput1.resize(421, 31)
            self.CmbInput1.setParent(self.frmInputSettings)

           
            self.CmbInput2 = QComboBox()
            self.CmbInput2.setFont(QFont('Inter', 12))
            self.CmbInput2.move(20, 160)
            self.CmbInput2.resize(421, 31)
            self.CmbInput2.setParent(self.frmInputSettings)           

            self.CmbInput3 = QComboBox()
            self.CmbInput3.setFont(QFont('Inter', 12))
            self.CmbInput3.move(20, 240)
            self.CmbInput3.resize(421, 31)
            self.CmbInput3.setParent(self.frmInputSettings)           

            self.CmbInput4 = QComboBox()
            self.CmbInput4.setFont(QFont('Inter', 12))
            self.CmbInput4.move(20, 330)
            self.CmbInput4.resize(421, 31)
            self.CmbInput4.setParent(self.frmInputSettings)


            self.lblIp1Status = QLabel()
            self.lblIp1Status.move(150, 50)
            self.lblIp1Status.resize(21, 21)
            self.lblIp1Status.setParent(self.frmInputSettings)

            self.lblIp2Status = QLabel()
            self.lblIp2Status.move(150, 130)
            self.lblIp2Status.resize(21, 21)
            self.lblIp2Status.setParent(self.frmInputSettings)

            self.lblIp3Status = QLabel()
            self.lblIp3Status.move(150, 210)
            self.lblIp3Status.resize(21, 21)
            self.lblIp3Status.setParent(self.frmInputSettings)

            self.lblIp4Status = QLabel()
            self.lblIp4Status.move(150, 290)
            self.lblIp4Status.resize(21, 21)
            self.lblIp4Status.setParent(self.frmInputSettings)

            self.cmb_input_names = [self.CmbInput1, self.CmbInput2,  self.CmbInput3, self.CmbInput4]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])
            self.HorizontalLyt.addWidget(self.frmInputSettings)

            pass
        except Exception as e:
            print(e)
