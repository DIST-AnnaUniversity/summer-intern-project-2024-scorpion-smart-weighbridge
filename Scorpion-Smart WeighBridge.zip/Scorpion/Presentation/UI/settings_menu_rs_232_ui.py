from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QPushButton, QGraphicsDropShadowEffect, QComboBox, QLabel, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsRs232Ui:
    def __init__(self):
        super().__init__()

    def create_rs_232_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmRS232Comm = QFrame()
            lblRS232CommBg = QLabel(self.frmRS232Comm)
            lblRS232CommBg.resize(521, 429)
            lblRS232CommBg.setParent(self.frmRS232Comm)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["rs_232_components"]["header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(5, 3)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)
            self.lblHeader.setParent(self.frmRS232Comm)

            self.lblComm = QLabel()
            self.lblComm.setFont(QFont('Inter', 10))
            self.lblComm.setStyleSheet("color:white;border:0px solid grey;")
            self.lblComm.resize(151, 41)
            self.lblComm.move(550, 10)
            self.lblComm.setParent(self.frmRS232Comm)
            self.lblComm.raise_()

            self.lblCommMsg = QLabel()
            self.lblCommMsg.setFont(QFont('Inter', 10))
            self.lblCommMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblCommMsg.resize(135, 21)
            self.lblCommMsg.move(557, 20)
            self.lblCommMsg.setParent(self.frmRS232Comm)
            self.lblCommMsg.raise_()

            self.lblCom1 = QLabel()
            self.lblCom1.setText(GlobalVariable.language_setting_items["rs_232_components"]["com_header_1"])
            self.lblCom1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCom1.resize(140, 27)
            self.lblCom1.move(10, 60)
            self.lblCom1.setParent(self.frmRS232Comm)

            self.btnComEdit = QPushButton()
            self.btnComEdit.resize(42, 42)
            self.btnComEdit.move(360, 8)
            self.btnComEdit.clicked.connect(self.on_click_rs232_edit)
            self.btnComEdit.setParent(self.frmRS232Comm)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnComEdit.setGraphicsEffect(shadow)
            self.btnComEdit.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                 "/Edit.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); "
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "

                                          )
            self.btnComSave = QPushButton()
            self.btnComSave.resize(42, 42)
            self.btnComSave.move(420, 8)
            self.btnComSave.clicked.connect(self.on_click_rs232_save)
            self.btnComSave.setParent(self.frmRS232Comm)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnComSave.setGraphicsEffect(shadow)
            self.btnComSave.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                 "/Save.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                          )
            self.btnComSave.setEnabled(False)

            self.cmbCom1Baudrate = QComboBox()
            self.cmbCom1Baudrate.setFont(QFont('Inter', 15))
            self.cmbCom1Baudrate.resize(481, 37)
            self.cmbCom1Baudrate.move(10, 90)
            self.cmbCom1Baudrate.setParent(self.frmRS232Comm)

            self.lblCom2 = QLabel()
            self.lblCom2.setText(GlobalVariable.language_setting_items["rs_232_components"]["com_header_2"])
            self.lblCom2.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCom2.resize(140, 27)
            self.lblCom2.move(10, 140)
            self.lblCom2.setParent(self.frmRS232Comm)

            self.cmbCom2Baudrate = QComboBox()
            self.cmbCom2Baudrate.setFont(QFont('Inter', 15))
            self.cmbCom2Baudrate.resize(481, 37)
            self.cmbCom2Baudrate.move(10, 170)
            self.cmbCom2Baudrate.setParent(self.frmRS232Comm)

            self.lblCom3 = QLabel()
            self.lblCom3.setText(GlobalVariable.language_setting_items["rs_232_components"]["com_header_3"])
            self.lblCom3.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCom3.resize(140, 27)
            self.lblCom3.move(10, 220)
            self.lblCom3.setParent(self.frmRS232Comm)

            self.cmbCom3Baudrate = QComboBox()
            self.cmbCom3Baudrate.setFont(QFont('Inter', 15))
            self.cmbCom3Baudrate.resize(481, 37)
            self.cmbCom3Baudrate.move(10, 250)
            self.cmbCom3Baudrate.setParent(self.frmRS232Comm)

            self.lblcom1Status = QLabel()
            self.lblcom1Status.resize(21, 21)
            self.lblcom1Status.move(450, 58)
            self.lblcom1Status.setParent(self.frmRS232Comm)

            self.lblcom2Status = QLabel()
            self.lblcom2Status.resize(21, 21)
            self.lblcom2Status.move(450, 138)
            self.lblcom2Status.setParent(self.frmRS232Comm)

            self.lblcom3Status = QLabel()
            self.lblcom3Status.resize(21, 21)
            self.lblcom3Status.move(450, 218)
            self.lblcom3Status.setParent(self.frmRS232Comm)

            self.label_status.clear()
            self.label_status.append(self.lblcom1Status)
            self.label_status.append(self.lblcom2Status)
            self.label_status.append(self.lblcom3Status)

            self.cmb_input_names = [self.cmbCom1Baudrate, self.cmbCom2Baudrate, self.cmbCom3Baudrate]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])

            self.HorizontalLyt.addWidget(self.frmRS232Comm)
            pass
        except Exception as e:
            print(e)
