from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QLabel, QPushButton, QLineEdit, QFrame, QGraphicsDropShadowEffect

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsGeneralHeader:
    def __init__(self):
        super().__init__()

    def create_header_config_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()
            self.frmHeader = QFrame(self)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["header_components"]["header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(5, 3)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)
            self.lblHeader.setParent(self.frmHeader)

            lblHeadersBg = QLabel(self.frmHeader)
            lblHeadersBg.resize(760, 693)
            lblHeadersBg.setParent(self.frmHeader)

            self.lblHeader = QLabel()
            self.lblHeader.setFont(QFont('Inter', 10))
            self.lblHeader.setStyleSheet("color:white;border:0px solid grey;")
            self.lblHeader.resize(151, 41)
            self.lblHeader.move(550, 10)
            self.lblHeader.setParent(self.frmHeader)
            self.lblHeader.raise_()

            self.lblHeaderMsg = QLabel()
            self.lblHeaderMsg.setFont(QFont('Inter', 10))
            self.lblHeaderMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblHeaderMsg.resize(135, 21)
            self.lblHeaderMsg.move(557, 20)
            self.lblHeaderMsg.setParent(self.frmHeader)
            self.lblHeaderMsg.raise_()

            self.lblHeader1 = QLabel()
            self.lblHeader1.setText(GlobalVariable.language_setting_items["header_components"]["header_1"])
            self.lblHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader1.resize(145, 21)
            self.lblHeader1.move(10, 50)
            self.lblHeader1.setParent(self.frmHeader)

            self.txtHeader1 = QLineEdit()
            self.txtHeader1.move(8, 80)
            self.txtHeader1.resize(421, 31)
            self.txtHeader1.setMaxLength(24)
            self.txtHeader1.setFont(QFont('Inter', 12))
            self.txtHeader1.setParent(self.frmHeader)

            self.lblHeader2 = QLabel()
            self.lblHeader2.setText(GlobalVariable.language_setting_items["header_components"]["header_2"])
            self.lblHeader2.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader2.resize(145, 21)
            self.lblHeader2.move(10, 120)
            self.lblHeader2.setParent(self.frmHeader)

            self.txtHeader2 = QLineEdit()
            self.txtHeader2.setFont(QFont('Inter', 12))
            self.txtHeader2.setMaxLength(15)
            self.txtHeader2.resize(421, 31)
            self.txtHeader2.move(10, 150)
            self.txtHeader2.setParent(self.frmHeader)

            self.lblHeader3 = QLabel()
            self.lblHeader3.setText(GlobalVariable.language_setting_items["header_components"]["header_3"])
            self.lblHeader3.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader3.resize(145, 21)
            self.lblHeader3.move(10, 190)
            self.lblHeader3.setParent(self.frmHeader)

            self.txtHeader3 = QLineEdit()
            self.txtHeader3.setFont(QFont('Inter', 12))
            self.txtHeader3.setMaxLength(15)
            self.txtHeader3.resize(421, 31)
            self.txtHeader3.move(10, 220)
            self.txtHeader3.setParent(self.frmHeader)

            self.lblLogoHeader = QLabel()
            self.lblLogoHeader.setText(GlobalVariable.language_setting_items["header_components"]["header_4"])
            self.lblLogoHeader.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;font-weight:bold;")
            self.lblLogoHeader.resize(140, 21)
            self.lblLogoHeader.move(10, 260)
            self.lblLogoHeader.setParent(self.frmHeader)

            self.btnSelectLogo = QPushButton()
            self.btnSelectLogo.resize(113, 111)
            self.btnSelectLogo.move(20, 280)
            self.btnSelectLogo.clicked.connect(self.on_click_logo)
            self.btnSelectLogo.setParent(self.frmHeader)
            self.btnSelectLogo.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DefaultPic.png); "
                                                                                    "border : none "
                                                                                    "}"

                                             )

            self.lblLogo = QLabel()
            self.lblLogo.resize(113, 111)
            self.lblLogo.move(220, 270)
            self.lblLogo.setParent(self.frmHeader)

            self.btnHeaderEdit = QPushButton()
            self.btnHeaderEdit.resize(42, 42)
            self.btnHeaderEdit.move(360, 0)
            self.btnHeaderEdit.clicked.connect(self.on_click_header_config_edit)
            self.btnHeaderEdit.setParent(self.frmHeader)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnHeaderEdit.setGraphicsEffect(shadow)
            self.btnHeaderEdit.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                   "/Edit.png); "
                                                                                   "border : none; "
                                                                                   "}QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); }"

                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); }"

                                            )

            self.btnHeaderSave = QPushButton()
            self.btnHeaderSave.resize(42, 42)
            self.btnHeaderSave.move(420, 0)
            self.btnHeaderSave.clicked.connect(self.on_click_header_config_save)
            self.btnHeaderSave.setParent(self.frmHeader)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnHeaderSave.setGraphicsEffect(shadow)
            self.btnHeaderSave.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Save.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                            )

            self.lbl_header1_status = QLabel()
            self.lbl_header1_status.resize(21, 21)
            self.lbl_header1_status.move(405, 50)
            self.lbl_header1_status.setParent(self.frmHeader)

            self.lbl_header2_status = QLabel()
            self.lbl_header2_status.resize(21, 21)
            self.lbl_header2_status.move(405, 122)
            self.lbl_header2_status.setParent(self.frmHeader)

            self.lbl_header3_status = QLabel()
            self.lbl_header3_status.resize(21, 21)
            self.lbl_header3_status.move(405, 193)
            self.lbl_header3_status.setParent(self.frmHeader)

            self.label_status.clear()
            self.label_status.append(self.lbl_header1_status)
            self.label_status.append(self.lbl_header2_status)
            self.label_status.append(self.lbl_header3_status)

            text_inputs = [self.txtHeader1, self.txtHeader2, self.txtHeader3]
            for txtInput in text_inputs:
                UiComponents.textbox_default_stylesheet(txtInput)

            self.HorizontalLyt.addWidget(self.frmHeader)
            pass
        except Exception as e:
            print(e)