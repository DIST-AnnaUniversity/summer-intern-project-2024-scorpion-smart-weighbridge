from PyQt5.QtCore import QRegExp
from PyQt5.QtGui import QFont, QRegExpValidator
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QCheckBox

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsCreateUserUi:
    def __init__(self):
        super().__init__()

    def create_new_user_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()
            self.frmCreateNewUser = QFrame(self)

            self.lblProfileBg = QLabel(self.frmCreateNewUser)
            self.lblProfileBg.resize(521, 429)
            self.lblProfileBg.setParent(self.frmCreateNewUser)
            self.lblProfileBg.setStyleSheet("background-color:white;")

            self.lblProfileinfoPic = QLabel()
            self.lblProfileinfoPic.move(10, 35)
            self.lblProfileinfoPic.resize(104, 104)
            self.lblProfileinfoPic.setParent(self.frmCreateNewUser)
            self.lblProfileinfoPic.setStyleSheet("border:2px solid lightgrey;border-radius:7px;")

            self.lblProfileHeader1 = QLabel()
            self.lblProfileHeader1.setText(
                GlobalVariable.language_setting_items["create_new_user"]["profile_details"])
            self.lblProfileHeader1.move(10, 1)
            self.lblProfileHeader1.resize(261, 31)
            self.lblProfileHeader1.setParent(self.frmCreateNewUser)
            self.lblProfileHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;background-color:transparent")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblProfileHeader1.setGraphicsEffect(shadow)

            self.lblProfileHeader3 = QLabel()
            self.lblProfileHeader3.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_1"])
            self.lblProfileHeader3.move(10, 140)
            self.lblProfileHeader3.resize(191, 31)
            self.lblProfileHeader3.setParent(self.frmCreateNewUser)
            self.lblProfileHeader3.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lblProfileHeader4 = QLabel()
            self.lblProfileHeader4.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_2"])
            self.lblProfileHeader4.move(10, 210)
            self.lblProfileHeader4.resize(205, 31)
            self.lblProfileHeader4.setParent(self.frmCreateNewUser)
            self.lblProfileHeader4.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lblProfileHeader5 = QLabel()
            self.lblProfileHeader5.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_5"])
            self.lblProfileHeader5.move(260, 210)
            self.lblProfileHeader5.resize(100, 31)
            self.lblProfileHeader5.setParent(self.frmCreateNewUser)
            self.lblProfileHeader5.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lblProfileHeader6 = QLabel()
            self.lblProfileHeader6.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_4"])
            self.lblProfileHeader6.move(260, 140)
            self.lblProfileHeader6.resize(71, 31)
            self.lblProfileHeader6.setParent(self.frmCreateNewUser)
            self.lblProfileHeader6.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lblProfileHeader7 = QLabel()
            self.lblProfileHeader7.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_3"])
            self.lblProfileHeader7.move(10, 280)
            self.lblProfileHeader7.resize(100, 31)
            self.lblProfileHeader7.setParent(self.frmCreateNewUser)
            self.lblProfileHeader7.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lblProfileHeader8 = QLabel()
            self.lblProfileHeader8.setText(
                GlobalVariable.language_setting_items["create_new_user"]["create_header_6"])
            self.lblProfileHeader8.move(260, 280)
            self.lblProfileHeader8.resize(130, 31)
            self.lblProfileHeader8.setParent(self.frmCreateNewUser)
            self.lblProfileHeader8.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.chkShowRePassword = QCheckBox()
            self.chkShowRePassword.move(390, 290)
            self.chkShowRePassword.move(390, 290)
            self.chkShowRePassword.resize(111, 20)
            self.chkShowRePassword.setText("Show Password")
            self.chkShowRePassword.setParent(self.frmCreateNewUser)
            self.chkShowRePassword.stateChanged.connect(self.chk_show_re_password)
            self.chkShowRePassword.setStyleSheet("font: 12px Regular Inter;")

            self.chkShowPassword = QCheckBox()
            self.chkShowPassword.move(130, 290)
            self.chkShowPassword.resize(111, 20)
            self.chkShowPassword.setText("Show Password")
            self.chkShowPassword.setParent(self.frmCreateNewUser)
            self.chkShowPassword.stateChanged.connect(self.chk_show_password)
            self.chkShowPassword.setStyleSheet("font: 12px Regular Inter;")

            self.label_2 = QLabel()
            self.label_2.move(120, 5)
            self.label_2.resize(361, 31)
            self.label_2.setStyleSheet("color: rgb(17, 50, 238);font:10px Regular Inter;")
            self.label_2.setText(GlobalVariable.language_setting_items["profile_settings_components"]["profile_note"])
            self.label_2.setParent(self.frmCreateNewUser)

            self.txtUserName = QLineEdit()
            self.txtUserName.move(10, 170)
            self.txtUserName.resize(200, 31)
            self.txtUserName.setMaxLength(20)
            self.txtUserName.setFont(QFont('Inter', 12))
            self.txtUserName.setParent(self.frmCreateNewUser)
            self.txtUserName.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid "
                "lightgrey;")

            self.txtPhoneNumber = QLineEdit()
            self.txtPhoneNumber.move(10, 240)
            self.txtPhoneNumber.resize(200, 31)
            self.txtPhoneNumber.setMaxLength(10)
            self.txtPhoneNumber.setFont(QFont('Inter', 12))
            self.txtPhoneNumber.setParent(self.frmCreateNewUser)
            self.txtPhoneNumber.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.txtEmailId = QLineEdit()
            self.txtEmailId.move(260, 170)
            self.txtEmailId.resize(200, 31)
            self.txtEmailId.setMaxLength(20)
            self.txtEmailId.setFont(QFont('Inter', 14))
            self.txtEmailId.setParent(self.frmCreateNewUser)
            self.txtEmailId.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.txtDesignation = QLineEdit()
            self.txtDesignation.setEnabled(False)
            self.txtDesignation.move(260, 240)
            self.txtDesignation.resize(200, 31)
            self.txtDesignation.setFont(QFont('Inter', 12))
            self.txtDesignation.setParent(self.frmCreateNewUser)
            self.txtDesignation.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.txtCreatePassword = QLineEdit()
            self.txtCreatePassword.setEnabled(False)
            self.txtCreatePassword.move(10, 310)
            self.txtCreatePassword.resize(200, 31)
            self.txtCreatePassword.setMaxLength(10)
            self.txtCreatePassword.setFont(QFont('Inter', 12))
            self.txtCreatePassword.setParent(self.frmCreateNewUser)
            self.txtCreatePassword.setEchoMode(QLineEdit.Password)
            self.txtCreatePassword.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.txtConformPassword = QLineEdit()
            self.txtConformPassword.move(260, 310)
            self.txtConformPassword.resize(200, 31)
            self.txtConformPassword.setMaxLength(10)
            self.txtConformPassword.setFont(QFont('Inter', 12))
            self.txtConformPassword.setEchoMode(QLineEdit.Password)
            self.txtConformPassword.setParent(self.frmCreateNewUser)
            self.txtConformPassword.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.btnProfileDetailsEdit = QPushButton()
            self.btnProfileDetailsEdit.resize(42, 42)
            self.btnProfileDetailsEdit.move(360, 0)
            self.btnProfileDetailsEdit.clicked.connect(self.on_click_create_user_edit)
            self.btnProfileDetailsEdit.setParent(self.frmCreateNewUser)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnProfileDetailsEdit.setGraphicsEffect(shadow)
            self.btnProfileDetailsEdit.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Edit.png); "
                                                                                            "border : none ;"
                                                                                            "background-color:transparent;"
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditHover.png); "
                                                                                                                                   "background-color:transparent;"
                                                                                                                                   "}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditDisable.png); "
                                                                                                                                                                          "background-color:transparent;"
                                                                                                                                                                          "}"
                                                     )
            self.btnProfileDetailsSave = QPushButton()
            self.btnProfileDetailsSave.resize(42, 42)
            self.btnProfileDetailsSave.move(420, 0)
            self.btnProfileDetailsSave.clicked.connect(self.on_click_create_user_save)
            self.btnProfileDetailsSave.setParent(self.frmCreateNewUser)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnProfileDetailsSave.setGraphicsEffect(shadow)
            self.btnProfileDetailsSave.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Save.png); "
                                                                                            "border : none; "
                                                                                            "background-color:transparent;"
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                                   "background-color:transparent;"
                                                                                                                                   "}"
                                                     )

            self.btnProfilePictureEdit = QPushButton()
            self.btnProfilePictureEdit.resize(128, 36)
            self.btnProfilePictureEdit.move(150, 80)
            self.btnProfilePictureEdit.clicked.connect(self.on_click_user_picture_edit)
            self.btnProfilePictureEdit.setParent(self.frmCreateNewUser)
            self.btnProfilePictureEdit.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPicture.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPictureHover.png);"
                                                                                                                                   "}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPictureDisable.png); "
                                                                                                                                                                          "}"

                                                     )

            self.txtDesignation.setStyleSheet(
                "color:grey;font: 18px Inter;border : 0px solid lightgrey;border-bottom:1px solid lightgrey;")

            """Status Label"""
            self.lblNewUserNameStatus = QLabel()
            self.lblNewUserNameStatus.setFont(QFont('Inter', 10))
            self.lblNewUserNameStatus.setStyleSheet("border:0px solid grey;")
            self.lblNewUserNameStatus.move(200, 140)
            self.lblNewUserNameStatus.resize(21, 21)
            self.lblNewUserNameStatus.setParent(self.frmCreateNewUser)

            self.lblNewUserPhoneNoStatus = QLabel()
            self.lblNewUserPhoneNoStatus.setFont(QFont('Inter', 10))
            self.lblNewUserPhoneNoStatus.setStyleSheet("border:0px solid grey;")
            self.lblNewUserPhoneNoStatus.move(200, 210)
            self.lblNewUserPhoneNoStatus.resize(21, 21)
            self.lblNewUserPhoneNoStatus.setParent(self.frmCreateNewUser)

            self.lblNewUserEmailIdStatus = QLabel()
            self.lblNewUserEmailIdStatus.setFont(QFont('Inter', 10))
            self.lblNewUserEmailIdStatus.setStyleSheet("border:0px solid grey;")
            self.lblNewUserEmailIdStatus.move(400, 140)
            self.lblNewUserEmailIdStatus.resize(21, 21)
            self.lblNewUserEmailIdStatus.setParent(self.frmCreateNewUser)

            self.lblNewUserDesignationStatus = QLabel()
            self.lblNewUserDesignationStatus.setFont(QFont('Inter', 10))
            self.lblNewUserDesignationStatus.setStyleSheet("border:0px solid grey;")
            self.lblNewUserDesignationStatus.move(400, 210)
            self.lblNewUserDesignationStatus.resize(21, 21)
            self.lblNewUserDesignationStatus.setParent(self.frmCreateNewUser)

            self.lblCreateUserPassword = QLabel()
            self.lblCreateUserPassword.setFont(QFont('Inter', 10))
            self.lblCreateUserPassword.setStyleSheet("border:0px solid grey;")
            self.lblCreateUserPassword.move(200, 280)
            self.lblCreateUserPassword.resize(21, 21)
            self.lblCreateUserPassword.setParent(self.frmCreateNewUser)

            self.lblNewUserConformPasswordStatus = QLabel()
            self.lblNewUserConformPasswordStatus.setFont(QFont('Inter', 10))
            self.lblNewUserConformPasswordStatus.setStyleSheet("border:0px solid grey;")
            self.lblNewUserConformPasswordStatus.move(400, 280)
            self.lblNewUserConformPasswordStatus.resize(21, 21)
            self.lblNewUserConformPasswordStatus.setParent(self.frmCreateNewUser)

            text_inputs = [self.txtUserName, self.txtEmailId, self.txtPhoneNumber,
                           self.txtDesignation, self.txtConformPassword, self.txtCreatePassword]
            for txtInput in text_inputs:
                UiComponents.textbox_default_stylesheet(txtInput)

            self.HorizontalLyt.addWidget(self.frmCreateNewUser)

            Int = QRegExpValidator(QRegExp("\\d+"))
            self.txtPhoneNumber.setValidator(Int)
            reg_ex = QRegExp("[a-zA-Z0-9]+$")
            username_validator = QRegExpValidator(reg_ex, self.txtProfileInfoUserName)
            self.txtUserName.setValidator(username_validator)
            pass
        except Exception as e:
            print(e)
