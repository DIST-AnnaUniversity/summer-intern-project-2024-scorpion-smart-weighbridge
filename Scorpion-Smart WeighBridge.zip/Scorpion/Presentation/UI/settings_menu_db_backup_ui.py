from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QWidget

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsDbBackupUi:
    def __init__(self):
        super().__init__()

    def create_db_backup_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmDbBackup = QFrame(self)

            lblDbBackupBg = QLabel(self.frmDbBackup)
            lblDbBackupBg.resize(760, 693)
            lblDbBackupBg.setParent(self.frmDbBackup)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["db_backup_componenets"]["db_backup_header"])
            self.lblHeader.setFont(QFont('Inter', 25))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(500, 41)
            self.lblHeader.move(8, 8)
            self.lblHeader.setParent(self.frmDbBackup)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.lblBackUp = QLabel()
            self.lblBackUp.setFont(QFont('Inter', 10))
            self.lblBackUp.setStyleSheet("color:white;border:0px solid grey;")
            self.lblBackUp.resize(151, 41)
            self.lblBackUp.move(550, 10)
            self.lblBackUp.setParent(self.frmDbBackup)
            self.lblBackUp.raise_()

            self.lblBackupMessage = QLabel()
            self.lblBackupMessage.setFont(QFont('Inter', 10))
            self.lblBackupMessage.setStyleSheet("color:white;border:0px solid grey;")
            self.lblBackupMessage.resize(135, 21)
            self.lblBackupMessage.move(557, 20)
            self.lblBackupMessage.setParent(self.frmDbBackup)
            self.lblBackupMessage.raise_()

            self.btnDBBackup = QPushButton()
            self.btnDBBackup.setText(GlobalVariable.language_setting_items["db_backup_componenets"]["db_backup_header"])
            self.btnDBBackup.setFont(QFont('Inter', 12))
            self.btnDBBackup.resize(232, 56)
            self.btnDBBackup.move(100, 280)
            self.btnDBBackup.clicked.connect(self.on_click_get_db_backup)
            self.btnDBBackup.setParent(self.frmDbBackup)
            self.btnDBBackup.setStyleSheet("QPushButton"
                                           "{"
                                           "background-color:white;"
                                           "color:black;"
                                           "border : 1px solid lightgrey;"
                                           "border-radius : 4px;"
                                           "font-weight:bold;"
                                           "}"
                                           "QPushButton::hover"
                                           "{"
                                           "background-color:black;"
                                           "color:white;"
                                           "border : 1px solid lightgrey;"
                                           "border-radius : 4px;"
                                           "font-weight:bold;"
                                           "}"
                                           "QPushButton::disabled"
                                           "{"
                                           "background-color:white;"
                                           "color:solid lightgrey;"
                                           "border : 1px solid lightgrey;"
                                           "border-radius : 4px;"
                                           "font-weight:bold;"
                                           "}"
                                           )

            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnDBBackup.setGraphicsEffect(shadow)

            self.lblDesign = QLabel()
            self.lblDesign.setFont(QFont('Inter', 10))
            self.lblDesign.resize(100, 100)
            self.lblDesign.move(140, 130)
            self.lblDesign.setParent(self.frmDbBackup)
            self.lblDesign.setStyleSheet("QLabel"
                                         "{"
                                         "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DbDesign.png); "
                                                                                "border : none "
                                                                                "}"
                                         )

            '''panel messsage'''
            self.pnl_db_alert = QWidget()
            self.pnl_db_alert.setStyleSheet("border:0px solid grey;")
            self.pnl_db_alert.resize(321, 276)
            self.pnl_db_alert.move(50, 80)
            self.pnl_db_alert.setParent(self.frmDbBackup)
            self.pnl_db_alert.raise_()

            self.lbl_alert_bg = QLabel()
            self.lbl_alert_bg.setFont(QFont('Inter', 10))
            self.lbl_alert_bg.setStyleSheet(
                "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;"
                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/db_backup.png);")
            self.lbl_alert_bg.resize(321, 276)
            self.lbl_alert_bg.move(0, 0)
            self.lbl_alert_bg.setParent(self.pnl_db_alert)

            self.btn_backup_no = QPushButton()
            self.btn_backup_no.resize(72, 42)
            self.btn_backup_no.move(220, 190)
            self.btn_backup_no.clicked.connect(self.on_click_no_backup)
            self.btn_backup_no.setParent(self.pnl_db_alert)
            self.btn_backup_no.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/No.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/NoHover.png); "
                                                                                                                           "}")

            self.btn_backup_yes = QPushButton()
            self.btn_backup_yes.resize(72, 42)
            self.btn_backup_yes.move(30, 190)
            self.btn_backup_yes.clicked.connect(self.on_click_yes_backup)
            self.btn_backup_yes.setParent(self.pnl_db_alert)
            self.btn_backup_yes.setStyleSheet("QPushButton"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Yes.png); "
                                                                                     "border : none "
                                                                                     "}"
                                                                                     "QPushButton::hover"
                                                                                     "{"
                                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/YesHover.png); "
                                                                                                                            "}")

            self.pnl_db_alert.move(500000, 800000)

            self.pnl_db_msg = QWidget()
            self.pnl_db_msg.setStyleSheet("border:0px solid grey;")
            self.pnl_db_msg.resize(320, 276)
            self.pnl_db_msg.move(500000, 800000)
            self.pnl_db_msg.setParent(self.frmDbBackup)
            self.pnl_db_msg.raise_()

            self.lbl_db_msg_bg = QLabel()
            self.lbl_db_msg_bg.setFont(QFont('Inter', 10))
            self.lbl_db_msg_bg.setStyleSheet(
                "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;"
                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/no_dev_found.png);")

            self.lbl_db_msg_bg.resize(320, 276)
            self.lbl_db_msg_bg.move(0, 0)
            self.lbl_db_msg_bg.setParent(self.pnl_db_msg)

            self.btn_db_msg_ok = QPushButton()
            self.btn_db_msg_ok.resize(72, 42)
            self.btn_db_msg_ok.move(140, 190)
            self.btn_db_msg_ok.clicked.connect(self.on_click_db_msg_ok)
            self.btn_db_msg_ok.setParent(self.pnl_db_msg)
            self.btn_db_msg_ok.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Ok.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OkHover.png); "
                                                                                                                           "}")

            self.HorizontalLyt.addWidget(self.frmDbBackup)
            pass
        except Exception as e:
            print(e)
