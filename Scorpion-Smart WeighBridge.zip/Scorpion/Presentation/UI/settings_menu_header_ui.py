from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QCheckBox, QLabel, QPushButton, QGraphicsDropShadowEffect, QFrame, QLineEdit, QWidget

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsHeaderParameterUi:
    def __init__(self):
        super().__init__()

    def create_header_parameter(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmHeaderSettings = QFrame(self)

            lblPrinterBg = QLabel(self.frmHeaderSettings)
            lblPrinterBg.resize(521, 429)
            lblPrinterBg.setParent(self.frmHeaderSettings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["parameters_components"]["header_params"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(200, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frmHeaderSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.btn_entry = QPushButton()
            self.btn_entry.setText(GlobalVariable.language_setting_items["printer_components"]["default"])
            self.btn_entry.setFont(QFont('Inter', 10))
            self.btn_entry.resize(80, 31)
            self.btn_entry.move(200, 5)
            self.btn_entry.clicked.connect(self.on_click_header_entry)
            self.btn_entry.setParent(self.frmHeaderSettings)


            self.btn_entry.setStyleSheet("QPushButton::disabled"
                                         "{"
                                         "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                         "}"
                                         )
            self.btn_re_entry = QPushButton()
            self.btn_re_entry.setText(GlobalVariable.language_setting_items["printer_components"]["custom"])
            self.btn_re_entry.setFont(QFont('Inter', 10))
            self.btn_re_entry.resize(80, 31)
            self.btn_re_entry.move(280, 5)
            self.btn_re_entry.clicked.connect(self.on_click_header_reentry)
            self.btn_re_entry.setParent(self.frmHeaderSettings)


            self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                            "{"
                                            "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_re_entry.raise_()

            self.lbl_input1_header = QLabel(self.frmHeaderSettings)
            self.lbl_input1_header.setFixedWidth(220)
            self.lbl_input1_header.setFixedHeight(31)
            self.lbl_input1_header.setGeometry(20, 50, 220, 21)
            self.lbl_input1_header.setText("Header1")
            self.lbl_input1_header.setFont(QFont('Inter', 14))
            self.lbl_input1_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input1_header.setParent(self.frmHeaderSettings)

            self.lbl_header1 = QLineEdit(self.frmHeaderSettings)
            self.lbl_header1.setFixedWidth(320)
            self.lbl_header1.setFixedHeight(21)
            self.lbl_header1.setGeometry(20, 90, 320, 21)
            self.lbl_header1.setText("Header1")
            self.lbl_header1.setFont(QFont('Inter', 14))
            self.lbl_header1.setMaxLength(14)
            self.lbl_header1.setParent(self.frmHeaderSettings)

            self.chk_header1 = QCheckBox(self.frmHeaderSettings)
            self.chk_header1.setObjectName("chk_header1")
            self.chk_header1.setFixedSize(70, 41)
            self.chk_header1.move(390, 79)
            self.chk_header1.setParent(self.frmHeaderSettings)
            self.chk_header1.setText("Entry")
            # UiComponents.set_checkbox_style_sheet(self,self.chk_header1)

            self.chk_Reheader1 = QCheckBox(self.frmHeaderSettings)
            self.chk_Reheader1.setObjectName("chk_Reheader1")
            self.chk_Reheader1.setFixedSize(70, 41)
            self.chk_Reheader1.move(390, 79)
            self.chk_Reheader1.setParent(self.frmHeaderSettings)
            self.chk_Reheader1.setText("ReEntry")
            # UiComponents.set_checkbox_style_sheet(self, self.chk_Reheader1)

            self.chk_header1.raise_()
            self.chk_Reheader1.setVisible(False)

            self.lbl_input2_header = QLabel(self.frmHeaderSettings)
            self.lbl_input2_header.setFixedWidth(220)
            self.lbl_input2_header.setFixedHeight(31)
            self.lbl_input2_header.setGeometry(20, 122, 220, 21)
            self.lbl_input2_header.setText("Header2")
            self.lbl_input2_header.setFont(QFont('Inter', 14))
            self.lbl_input2_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input2_header.setParent(self.frmHeaderSettings)

            self.lbl_header2 = QLineEdit(self.frmHeaderSettings)
            self.lbl_header2.setFixedWidth(320)
            self.lbl_header2.setFixedHeight(21)
            self.lbl_header2.setGeometry(20, 162, 320, 21)
            self.lbl_header2.setText("Header1")
            self.lbl_header2.setFont(QFont('Inter', 14))
            self.lbl_header2.setMaxLength(14)
            self.lbl_header2.setParent(self.frmHeaderSettings)

            self.chk_header2 = QCheckBox(self.frmHeaderSettings)
            self.chk_header2.setObjectName("chk_header2")
            self.chk_header2.setFixedSize(70, 41)
            self.chk_header2.move(390, 148)
            self.chk_header2.setParent(self.frmHeaderSettings)
            self.chk_header2.setText("Entry")

            self.chk_Reheader2 = QCheckBox(self.frmHeaderSettings)
            self.chk_Reheader2.setObjectName("chk_Reheader2")
            self.chk_Reheader2.setFixedSize(70, 41)
            self.chk_Reheader2.move(390, 148)
            self.chk_Reheader2.setParent(self.frmHeaderSettings)
            self.chk_Reheader2.setText("ReEntry")

            self.chk_header2.raise_()
            self.chk_Reheader2.setVisible(False)

            self.lbl_input3_header = QLabel(self.frmHeaderSettings)
            self.lbl_input3_header.setFixedWidth(220)
            self.lbl_input3_header.setFixedHeight(31)
            self.lbl_input3_header.setGeometry(20, 193, 220, 21)
            self.lbl_input3_header.setText("Header3")
            self.lbl_input3_header.setFont(QFont('Inter', 14))
            self.lbl_input3_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input3_header.setParent(self.frmHeaderSettings)

            self.lbl_header3 = QLineEdit(self.frmHeaderSettings)
            self.lbl_header3.setFixedWidth(320)
            self.lbl_header3.setFixedHeight(21)
            self.lbl_header3.setGeometry(20, 235, 320, 21)
            self.lbl_header3.setText("Header1")
            self.lbl_header3.setFont(QFont('Inter', 14))
            self.lbl_header3.setMaxLength(14)
            self.lbl_header3.setParent(self.frmHeaderSettings)

            self.chk_header3 = QCheckBox(self.frmHeaderSettings)
            self.chk_header3.setFixedSize(70, 41)
            self.chk_header3.move(390, 220)
            self.chk_header3.setParent(self.frmHeaderSettings)
            self.chk_header3.setObjectName("chk_header3")
            self.chk_header3.setText("Entry")

            self.chk_Reheader3 = QCheckBox(self.frmHeaderSettings)
            self.chk_Reheader3.setFixedSize(70, 41)
            self.chk_Reheader3.move(390, 220)
            self.chk_Reheader3.setParent(self.frmHeaderSettings)
            self.chk_Reheader3.setObjectName("chk_Reheader3")
            self.chk_Reheader3.setText("ReEntry")

            self.chk_header3.raise_()
            self.chk_Reheader3.setVisible(False)

            self.lbl_input4_header = QLabel(self.frmHeaderSettings)
            self.lbl_input4_header.setFixedWidth(220)
            self.lbl_input4_header.setFixedHeight(31)
            self.lbl_input4_header.setGeometry(20, 265, 220, 21)
            self.lbl_input4_header.setText("Header4")
            self.lbl_input4_header.setFont(QFont('Inter', 14))
            self.lbl_input4_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input4_header.setParent(self.frmHeaderSettings)

            self.lbl_header4 = QLineEdit(self.frmHeaderSettings)
            self.lbl_header4.setFixedWidth(320)
            self.lbl_header4.setFixedHeight(21)
            self.lbl_header4.setGeometry(20, 305, 320, 21)
            self.lbl_header4.setText("Header1")
            self.lbl_header4.setFont(QFont('Inter', 14))
            self.lbl_header4.setMaxLength(14)
            self.lbl_header4.setParent(self.frmHeaderSettings)

            self.chk_header4 = QCheckBox(self.frmHeaderSettings)
            self.chk_header4.setFixedSize(70, 41)
            self.chk_header4.move(390, 287)
            self.chk_header4.setParent(self.frmHeaderSettings)
            self.chk_header4.setObjectName("chk_header4")
            self.chk_header4.setText("Entry")

            self.chk_Reheader4 = QCheckBox(self.frmHeaderSettings)
            self.chk_Reheader4.setFixedSize(70, 41)
            self.chk_Reheader4.move(390, 287)
            self.chk_Reheader4.setParent(self.frmHeaderSettings)
            self.chk_Reheader4.setObjectName("chk_Reheader4")
            self.chk_Reheader4.setText("ReEntry")

            self.chk_header4.raise_()
            self.chk_Reheader4.setVisible(False)

            self.lbl_input5_header = QLabel(self.frmHeaderSettings)
            self.lbl_input5_header.setFixedWidth(220)
            self.lbl_input5_header.setFixedHeight(31)
            self.lbl_input5_header.setGeometry(20, 332, 220, 21)
            self.lbl_input5_header.setText("Header5")
            self.lbl_input5_header.setFont(QFont('Inter', 14))
            self.lbl_input5_header.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_input5_header.setParent(self.frmHeaderSettings)

            self.lbl_header5 = QLineEdit(self.frmHeaderSettings)
            self.lbl_header5.setFixedWidth(320)
            self.lbl_header5.setFixedHeight(21)
            self.lbl_header5.setGeometry(20, 371, 320, 21)
            self.lbl_header5.setText("Header1")
            self.lbl_header5.setFont(QFont('Inter', 14))
            self.lbl_header5.setMaxLength(14)
            self.lbl_header5.setParent(self.frmHeaderSettings)

            self.chk_header5 = QCheckBox(self.frmHeaderSettings)
            self.chk_header5.setFixedSize(70, 41)
            self.chk_header5.move(390, 358)
            self.chk_header5.setParent(self.frmHeaderSettings)
            self.chk_header5.setObjectName("chk_header5")
            self.chk_header5.setText("Entry")

            self.chk_Reheader5 = QCheckBox(self.frmHeaderSettings)
            self.chk_Reheader5.setFixedSize(70, 41)
            self.chk_Reheader5.move(390, 358)
            self.chk_Reheader5.setParent(self.frmHeaderSettings)
            self.chk_Reheader5.setObjectName("chk_Reheader5")
            self.chk_Reheader5.setText("ReEntry")

            self.chk_header5.raise_()
            self.chk_Reheader5.setVisible(False)

            self.lbl_header1_status = QLabel()
            self.lbl_header1_status.resize(21, 21)
            self.lbl_header1_status.move(310, 50)
            self.lbl_header1_status.setParent(self.frmHeaderSettings)

            self.lbl_header2_status = QLabel()
            self.lbl_header2_status.resize(21, 21)
            self.lbl_header2_status.move(310, 122)
            self.lbl_header2_status.setParent(self.frmHeaderSettings)

            self.lbl_header3_status = QLabel()
            self.lbl_header3_status.resize(21, 21)
            self.lbl_header3_status.move(310, 193)
            self.lbl_header3_status.setParent(self.frmHeaderSettings)

            self.lbl_header4_status = QLabel()
            self.lbl_header4_status.resize(21, 21)
            self.lbl_header4_status.move(310, 265)
            self.lbl_header4_status.setParent(self.frmHeaderSettings)

            self.lbl_header5_status = QLabel()
            self.lbl_header5_status.resize(21, 21)
            self.lbl_header5_status.move(310, 330)
            self.lbl_header5_status.setParent(self.frmHeaderSettings)

            self.btn_header_edit = QPushButton()
            self.btn_header_edit.resize(42, 42)
            self.btn_header_edit.move(370, 0)
            self.btn_header_edit.clicked.connect(self.on_click_header_edit)
            self.btn_header_edit.setParent(self.frmHeaderSettings)
            self.btn_header_edit.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                      "/Edit.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_header_edit.setGraphicsEffect(shadow)

            self.btn_header_save = QPushButton()
            self.btn_header_save.resize(42, 42)
            self.btn_header_save.move(430, 0)
            self.btn_header_save.clicked.connect(self.on_click_header_save)
            self.btn_header_save.setParent(self.frmHeaderSettings)
            self.btn_header_save.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Save.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                               )
            self.btn_header_save.setEnabled(False)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_header_save.setGraphicsEffect(shadow)

            '''panel messsage'''
            self.pnl_header_save = QWidget()
            self.pnl_header_save.setStyleSheet("border:0px solid grey;")
            self.pnl_header_save.resize(340, 180)
            self.pnl_header_save.move(50, 80)
            self.pnl_header_save.setParent(self.frmHeaderSettings)
            self.pnl_header_save.raise_()

            self.lbl_alert_bg = QLabel()
            self.lbl_alert_bg.setFont(QFont('Inter', 10))
            self.lbl_alert_bg.setStyleSheet(
                "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;"
                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/header_save.png);")
            self.lbl_alert_bg.resize(340, 180)
            self.lbl_alert_bg.move(0, 0)
            self.lbl_alert_bg.setParent(self.pnl_header_save)

            self.btn_save_no = QPushButton()
            self.btn_save_no.resize(72, 42)
            self.btn_save_no.move(220, 100)
            self.btn_save_no.clicked.connect(self.on_click_header_hide)
            self.btn_save_no.setParent(self.pnl_header_save)
            self.btn_save_no.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/No.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/NoHover.png); "
                                                                                                                           "}")

            self.btn_save_yes = QPushButton()
            self.btn_save_yes.resize(72, 42)
            self.btn_save_yes.move(30, 100)
            self.btn_save_yes.clicked.connect(self.on_click_header_save_ok)
            self.btn_save_yes.setParent(self.pnl_header_save)
            self.btn_save_yes.setStyleSheet("QPushButton"
                                              "{"
                                              "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Yes.png); "
                                                                                     "border : none "
                                                                                     "}"
                                                                                     "QPushButton::hover"
                                                                                     "{"
                                                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/YesHover.png); "
                                                                                                                            "}")

            self.pnl_header_save.move(500000, 800000)

            self.label_controls = [self.lbl_header1, self.lbl_header2, self.lbl_header3, self.lbl_header4,
                                   self.lbl_header5]
            for labels in range(len(self.label_controls)):
                UiComponents.textbox_parameters_stylesheet(self.label_controls[labels])
            GlobalEntities.header_checkbox_names.clear()
            GlobalEntities.re_header_checkbox_names.clear()
            GlobalEntities.header_checkbox_names.append(self.chk_header1)
            GlobalEntities.header_checkbox_names.append(self.chk_header2)
            GlobalEntities.header_checkbox_names.append(self.chk_header3)
            GlobalEntities.header_checkbox_names.append(self.chk_header4)
            GlobalEntities.header_checkbox_names.append(self.chk_header5)

            GlobalEntities.re_header_checkbox_names.append(self.chk_Reheader1)
            GlobalEntities.re_header_checkbox_names.append(self.chk_Reheader2)
            GlobalEntities.re_header_checkbox_names.append(self.chk_Reheader3)
            GlobalEntities.re_header_checkbox_names.append(self.chk_Reheader4)
            GlobalEntities.re_header_checkbox_names.append(self.chk_Reheader5)
            for i in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )
            for i in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[i].setStyleSheet("QCheckBox::indicator"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       "QCheckBox::indicator:checked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "background-color: #007acc;"
                                                       "}"
                                                       "QCheckBox::indicator:unchecked"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid # 555;"
                                                       "background-color: #eee;"
                                                       "}"
                                                       "QCheckBox::indicator:disabled"
                                                       "{"
                                                       "width:20px;"
                                                       "height:20px;"
                                                       "border:1px solid #555;"
                                                       "}"
                                                       )

            self.label_status.clear()
            self.label_status.append(self.lbl_header1_status)
            self.label_status.append(self.lbl_header2_status)
            self.label_status.append(self.lbl_header3_status)
            self.label_status.append(self.lbl_header4_status)
            self.label_status.append(self.lbl_header5_status)

            GlobalEntities.header_params_checkbox = {"chk_header1": "1", "chk_header2": "0", "chk_header3": "0",
                                                     "chk_header4": "0",
                                                     "chk_header5": "0", "chk_Reheader1": "1", "chk_Reheader2": "0",
                                                     "chk_Reheader3": "0",
                                                     "chk_Reheader4": "0",
                                                     "chk_Reheader5": "0"}

            GlobalEntities.text_box_entry_count = 1
            GlobalEntities.text_box_contents.clear()
            GlobalEntities.text_box_contents = [self.lbl_header1, self.lbl_header2, self.lbl_header3, self.lbl_header4,
                                                self.lbl_header5]
            self.lbl_header1.setFocus()
            GlobalEntities.parameter_active_screen_events.update({"save": self.on_click_header_save})
            GlobalEntities.parameter_active_screen_events.update({"yes": self.on_click_header_save_ok})
            GlobalEntities.parameter_active_screen_events.update({"no": self.on_click_header_hide})

            

            self.HorizontalLyt.addWidget(self.frmHeaderSettings)

            pass
        except Exception as e:
            print(e)
