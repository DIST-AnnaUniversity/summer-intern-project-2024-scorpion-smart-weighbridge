from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QLabel, QComboBox, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsMenuOutputUi:
    def __init__(self):
        super().__init__()

    def create_output_settings_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmOutputSettings = QFrame(self)

            self.lblInputSettingsBg = QLabel(self.frmOutputSettings)
            self.lblInputSettingsBg.resize(521, 429)
            self.lblInputSettingsBg.setParent(self.frmOutputSettings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(
                GlobalVariable.language_setting_items["output_config_components"]["output_config_header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(250, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frmOutputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.btnOutputEdit = QPushButton()
            self.btnOutputEdit.resize(42, 42)
            self.btnOutputEdit.move(360, 0)
            self.btnOutputEdit.clicked.connect(self.on_click_output_edit)
            self.btnOutputEdit.setParent(self.frmOutputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnOutputEdit.setGraphicsEffect(shadow)
            self.btnOutputEdit.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                    "/Edit.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); }"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);} "

                                             )

            self.btnOutputSave = QPushButton()
            self.btnOutputSave.resize(42, 42)
            self.btnOutputSave.move(420, 0)
            self.btnOutputSave.clicked.connect(self.on_click_output_save)
            self.btnOutputSave.setParent(self.frmOutputSettings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnOutputSave.setGraphicsEffect(shadow)
            self.btnOutputSave.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Save.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                             )

            self.lbl_header_position = 50

            for i in range(4):
                self.lbl_header = QLabel()
                self.lbl_header.setText(
                    GlobalVariable.language_setting_items["output_config_components"]["output_header"] + str(i + 1))
                self.lbl_header.setStyleSheet(
                    "border:0px solid lightgrey;font: 18px Regular Inter;color:#696667;text-align:left;")
                self.lbl_header.resize(111, 31)
                self.lbl_header.move(15, self.lbl_header_position)
                self.lbl_header.setParent(self.frmOutputSettings)
                self.lbl_header_position += 80

            self.cmbOutput1 = QComboBox()
            self.cmbOutput1.setFont(QFont('Inter', 12))
            self.cmbOutput1.move(20, 80)
            self.cmbOutput1.resize(421, 31)
            self.cmbOutput1.setParent(self.frmOutputSettings)

            self.cmbOutput2 = QComboBox()
            self.cmbOutput2.setFont(QFont('Inter', 12))
            self.cmbOutput2.move(20, 160)
            self.cmbOutput2.resize(421, 31)
            self.cmbOutput2.setParent(self.frmOutputSettings)

            self.cmbOutput3 = QComboBox()
            self.cmbOutput3.setFont(QFont('Inter', 12))
            self.cmbOutput3.move(20, 240)
            self.cmbOutput3.resize(421, 31)
            self.cmbOutput3.setParent(self.frmOutputSettings)

            self.cmbOutput4 = QComboBox()
            self.cmbOutput4.setFont(QFont('Inter', 12))
            self.cmbOutput4.move(20, 330)
            self.cmbOutput4.resize(421, 31)
            self.cmbOutput4.setParent(self.frmOutputSettings)

            self.lblOp1Status = QLabel()
            self.lblOp1Status.move(150, 50)
            self.lblOp1Status.resize(21, 21)
            self.lblOp1Status.setParent(self.frmOutputSettings)

            self.lblOp2Status = QLabel()
            self.lblOp2Status.move(150, 130)
            self.lblOp2Status.resize(21, 21)
            self.lblOp2Status.setParent(self.frmOutputSettings)

            self.lblOp3Status = QLabel()
            self.lblOp3Status.move(150, 210)
            self.lblOp3Status.resize(21, 21)
            self.lblOp3Status.setParent(self.frmOutputSettings)

            self.lblOp4Status = QLabel()
            self.lblOp4Status.move(150, 290)
            self.lblOp4Status.resize(21, 21)
            self.lblOp4Status.setParent(self.frmOutputSettings)

            self.cmb_input_names = [self.cmbOutput1, self.cmbOutput2, self.cmbOutput3, self.cmbOutput4]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])
            self.HorizontalLyt.addWidget(self.frmOutputSettings)

            pass
        except Exception as e:
            print(e)
