from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QComboBox, \
    QPlainTextEdit

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsSupportUi:
    def __init__(self):
        super().__init__()

    def create_support_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmSupport = QFrame(self)

            lblSupportBg = QLabel(self.frmSupport)
            lblSupportBg.resize(521, 429)
            lblSupportBg.setParent(self.frmSupport)

            self.lblContact = QLabel()
            self.lblContact.resize(221, 31)
            self.lblContact.move(1, 0)
            self.lblContact.setParent(self.frmSupport)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblContact.setGraphicsEffect(shadow)

            self.lblContactMsg = QLabel()
            self.lblContactMsg.move(10, 20)
            self.lblContactMsg.resize(520, 81)
            self.lblContactMsg.setParent(self.frmSupport)
            self.lblContactMsg.setFont(QFont('Inter', 10))

            self.lblSupport = QLabel()
            self.lblSupport.setFont(QFont('Inter', 10))
            self.lblSupport.setStyleSheet("color:white;border:0px solid grey;")
            self.lblSupport.resize(151, 41)
            self.lblSupport.move(550, 10)
            self.lblSupport.setParent(self.frmSupport)
            self.lblSupport.raise_()

            self.lblSupportMsg = QLabel()
            self.lblSupportMsg.setFont(QFont('Inter', 10))
            self.lblSupportMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblSupportMsg.resize(135, 21)
            self.lblSupportMsg.move(557, 20)
            self.lblSupportMsg.setParent(self.frmSupport)
            self.lblSupportMsg.raise_()

            self.lblName = QLabel()
            self.lblName.move(10, 90)
            self.lblName.resize(131, 21)
            self.lblName.setText("Your Name")
            self.lblName.setFont(QFont('Inter', 11))
            self.lblName.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblName.setParent(self.frmSupport)

            self.txt_support_sender_name = QLineEdit()
            self.txt_support_sender_name.move(10, 110)
            self.txt_support_sender_name.resize(420, 31)
            self.txt_support_sender_name.setFont(QFont('Inter', 15))
            self.txt_support_sender_name.setParent(self.frmSupport)
            self.txt_support_sender_name.setMaxLength(30)

            self.lblEmailHeader = QLabel()
            self.lblEmailHeader.move(10, 140)
            self.lblEmailHeader.resize(131, 21)
            self.lblEmailHeader.setText("Your Email")
            self.lblEmailHeader.setFont(QFont('Inter', 11))
            self.lblEmailHeader.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblEmailHeader.setParent(self.frmSupport)

            self.txt_support_receiver_email = QLineEdit()
            self.txt_support_receiver_email.move(10, 160)
            self.txt_support_receiver_email.resize(420, 31)
            self.txt_support_receiver_email.setFont(QFont('Inter', 12))
            self.txt_support_receiver_email.setParent(self.frmSupport)
            self.txt_support_receiver_email.setMaxLength(30)

            self.lblSubject = QLabel()
            self.lblSubject.move(10, 190)
            self.lblSubject.resize(131, 21)
            self.lblSubject.setText("Message")
            self.lblSubject.setFont(QFont('Inter', 11))
            self.lblSubject.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblSubject.setParent(self.frmSupport)

            self.cmbSupportType = QComboBox()
            self.cmbSupportType.setFont(QFont('Inter', 14))
            self.cmbSupportType.move(10, 210)
            self.cmbSupportType.resize(420, 31)
            self.cmbSupportType.setParent(self.frmSupport)
            self.supporttypes = [
                GlobalVariable.language_setting_items["notification_components"]["subject_item_1"],
                GlobalVariable.language_setting_items["notification_components"]["subject_item_2"],
                GlobalVariable.language_setting_items["notification_components"]["subject_item_3"]]
            self.cmbSupportType.clear()
            self.cmbSupportType.addItems(self.supporttypes)

            self.lblMessage = QLabel()
            self.lblMessage.setText(
                GlobalVariable.language_setting_items["notification_components"]["support_header_3"])
            self.lblMessage.setFont(QFont('Inter', 11))
            self.lblMessage.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblMessage.move(10, 250)
            self.lblMessage.resize(201, 21)
            self.lblMessage.setParent(self.frmSupport)

            self.txt_support_feedback = QPlainTextEdit()
            self.txt_support_feedback.setFont(QFont('Inter', 14))
            self.txt_support_feedback.move(10, 280)
            self.txt_support_feedback.resize(420, 60)
            self.txt_support_feedback.setParent(self.frmSupport)

            self.btnSubmit = QPushButton()
            self.btnSubmit.setText(GlobalVariable.language_setting_items["notification_components"]["btn_submit"])
            self.btnSubmit.setFont(QFont('Inter', 11))
            self.btnSubmit.resize(159, 31)
            self.btnSubmit.move(10, 365)
            self.btnSubmit.clicked.connect(self.on_click_support_submit)
            self.btnSubmit.setParent(self.frmSupport)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnSubmit.setGraphicsEffect(shadow)

            UiComponents.SupportUi(self)
            self.HorizontalLyt.addWidget(self.frmSupport)
        except Exception as e:
            print(e)
