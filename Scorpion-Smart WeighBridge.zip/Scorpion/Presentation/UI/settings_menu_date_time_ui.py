from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QPushButton, QGraphicsDropShadowEffect, QLabel, QLineEdit, QFrame, QComboBox, QWidget

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsGeneralMenu:
    def __init__(self):
        super().__init__()

    def create_date_time_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmDateTime = QFrame(self)

            self.lblDateTimeBg = QLabel(self.frmDateTime)
            self.lblDateTimeBg.resize(521, 429)
            self.lblDateTimeBg.setParent(self.frmDateTime)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["date_time_components"]["date_time_header"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(5, 3)
            self.lblHeader.setParent(self.frmDateTime)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.lblEthernet = QLabel()
            self.lblEthernet.setFont(QFont('Inter', 10))
            self.lblEthernet.setStyleSheet("color:white;border:0px solid grey;")
            self.lblEthernet.resize(151, 41)
            self.lblEthernet.move(550, 10)
            self.lblEthernet.setParent(self.frmDateTime)
            self.lblEthernet.raise_()

            self.lblEthernetMsg = QLabel()
            self.lblEthernetMsg.setFont(QFont('Inter', 10))
            self.lblEthernetMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblEthernetMsg.resize(135, 21)
            self.lblEthernetMsg.move(557, 20)
            self.lblEthernetMsg.setParent(self.frmDateTime)
            self.lblEthernetMsg.raise_()

            self.btnDateTimeEdit = QPushButton()
            self.btnDateTimeEdit.resize(42, 42)
            self.btnDateTimeEdit.move(400, 8)
            self.btnDateTimeEdit.clicked.connect(self.on_click_date_time_edit)
            self.btnDateTimeEdit.setParent(self.frmDateTime)
            self.btnDateTimeEdit.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Edit.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditHover.png);} "
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditDisable.png); }"

                                               )

            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnDateTimeEdit.setGraphicsEffect(shadow)

            self.btnDateTimeSave = QPushButton()
            self.btnDateTimeSave.resize(42, 42)
            self.btnDateTimeSave.move(450, 8)
            self.btnDateTimeSave.clicked.connect(self.on_click_date_time_save)
            self.btnDateTimeSave.setParent(self.frmDateTime)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnDateTimeSave.setGraphicsEffect(shadow)
            self.btnDateTimeSave.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Save.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                               )

            self.lblContinentHeader = QLabel()
            self.lblContinentHeader.setText(
                GlobalVariable.language_setting_items["date_time_components"]["header1"])
            self.lblContinentHeader.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblContinentHeader.resize(140, 27)
            self.lblContinentHeader.move(10, 60)
            self.lblContinentHeader.setParent(self.frmDateTime)

            self.txt_date = QLineEdit()
            self.txt_date.setFont(QFont('Inter', 15))
            self.txt_date.resize(481, 37)
            self.txt_date.move(10, 90)
            self.txt_date.setPlaceholderText("DD-MM-YYYY")
            self.txt_date.setMaxLength(10)
            self.txt_date.setInputMask("99-99-9999")
            self.txt_date.setParent(self.frmDateTime)

            self.cmbContinent = QComboBox()
            self.cmbContinent.setFont(QFont('Inter', 15))
            self.cmbContinent.resize(481, 37)
            self.cmbContinent.move(10, 90)
            self.cmbContinent.setParent(self.frmDateTime)
            self.cmbContinent.currentIndexChanged.connect(self.updateregioncmb)

            self.lblRegionHeader = QLabel()
            self.lblRegionHeader.setText(
                GlobalVariable.language_setting_items["date_time_components"]["header2"])
            self.lblRegionHeader.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblRegionHeader.resize(140, 27)
            self.lblRegionHeader.move(10, 140)
            self.lblRegionHeader.setParent(self.frmDateTime)

            self.txt_time = QLineEdit()
            self.txt_time.setFont(QFont('Inter', 15))
            self.txt_time.resize(481, 37)
            self.txt_time.move(10, 170)
            self.txt_time.setPlaceholderText("hh:mm")
            self.txt_time.setText("00:00")
            self.txt_time.setInputMask("99:99")
            self.txt_time.setMaxLength(5)
            self.txt_time.setParent(self.frmDateTime)

            self.cmbRegion = QComboBox()
            self.cmbRegion.setFont(QFont('Inter', 15))
            self.cmbRegion.resize(481, 37)
            self.cmbRegion.move(10, 170)
            self.cmbRegion.setParent(self.frmDateTime)

            self.lbl_continent_status = QLabel()
            self.lbl_continent_status.resize(21, 21)
            self.lbl_continent_status.move(430, 62)
            self.lbl_continent_status.setParent(self.frmDateTime)

            self.lbl_region_status = QLabel()
            self.lbl_region_status.resize(21, 21)
            self.lbl_region_status.move(430, 142)
            self.lbl_region_status.setParent(self.frmDateTime)

            self.wt_auto_manual = QWidget()
            self.wt_auto_manual.setStyleSheet("border:1px solid rgb(222, 222, 222);")
            self.wt_auto_manual.resize(190, 51)
            self.wt_auto_manual.move(180, 2)
            self.wt_auto_manual.setParent(self.frmDateTime)
            self.wt_auto_manual.raise_()

            self.btn_auto = QPushButton()
            self.btn_auto.setText(GlobalVariable.language_setting_items["date_time_components"]["auto_mode"])
            self.btn_auto.setFont(QFont('Inter', 12))
            self.btn_auto.resize(91, 43)
            self.btn_auto.move(4, 4)
            self.btn_auto.clicked.connect(self.on_click_date_time_auto)
            self.btn_auto.setParent(self.wt_auto_manual)
            self.btn_auto.setStyleSheet(" QPushButton"
                                        "{"
                                        "background-color:black;"
                                        "border-radius:6px;"
                                        "color: rgb(255, 255, 255);"
                                        "}")

            self.btn_manual = QPushButton()
            self.btn_manual.setText(GlobalVariable.language_setting_items["date_time_components"]["manual_mode"])
            self.btn_manual.setFont(QFont('Inter', 12))
            self.btn_manual.resize(91, 43)
            self.btn_manual.move(94, 4)
            self.btn_manual.clicked.connect(self.on_click_date_time_manual)
            self.btn_manual.setParent(self.wt_auto_manual)
            self.btn_manual.setStyleSheet(" QPushButton"
                                          "{"
                                          "background-color:rgb(255,255,255);"
                                          "color: rgb(0, 0, 0);"
                                          "border:0px"
                                          "}")

            self.txt_date_names = [self.txt_date, self.txt_time]
            for i in range(len(self.txt_date_names)):
                UiComponents.textbox_default_stylesheet(self.txt_date_names[i])
                self.txt_date_names[i].setEnabled(False)

            self.cmb_date_names = [self.cmbContinent, self.cmbRegion]
            for i in range(len(self.cmb_date_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_date_names[i])

            self.label_status.clear()
            self.label_status.append(self.lbl_continent_status)
            self.label_status.append(self.lbl_region_status)

            self.HorizontalLyt.addWidget(self.frmDateTime)
            pass
        except Exception as e:
            print(e)