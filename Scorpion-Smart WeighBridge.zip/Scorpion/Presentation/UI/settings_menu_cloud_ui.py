from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QCheckBox

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsCloudUi:
    def __init__(self):
        super().__init__()

    def create_cloud_storage_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frm_cloud_settings = QFrame(self)

            lblDbBackupBg = QLabel(self.frm_cloud_settings)
            lblDbBackupBg.resize(760, 693)
            lblDbBackupBg.setParent(self.frm_cloud_settings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(
                GlobalVariable.language_setting_items["cloud_storage_componenets"]["cloud_storage_header"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(500, 41)
            self.lblHeader.move(8, 8)
            self.lblHeader.setParent(self.frm_cloud_settings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.lbl_header_1 = QLabel()
            self.lbl_header_1.setText(
                GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_1"])
            self.lbl_header_1.move(10, 50)
            self.lbl_header_1.resize(191, 21)
            self.lbl_header_1.setParent(self.frm_cloud_settings)
            self.lbl_header_1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_2 = QLabel()
            self.lbl_header_2.setText(GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_2"])
            self.lbl_header_2.move(290, 50)
            self.lbl_header_2.resize(191, 21)
            self.lbl_header_2.setParent(self.frm_cloud_settings)
            self.lbl_header_2.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_3 = QLabel()
            self.lbl_header_3.setText(
                GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_3"])
            self.lbl_header_3.move(10, 130)
            self.lbl_header_3.resize(191, 31)
            self.lbl_header_3.setParent(self.frm_cloud_settings)
            self.lbl_header_3.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_4 = QLabel()
            self.lbl_header_4.setText(GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_4"])
            self.lbl_header_4.move(290, 130)
            self.lbl_header_4.resize(191, 21)
            self.lbl_header_4.setParent(self.frm_cloud_settings)
            self.lbl_header_4.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_5 = QLabel()
            self.lbl_header_5.setText(
                GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_5"])
            self.lbl_header_5.move(10, 240)
            self.lbl_header_5.resize(191, 21)
            self.lbl_header_5.setParent(self.frm_cloud_settings)
            self.lbl_header_5.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_6 = QLabel()
            self.lbl_header_6.setText(GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_6"])
            self.lbl_header_6.move(290, 240)
            self.lbl_header_6.resize(191, 31)
            self.lbl_header_6.setParent(self.frm_cloud_settings)
            self.lbl_header_6.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_7 = QLabel()
            self.lbl_header_7.setText(
                GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_7"])
            self.lbl_header_7.move(10, 330)
            self.lbl_header_7.resize(191, 21)
            self.lbl_header_7.setParent(self.frm_cloud_settings)
            self.lbl_header_7.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header_8 = QLabel()
            self.lbl_header_8.setText(GlobalVariable.language_setting_items["cloud_storage_componenets"]["header_8"])
            self.lbl_header_8.move(290, 330)
            self.lbl_header_8.resize(191, 21)
            self.lbl_header_8.setParent(self.frm_cloud_settings)
            self.lbl_header_8.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

            self.lbl_header1_status = QLabel()
            self.lbl_header1_status.resize(21, 21)
            self.lbl_header1_status.move(210, 50)
            self.lbl_header1_status.setParent(self.frm_cloud_settings)

            self.lbl_header2_status = QLabel()
            self.lbl_header2_status.resize(21, 21)
            self.lbl_header2_status.move(410, 50)
            self.lbl_header2_status.setParent(self.frm_cloud_settings)

            self.lbl_header3_status = QLabel()
            self.lbl_header3_status.resize(21, 21)
            self.lbl_header3_status.move(210, 130)
            self.lbl_header3_status.setParent(self.frm_cloud_settings)

            self.lbl_header4_status = QLabel()
            self.lbl_header4_status.resize(21, 21)
            self.lbl_header4_status.move(410, 130)
            self.lbl_header4_status.setParent(self.frm_cloud_settings)

            self.lbl_header5_status = QLabel()
            self.lbl_header5_status.resize(21, 21)
            self.lbl_header5_status.move(210, 240)
            self.lbl_header5_status.setParent(self.frm_cloud_settings)

            self.lbl_header6_status = QLabel()
            self.lbl_header6_status.resize(21, 21)
            self.lbl_header6_status.move(410, 240)
            self.lbl_header6_status.setParent(self.frm_cloud_settings)

            self.lbl_header7_status = QLabel()
            self.lbl_header7_status.resize(21, 21)
            self.lbl_header7_status.move(210, 330)
            self.lbl_header7_status.setParent(self.frm_cloud_settings)

            self.lbl_header8_status = QLabel()
            self.lbl_header8_status.resize(21, 21)
            self.lbl_header8_status.move(410, 330)
            self.lbl_header8_status.setParent(self.frm_cloud_settings)

            self.txt_customer_name = QLineEdit()
            self.txt_customer_name.move(10, 80)
            self.txt_customer_name.resize(200, 31)
            self.txt_customer_name.setMaxLength(20)
            self.txt_customer_name.setFont(QFont('Inter', 12))
            self.txt_customer_name.setParent(self.frm_cloud_settings)

            self.txt_domain_name = QLineEdit()
            self.txt_domain_name.move(290, 80)
            self.txt_domain_name.resize(200, 31)
            self.txt_domain_name.setMaxLength(20)
            self.txt_domain_name.setFont(QFont('Inter', 12))
            self.txt_domain_name.setParent(self.frm_cloud_settings)

            self.txt_customer_code = QLineEdit()
            self.txt_customer_code.move(10, 160)
            self.txt_customer_code.resize(200, 31)
            self.txt_customer_code.setMaxLength(4)
            self.txt_customer_code.setFont(QFont('Inter', 12))
            self.txt_customer_code.setParent(self.frm_cloud_settings)

            self.txt_device_id = QLineEdit()
            self.txt_device_id.move(290, 160)
            self.txt_device_id.resize(200, 31)
            self.txt_device_id.setMaxLength(5)
            self.txt_device_id.setFont(QFont('Inter', 12))
            self.txt_device_id.setParent(self.frm_cloud_settings)

            self.txt_server_hostname = QLineEdit()
            self.txt_server_hostname.move(10, 270)
            self.txt_server_hostname.resize(200, 31)
            # self.txt_server_hostname.setMaxLength(40)
            self.txt_server_hostname.setFont(QFont('Inter', 12))
            self.txt_server_hostname.setParent(self.frm_cloud_settings)

            self.txt_server_db_name = QLineEdit()
            self.txt_server_db_name.move(290, 270)
            self.txt_server_db_name.resize(200, 31)
            self.txt_server_db_name.setMaxLength(20)
            self.txt_server_db_name.setFont(QFont('Inter', 12))
            self.txt_server_db_name.setParent(self.frm_cloud_settings)

            self.chkShowPassword = QCheckBox()
            self.chkShowPassword.move(190, 330)
            self.chkShowPassword.resize(111, 20)
            self.chkShowPassword.setParent(self.frm_cloud_settings)
            # self.chkShowPassword.stateChanged.connect(self.cloud_storage_checkbox_enable)
            self.chkShowPassword.setStyleSheet("font: 12px Regular Inter;")
            self.chkShowPassword.raise_()
            self.chkShowPassword.stateChanged.connect(self.chk_show_server_password)

            self.txt_server_password = QLineEdit()
            self.txt_server_password.move(10, 360)
            self.txt_server_password.resize(200, 31)
            self.txt_server_password.setMaxLength(25)
            self.txt_server_password.setFont(QFont('Inter', 12))
            self.txt_server_password.setParent(self.frm_cloud_settings)
            self.txt_server_password.setEchoMode(QLineEdit.Password)

            self.txt_server_port = QLineEdit()
            self.txt_server_port.move(290, 360)
            self.txt_server_port.resize(200, 31)
            self.txt_server_port.setMaxLength(5)
            self.txt_server_port.setFont(QFont('Inter', 31))
            self.txt_server_port.setParent(self.frm_cloud_settings)

            self.txt_names = [self.txt_server_port, self.txt_server_password, self.txt_server_db_name,
                              self.txt_server_hostname, self.txt_device_id, self.txt_customer_code,
                              self.txt_domain_name,
                              self.txt_customer_name]
            for i in range(len(self.txt_names)):
                UiComponents.textbox_parameters_stylesheet(self.txt_names[i])

            self.btn_cloud_edit = QPushButton()
            self.btn_cloud_edit.resize(42, 42)
            self.btn_cloud_edit.move(370, 0)
            self.btn_cloud_edit.clicked.connect(self.on_click_cloud_edit)
            self.btn_cloud_edit.setParent(self.frm_cloud_settings)
            self.btn_cloud_edit.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                      "/Edit.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_cloud_edit.setGraphicsEffect(shadow)

            self.btn_cloud_save = QPushButton()
            self.btn_cloud_save.resize(42, 42)
            self.btn_cloud_save.move(430, 0)
            self.btn_cloud_save.clicked.connect(self.on_click_cloud_save)
            self.btn_cloud_save.setParent(self.frm_cloud_settings)
            self.btn_cloud_save.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Save.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_cloud_save.setGraphicsEffect(shadow)

            self.label_status.clear()
            self.label_status.append(self.lbl_header1_status)
            self.label_status.append(self.lbl_header2_status)
            self.label_status.append(self.lbl_header3_status)
            self.label_status.append(self.lbl_header4_status)
            self.label_status.append(self.lbl_header5_status)
            self.label_status.append(self.lbl_header6_status)
            self.label_status.append(self.lbl_header7_status)
            self.label_status.append(self.lbl_header8_status)

            self.HorizontalLyt.addWidget(self.frm_cloud_settings)


            pass
        except Exception as e:
            print(e)