class SettingsDeviceInfoUi:
    def __init__(self):
        super().__init__()

    def create_device_info_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()
        except Exception as e:
            print(e)
