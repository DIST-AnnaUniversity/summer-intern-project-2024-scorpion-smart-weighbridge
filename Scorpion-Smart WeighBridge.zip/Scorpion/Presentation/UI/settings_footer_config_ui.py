from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsGeneralFooter:
    def __init__(self):
        super().__init__()

    def create_footer_config_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmFooter = QFrame(self)
            
            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["header_components"]["footer_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(5, 3)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)
            self.lblHeader.setParent(self.frmFooter)

            lblHeadersBg = QLabel(self.frmFooter)
            lblHeadersBg.resize(760, 693)
            lblHeadersBg.setParent(self.frmFooter)

            self.lblHeader = QLabel()
            self.lblHeader.setFont(QFont('Inter', 10))
            self.lblHeader.setStyleSheet("color:white;border:0px solid grey;")
            self.lblHeader.resize(151, 41)
            self.lblHeader.move(550, 10)
            self.lblHeader.setParent(self.frmFooter)
            self.lblHeader.raise_()

            self.lblHeaderMsg = QLabel()
            self.lblHeaderMsg.setFont(QFont('Inter', 10))
            self.lblHeaderMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblHeaderMsg.resize(135, 21)
            self.lblHeaderMsg.move(557, 20)
            self.lblHeaderMsg.setParent(self.frmFooter)
            self.lblHeaderMsg.raise_()

            self.lblHeader1 = QLabel()
            self.lblHeader1.setText(GlobalVariable.language_setting_items["footer_components"]["footer_1"])
            self.lblHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader1.resize(145, 21)
            self.lblHeader1.move(10, 50)
            self.lblHeader1.setParent(self.frmFooter)

            self.txtFooter1 = QLineEdit()
            self.txtFooter1.move(8, 80)
            self.txtFooter1.resize(421, 31)
            self.txtFooter1.setMaxLength(15)
            self.txtFooter1.setFont(QFont('Inter', 12))
            self.txtFooter1.setParent(self.frmFooter)

            self.lblHeader2 = QLabel()
            self.lblHeader2.setText(GlobalVariable.language_setting_items["footer_components"]["footer_2"])
            self.lblHeader2.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader2.resize(145, 21)
            self.lblHeader2.move(10, 120)
            self.lblHeader2.setParent(self.frmFooter)

            self.txtFooter2 = QLineEdit()
            self.txtFooter2.setFont(QFont('Inter', 12))
            self.txtFooter2.setMaxLength(15)
            self.txtFooter2.resize(421, 31)
            self.txtFooter2.move(10, 150)
            self.txtFooter2.setParent(self.frmFooter)

            self.lblHeader3 = QLabel()
            self.lblHeader3.setText(GlobalVariable.language_setting_items["footer_components"]["footer_3"])
            self.lblHeader3.setStyleSheet(
                "border:0px solid lightgrey;font: 12px Regular Inter;color:#696667;text-align:left;")
            self.lblHeader3.resize(145, 21)
            self.lblHeader3.move(10, 190)
            self.lblHeader3.setParent(self.frmFooter)

            self.txtFooter3 = QLineEdit()
            self.txtFooter3.setFont(QFont('Inter', 12))
            self.txtFooter3.setMaxLength(15)
            self.txtFooter3.resize(421, 31)
            self.txtFooter3.move(10, 220)
            self.txtFooter3.setParent(self.frmFooter)            

            self.btnFooterEdit = QPushButton()
            self.btnFooterEdit.resize(42, 42)
            self.btnFooterEdit.move(360, 0)
            self.btnFooterEdit.clicked.connect(self.on_click_footer_config_edit)
            self.btnFooterEdit.setParent(self.frmFooter)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnFooterEdit.setGraphicsEffect(shadow)
            self.btnFooterEdit.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                    "/Edit.png); "
                                                                                    "border : none; "
                                                                                    "}QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); }"

                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); }"

                                             )

            self.btnFooterSave = QPushButton()
            self.btnFooterSave.resize(42, 42)
            self.btnFooterSave.move(420, 0)
            self.btnFooterSave.clicked.connect(self.on_click_footer_config_save)
            self.btnFooterSave.setParent(self.frmFooter)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnFooterSave.setGraphicsEffect(shadow)
            self.btnFooterSave.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Save.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                             )

            self.lbl_footer1_status = QLabel()
            self.lbl_footer1_status.resize(21, 21)
            self.lbl_footer1_status.move(405, 50)
            self.lbl_footer1_status.setParent(self.frmFooter)

            self.lbl_footer2_status = QLabel()
            self.lbl_footer2_status.resize(21, 21)
            self.lbl_footer2_status.move(405, 122)
            self.lbl_footer2_status.setParent(self.frmFooter)

            self.lbl_footer3_status = QLabel()
            self.lbl_footer3_status.resize(21, 21)
            self.lbl_footer3_status.move(405, 193)
            self.lbl_footer3_status.setParent(self.frmFooter)

            self.label_status.clear()
            self.label_status.append(self.lbl_footer1_status)
            self.label_status.append(self.lbl_footer2_status)
            self.label_status.append(self.lbl_footer3_status)

            text_inputs = [self.txtFooter1, self.txtFooter2, self.txtFooter3]
            for txtInput in text_inputs:
                UiComponents.textbox_default_stylesheet(txtInput)

            self.HorizontalLyt.addWidget(self.frmFooter)
            pass
        except Exception as e:
            print(e)