from PyQt5.QtCore import QRegExp
from PyQt5.QtGui import QFont, QRegExpValidator
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect, QLineEdit, QPushButton

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsProfileDetailsUi:
    def __init__(self):
        super().__init__()

    def create_profile_details_ui(self):
        for i in reversed(range(self.HorizontalLyt.count())):
            self.HorizontalLyt.itemAt(i).widget().deleteLater()

        self.frmProfileDetails = QFrame(self)

        self.lblProfileBg = QLabel(self.frmProfileDetails)
        self.lblProfileBg.resize(521, 429)
        self.lblProfileBg.setParent(self.frmProfileDetails)
        self.lblProfileBg.setStyleSheet("background-color:white;")

        self.lblProfileinfoPic = QLabel()
        self.lblProfileinfoPic.move(10, 35)
        self.lblProfileinfoPic.resize(104, 104)
        self.lblProfileinfoPic.setParent(self.frmProfileDetails)
        self.lblProfileinfoPic.setStyleSheet("border:2px solid lightgrey;border-radius:7px;")

        self.lblProfileHeader1 = QLabel()
        self.lblProfileHeader1.setText(
            GlobalVariable.language_setting_items["profile_settings_components"]["profile_header"])
        self.lblProfileHeader1.move(10, 1)
        self.lblProfileHeader1.resize(261, 31)
        self.lblProfileHeader1.setParent(self.frmProfileDetails)
        self.lblProfileHeader1.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;background-color:transparent")
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.lblProfileHeader1.setGraphicsEffect(shadow)

        self.lblProfileHeader3 = QLabel()
        self.lblProfileHeader3.setText(
            GlobalVariable.language_setting_items["profile_settings_components"]["profile_header_1"])
        self.lblProfileHeader3.move(10, 150)
        self.lblProfileHeader3.resize(191, 31)
        self.lblProfileHeader3.setParent(self.frmProfileDetails)
        self.lblProfileHeader3.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

        self.lblProfileHeader4 = QLabel()
        self.lblProfileHeader4.setText(
            GlobalVariable.language_setting_items["profile_settings_components"]["profile_header_2"])
        self.lblProfileHeader4.move(10, 250)
        self.lblProfileHeader4.resize(205, 31)
        self.lblProfileHeader4.setParent(self.frmProfileDetails)
        self.lblProfileHeader4.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

        self.lblProfileHeader5 = QLabel()
        self.lblProfileHeader5.setText(
            GlobalVariable.language_setting_items["profile_settings_components"]["profile_header_4"])
        self.lblProfileHeader5.move(300, 250)
        self.lblProfileHeader5.resize(71, 31)
        self.lblProfileHeader5.setParent(self.frmProfileDetails)
        self.lblProfileHeader5.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

        self.lblProfileHeader6 = QLabel()
        self.lblProfileHeader6.setText(
            GlobalVariable.language_setting_items["profile_settings_components"]["profile_header_3"])
        self.lblProfileHeader6.move(300, 150)
        self.lblProfileHeader6.resize(71, 31)
        self.lblProfileHeader6.setParent(self.frmProfileDetails)
        self.lblProfileHeader6.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")

        self.label_2 = QLabel()
        self.label_2.move(120, 5)
        self.label_2.resize(361, 31)
        self.label_2.setStyleSheet("color: rgb(17, 50, 238);font:10px Regular Inter;")
        self.label_2.setText(GlobalVariable.language_setting_items["profile_settings_components"]["profile_note"])
        self.label_2.setParent(self.frmProfileDetails)

        self.txtProfileInfoUserName = QLineEdit()
        self.txtProfileInfoUserName.move(10, 190)
        self.txtProfileInfoUserName.resize(200, 31)
        self.txtProfileInfoUserName.setMaxLength(10)
        self.txtProfileInfoUserName.setFont(QFont('Inter', 12))
        self.txtProfileInfoUserName.setParent(self.frmProfileDetails)
        self.txtProfileInfoUserName.setStyleSheet(
            "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid "
            "lightgrey;")

        self.txtProfileInfoPhoneNumber = QLineEdit()
        self.txtProfileInfoPhoneNumber.move(10, 290)
        self.txtProfileInfoPhoneNumber.resize(200, 31)
        self.txtProfileInfoPhoneNumber.setMaxLength(10)
        self.txtProfileInfoPhoneNumber.setFont(QFont('Inter', 12))
        self.txtProfileInfoPhoneNumber.setParent(self.frmProfileDetails)
        self.txtProfileInfoPhoneNumber.setStyleSheet(
            "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

        self.txtProfileInfoEmailId = QLineEdit()
        self.txtProfileInfoEmailId.move(300, 190)
        self.txtProfileInfoEmailId.resize(200, 31)
        self.txtProfileInfoEmailId.setMaxLength(20)
        self.txtProfileInfoEmailId.setFont(QFont('Inter', 14))
        self.txtProfileInfoEmailId.setParent(self.frmProfileDetails)
        self.txtProfileInfoEmailId.setStyleSheet(
            "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

        self.txtUserRole = QLineEdit()
        self.txtUserRole.setEnabled(False)
        self.txtUserRole.move(300, 290)
        self.txtUserRole.resize(200, 31)
        self.txtUserRole.setFont(QFont('Inter', 12))
        self.txtUserRole.setParent(self.frmProfileDetails)
        self.txtUserRole.setStyleSheet(
            "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

        self.btnProfileDetailsEdit = QPushButton()
        self.btnProfileDetailsEdit.resize(42, 42)
        self.btnProfileDetailsEdit.move(360, 0)
        self.btnProfileDetailsEdit.clicked.connect(self.on_click_profile_edit)
        self.btnProfileDetailsEdit.setParent(self.frmProfileDetails)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnProfileDetailsEdit.setGraphicsEffect(shadow)
        self.btnProfileDetailsEdit.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Edit.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditHover.png); "
                                                                                                                               "background-color:transparent;"
                                                                                                                               "}"
                                                                                        "QPushButton::disabled"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditDisable.png); "
                                                                                                                               "background-color:transparent;"
                                                                                                                               "}"
                                                 )
        self.btnProfileDetailsSave = QPushButton()
        self.btnProfileDetailsSave.resize(42, 42)
        self.btnProfileDetailsSave.move(420, 0)
        self.btnProfileDetailsSave.clicked.connect(self.on_click_profile_save)
        self.btnProfileDetailsSave.setParent(self.frmProfileDetails)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnProfileDetailsSave.setGraphicsEffect(shadow)
        self.btnProfileDetailsSave.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Save.png); "
                                                                                        "border : none; "
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                               "background-color:transparent;"
                                                                                                                               "}"
                                                 )

        self.btnProfilePictureEdit = QPushButton()
        self.btnProfilePictureEdit.resize(128, 36)
        self.btnProfilePictureEdit.move(150, 80)
        self.btnProfilePictureEdit.clicked.connect(self.on_click_profile_picture_edit)
        self.btnProfilePictureEdit.setParent(self.frmProfileDetails)
        self.btnProfilePictureEdit.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPicture.png); "
                                                                                        "border : none "
                                                                                        "}"
                                                                                        "QPushButton::hover"
                                                                                        "{"
                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPictureHover.png);"
                                                                                                                               "}"
                                                                                                                               "QPushButton::disabled"
                                                                                                                               "{"
                                                                                                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/UploadPictureDisable.png); "
                                                                                                                                                                      "}"

                                                 )

        self.lblProfileInfo = QLabel()
        self.lblProfileInfo.setFont(QFont('Inter', 10))
        self.lblProfileInfo.setStyleSheet("color:white;border:0px solid grey;")
        self.lblProfileInfo.resize(151, 41)
        self.lblProfileInfo.move(350, 8)
        # self.lblProfileInfo.setParent(self.frmProfileDetails)
        self.lblProfileInfo.raise_()

        self.txtUsername = QLabel()
        self.txtUsername.setStyleSheet("font-weight:bold;border:0px solid grey;")
        self.txtUsername.resize(151, 41)
        self.txtUsername.move(180, 40)
        self.txtUsername.setFont(QFont('Inter', 24))
        self.txtUsername.setParent(self.frmProfileDetails)

        """Status Label"""
        self.lblProfileUserNameStatus = QLabel()
        self.lblProfileUserNameStatus.setFont(QFont('Inter', 10))
        self.lblProfileUserNameStatus.setStyleSheet("border:0px solid grey;")
        self.lblProfileUserNameStatus.move(200, 150)
        self.lblProfileUserNameStatus.resize(21, 21)
        self.lblProfileUserNameStatus.setParent(self.frmProfileDetails)

        self.lblProfilePhoneNumber = QLabel()
        self.lblProfilePhoneNumber.setFont(QFont('Inter', 10))
        self.lblProfilePhoneNumber.setStyleSheet("border:0px solid grey;")
        self.lblProfilePhoneNumber.move(200, 250)
        self.lblProfilePhoneNumber.resize(21, 21)
        self.lblProfilePhoneNumber.setParent(self.frmProfileDetails)

        self.lblProfileEmailStatus = QLabel()
        self.lblProfileEmailStatus.setFont(QFont('Inter', 10))
        self.lblProfileEmailStatus.setStyleSheet("border:0px solid grey;")
        self.lblProfileEmailStatus.move(400, 150)
        self.lblProfileEmailStatus.resize(21, 21)
        self.lblProfileEmailStatus.setParent(self.frmProfileDetails)

        self.lblProfileRoleStatus = QLabel()
        self.lblProfileRoleStatus.setFont(QFont('Inter', 10))
        self.lblProfileRoleStatus.setStyleSheet("border:0px solid grey;")
        self.lblProfileRoleStatus.move(400, 250)
        self.lblProfileRoleStatus.resize(21, 21)
        self.lblProfileRoleStatus.setParent(self.frmProfileDetails)

        self.txtUserRole.setStyleSheet(
            "color:grey;font: 18px Inter;border : 0px solid lightgrey;border-bottom:1px solid lightgrey;")
        text_inputs = [self.txtProfileInfoUserName, self.txtProfileInfoEmailId, self.txtProfileInfoPhoneNumber, self.txtUserRole]
        for txtInput in text_inputs:
            UiComponents.textbox_default_stylesheet(txtInput)

        Int = QRegExpValidator(QRegExp("\\d+"))
        self.txtProfileInfoPhoneNumber.setValidator(Int)
        reg_ex = QRegExp("[a-zA-Z0-9]+$")
        username_validator = QRegExpValidator(reg_ex, self.txtProfileInfoUserName)
        self.txtProfileInfoUserName.setValidator(username_validator)

        email_regex = QRegExp("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}")
        email_validator = QRegExpValidator(email_regex, self.txtProfileInfoEmailId)
        self.txtProfileInfoEmailId.setValidator(email_validator)

        self.HorizontalLyt.addWidget(self.frmProfileDetails)