from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsDomainUi:
    def __init__(self):
        super().__init__()

    def create_domain_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frm_domain_settings = QFrame(self)

            lblPrinterBg = QLabel(self.frm_domain_settings)
            lblPrinterBg.resize(521, 429)
            lblPrinterBg.setParent(self.frm_domain_settings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["domain_settings"]["domain_header_name"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(250, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frm_domain_settings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.btn_domain_edit = QPushButton()
            self.btn_domain_edit.resize(42, 42)
            self.btn_domain_edit.move(370, 0)
            self.btn_domain_edit.clicked.connect(self.on_click_domain_edit)
            self.btn_domain_edit.setParent(self.frm_domain_settings)
            self.btn_domain_edit.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                      "/Edit.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_domain_edit.setGraphicsEffect(shadow)

            self.btn_domain_save = QPushButton()
            self.btn_domain_save.resize(42, 42)
            self.btn_domain_save.move(430, 0)
            self.btn_domain_save.clicked.connect(self.on_click_domain_save)
            self.btn_domain_save.setParent(self.frm_domain_settings)
            self.btn_domain_save.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                      "/Save.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                             "}"
                                                                                                                             "QPushButton::disabled"
                                                                                                                             "{"
                                                                                                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                               )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_domain_save.setGraphicsEffect(shadow)

            self.lbl_header1 = QLabel(self.frm_domain_settings)
            self.lbl_header1.setFixedWidth(220)
            self.lbl_header1.setFixedHeight(31)
            self.lbl_header1.setGeometry(20, 80, 220, 21)
            self.lbl_header1.setText(GlobalVariable.language_setting_items["domain_settings"]["domain_header_1"])
            self.lbl_header1.setFont(QFont('Inter', 14))
            self.lbl_header1.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_header1.setParent(self.frm_domain_settings)

            self.txt_domain_name = QLineEdit(self.frm_domain_settings)
            self.txt_domain_name.setFixedWidth(320)
            self.txt_domain_name.setFixedHeight(21)
            self.txt_domain_name.setGeometry(20, 120, 320, 21)
            self.txt_domain_name.setText("NA")
            self.txt_domain_name.setFont(QFont('Inter', 14))
            self.txt_domain_name.setParent(self.frm_domain_settings)

            self.lbl_header_2 = QLabel(self.frm_domain_settings)
            self.lbl_header_2.setFixedWidth(220)
            self.lbl_header_2.setFixedHeight(31)
            self.lbl_header_2.setGeometry(20, 180, 220, 21)
            self.lbl_header_2.setText(GlobalVariable.language_setting_items["domain_settings"]["domain_header_2"])
            self.lbl_header_2.setFont(QFont('Inter', 14))
            self.lbl_header_2.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_header_2.setParent(self.frm_domain_settings)

            self.txt_cust_code = QLineEdit(self.frm_domain_settings)
            self.txt_cust_code.setFixedWidth(320)
            self.txt_cust_code.setFixedHeight(21)
            self.txt_cust_code.setGeometry(20, 220, 320, 21)
            self.txt_cust_code.setText("Header1")
            self.txt_cust_code.setFont(QFont('Inter', 14))
            self.txt_cust_code.setParent(self.frm_domain_settings)

            self.lbl_header3 = QLabel(self.frm_domain_settings)
            self.lbl_header3.setFixedWidth(220)
            self.lbl_header3.setFixedHeight(31)
            self.lbl_header3.setGeometry(20, 280, 220, 21)
            self.lbl_header3.setText(GlobalVariable.language_setting_items["domain_settings"]["domain_header_3"])
            self.lbl_header3.setFont(QFont('Inter', 14))
            self.lbl_header3.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_header3.setParent(self.frm_domain_settings)

            self.txt_device_id = QLineEdit(self.frm_domain_settings)
            self.txt_device_id.setFixedWidth(320)
            self.txt_device_id.setFixedHeight(21)
            self.txt_device_id.setGeometry(20, 330, 320, 21)
            self.txt_device_id.setText("Header1")
            self.txt_device_id.setFont(QFont('Inter', 14))
            self.txt_device_id.setParent(self.frm_domain_settings)

            self.label_controls = [self.txt_domain_name, self.txt_cust_code, self.txt_device_id]
            for labels in range(len(self.label_controls)):
                UiComponents.textbox_parameters_stylesheet(self.label_controls[labels])

            self.btn_configure_device = QPushButton()
            self.btn_configure_device.setObjectName("configure_device")
            self.btn_configure_device.setText(GlobalVariable.language_setting_items["domain_settings"]["domain_header_4"])
            self.btn_configure_device.setFont(QFont('Inter', 10))
            self.btn_configure_device.resize(150, 31)
            self.btn_configure_device.move(360, 330)
            self.btn_configure_device.clicked.connect(self.on_click_code_details_entry)
            self.btn_configure_device.setParent(self.frm_domain_settings)

            self.btn_configure_device.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.HorizontalLyt.addWidget(self.frm_domain_settings)
            pass
        except Exception as e:
            print(e)