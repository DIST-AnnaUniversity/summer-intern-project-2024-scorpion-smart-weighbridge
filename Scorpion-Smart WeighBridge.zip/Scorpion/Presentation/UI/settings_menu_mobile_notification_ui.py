from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QComboBox, \
    QPlainTextEdit

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable
class SettingsMobileNotification:
    def __init__(self):
        super().__init__()

    def create_mob_notification_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()
            self.frmAppNotification = QFrame(self)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["mobile_notification"]["mobile_header"])
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(500, 21)
            self.lblHeader.move(0, 0)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)
            self.lblHeader.setParent(self.frmAppNotification)

            print(GlobalVariable.super_admin_login)
            if GlobalVariable.super_admin_login:
                self.btnNotificaticationStatus = QPushButton()
                self.btnNotificaticationStatus.setText(
                    GlobalVariable.language_setting_items["mobile_notification"]["btn_status"])
                self.btnNotificaticationStatus.resize(151, 41)
                self.btnNotificaticationStatus.move(210, 0)
                self.btnNotificaticationStatus.setFont(QFont('Inter', 10))
                self.btnNotificaticationStatus.clicked.connect(self.On_Click_mob_notification_status)
                self.btnNotificaticationStatus.setParent(self.frmAppNotification)
                shadow = QGraphicsDropShadowEffect()
                shadow.setBlurRadius(13)
                self.btnNotificaticationStatus.setGraphicsEffect(shadow)
                self.btnNotificaticationStatus.setStyleSheet("QPushButton"
                                                             "{"
                                                             "background-color: #000000; color: white;border-radius : 20px;border: 0px solid grey;"
                                                             "}"
                                                             )

                self.btnNotificaticationDeviceConfig = QPushButton()
                self.btnNotificaticationDeviceConfig.setText(
                    GlobalVariable.language_setting_items["mobile_notification"]["btn_config"])
                self.btnNotificaticationDeviceConfig.resize(151, 41)
                self.btnNotificaticationDeviceConfig.move(350, 0)
                self.btnNotificaticationDeviceConfig.setFont(QFont('Inter', 10))
                self.btnNotificaticationDeviceConfig.clicked.connect(self.On_Click_mob_notification_status)
                self.btnNotificaticationDeviceConfig.setParent(self.frmAppNotification)
                shadow = QGraphicsDropShadowEffect()
                shadow.setBlurRadius(13)
                self.btnNotificaticationDeviceConfig.setGraphicsEffect(shadow)
                self.btnNotificaticationDeviceConfig.setStyleSheet("QPushButton"
                                                                   "{"
                                                                   "background-color: #dedede; color: black;border-radius : 20px;border: 0px solid grey;"
                                                                   "}"
                                                                   )

                self.btnNotificaticationStatus.raise_()

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["mobile_notification"]["status_header_1"])
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(221, 31)
            self.lblHeader.move(5, 80)
            self.lblHeader.setParent(self.frmAppNotification)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["mobile_notification"]["status_header_2"])
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(221, 31)
            self.lblHeader.move(5, 150)
            self.lblHeader.setParent(self.frmAppNotification)

            self.lblHeader = QLabel()
            self.lblHeader.setText("IO Status")
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(221, 31)
            self.lblHeader.move(5, 220)
            self.lblHeader.setParent(self.frmAppNotification)

            self.lblHeader = QLabel()
            self.lblHeader.setText("Online Data")
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(221, 21)
            self.lblHeader.move(5, 290)
            self.lblHeader.setParent(self.frmAppNotification)

            self.btnCalibrationON = QPushButton()
            self.btnCalibrationON.resize(62, 32)
            self.btnCalibrationON.move(290, 80)
            self.btnCalibrationON.clicked.connect(self.On_Click_mob_notification_status)
            self.btnCalibrationON.setStyleSheet("border:0px solid lightgrey;")
            self.btnCalibrationON.setParent(self.frmAppNotification)
            self.btnCalibrationON.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                       "border : none ;"
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )

            self.btnCalibrationOFF = QPushButton()
            self.btnCalibrationOFF.resize(62, 32)
            self.btnCalibrationOFF.move(290, 80)
            self.btnCalibrationOFF.clicked.connect(self.On_Click_mob_notification_status)
            self.btnCalibrationOFF.setParent(self.frmAppNotification)
            self.btnCalibrationOFF.setStyleSheet("border:0px solid lightgrey;")
            self.btnCalibrationOFF.raise_()
            self.btnCalibrationOFF.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnCalibrationOFF.setGraphicsEffect(shadow)

            self.btnErrorON = QPushButton()
            self.btnErrorON.resize(62, 32)
            self.btnErrorON.move(290, 150)
            # self.btnErrorON.clicked.connect(self.on_click_error_notify_on)
            self.btnErrorON.setParent(self.frmAppNotification)
            self.btnErrorON.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnErrorON.setGraphicsEffect(shadow)
            self.btnErrorON.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                 "border : none ;"
                                                                                 "background-color:transparent;"
                                                                                 "}"
                                          )

            self.btnErrorOFF = QPushButton()
            self.btnErrorOFF.resize(62, 32)
            self.btnErrorOFF.move(290, 150)
            # self.btnErrorOFF.clicked.connect(self.on_click_error_notify_off)
            self.btnErrorOFF.setParent(self.frmAppNotification)
            self.btnErrorOFF.setStyleSheet("border:0px solid lightgrey;")
            self.btnErrorOFF.raise_()
            self.btnErrorOFF.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                  "border : none; "
                                                                                  "background-color:transparent;"
                                                                                  "}"
                                           )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnErrorOFF.setGraphicsEffect(shadow)

            self.btn_io_status_ON = QPushButton()
            self.btn_io_status_ON.resize(62, 32)
            self.btn_io_status_ON.move(290, 220)
            self.btn_io_status_ON.clicked.connect(self.On_Click_mob_notification_status)
            self.btn_io_status_ON.setParent(self.frmAppNotification)
            self.btn_io_status_ON.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_io_status_ON.setGraphicsEffect(shadow)
            self.btn_io_status_ON.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                       "border : none ;"
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )

            self.btn_io_status_OFF = QPushButton()
            self.btn_io_status_OFF.resize(62, 32)
            self.btn_io_status_OFF.move(290, 220)
            self.btn_io_status_OFF.clicked.connect(self.On_Click_mob_notification_status)
            self.btn_io_status_OFF.setParent(self.frmAppNotification)
            self.btn_io_status_OFF.setStyleSheet("border:0px solid lightgrey;")
            self.btn_io_status_OFF.raise_()
            self.btn_io_status_OFF.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                        "border : none; "
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_io_status_OFF.setGraphicsEffect(shadow)

            self.btn_online_data_ON = QPushButton()
            self.btn_online_data_ON.resize(62, 32)
            self.btn_online_data_ON.move(290, 290)
            self.btn_online_data_ON.clicked.connect(self.On_Click_mob_notification_status)
            self.btn_online_data_ON.setParent(self.frmAppNotification)
            self.btn_online_data_ON.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_online_data_ON.setGraphicsEffect(shadow)
            self.btn_online_data_ON.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                         "border : none ;"
                                                                                         "background-color:transparent;"
                                                                                         "}"
                                                  )

            self.btn_online_data_OFF = QPushButton()
            self.btn_online_data_OFF.resize(62, 32)
            self.btn_online_data_OFF.move(290, 290)
            self.btn_online_data_OFF.clicked.connect(self.On_Click_mob_notification_status)
            self.btn_online_data_OFF.setParent(self.frmAppNotification)
            self.btn_online_data_OFF.setStyleSheet("border:0px solid lightgrey;")
            self.btn_online_data_OFF.raise_()
            self.btn_online_data_OFF.setStyleSheet("QPushButton"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                          "border : none; "
                                                                                          "background-color:transparent;"
                                                                                          "}"
                                                   )
            self.btn_online_data_OFF.setGraphicsEffect(shadow)

            self.HorizontalLyt.addWidget(self.frmAppNotification)
            pass
        except Exception as e:
            print(e)