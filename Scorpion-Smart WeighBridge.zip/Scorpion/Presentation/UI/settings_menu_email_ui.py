from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsEmailUi:
    def __init__(self):
        super().__init__()

    def create_email_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frm_email_config = QFrame(self)
            lbl_code_entry_bg = QLabel(self.frm_email_config)
            lbl_code_entry_bg.resize(521, 429)
            lbl_code_entry_bg.setParent(self.frm_email_config)

            self.lblentryHeader = QLabel()
            self.lblentryHeader.setText("Email Config")
            self.lblentryHeader.setFont(QFont('Inter', 15))
            self.lblentryHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblentryHeader.resize(200, 31)
            self.lblentryHeader.move(1, 1)
            self.lblentryHeader.setParent(self.frm_email_config)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblentryHeader.setGraphicsEffect(shadow)

            self.lblCodeHeader1 = QLabel()
            self.lblCodeHeader1.setText(
                GlobalVariable.language_setting_items["notification_components"]["email_header_1"])
            self.lblCodeHeader1.setFont(QFont('Inter', 11))
            self.lblCodeHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCodeHeader1.resize(130, 27)
            self.lblCodeHeader1.move(10, 35)
            self.lblCodeHeader1.setParent(self.frm_email_config)

            self.txtSenderMail = QLineEdit()
            self.txtSenderMail.setFont(QFont('Inter', 15))
            self.txtSenderMail.setMaxLength(30)
            self.txtSenderMail.resize(351, 42)
            self.txtSenderMail.move(8, 55)
            self.txtSenderMail.setParent(self.frm_email_config)
            UiComponents.textbox_parameters_stylesheet(self.txtSenderMail)

            self.lblCodeHeader2 = QLabel()
            self.lblCodeHeader2.setText(
                GlobalVariable.language_setting_items["notification_components"]["email_header_2"])
            self.lblCodeHeader2.setFont(QFont('Inter', 11))
            self.lblCodeHeader2.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCodeHeader2.resize(130, 27)
            self.lblCodeHeader2.move(10, 100)
            self.lblCodeHeader2.setParent(self.frm_email_config)

            self.txt_code_value = QLineEdit()
            self.txt_code_value.setFont(QFont('Inter', 15))
            self.txt_code_value.setMaxLength(50)
            self.txt_code_value.resize(351, 42)
            self.txt_code_value.move(8, 125)
            self.txt_code_value.setParent(self.frm_email_config)
            UiComponents.textbox_parameters_stylesheet(self.txt_code_value)

            self.btn_delete_email = QPushButton()
            self.btn_delete_email.resize(42, 42)
            self.btn_delete_email.move(430, 0)
            self.btn_delete_email.clicked.connect(self.on_click_delete_email)
            self.btn_delete_email.setParent(self.frm_email_config)
            self.btn_delete_email.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Delete.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/DeleteHover.png); "
                                                                                                                      "}"
                                                                                                                      "QPushButton::disabled"
                                                                                                                      "{"
                                                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Delete.png); "
                                                                                                                                                             "}"
                                        )

            self.btn_add_email = QPushButton()
            self.btn_add_email.resize(42, 42)
            self.btn_add_email.move(250, 0)
            self.btn_add_email.clicked.connect(self.on_click_add_email)
            self.btn_add_email.setParent(self.frm_email_config)
            self.btn_add_email.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Add.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AddHover.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AddDisable.png); "
                                                                                                                                                                 "}"
                                            )

            self.btn_edit_email = QPushButton()
            self.btn_edit_email.resize(42, 42)
            self.btn_edit_email.move(310, 0)
            self.btn_edit_email.clicked.connect(self.on_click_edit_email)
            self.btn_edit_email.setParent(self.frm_email_config)
            self.btn_edit_email.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                            "/Edit.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                                     )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_edit_email.setGraphicsEffect(shadow)

            self.btn_save_email = QPushButton()
            self.btn_save_email.resize(42, 42)
            self.btn_save_email.move(370, 0)
            self.btn_save_email.clicked.connect(self.on_click_save_email)
            self.btn_save_email.setParent(self.frm_email_config)
            self.btn_save_email.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                            "/Save.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                                   "}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                                     )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_save_email.setGraphicsEffect(shadow)

            self.dgvEmail = QTableWidget()
            self.dgvEmail.resize(450, 200)
            self.dgvEmail.move(10, 190)
            self.dgvEmail.setFont(QFont('Inter', 12))
            self.dgvEmail.setStyleSheet("border:1px solid lightgrey;")
            self.dgvEmail.setParent(self.frm_email_config)
            self.dgvEmail.horizontalHeader().setVisible(False)

            self.HorizontalLyt.addWidget(self.frm_email_config)
        except Exception as e:
            print(e)
