from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QPushButton, QGraphicsDropShadowEffect, QComboBox, QLabel, QFrame

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsComSelectionUi:
    def __init__(self):
        super().__init__()

    def create_com_selection_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmPeripherals = QFrame()
            lblRS232CommBg = QLabel(self.frmPeripherals)
            lblRS232CommBg.resize(521, 429)
            lblRS232CommBg.setParent(self.frmPeripherals)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["peripherals_components"]["peripherals_header"])
            self.lblHeader.setFont(QFont('Inter', 12))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(441, 41)
            self.lblHeader.move(5, 3)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)
            self.lblHeader.setParent(self.frmPeripherals)

            self.lblComm = QLabel()
            self.lblComm.setFont(QFont('Inter', 10))
            self.lblComm.setStyleSheet("color:white;border:0px solid grey;")
            self.lblComm.resize(151, 41)
            self.lblComm.move(550, 10)
            self.lblComm.setParent(self.frmPeripherals)
            self.lblComm.raise_()

            self.lblCommMsg = QLabel()
            self.lblCommMsg.setFont(QFont('Inter', 10))
            self.lblCommMsg.setStyleSheet("color:white;border:0px solid grey;")
            self.lblCommMsg.resize(135, 21)
            self.lblCommMsg.move(557, 20)
            self.lblCommMsg.setParent(self.frmPeripherals)
            self.lblCommMsg.raise_()

            self.lblCom1 = QLabel()
            self.lblCom1.setText(GlobalVariable.language_setting_items["peripherals_components"]["peripherals_header_1"])
            self.lblCom1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCom1.resize(170, 27)
            self.lblCom1.move(10, 60)
            self.lblCom1.setParent(self.frmPeripherals)

            self.btnPeripheralsEdit = QPushButton()
            self.btnPeripheralsEdit.resize(42, 42)
            self.btnPeripheralsEdit.move(360, 8)
            self.btnPeripheralsEdit.clicked.connect(self.on_click_edit_peripherals)
            self.btnPeripheralsEdit.setParent(self.frmPeripherals)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnPeripheralsEdit.setGraphicsEffect(shadow)
            self.btnPeripheralsEdit.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                 "/Edit.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                  "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png); "
                                                                                 "QPushButton::disabled"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png); "

                                          )

            self.btnPeripheralsSave = QPushButton()
            self.btnPeripheralsSave.resize(42, 42)
            self.btnPeripheralsSave.move(420, 8)
            self.btnPeripheralsSave.clicked.connect(self.on_click_save_peripherals)
            self.btnPeripheralsSave.setParent(self.frmPeripherals)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btnPeripheralsSave.setGraphicsEffect(shadow)
            self.btnPeripheralsSave.setStyleSheet("QPushButton"
                                          "{"
                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                 "/Save.png); "
                                                                                 "border : none "
                                                                                 "}"
                                                                                 "QPushButton::hover"
                                                                                 "{"
                                                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); }"
                                                                                                                        "QPushButton::disabled"
                                                                                                                        "{"
                                                                                                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                          )

            self.cmbPeripherals1 = QComboBox()
            self.cmbPeripherals1.setFont(QFont('Inter', 15))
            self.cmbPeripherals1.resize(481, 37)
            self.cmbPeripherals1.move(10, 90)
            self.cmbPeripherals1.setParent(self.frmPeripherals)

            self.lblCom2 = QLabel()
            self.lblCom2.setText(GlobalVariable.language_setting_items["peripherals_components"]["peripherals_header_2"])
            self.lblCom2.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCom2.resize(170, 27)
            self.lblCom2.move(10, 140)
            self.lblCom2.setParent(self.frmPeripherals)

            self.cmbPeripherals2 = QComboBox()
            self.cmbPeripherals2.setFont(QFont('Inter', 15))
            self.cmbPeripherals2.resize(481, 37)
            self.cmbPeripherals2.move(10, 170)
            self.cmbPeripherals2.setParent(self.frmPeripherals)


            self.lblcom1Status = QLabel()
            self.lblcom1Status.resize(21, 21)
            self.lblcom1Status.move(450, 58)
            self.lblcom1Status.setParent(self.frmPeripherals)

            self.lblcom2Status = QLabel()
            self.lblcom2Status.resize(21, 21)
            self.lblcom2Status.move(450, 138)
            self.lblcom2Status.setParent(self.frmPeripherals)

            self.label_status.clear()
            self.label_status.append(self.lblcom1Status)
            self.label_status.append(self.lblcom2Status)

            self.cmb_input_names = [self.cmbPeripherals1, self.cmbPeripherals2]
            for i in range(len(self.cmb_input_names)):
                UiComponents.ComboBoxDefault_Style(self, self.cmb_input_names[i])

            self.HorizontalLyt.addWidget(self.frmPeripherals)
            pass
        except Exception as e:
            print(e)
