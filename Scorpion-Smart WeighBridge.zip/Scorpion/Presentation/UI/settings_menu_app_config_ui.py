from PyQt5.QtCore import QRegExp
from PyQt5.QtGui import QFont, QRegExpValidator
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QComboBox

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsAppConfigUi:
    def __init__(self):
        super().__init__()

    def create_app_config_ui(self):
        try:
            for i in reversed(range(self.hlyt_main.count())):
                self.hlyt_main.itemAt(i).widget().deleteLater()

            self.frm_app_config = QFrame(self)
            self.lbl_main_menu_bg = QLabel(self.frm_app_config)
            self.lbl_main_menu_bg.setGeometry(0, -3, 1000, 700)
            self.lbl_main_menu_bg.setParent(self.frm_app_config)

            self.lblProductHeader = QLabel()
            self.lblProductHeader.setText(GlobalVariable.language_setting_items["app_setting_components"]["app_setting_header"])
            self.lblProductHeader.setFont(QFont('Inter', 15))
            self.lblProductHeader.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lblProductHeader.resize(500, 41)
            self.lblProductHeader.move(8, 8)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblProductHeader.setGraphicsEffect(shadow)
            self.lblProductHeader.setParent(self.frm_app_config)

            self.btn_app_edit = QPushButton()
            self.btn_app_edit.resize(42, 42)
            self.btn_app_edit.move(500, 0)
            self.btn_app_edit.clicked.connect(self.on_click_app_edit)
            self.btn_app_edit.setParent(self.frm_app_config)
            self.btn_app_edit.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Edit.png); "
                                                                                   "border : none;"
                                                                                   "background-color:transparent;"
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditHover.png); }"
                                                                                   "QPushButton::disabled"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/EditDisable.png); }"

                                            )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_app_edit.setGraphicsEffect(shadow)

            self.btn_app_save = QPushButton()
            self.btn_app_save.resize(42, 42)
            self.btn_app_save.move(560, 0)
            self.btn_app_save.clicked.connect(self.on_click_app_save)
            self.btn_app_save.setParent(self.frm_app_config)
            self.btn_app_save.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                   "/Save.png); "
                                                                                   "border : none; "    
                                                                                   "background-color:transparent;"
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                          
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png);} "

                                            )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_app_save.setGraphicsEffect(shadow)

            ''' Auto Zero Parameter '''
            self.lbl_auto_zero_header = QLabel()
            self.lbl_auto_zero_header.setText(
                GlobalVariable.language_setting_items["app_setting_components"]["app_header_1"])
            self.lbl_auto_zero_header.setStyleSheet(
                "border:0px solid lightgrey;font: 19px Regular Inter;color:#696667;text-align:left;")
            self.lbl_auto_zero_header.resize(200, 31)
            self.lbl_auto_zero_header.move(30, 63)
            self.lbl_auto_zero_header.setParent(self.frm_app_config)

            self.txt_auto_zero = QLineEdit()
            self.txt_auto_zero.move(30, 100)
            self.txt_auto_zero.resize(200, 41)
            self.txt_auto_zero.setMaxLength(15)
            self.txt_auto_zero.setFont(QFont('Inter', 12))
            self.txt_auto_zero.setMaxLength(1)
            self.txt_auto_zero.setParent(self.frm_app_config)

            self.lbl_auto_zero_status = QLabel()
            self.lbl_auto_zero_status.resize(21, 21)
            self.lbl_auto_zero_status.move(190, 63)
            self.lbl_auto_zero_status.setParent(self.frm_app_config)

            self.lbl_auto_zero_note = QLabel()
            self.lbl_auto_zero_note.resize(220, 21)
            self.lbl_auto_zero_note.move(30, 150)
            self.lbl_auto_zero_note.setText(
                "Note: Auto zero must be (0-9)")
            self.lbl_auto_zero_note.setStyleSheet(
                "border:0px solid lightgrey;font: 14px Regular Inter;color:#696667;text-align:left;")
            self.lbl_auto_zero_note.setParent(self.frm_app_config)

            ''' Moving Average Parameter '''

            self.lbl_moving_average_header = QLabel()
            self.lbl_moving_average_header.setText(
                GlobalVariable.language_setting_items["app_setting_components"]["app_header_2"])
            self.lbl_moving_average_header.setStyleSheet(
                "border:0px solid lightgrey;font: 19px Regular Inter;color:#696667;text-align:left;")
            self.lbl_moving_average_header.resize(200, 30)
            self.lbl_moving_average_header.move(270, 63)
            self.lbl_moving_average_header.setParent(self.frm_app_config)

            self.txt_moving_average = QLineEdit()
            self.txt_moving_average.move(270, 100)
            self.txt_moving_average.resize(200, 41)
            self.txt_moving_average.setMaxLength(3)
            self.txt_moving_average.setFont(QFont('Inter', 12))
            self.txt_moving_average.setParent(self.frm_app_config)

            self.lbl_moving_average_status = QLabel()
            self.lbl_moving_average_status.resize(21, 21)
            self.lbl_moving_average_status.move(470, 63)
            self.lbl_moving_average_status.setParent(self.frm_app_config)

            self.lbl_moving_average_note = QLabel()
            self.lbl_moving_average_note.resize(250, 21)
            self.lbl_moving_average_note.move(270, 150)
            self.lbl_moving_average_note.setText(
                "Note:MOV-Average must be (1-100)")
            self.lbl_moving_average_note.setStyleSheet(
                "border:0px solid lightgrey;font: 14px Regular Inter;color:#696667;text-align:left;")
            self.lbl_moving_average_note.setParent(self.frm_app_config)


            ''' ADC Filter parameter '''

            self.lbl_adc_filter_header = QLabel()
            self.lbl_adc_filter_header.setText(
                GlobalVariable.language_setting_items["app_setting_components"]["app_header_3"])
            self.lbl_adc_filter_header.setStyleSheet(
                "border:0px solid lightgrey;font: 19px Regular Inter;color:#696667;text-align:left;")
            self.lbl_adc_filter_header.resize(200, 30)
            self.lbl_adc_filter_header.move(30, 200)
            self.lbl_adc_filter_header.setParent(self.frm_app_config)

            self.cmb_adc_filter = QComboBox()
            self.cmb_adc_filter.setFont(QFont('Inter', 12))
            self.cmb_adc_filter.move(30, 250)
            self.cmb_adc_filter.resize(200, 41)
            self.cmb_adc_filter.setParent(self.frm_app_config)
            self.cmb_adc_filter.setMaxVisibleItems(5)

            self.lbl_adc_filter_status = QLabel()
            self.lbl_adc_filter_status.resize(21, 21)
            self.lbl_adc_filter_status.move(200, 200)
            self.lbl_adc_filter_status.setParent(self.frm_app_config)

            self.txt_names = [self.txt_auto_zero, self.txt_moving_average]
            for i in range(len(self.txt_names)):
                UiComponents.textbox_default_stylesheet(self.txt_names[i])
                self.int_decimal_validation = QRegExpValidator(QRegExp("^\\d*\\.?\\d+$"))
                self.txt_names[i].setValidator(self.int_decimal_validation)
            UiComponents.ComboBoxDefault_Style(self,self.cmb_adc_filter)

            self.label_status.clear()
            self.label_status.append(self.lbl_auto_zero_status)
            self.label_status.append(self.lbl_moving_average_status)
            self.label_status.append(self.lbl_adc_filter_status)
            self.hlyt_main.addWidget(self.frm_app_config)
        except Exception as e:
            print(e)