from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QMainWindow, QFrame, QLabel, QGraphicsDropShadowEffect, QPushButton, QTableWidget, QWidget, \
    QCheckBox, QLineEdit

from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsWifiUi:
    def __init__(self):
        super().__init__()

    def wifi_ui(self):
        for i in reversed(range(self.HorizontalLyt.count())):
            self.HorizontalLyt.itemAt(i).widget().deleteLater()

        self.frmWifi = QFrame(self)

        self.lblDashboardCustomizationBg = QLabel(self.frmWifi)
        self.lblDashboardCustomizationBg.resize(760, 693)
        self.lblDashboardCustomizationBg.setParent(self.frmWifi)

        lblWifiHeader = QLabel(self.frmWifi)
        lblWifiHeader.setText(GlobalVariable.language_setting_items["wifi_components"]["wifi_header"])
        lblWifiHeader.setFont(QFont('Inter', 16))
        lblWifiHeader.resize(400, 51)
        lblWifiHeader.move(8, 8)
        lblWifiHeader.setParent(self.frmWifi)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        lblWifiHeader.setGraphicsEffect(shadow)


        self.btnWifiON = QPushButton()
        self.btnWifiON.resize(62, 32)
        self.btnWifiON.move(380, 15)
        self.btnWifiON.clicked.connect(self.on_click_wifi_ON)
        self.btnWifiON.setStyleSheet("border:0px solid lightgrey;")
        self.btnWifiON.setParent(self.frmWifi)

        self.btnWifiOFF = QPushButton()
        self.btnWifiOFF.resize(62, 32)
        self.btnWifiOFF.move(380, 15)
        self.btnWifiOFF.clicked.connect(self.on_click_wifi_OFF)
        self.btnWifiOFF.setParent(self.frmWifi)
        self.btnWifiOFF.setStyleSheet("border:0px solid lightgrey;")
        self.btnWifiOFF.raise_()
        self.btnWifiOFF.setStyleSheet("QPushButton"
                                      "{"
                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                             "border : none ;"
                                                                             "background-color:transparent;"
                                                                             "}"
                                      )
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btnWifiOFF.setGraphicsEffect(shadow)

        self.frmTableWidget = QFrame()
        self.frmTableWidget.resize(450, 330)
        self.frmTableWidget.move(10, 71)
        self.frmTableWidget.setStyleSheet("border:0px solid lightgrey;QScrollBar:vertical { width: 50px; }")
        self.frmTableWidget.setParent(self.frmWifi)

        self.dgvWifiList = QTableWidget(self.frmTableWidget)
        self.dgvWifiList.resize(450, 330)
        # self.dgvWifiList.move(0, 0)
        self.dgvWifiList.setStyleSheet("border:1px solid lightgrey;")
        self.dgvWifiList.setParent(self.frmTableWidget)

        self.frmMsgpanel = QWidget()
        self.frmMsgpanel.setStyleSheet("border:0px solid grey;")
        self.frmMsgpanel.resize(450, 350)
        self.frmMsgpanel.move(8, 30)
        self.frmMsgpanel.setParent(self.frmWifi)
        self.frmMsgpanel.raise_()

        self.lblMsgPanel = QLabel()
        self.lblMsgPanel.setFont(QFont('Inter', 10))
        self.lblMsgPanel.resize(450, 350)
        self.lblMsgPanel.move(0, 0)
        self.lblMsgPanel.setParent(self.frmMsgpanel)
        self.lblMsgPanel.setStyleSheet("QLabel"
                                       "{"
                                       "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/TurnONWifi.png); "
                                                                              "border : none "
                                                                              "}"
                                       )

        self.btn_wifi_ok = QPushButton()
        self.btn_wifi_ok.setText(GlobalVariable.language_setting_items["wifi_components"]["wifi_ok"])
        self.btn_wifi_ok.setFont(QFont('Inter', 12))
        self.btn_wifi_ok.resize(141, 51)
        self.btn_wifi_ok.move(245, 492)
        self.btn_wifi_ok.clicked.connect(self.hide_msg_panel)
        self.btn_wifi_ok.setParent(self.frmMsgpanel)
        self.btn_wifi_ok.setStyleSheet("QPushButton"
                                       "{"
                                       "background-color:white;"
                                       "color:black;"
                                       "border : 1px solid lightgrey;"
                                       "border-radius : 4px;"
                                       "font-weight:bold;"
                                       "}"
                                       "QPushButton::hover"
                                       "{"
                                       "background-color:black;"
                                       "color:white;"
                                       "border : 1px solid lightgrey;"
                                       "border-radius : 4px;"
                                       "font-weight:bold;"
                                       "}"
                                       "QPushButton::disabled"
                                       "{"
                                       "background-color:white;"
                                       "color:solid lightgrey;"
                                       "border : 1px solid lightgrey;"
                                       "border-radius : 4px;"
                                       "font-weight:bold;"
                                       "}"
                                       )

        self.frmWifiPanel = QWidget()
        self.frmWifiPanel.setStyleSheet("border:0px solid grey;")
        self.frmWifiPanel.resize(351, 251)
        self.frmWifiPanel.move(80, 100)
        self.frmWifiPanel.setParent(self.frmWifi)
        self.frmWifiPanel.raise_()

        self.lbl_alert_bg = QLabel()
        self.lbl_alert_bg.setFont(QFont('Inter', 10))
        self.lbl_alert_bg.setStyleSheet(
            "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;")
        self.lbl_alert_bg.resize(351, 251)
        self.lbl_alert_bg.move(0, 0)
        self.lbl_alert_bg.setParent(self.frmWifiPanel)

        self.lbl_alert_msg = QLabel()
        self.lbl_alert_msg.setText(GlobalVariable.language_setting_items["wifi_components"]["wifi_alert_header"])
        self.lbl_alert_msg.setStyleSheet(
            "border: 0px solid grey;font: 20px Regular Inter;")
        self.lbl_alert_msg.resize(331, 51)
        self.lbl_alert_msg.move(30, 10)
        self.lbl_alert_msg.setParent(self.frmWifiPanel)

        self.txtWifiName = QLineEdit()
        self.txtWifiName.move(110, 60)
        self.txtWifiName.resize(201, 31)
        self.txtWifiName.setFont(QFont('Inter', 12))
        self.txtWifiName.setParent(self.frmWifiPanel)
        self.txtWifiName.raise_()

        self.txtWifiPassword = QLineEdit()
        self.txtWifiPassword.move(110, 130)
        self.txtWifiPassword.resize(201, 31)
        self.txtWifiPassword.setFont(QFont('Inter', 12))
        self.txtWifiPassword.setParent(self.frmWifiPanel)
        self.txtWifiPassword.raise_()

        self.lblPassword = QLabel()
        self.lblPassword.setText(GlobalVariable.language_setting_items["wifi_components"]["password_header"])
        self.lblPassword.setFont(QFont('Inter', 12))
        self.lblPassword.resize(251, 21)
        self.lblPassword.move(30, 140)
        self.lblPassword.setParent(self.frmWifiPanel)

        self.chkWifiPassword = QCheckBox()
        self.chkWifiPassword.move(170, 100)
        self.chkWifiPassword.resize(111, 20)
        self.chkWifiPassword.setText(GlobalVariable.language_setting_items["wifi_components"]["show_password"])
        self.chkWifiPassword.setParent(self.frmWifiPanel)
        # self.chkWifiPassword.stateChanged.connect(self.checkbox_wifi_enable)
        self.chkWifiPassword.setStyleSheet("font: 10px Regular Inter;")

        self.lblSSID = QLabel()
        self.lblSSID.setText(GlobalVariable.language_setting_items["wifi_components"]["ssid_header"])
        self.lblSSID.setFont(QFont('Inter', 12))
        self.lblSSID.resize(251, 21)
        self.lblSSID.move(30, 70)
        self.lblSSID.setParent(self.frmWifiPanel)

        self.btnConnect = QPushButton()
        self.btnConnect.setText(GlobalVariable.language_setting_items["wifi_components"]["connect_wifi"])
        self.btnConnect.setFont(QFont('Inter', 11))
        self.btnConnect.resize(82, 35)
        self.btnConnect.move(200, 190)
        self.btnConnect.clicked.connect(self.connect_wifi)
        self.btnConnect.setParent(self.frmWifiPanel)
        self.btnConnect.setStyleSheet("QPushButton"
                                      "{"
                                      "background-color:white;"
                                      "color:black;"
                                      "border : 1px solid lightgrey;"
                                      "border-radius : 4px;"
                                      "font-weight:bold;"
                                      "}"
                                      "QPushButton::hover"
                                      "{"
                                      "background-color:black;"
                                      "color:white;"
                                      "border : 1px solid lightgrey;"
                                      "border-radius : 4px;"
                                      "font-weight:bold;"
                                      "}"
                                      "QPushButton::disabled"
                                      "{"
                                      "background-color:white;"
                                      "color:solid lightgrey;"
                                      "border : 1px solid lightgrey;"
                                      "border-radius : 4px;"
                                      "font-weight:bold;"
                                      "}"
                                      )

        self.btnWifiCancel = QPushButton()
        self.btnWifiCancel.setText(GlobalVariable.language_setting_items["wifi_components"]["cancel_wifi"])
        self.btnWifiCancel.setFont(QFont('Inter', 11))
        self.btnWifiCancel.resize(82, 35)
        self.btnWifiCancel.move(80, 190)
        self.btnWifiCancel.clicked.connect(self.hide_wifi_panel)
        self.btnWifiCancel.setParent(self.frmWifiPanel)
        self.btnWifiCancel.setStyleSheet("QPushButton"
                                         "{"
                                         "background-color:white;"
                                         "color:black;"
                                         "border : 1px solid lightgrey;"
                                         "border-radius : 4px;"
                                         "font-weight:bold;"
                                         "}"
                                         "QPushButton::hover"
                                         "{"
                                         "background-color:black;"
                                         "color:white;"
                                         "border : 1px solid lightgrey;"
                                         "border-radius : 4px;"
                                         "font-weight:bold;"
                                         "}"
                                         "QPushButton::disabled"
                                         "{"
                                         "background-color:white;"
                                         "color:solid lightgrey;"
                                         "border : 1px solid lightgrey;"
                                         "border-radius : 4px;"
                                         "font-weight:bold;"
                                         "}"
                                         )

        self.HorizontalLyt.addWidget(self.frmWifi)
