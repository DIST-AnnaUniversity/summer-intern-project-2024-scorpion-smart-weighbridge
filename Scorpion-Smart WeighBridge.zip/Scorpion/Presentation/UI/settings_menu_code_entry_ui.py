from PyQt5 import QtWidgets
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QCheckBox, QLabel, QPushButton, QGraphicsDropShadowEffect, QFrame, QLineEdit, QTableWidget, \
    QHeaderView, QWidget

from Presentation.Bundles.UiComponents import UiComponents
from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalEntities import GlobalEntities
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsCodeParameterUi:
    def __init__(self):
        super().__init__()

    def create_code_parameter(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frmCodeSettings = QFrame(self)

            self.frm_code_entered_details = QFrame(self)
            self.frm_code_entered_details.setParent(self.frmCodeSettings)

            lblPrinterBg = QLabel(self.frm_code_entered_details)
            lblPrinterBg.resize(521, 429)
            lblPrinterBg.setParent(self.frm_code_entered_details)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["parameters_components"]["code_params"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(200, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frm_code_entered_details)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.btn_entry = QPushButton()
            self.btn_entry.setText(GlobalVariable.language_setting_items["printer_components"]["default"])
            self.btn_entry.setFont(QFont('Inter', 10))
            self.btn_entry.resize(80, 31)
            self.btn_entry.move(200, 5)
            self.btn_entry.clicked.connect(self.on_click_code_entry)
            self.btn_entry.setParent(self.frm_code_entered_details)

            # self.btn_entry.setStyleSheet("QPushButton"
            #                              "{"
            #                              "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
            #                              "}"
            #                              )
            self.btn_entry.setStyleSheet("QPushButton::disabled"
                                         "{"
                                         "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                         "}"
                                         )

            self.btn_re_entry = QPushButton()
            self.btn_re_entry.setText(GlobalVariable.language_setting_items["printer_components"]["custom"])
            self.btn_re_entry.setFont(QFont('Inter', 10))
            self.btn_re_entry.resize(80, 31)
            self.btn_re_entry.move(280, 5)
            self.btn_re_entry.clicked.connect(self.on_click_code_reentry)
            self.btn_re_entry.setParent(self.frm_code_entered_details)

            # self.btn_re_entry.setStyleSheet("QPushButton"
            #                                 "{"
            #                                 "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
            #                                 "}"
            #                                 )
            self.btn_re_entry.setStyleSheet("QPushButton::disabled"
                                            "{"
                                            "background-color:#e0e0e0; color:#c7c7c7;border-radius : 20px;border: 0px solid grey;"
                                            "}"
                                            )
            self.btn_re_entry.raise_()

            self.lbl_code_header1 = QLabel(self.frm_code_entered_details)
            self.lbl_code_header1.setFixedWidth(220)
            self.lbl_code_header1.setFixedHeight(31)
            self.lbl_code_header1.setGeometry(20, 50, 220, 21)
            self.lbl_code_header1.setText("Code1")
            self.lbl_code_header1.setFont(QFont('Inter', 14))
            self.lbl_code_header1.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code_header1.setParent(self.frm_code_entered_details)

            self.lbl_code1 = QLineEdit(self.frm_code_entered_details)
            self.lbl_code1.setFixedWidth(270)
            self.lbl_code1.setFixedHeight(21)
            self.lbl_code1.setGeometry(20, 90, 270, 21)
            self.lbl_code1.setText("Code1")
            self.lbl_code1.setFont(QFont('Inter', 14))
            self.lbl_code1.setMaxLength(14)
            self.lbl_code1.setParent(self.frm_code_entered_details)

            self.chk_code1 = QCheckBox(self.frm_code_entered_details)
            self.chk_code1.setFixedSize(70, 41)
            self.chk_code1.setText("Entry")
            self.chk_code1.move(310, 79)
            self.chk_code1.setParent(self.frm_code_entered_details)
            self.chk_code1.setObjectName("chk_code1")

            self.chk_re_code1 = QCheckBox(self.frm_code_entered_details)
            self.chk_re_code1.setFixedSize(70, 41)
            self.chk_re_code1.setText("ReEntry")
            self.chk_re_code1.move(310, 79)
            self.chk_re_code1.setParent(self.frm_code_entered_details)
            self.chk_re_code1.setObjectName("chk_re_code1")

            self.chk_re_code1.setVisible(False)

            self.btn_code1details = QPushButton()
            self.btn_code1details.setObjectName("code1details")
            self.btn_code1details.setText("Details")
            self.btn_code1details.setFont(QFont('Inter', 10))
            self.btn_code1details.resize(80, 31)
            self.btn_code1details.move(370, 79)
            self.btn_code1details.clicked.connect(self.on_click_code_details_entry)
            self.btn_code1details.setParent(self.frm_code_entered_details)

            self.btn_code1details.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.lbl_code_header2 = QLabel(self.frm_code_entered_details)
            self.lbl_code_header2.setFixedWidth(220)
            self.lbl_code_header2.setFixedHeight(31)
            self.lbl_code_header2.setGeometry(20, 122, 220, 21)
            self.lbl_code_header2.setText("Code2")
            self.lbl_code_header2.setFont(QFont('Inter', 14))
            self.lbl_code_header2.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code_header2.setParent(self.frm_code_entered_details)

            self.lbl_code2 = QLineEdit(self.frm_code_entered_details)
            self.lbl_code2.setFixedWidth(270)
            self.lbl_code2.setFixedHeight(21)
            self.lbl_code2.setGeometry(20, 162, 270, 21)
            self.lbl_code2.setText("Code1")
            self.lbl_code2.setFont(QFont('Inter', 14))
            self.lbl_code2.setMaxLength(14)
            self.lbl_code2.setParent(self.frm_code_entered_details)

            self.chk_code2 = QCheckBox(self.frm_code_entered_details)
            self.chk_code2.setFixedSize(70, 41)
            self.chk_code2.setText("Entry")
            self.chk_code2.setObjectName("chk_code2")
            self.chk_code2.move(310, 148)
            self.chk_code2.setParent(self.frm_code_entered_details)

            self.chk_re_code2 = QCheckBox(self.frm_code_entered_details)
            self.chk_re_code2.setFixedSize(70, 41)
            self.chk_re_code2.setText("ReEntry")
            self.chk_re_code2.setObjectName("chk_re_code2")
            self.chk_re_code2.move(310, 148)
            self.chk_re_code2.setParent(self.frm_code_entered_details)

            self.chk_re_code2.setVisible(False)

            self.btn_code2details = QPushButton()
            self.btn_code2details.setObjectName("code2details")
            self.btn_code2details.setText("Details")
            self.btn_code2details.setFont(QFont('Inter', 10))
            self.btn_code2details.resize(80, 31)
            self.btn_code2details.move(370, 148)
            self.btn_code2details.clicked.connect(self.on_click_code_details_entry)
            self.btn_code2details.setParent(self.frm_code_entered_details)

            self.btn_code2details.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.lbl_code_header3 = QLabel(self.frm_code_entered_details)
            self.lbl_code_header3.setFixedWidth(220)
            self.lbl_code_header3.setFixedHeight(31)
            self.lbl_code_header3.setGeometry(20, 193, 220, 21)
            self.lbl_code_header3.setText("Code3")
            self.lbl_code_header3.setFont(QFont('Inter', 14))
            self.lbl_code_header3.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code_header3.setParent(self.frm_code_entered_details)

            self.lbl_code3 = QLineEdit(self.frm_code_entered_details)
            self.lbl_code3.setFixedWidth(270)
            self.lbl_code3.setFixedHeight(21)
            self.lbl_code3.setGeometry(20, 235, 270, 21)
            self.lbl_code3.setText("Code1")
            self.lbl_code3.setFont(QFont('Inter', 14))
            self.lbl_code3.setMaxLength(14)
            self.lbl_code3.setParent(self.frm_code_entered_details)

            self.chk_code3 = QCheckBox(self.frm_code_entered_details)
            self.chk_code3.setText("Entry")
            self.chk_code3.setObjectName("chk_code3")
            self.chk_code3.setFixedSize(70, 41)
            self.chk_code3.move(310, 220)
            self.chk_code3.setParent(self.frm_code_entered_details)

            self.chk_re_code3 = QCheckBox(self.frm_code_entered_details)
            self.chk_re_code3.setText("ReEntry")
            self.chk_re_code3.setObjectName("chk_re_code3")
            self.chk_re_code3.setFixedSize(70, 41)
            self.chk_re_code3.move(310, 220)
            self.chk_re_code3.setParent(self.frm_code_entered_details)

            self.chk_re_code3.setVisible(False)

            self.btn_code3details = QPushButton()
            self.btn_code3details.setObjectName("code3details")
            self.btn_code3details.setText("Details")
            self.btn_code3details.setFont(QFont('Inter', 10))
            self.btn_code3details.resize(80, 31)
            self.btn_code3details.move(370, 220)
            self.btn_code3details.clicked.connect(self.on_click_code_details_entry)
            self.btn_code3details.setParent(self.frm_code_entered_details)

            self.btn_code3details.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.lbl_code_header4 = QLabel(self.frm_code_entered_details)
            self.lbl_code_header4.setFixedWidth(220)
            self.lbl_code_header4.setFixedHeight(31)
            self.lbl_code_header4.setGeometry(20, 265, 220, 21)
            self.lbl_code_header4.setText("Code4")
            self.lbl_code_header4.setFont(QFont('Inter', 14))
            self.lbl_code_header4.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code_header4.setParent(self.frm_code_entered_details)

            self.lbl_code4 = QLineEdit(self.frm_code_entered_details)
            self.lbl_code4.setFixedWidth(270)
            self.lbl_code4.setFixedHeight(21)
            self.lbl_code4.setGeometry(20, 305, 270, 21)
            self.lbl_code4.setText("Code1")
            self.lbl_code4.setMaxLength(14)
            self.lbl_code4.setFont(QFont('Inter', 14))
            self.lbl_code4.setParent(self.frm_code_entered_details)

            self.chk_code4 = QCheckBox(self.frm_code_entered_details)
            self.chk_code4.setText("Entry")
            self.chk_code4.setObjectName("chk_code4")
            self.chk_code4.setFixedSize(70, 41)
            self.chk_code4.move(310, 287)
            self.chk_code4.setParent(self.frm_code_entered_details)

            self.chk_re_code4 = QCheckBox(self.frm_code_entered_details)
            self.chk_re_code4.setText("ReEntry")
            self.chk_re_code4.setObjectName("chk_re_code4")
            self.chk_re_code4.setFixedSize(70, 41)
            self.chk_re_code4.move(310, 287)
            self.chk_re_code4.setParent(self.frm_code_entered_details)
            self.chk_re_code4.setVisible(False)

            self.btn_code4details = QPushButton()
            self.btn_code4details.setObjectName("code4details")
            self.btn_code4details.setText("Details")
            self.btn_code4details.setFont(QFont('Inter', 10))
            self.btn_code4details.resize(80, 31)
            self.btn_code4details.move(370, 287)
            self.btn_code4details.clicked.connect(self.on_click_code_details_entry)
            self.btn_code4details.setParent(self.frm_code_entered_details)

            self.btn_code4details.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.lbl_code_header5 = QLabel(self.frm_code_entered_details)
            self.lbl_code_header5.setFixedWidth(220)
            self.lbl_code_header5.setFixedHeight(31)
            self.lbl_code_header5.setGeometry(20, 332, 220, 21)
            self.lbl_code_header5.setText("Code5")
            self.lbl_code_header5.setFont(QFont('Inter', 14))
            self.lbl_code_header5.setStyleSheet("text-align: left;border:0px solid black;color:black;")
            self.lbl_code_header5.setParent(self.frm_code_entered_details)

            self.lbl_code5 = QLineEdit(self.frm_code_entered_details)
            self.lbl_code5.setFixedWidth(270)
            self.lbl_code5.setFixedHeight(21)
            self.lbl_code5.setGeometry(20, 371, 270, 21)
            self.lbl_code5.setText("Code1")
            self.lbl_code5.setFont(QFont('Inter', 14))
            self.lbl_code5.setMaxLength(14)
            self.lbl_code5.setParent(self.frm_code_entered_details)

            self.chk_code5 = QCheckBox(self.frm_code_entered_details)
            self.chk_code5.setText("Entry")
            self.chk_code5.setObjectName("chk_code5")
            self.chk_code5.setFixedSize(70, 41)
            self.chk_code5.move(310, 358)
            self.chk_code5.setParent(self.frm_code_entered_details)

            self.chk_re_code5 = QCheckBox(self.frm_code_entered_details)
            self.chk_re_code5.setText("ReEntry")
            self.chk_re_code5.setObjectName("chk_re_code5")
            self.chk_re_code5.setFixedSize(70, 41)
            self.chk_re_code5.move(310, 358)
            self.chk_re_code5.setParent(self.frm_code_entered_details)
            self.chk_re_code5.setVisible(False)

            self.btn_code5details = QPushButton()
            self.btn_code5details.setObjectName("code5details")
            self.btn_code5details.setText("Details")
            self.btn_code5details.setFont(QFont('Inter', 10))
            self.btn_code5details.resize(80, 31)
            self.btn_code5details.move(370, 358)
            self.btn_code5details.clicked.connect(self.on_click_code_details_entry)
            self.btn_code5details.setParent(self.frm_code_entered_details)

            self.btn_code5details.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                                "}"
                                                "QPushButton::hover"
                                                "{"
                                                "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                                "}"
                                                )

            self.btn_code_edit = QPushButton()
            self.btn_code_edit.resize(42, 42)
            self.btn_code_edit.move(370, 0)
            self.btn_code_edit.clicked.connect(self.on_click_code_edit)
            self.btn_code_edit.setParent(self.frm_code_entered_details)
            self.btn_code_edit.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                    "/Edit.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                             )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_code_edit.setGraphicsEffect(shadow)

            self.btn_code_save = QPushButton()
            self.btn_code_save.resize(42, 42)
            self.btn_code_save.move(430, 0)
            self.btn_code_save.clicked.connect(self.on_click_code_save)
            self.btn_code_save.setParent(self.frm_code_entered_details)
            self.btn_code_save.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                    "/Save.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                           "}"
                                                                                                                           "QPushButton::disabled"
                                                                                                                           "{"
                                                                                                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                             )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_code_save.setGraphicsEffect(shadow)

            self.label_controls = [self.lbl_code1, self.lbl_code2, self.lbl_code3, self.lbl_code4,
                                   self.lbl_code5]
            for labels in range(len(self.label_controls)):
                UiComponents.textbox_parameters_stylesheet(self.label_controls[labels])

            self.lbl_code1_status = QLabel()
            self.lbl_code1_status.resize(21, 21)
            self.lbl_code1_status.move(265, 50)
            self.lbl_code1_status.setParent(self.frm_code_entered_details)

            self.lbl_code2_status = QLabel()
            self.lbl_code2_status.resize(21, 21)
            self.lbl_code2_status.move(265, 122)
            self.lbl_code2_status.setParent(self.frm_code_entered_details)

            self.lbl_code3_status = QLabel()
            self.lbl_code3_status.resize(21, 21)
            self.lbl_code3_status.move(265, 193)
            self.lbl_code3_status.setParent(self.frm_code_entered_details)

            self.lbl_code4_status = QLabel()
            self.lbl_code4_status.resize(21, 21)
            self.lbl_code4_status.move(265, 265)
            self.lbl_code4_status.setParent(self.frm_code_entered_details)

            self.lbl_code5_status = QLabel()
            self.lbl_code5_status.resize(21, 21)
            self.lbl_code5_status.move(265, 330)
            self.lbl_code5_status.setParent(self.frm_code_entered_details)

            '''panel messsage'''
            self.pnl_code_save = QWidget()
            self.pnl_code_save.setStyleSheet("border:0px solid grey;")
            self.pnl_code_save.resize(340, 180)
            self.pnl_code_save.move(50, 80)
            self.pnl_code_save.setParent(self.frm_code_entered_details)
            self.pnl_code_save.raise_()

            self.lbl_alert_bg = QLabel()
            self.lbl_alert_bg.setFont(QFont('Inter', 10))
            self.lbl_alert_bg.setStyleSheet(
                "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;"
                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/header_save.png);")
            self.lbl_alert_bg.resize(340, 180)
            self.lbl_alert_bg.move(0, 0)
            self.lbl_alert_bg.setParent(self.pnl_code_save)

            self.btn_save_no = QPushButton()
            self.btn_save_no.resize(72, 42)
            self.btn_save_no.move(220, 100)
            self.btn_save_no.clicked.connect(self.on_click_code_hide)
            self.btn_save_no.setParent(self.pnl_code_save)
            self.btn_save_no.setStyleSheet("QPushButton"
                                           "{"
                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/No.png); "
                                                                                  "border : none "
                                                                                  "}"
                                                                                  "QPushButton::hover"
                                                                                  "{"
                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/NoHover.png); "
                                                                                                                         "}")

            self.btn_save_yes = QPushButton()
            self.btn_save_yes.resize(72, 42)
            self.btn_save_yes.move(30, 100)
            self.btn_save_yes.clicked.connect(self.on_click_code_save_ok)
            self.btn_save_yes.setParent(self.pnl_code_save)
            self.btn_save_yes.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Yes.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/YesHover.png); "
                                                                                                                          "}")

            self.pnl_code_save.move(500000, 800000)

            ''' For Code Entry details'''
            self.frm_code_details = QFrame(self)
            self.frm_code_details.setParent(self.frmCodeSettings)
            lbl_code_entry_bg = QLabel(self.frm_code_details)
            lbl_code_entry_bg.resize(521, 429)
            lbl_code_entry_bg.setParent(self.frm_code_details)

            self.lblentryHeader = QLabel()
            self.lblentryHeader.setText("Code Details")
            self.lblentryHeader.setFont(QFont('Inter', 15))
            self.lblentryHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblentryHeader.resize(200, 31)
            self.lblentryHeader.move(1, 1)
            self.lblentryHeader.setParent(self.frm_code_details)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblentryHeader.setGraphicsEffect(shadow)

            self.lblCodeHeader1 = QLabel()
            self.lblCodeHeader1.setText(
                GlobalVariable.language_setting_items["parameters_components"]["code_name"])
            self.lblCodeHeader1.setFont(QFont('Inter', 11))
            self.lblCodeHeader1.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCodeHeader1.resize(130, 27)
            self.lblCodeHeader1.move(10, 55)
            self.lblCodeHeader1.setParent(self.frm_code_details)

            self.txt_code_name = QLineEdit()
            self.txt_code_name.setFont(QFont('Inter', 15))
            self.txt_code_name.setMaxLength(10)
            self.txt_code_name.resize(200, 42)
            self.txt_code_name.move(8, 75)
            self.txt_code_name.setParent(self.frm_code_details)
            UiComponents.textbox_parameters_stylesheet(self.txt_code_name)

            self.lblCodeHeader2 = QLabel()
            self.lblCodeHeader2.setText(
                GlobalVariable.language_setting_items["parameters_components"]["code_value"])
            self.lblCodeHeader2.setFont(QFont('Inter', 11))
            self.lblCodeHeader2.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lblCodeHeader2.resize(130, 27)
            self.lblCodeHeader2.move(240, 55)
            self.lblCodeHeader2.setParent(self.frm_code_details)

            self.txt_code_value = QLineEdit()
            self.txt_code_value.setFont(QFont('Inter', 15))
            self.txt_code_value.setMaxLength(10)
            self.txt_code_value.resize(200, 42)
            self.txt_code_value.move(240, 75)
            self.txt_code_value.setParent(self.frm_code_details)
            UiComponents.textbox_parameters_stylesheet(self.txt_code_value)

            self.lbl_codeno_status = QLabel()
            self.lbl_codeno_status.resize(21, 21)
            self.lbl_codeno_status.move(330, 60)
            self.lbl_codeno_status.setParent(self.frm_code_details)

            self.lbl_code_name_status = QLabel()
            self.lbl_code_name_status.resize(21, 21)
            self.lbl_code_name_status.move(500, 70)
            self.lbl_code_name_status.setParent(self.frm_code_details)

            self.lbl_edit_msg = QLabel()
            self.lbl_edit_msg.setText(
                GlobalVariable.language_setting_items["parameters_components"]["code_message"])
            self.lbl_edit_msg.setFont(QFont('Inter', 11))
            self.lbl_edit_msg.setStyleSheet(
                "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;")
            self.lbl_edit_msg.resize(350, 27)
            self.lbl_edit_msg.move(10, 125)
            self.lbl_edit_msg.setVisible(False)
            self.lbl_edit_msg.setParent(self.frm_code_details)

            self.btn_back = QPushButton()
            self.btn_back.resize(42, 42)
            self.btn_back.move(250, 0)
            self.btn_back.clicked.connect(self.on_click_return_code)
            self.btn_back.setParent(self.frm_code_details)
            self.btn_back.setStyleSheet("QPushButton"
                                        "{"
                                        "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Back.png); "
                                                                               "border : none "
                                                                               "}"
                                                                               "QPushButton::hover"
                                                                               "{"
                                                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/BackHover.png); "
                                                                                                                      "}"
                                                                                                                      "QPushButton::disabled"
                                                                                                                      "{"
                                                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/BackDisable.png); "
                                                                                                                                                             "}"
                                        )

            self.btn_add_code = QPushButton()
            self.btn_add_code.resize(42, 42)
            self.btn_add_code.move(310, 0)
            self.btn_add_code.clicked.connect(self.on_click_add_code)
            self.btn_add_code.setParent(self.frm_code_details)
            self.btn_add_code.setStyleSheet("QPushButton"
                                            "{"
                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Add.png); "
                                                                                   "border : none "
                                                                                   "}"
                                                                                   "QPushButton::hover"
                                                                                   "{"
                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AddHover.png); "
                                                                                                                          "}"
                                                                                                                          "QPushButton::disabled"
                                                                                                                          "{"
                                                                                                                          "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/AddDisabled.png); "
                                                                                                                                                                 "}"
                                            )

            self.btn_code_details_edit = QPushButton()
            self.btn_code_details_edit.resize(42, 42)
            self.btn_code_details_edit.move(370, 0)
            self.btn_code_details_edit.clicked.connect(self.on_click_code_details_edit)
            self.btn_code_details_edit.setParent(self.frm_code_details)
            self.btn_code_details_edit.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                            "/Edit.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                                     )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_code_details_edit.setGraphicsEffect(shadow)

            self.btn_code_details_save = QPushButton()
            self.btn_code_details_save.resize(42, 42)
            self.btn_code_details_save.move(430, 0)
            self.btn_code_details_save.clicked.connect(self.on_click_code_details_save)
            self.btn_code_details_save.setParent(self.frm_code_details)
            self.btn_code_details_save.setStyleSheet("QPushButton"
                                                     "{"
                                                     "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                            "/Save.png); "
                                                                                            "border : none "
                                                                                            "}"
                                                                                            "QPushButton::hover"
                                                                                            "{"
                                                                                            "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                                   "}"
                                                                                                                                   "QPushButton::disabled"
                                                                                                                                   "{"
                                                                                                                                   "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); }"

                                                     )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_code_details_save.setGraphicsEffect(shadow)

            self.btn_scroll_up = QPushButton()
            self.btn_scroll_up.resize(40, 40)
            self.btn_scroll_up.move(460, 160)
            self.btn_scroll_up.clicked.connect(self.on_click_code_scroll_up)
            self.btn_scroll_up.setParent(self.frm_code_details)
            self.btn_scroll_up.setStyleSheet("QPushButton"
                                             "{"
                                             "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/up.png); "
                                                                                    "border : none "
                                                                                    "}"
                                                                                    "QPushButton::hover"
                                                                                    "{"
                                                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/up_hover.png); "
                                                                                                                           "}"
                                             )

            self.dgv_code_details = QTableWidget()
            self.dgv_code_details.resize(450, 220)
            self.dgv_code_details.move(10, 160)
            self.dgv_code_details.setFont(QFont('Inter', 12))

            self.dgv_code_details.setParent(self.frm_code_details)
            # self.dgv_code_details.horizontalHeader().setVisible(False)
            self.dgv_code_details.selectionModel().selectionChanged.connect(self.on_code_details_selected)
            self.dgv_code_details.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.dgv_code_details.horizontalHeader().setSectionResizeMode(QHeaderView.Fixed)
            self.dgv_code_details.verticalHeader().hide()
            self.dgv_code_details.setEnabled(False)
            self.dgv_code_details.setStyleSheet("QTableWidget"
                                                "{"
                                                "border:1px solid lightgrey;"
                                                "background-color:white;"
                                                "}"
                                                "QTableWidget:disabled"
                                                "{"
                                                "background-color:white;"
                                                "}"
                                                "QHeaderView::section"
                                                "{"
                                                "background-color: grey;"
                                                "color: black;"
                                                )

            self.btn_scroll_down = QPushButton()
            self.btn_scroll_down.resize(40, 40)
            self.btn_scroll_down.move(460, 350)
            self.btn_scroll_down.clicked.connect(self.on_click_code_scroll_down)
            self.btn_scroll_down.setParent(self.frm_code_details)
            self.btn_scroll_down.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/down_arrow.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/down_hover.png); "
                                                                                                                             "}"
                                               )

            self.frm_code_details.move(555555, 1000000)

            self.HorizontalLyt.addWidget(self.frmCodeSettings)

            GlobalEntities.header_checkbox_names.clear()
            GlobalEntities.re_header_checkbox_names.clear()
            GlobalEntities.header_checkbox_names.append(self.chk_code1)
            GlobalEntities.header_checkbox_names.append(self.chk_code2)
            GlobalEntities.header_checkbox_names.append(self.chk_code3)
            GlobalEntities.header_checkbox_names.append(self.chk_code4)
            GlobalEntities.header_checkbox_names.append(self.chk_code5)

            GlobalEntities.re_header_checkbox_names.append(self.chk_re_code1)
            GlobalEntities.re_header_checkbox_names.append(self.chk_re_code2)
            GlobalEntities.re_header_checkbox_names.append(self.chk_re_code3)
            GlobalEntities.re_header_checkbox_names.append(self.chk_re_code4)
            GlobalEntities.re_header_checkbox_names.append(self.chk_re_code5)
            for i in range(len(GlobalEntities.header_checkbox_names)):
                GlobalEntities.header_checkbox_names[i].setStyleSheet("QCheckBox::indicator"
                                                                      "{"
                                                                      "width:20px;"
                                                                      "height:20px;"
                                                                      "border:1px solid #555;"
                                                                      "}"
                                                                      "QCheckBox::indicator:checked"
                                                                      "{"
                                                                      "width:20px;"
                                                                      "height:20px;"
                                                                      "border:1px solid #555;"
                                                                      "background-color: #007acc;"
                                                                      "}"
                                                                      "QCheckBox::indicator:unchecked"
                                                                      "{"
                                                                      "width:20px;"
                                                                      "height:20px;"
                                                                      "border:1px solid # 555;"
                                                                      "background-color: #eee;"
                                                                      "}"
                                                                      "QCheckBox::indicator:disabled"
                                                                      "{"
                                                                      "width:20px;"
                                                                      "height:20px;"
                                                                      "border:1px solid #555;"
                                                                      "}"
                                                                      )

            for i in range(len(GlobalEntities.re_header_checkbox_names)):
                GlobalEntities.re_header_checkbox_names[i].setStyleSheet("QCheckBox::indicator"
                                                                         "{"
                                                                         "width:20px;"
                                                                         "height:20px;"
                                                                         "border:1px solid #555;"
                                                                         "}"
                                                                         "QCheckBox::indicator:checked"
                                                                         "{"
                                                                         "width:20px;"
                                                                         "height:20px;"
                                                                         "border:1px solid #555;"
                                                                         "background-color: #007acc;"
                                                                         "}"
                                                                         "QCheckBox::indicator:unchecked"
                                                                         "{"
                                                                         "width:20px;"
                                                                         "height:20px;"
                                                                         "border:1px solid # 555;"
                                                                         "background-color: #eee;"
                                                                         "}"
                                                                         "QCheckBox::indicator:disabled"
                                                                         "{"
                                                                         "width:20px;"
                                                                         "height:20px;"
                                                                         "border:1px solid #555;"
                                                                         "}"
                                                                         )

            self.chk_code1.setChecked(True)
            self.chk_re_code1.setChecked(True)

            self.label_status.clear()
            self.label_status.append(self.lbl_code1_status)
            self.label_status.append(self.lbl_code2_status)
            self.label_status.append(self.lbl_code3_status)
            self.label_status.append(self.lbl_code4_status)
            self.label_status.append(self.lbl_code5_status)

            self.code_label_status.clear()
            self.code_label_status.append(self.lbl_codeno_status)
            self.code_label_status.append(self.lbl_code_name_status)

            GlobalEntities.header_params_checkbox = {"chk_code1": "1", "chk_code2": "0", "chk_code3": "0",
                                                     "chk_code4": "0",
                                                     "chk_code5": "0", "chk_re_code1": "1", "chk_re_code2": "0",
                                                     "chk_re_code3": "0",
                                                     "chk_re_code4": "0",
                                                     "chk_re_code5": "0"}

            pass
        except Exception as e:
            print(e)
