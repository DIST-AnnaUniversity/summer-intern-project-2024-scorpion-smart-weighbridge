from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect, QPushButton, QComboBox

from Presentation.Bundles.UiConfiguration import ROOT_PATH
from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsOtherParameterUi:
    def __init__(self):
        super().__init__()

    def create_other_parameter_ui(self):
        try:
            for i in reversed(range(self.HorizontalLyt.count())):
                self.HorizontalLyt.itemAt(i).widget().deleteLater()

            self.frm_other_settings = QFrame(self)

            lblPrinterBg = QLabel(self.frm_other_settings)
            lblPrinterBg.resize(521, 429)
            lblPrinterBg.setParent(self.frm_other_settings)

            self.lblHeader = QLabel()
            self.lblHeader.setText(GlobalVariable.language_setting_items["parameters_components"]["other_params"])
            self.lblHeader.setFont(QFont('Inter', 15))
            self.lblHeader.setStyleSheet("text-align: left;border:0px solid grey;")
            self.lblHeader.resize(200, 31)
            self.lblHeader.move(1, 1)
            self.lblHeader.setParent(self.frm_other_settings)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lblHeader.setGraphicsEffect(shadow)

            self.lbl_header_position = 80
            for i in range(4):
                self.lbl_header = QLabel()
                self.lbl_header.setText(
                    GlobalVariable.language_setting_items["parameters_components"]["general_header_" + str(i + 1)])
                self.lbl_header.setStyleSheet(
                    "border:0px solid lightgrey;font: 18px Regular Inter;color:#696667;text-align:left;")
                self.lbl_header.resize(121, 31)
                self.lbl_header.move(15, self.lbl_header_position)
                self.lbl_header.setParent(self.frm_other_settings)
                self.lbl_header_position += 70

            self.btn_amount_enable = QPushButton()
            self.btn_amount_enable.resize(62, 32)
            self.btn_amount_enable.move(200090, 80)
            self.btn_amount_enable.setObjectName("amount_enable")
            self.btn_amount_enable.clicked.connect(self.on_click_other_params_status)
            self.btn_amount_enable.setStyleSheet("border:0px solid lightgrey;")
            self.btn_amount_enable.setParent(self.frm_other_settings)
            self.btn_amount_enable.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )

            self.btn_amount_disable = QPushButton()
            self.btn_amount_disable.resize(62, 32)
            self.btn_amount_disable.move(290000, 80)
            self.btn_amount_disable.setObjectName("amount_disable")
            self.btn_amount_disable.clicked.connect(self.on_click_other_params_status)
            self.btn_amount_disable.setParent(self.frm_other_settings)
            self.btn_amount_disable.setStyleSheet("border:0px solid lightgrey;")
            self.btn_amount_disable.raise_()
            self.btn_amount_disable.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                         "border : none ;"
                                                                                         "background-color:transparent;"
                                                                                         "}"
                                                  )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_amount_disable.setGraphicsEffect(shadow)

            self.btn_date_enable = QPushButton()
            self.btn_date_enable.resize(62, 32)
            self.btn_date_enable.move(290, 80)
            self.btn_date_enable.setObjectName("date_enable")
            self.btn_date_enable.clicked.connect(self.on_click_other_params_status)
            self.btn_date_enable.setParent(self.frm_other_settings)
            self.btn_date_enable.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_date_enable.setGraphicsEffect(shadow)
            self.btn_date_enable.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                      "border : none ;"
                                                                                      "background-color:transparent;"
                                                                                      "}"
                                               )

            self.btn_date_disable = QPushButton()
            self.btn_date_disable.resize(62, 32)
            self.btn_date_disable.move(290, 80)
            self.btn_date_disable.setObjectName("date_disable")
            self.btn_date_disable.clicked.connect(self.on_click_other_params_status)
            self.btn_date_disable.setParent(self.frm_other_settings)
            self.btn_date_disable.setStyleSheet("border:0px solid lightgrey;")
            self.btn_date_disable.raise_()
            self.btn_date_disable.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                       "border : none; "
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_date_disable.setGraphicsEffect(shadow)

            self.btn_gunny_enable = QPushButton()
            self.btn_gunny_enable.resize(62, 32)
            self.btn_gunny_enable.move(290, 150)
            self.btn_gunny_enable.setObjectName("gunny_enable")
            self.btn_gunny_enable.clicked.connect(self.on_click_other_params_status)
            self.btn_gunny_enable.setParent(self.frm_other_settings)
            self.btn_gunny_enable.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_gunny_enable.setGraphicsEffect(shadow)
            self.btn_gunny_enable.setStyleSheet("QPushButton"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                       "border : none ;"
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )

            self.btn_gunny_disable = QPushButton()
            self.btn_gunny_disable.resize(62, 32)
            self.btn_gunny_disable.move(290, 150)
            self.btn_gunny_disable.setObjectName("gunny_disable")
            self.btn_gunny_disable.clicked.connect(self.on_click_other_params_status)
            self.btn_gunny_disable.setParent(self.frm_other_settings)
            self.btn_gunny_disable.setStyleSheet("border:0px solid lightgrey;")
            self.btn_gunny_disable.raise_()
            self.btn_gunny_disable.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                        "border : none; "
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_gunny_disable.setGraphicsEffect(shadow)

            self.btn_manual_enable = QPushButton()
            self.btn_manual_enable.resize(62, 32)
            self.btn_manual_enable.move(290, 220)
            self.btn_manual_enable.setObjectName("manual_enable")
            self.btn_manual_enable.clicked.connect(self.on_click_other_params_status)
            self.btn_manual_enable.setParent(self.frm_other_settings)
            self.btn_manual_enable.setStyleSheet("border:0px solid lightgrey;")
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_manual_enable.setGraphicsEffect(shadow)
            self.btn_manual_enable.setStyleSheet("QPushButton"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/ON.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )

            self.btn_manual_disable = QPushButton()
            self.btn_manual_disable.resize(62, 32)
            self.btn_manual_disable.move(290, 220)
            self.btn_manual_disable.setObjectName("manual_disable")
            self.btn_manual_disable.clicked.connect(self.on_click_other_params_status)
            self.btn_manual_disable.setParent(self.frm_other_settings)
            self.btn_manual_disable.setStyleSheet("border:0px solid lightgrey;")
            self.btn_manual_disable.raise_()
            self.btn_manual_disable.setStyleSheet("QPushButton"
                                                  "{"
                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OFF.png); "
                                                                                         "border : none; "
                                                                                         "background-color:transparent;"
                                                                                         "}"
                                                  )
            self.btn_manual_disable.setGraphicsEffect(shadow)

            self.btn_auto = QPushButton()
            self.btn_auto.setText("Auto")
            self.btn_auto.setFont(QFont('Inter', 10))
            self.btn_auto.resize(70, 31)
            self.btn_auto.move(36000, 220)
            self.btn_auto.setObjectName("auto")
            self.btn_auto.clicked.connect(self.on_click_other_params_status)
            self.btn_auto.setParent(self.frm_other_settings)

            self.btn_auto.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                          "}"
                                          )

            self.btn_manual = QPushButton()
            self.btn_manual.setText("Manual")
            self.btn_manual.setFont(QFont('Inter', 10))
            self.btn_manual.resize(70, 31)
            self.btn_manual.move(4300000, 220)
            self.btn_manual.setObjectName("manual")
            self.btn_manual.clicked.connect(self.on_click_other_params_status)
            self.btn_manual.setParent(self.frm_other_settings)

            self.btn_manual.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                          "}"
                                          )
            self.btn_manual.raise_()

            self.btn_unit_1 = QPushButton()
            self.btn_unit_1.setText(GlobalVariable.language_setting_items["parameters_components"]["unit_1"])
            self.btn_unit_1.setFont(QFont('Inter', 10))
            self.btn_unit_1.resize(80, 31)
            self.btn_unit_1.move(290, 290)
            self.btn_unit_1.setObjectName("unit_kg")
            self.btn_unit_1.clicked.connect(self.on_click_other_params_status)
            self.btn_unit_1.setParent(self.frm_other_settings)

            self.btn_unit_1.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:black; color:white;border-radius : 20px;border: 0px solid grey;"
                                          "}"
                                          )

            self.btn_unit_2 = QPushButton()
            self.btn_unit_2.setText(GlobalVariable.language_setting_items["parameters_components"]["unit_2"])
            self.btn_unit_2.setFont(QFont('Inter', 10))
            self.btn_unit_2.resize(80, 31)
            self.btn_unit_2.move(370, 290)
            self.btn_unit_2.setObjectName("unit_tonnes")
            self.btn_unit_2.clicked.connect(self.on_click_other_params_status)
            self.btn_unit_2.setParent(self.frm_other_settings)

            self.btn_unit_2.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 20px;"
                                          "}"
                                          )
            self.btn_unit_2.raise_()



            self.btn_other_param_edit = QPushButton()
            self.btn_other_param_edit.resize(42, 42)
            self.btn_other_param_edit.move(370, 0)
            self.btn_other_param_edit.clicked.connect(self.on_click_other_param_edit)
            self.btn_other_param_edit.setParent(self.frm_other_settings)
            self.btn_other_param_edit.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/MainScreenImages"
                                                                                           "/Edit.png); "
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditHover.png);}"
                                                                                                                                  "QPushButton::disabled"
                                                                                                                                  "{"
                                                                                                                                  "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/EditDisable.png);}"

                                                    )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_other_param_edit.setGraphicsEffect(shadow)

            self.btn_other_param_save = QPushButton()
            self.btn_other_param_save.resize(42, 42)
            self.btn_other_param_save.move(430, 0)
            self.btn_other_param_save.clicked.connect(self.on_click_other_param_save)
            self.btn_other_param_save.setParent(self.frm_other_settings)
            self.btn_other_param_save.setStyleSheet("QPushButton"
                                                    "{"
                                                    "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages"
                                                                                           "/Save.png); "
                                                                                           "border : none "
                                                                                           "}"
                                                                                           "QPushButton::hover"
                                                                                           "{"
                                                                                           "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveHover.png); "
                                                                                                                                  "}"
                                                                                                                                  "QPushButton::disabled"
                                                                                                                                  "{"
                                                                                                                                  "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/SaveDisable.png); "

                                                    )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_other_param_save.setGraphicsEffect(shadow)

            self.HorizontalLyt.addWidget(self.frm_other_settings)
            pass
        except Exception as e:
            print(e)
