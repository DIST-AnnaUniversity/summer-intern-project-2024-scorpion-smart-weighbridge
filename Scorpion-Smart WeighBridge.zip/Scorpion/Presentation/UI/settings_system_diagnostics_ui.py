from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QFrame, QLabel, QGraphicsDropShadowEffect, QPushButton

from Presentation.Utilities.GlobalVariable import GlobalVariable


class SettingsSystemDiagnosticsUi:
    def __init__(self):
        super().__init__()
        self.HorizontalLyt = None
        self.btn3 = None
        self.btn2 = None
        self.btn_can_com1 = None
        self.btn1 = None
        self.lbl = None
        self.btn_rS485_com1 = None
        self.btn_rS232_com2 = None
        self.btn_rS232_com1 = None
        self.lbl_can_header = None
        self.lbl_rS485_header = None
        self.lbl_rs232_header = None
        self.lbl_system_diagnostics_bg = None
        self.lbl_system_diagnostics_header = None
        self.frm_system_diagnostics = None

    def SystemDiagnostics_Ui(self):
        for i in reversed(range(self.HorizontalLyt.count())):
            self.HorizontalLyt.itemAt(i).widget().deleteLater()
        self.frm_system_diagnostics = QFrame()
        self.lbl_system_diagnostics_bg = QLabel(self.frm_system_diagnostics)
        self.lbl_system_diagnostics_bg.resize(521, 435)
        self.lbl_system_diagnostics_bg.setParent(self.frm_system_diagnostics)

        """ Header for System Diagnostics """
        self.lbl_system_diagnostics_header = QLabel()
        self.lbl_system_diagnostics_header.setText(
            GlobalVariable.language_setting_items["io_diagnostics_components"]["io_diagnostic_header"])
        self.lbl_system_diagnostics_header.setFont(QFont('Inter', 15))
        self.lbl_system_diagnostics_header.setStyleSheet("text-align: left;border:0px solid grey;")
        self.lbl_system_diagnostics_header.resize(200, 31)
        self.lbl_system_diagnostics_header.move(1, 1)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.lbl_system_diagnostics_header.setGraphicsEffect(shadow)
        self.lbl_system_diagnostics_header.setParent(self.frm_system_diagnostics)
        self.lbl_rs232_header = QLabel()
        self.lbl_rs232_header.setText(
            GlobalVariable.language_setting_items["io_diagnostics_components"]["system_dia_sub_header_1"])
        self.lbl_rs232_header.setStyleSheet(
            "border:0px solid lightgrey;font: 15px Regular Inter;color:#696667;text-align:left;font-weight:bold;")
        self.lbl_rs232_header.resize(280, 27)
        self.lbl_rs232_header.move(10, 45)
        self.lbl_rs232_header.setParent(self.frm_system_diagnostics)
        self.btn_rS232_com1 = QPushButton()
        self.btn_rS232_com1.setText("COM 1")
        self.btn_rS232_com1.setFont(QFont('Inter', 15))
        self.btn_rS232_com1.resize(100, 40)
        self.btn_rS232_com1.move(20, 80)
        self.btn_rS232_com1.clicked.connect(lambda: self.test_port('COM1'))
        self.btn_rS232_com1.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn_rS232_com1.setGraphicsEffect(shadow)
        self.btn_rS232_com1.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:black;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          "QPushButton::disabled"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:solid lightgrey;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          )
        self.btn_rS232_com2 = QPushButton()
        self.btn_rS232_com2.setText("COM 2")
        self.btn_rS232_com2.setFont(QFont('Inter', 15))
        self.btn_rS232_com2.resize(100, 40)
        self.btn_rS232_com2.move(160, 80)
        self.btn_rS232_com2.clicked.connect(lambda: self.test_port('COM2'))
        self.btn_rS232_com2.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn_rS232_com2.setGraphicsEffect(shadow)
        self.btn_rS232_com2.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:black;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          "QPushButton::disabled"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:solid lightgrey;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          )
        self.btn_rS232_com3 = QPushButton()
        self.btn_rS232_com3.setText("COM 3")
        self.btn_rS232_com3.setFont(QFont('Inter', 15))
        self.btn_rS232_com3.resize(100, 40)
        self.btn_rS232_com3.move(300, 80)
        self.btn_rS232_com3.clicked.connect(lambda: self.test_port('COM3'))
        self.btn_rS232_com3.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn_rS232_com3.setGraphicsEffect(shadow)
        self.btn_rS232_com3.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:black;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          "QPushButton::disabled"
                                          "{"
                                          "background-color:#f5f5f0;"
                                          "color:solid lightgrey;"
                                          "border : 2px solid #ffa31a;"
                                          "border-radius : 4px;"
                                          "font-weight:bold;"
                                          "}"
                                          )
        self.btn1 = QPushButton()
        self.btn1.setText(GlobalVariable.language_setting_items["io_diagnostics_components"]["default_status"])
        self.btn1.setFont(QFont('Inter', 14))
        self.btn1.resize(100, 40)
        self.btn1.move(20, 250)
        self.btn1.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn1.setGraphicsEffect(shadow)
        self.btn1.setStyleSheet("QPushButton"
                                "{"
                                "background-color:#f5f5f0;"
                                "color:black;"
                                "border : 2px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                "QPushButton::disabled"
                                "{"
                                "background-color:#f5f5f0;"
                                "color:solid lightgrey;"
                                "border : 2px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                )

        self.btn2 = QPushButton()
        self.btn2.setText(GlobalVariable.language_setting_items["io_diagnostics_components"]["connect_status"])
        self.btn2.setFont(QFont('Inter', 14))
        self.btn2.resize(100, 40)
        self.btn2.move(160, 250)
        self.btn2.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn2.setGraphicsEffect(shadow)
        self.btn2.setStyleSheet("QPushButton"
                                "{"
                                "background-color:#2C6E49;"
                                "color:white;"
                                "border : 0px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                "QPushButton::disabled"
                                "{"
                                "background-color:#f5f5f0;"
                                "color:solid lightgrey;"
                                "border : 2px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                )
        self.btn3 = QPushButton()
        self.btn3.setText(GlobalVariable.language_setting_items["io_diagnostics_components"]["error_status"])
        self.btn3.setFont(QFont('Inter', 14))
        self.btn3.resize(100, 40)
        self.btn3.move(300, 250)
        self.btn3.setParent(self.frm_system_diagnostics)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(13)
        self.btn3.setGraphicsEffect(shadow)
        self.btn3.setStyleSheet("QPushButton"
                                "{"
                                "background-color:#c1121f;"
                                "color:white;"
                                "border : 0px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                "QPushButton::disabled"
                                "{"
                                "background-color:#c1121f;"
                                "color:solid lightgrey;"
                                "border : 2px solid #ffa31a;"
                                "border-radius : 4px;"
                                "font-weight:bold;"
                                "}"
                                )
        self.lbl = QLabel(self.frm_system_diagnostics)
        self.lbl.setText(GlobalVariable.language_setting_items["io_diagnostics_components"]["note"])
        self.lbl.setFont(QFont('Inter', 12))
        self.lbl.setStyleSheet("color: rgb(17, 50, 238);font-weight:bold;")
        self.lbl.move(20, 210)
        self.HorizontalLyt.addWidget(self.frm_system_diagnostics)
