from PyQt5.QtWidgets import QFrame, QLabel
from Presentation.Bundles.UiConfiguration import ROOT_PATH


class SettingsAccessDeniedUi:
    def __init__(self):
        super().__init__()

    def main_layout_Ui(self):

        for i in reversed(range(self.hlyt_main.count())):
            self.hlyt_main.itemAt(i).widget().deleteLater()

        self.frmMainLytAccessDenied = QFrame(self)
        self.lblMainAccessDeniedBg = QLabel(self.frmMainLytAccessDenied)
        self.lblMainAccessDeniedBg.resize(661, 429)
        self.lblMainAccessDeniedBg.setParent(self.frmMainLytAccessDenied)
        self.lblMainAccessDeniedBg.setStyleSheet("QLabel"
                                                 "{"
                                                 "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/MainLytAccessDenied.png); "
                                                                                        "border : none ;"
                                                                                        "background-color:transparent;"
                                                                                        "}"
                                                 )
        self.hlyt_main.addWidget(self.frmMainLytAccessDenied)

    def sub_layout_Ui(self):
        for i in reversed(range(self.HorizontalLyt.count())):
            self.HorizontalLyt.itemAt(i).widget().deleteLater()

        self.frmSubLytAccessDenied = QFrame(self)
        self.lblSubAccessDeniedBg = QLabel(self.frmSubLytAccessDenied)
        self.lblSubAccessDeniedBg.resize(521, 430)
        self.lblSubAccessDeniedBg.setParent(self.frmSubLytAccessDenied)
        self.lblSubAccessDeniedBg.setStyleSheet("QLabel"
                                                "{"
                                                "background-image :url(" + ROOT_PATH + "Images/MainScreenImages/SubLytAccessDenied.png); "
                                                                                       "border : none ;"
                                                                                       "background-color:transparent;"
                                                                                       "}"
                                                )
        self.HorizontalLyt.addWidget(self.frmSubLytAccessDenied)
