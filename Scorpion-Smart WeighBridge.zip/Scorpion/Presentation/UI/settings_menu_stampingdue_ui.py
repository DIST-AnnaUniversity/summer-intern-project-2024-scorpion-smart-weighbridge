from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTableWidget, QGraphicsDropShadowEffect, QPushButton, QLineEdit, QLabel, QFrame, QWidget, \
    QCheckBox

from Presentation.Bundles.UiConfiguration import ROOT_PATH


class SettingsStampingDueUi:
    def __init__(self):
        super().__init__()

    def create_stamping_due_ui(self):
        try:
            for i in reversed(range(self.hlyt_main.count())):
                self.hlyt_main.itemAt(i).widget().deleteLater()

            self.frm_stamping_due = QFrame(self)

            self.lbl_stamping_due = QLabel(self.frm_stamping_due)
            self.lbl_stamping_due.resize(996, 693)
            self.lbl_stamping_due.setParent(self.frm_stamping_due)
            self.lbl_stamping_due.setStyleSheet("QLabel"
                                                "{"

                                                "background-color : white; "
                                                "}"
                                                )
            self.lbl_header = QLabel()
            self.lbl_header.setText("Stamping Due"
                                    )
            self.lbl_header.setFont(QFont('Inter', 15))
            self.lbl_header.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_header.resize(500, 41)
            self.lbl_header.move(8, 8)
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.lbl_header.setGraphicsEffect(shadow)
            self.lbl_header.setParent(self.frm_stamping_due)
            self.btn_browse = QPushButton()
            self.btn_browse.resize(62, 32)
            self.btn_browse.setFont(QFont('Inter', 10))
            self.btn_browse.move(320, 17)
            self.btn_browse.setText("Browse")
            self.btn_browse.clicked.connect(self.on_click_browse_stamping_image)
            self.btn_browse.setStyleSheet("border:0px solid lightgrey;")
            self.btn_browse.setParent(self.frm_stamping_due)
            self.btn_browse.setStyleSheet("QPushButton"
                                          "{"
                                          "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 5px;"
                                          "}"
                                          "QPushButton:hover"
                                          "{"
                                          "background-color:black; color: white;border: 0px solid grey;border-radius : 5px;"
                                          "}"
                                          )

            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_browse.setGraphicsEffect(shadow)
            self.btn_stamping_due = QPushButton()
            self.btn_stamping_due.resize(62, 32)
            self.btn_stamping_due.setFont(QFont('Inter', 10))
            self.btn_stamping_due.move(420, 17)
            self.btn_stamping_due.setText("edit")
            self.btn_stamping_due.clicked.connect(self.on_click_stamping_due)
            self.btn_stamping_due.setStyleSheet("border:0px solid lightgrey;")
            self.btn_stamping_due.setParent(self.frm_stamping_due)
            self.btn_stamping_due.setStyleSheet("QPushButton"
                                                "{"
                                                "background-color:#ededed; color: black;border: 0px solid grey;border-radius : 5px;"
                                                "}"
                                                "QPushButton:hover"
                                                "{"
                                                "background-color:black; color: white;border: 0px solid grey;border-radius : 5px;"
                                                "}"
                                                )
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(13)
            self.btn_stamping_due.setGraphicsEffect(shadow)
            self.lbl_stamping_image = QLabel()
            self.lbl_stamping_image.resize(550, 200)
            self.lbl_stamping_image.setStyleSheet("QLabel"
                                                  "{"
                                                  "color:grey;"
                                                  "background-color:white;"
                                                  "border:1px solid black;"
                                                  "}"
                                                  )
            self.lbl_stamping_image.setAlignment(Qt.AlignCenter)
            self.lbl_stamping_image.move(30, 200)


            self.lbl_stamping_image.setText("Browse Image")
            self.lbl_stamping_image.setFont(QFont('Inter', 15))
            self.lbl_stamping_image.setParent(self.frm_stamping_due)

            self.lbl_user_name_header = QLabel()
            self.lbl_user_name_header.setText("User Name"
                                       )
            self.lbl_user_name_header.setFont(QFont('Inter', 13))
            self.lbl_user_name_header.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_user_name_header.resize(500, 41)
            self.lbl_user_name_header.move(50, 60)
            self.lbl_user_name_header.setParent(self.frm_stamping_due)

            self.lbl_user_name = QLabel()
            self.lbl_user_name.setText("NA"
                                       )
            self.lbl_user_name.setFont(QFont('Inter', 13))
            self.lbl_user_name.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_user_name.resize(500, 41)
            self.lbl_user_name.move(200, 60)
            self.lbl_user_name.setParent(self.frm_stamping_due)

            self.lbl_stamping_date_header = QLabel()
            self.lbl_stamping_date_header.setText("Stamping Date"
                                              )
            self.lbl_stamping_date_header.setFont(QFont('Inter', 13))
            self.lbl_stamping_date_header.setStyleSheet(
                "text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_stamping_date_header.resize(500, 41)
            self.lbl_stamping_date_header.move(50, 100)
            self.lbl_stamping_date_header.setParent(self.frm_stamping_due)

            self.lbl_stamping_date = QLabel()
            self.lbl_stamping_date.setText("NA"
                                       )
            self.lbl_stamping_date.setFont(QFont('Inter', 13))
            self.lbl_stamping_date.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_stamping_date.resize(500, 41)
            self.lbl_stamping_date.move(200, 100)
            self.lbl_stamping_date.setParent(self.frm_stamping_due)

            self.lbl_stamping_time_header = QLabel()
            self.lbl_stamping_time_header.setText("Stamping Time"
                                              )

            self.lbl_stamping_time_header.setFont(QFont('Inter', 13))
            self.lbl_stamping_time_header.setStyleSheet(
                "text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_stamping_time_header.resize(500, 41)
            self.lbl_stamping_time_header.move(50, 150)
            self.lbl_stamping_time_header.setParent(self.frm_stamping_due)

            self.lbl_stamping_time = QLabel()
            self.lbl_stamping_time.setText("NA"
                                           )
            self.lbl_stamping_time.setFont(QFont('Inter', 13))
            self.lbl_stamping_time.setStyleSheet("text-align: left;border:0px solid grey;background-color:transparent")
            self.lbl_stamping_time.resize(500, 41)
            self.lbl_stamping_time.move(200, 150)
            self.lbl_stamping_time.setParent(self.frm_stamping_due)

            '''panel messsage'''
            self.pnl_password = QWidget()
            self.pnl_password.setStyleSheet("border:0px solid grey;")
            self.pnl_password.resize(340, 180)
            self.pnl_password.move(80, 120)
            self.pnl_password.setParent(self.frm_stamping_due)
            self.pnl_password.raise_()
            self.lbl_password_bg = QLabel()
            self.lbl_password_bg.setFont(QFont('Inter', 10))
            self.lbl_password_bg.setStyleSheet(
                "background-color: rgb(244, 244, 244);border:1px solid  rgb(165, 165, 165);border-radius:10px;")
            # "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/header_save.png);")
            self.lbl_password_bg.resize(340, 180)
            self.lbl_password_bg.move(0, 0)
            self.lbl_password_bg.setParent(self.pnl_password)
            self.lbl_password_header = QLabel()
            self.lbl_password_header.resize(200, 50)
            self.lbl_password_header.move(15, 10)
            self.lbl_password_header.setFont(QFont('Inter', 15))
            self.lbl_password_header.setText("Enter Password")
            self.lbl_password_header.setStyleSheet(
                "background-color: transparent;")
            self.lbl_password_header.raise_()
            self.lbl_password_header.setParent(self.pnl_password)

            self.txt_password = QLineEdit()
            self.txt_password.move(50, 80)
            self.txt_password.resize(230, 35)
            self.txt_password.setMaxLength(50)
            self.txt_password.setFont(QFont('Inter', 12))
            self.txt_password.setParent(self.pnl_password)
            self.txt_password.setStyleSheet(
                "font-weight:bold;background-color: rgb(255, 255, 255);border-radius: 7px;border: 2px solid lightgrey;")

            self.chk_show_password = QCheckBox()
            self.chk_show_password.move(160, 55)
            self.chk_show_password.resize(111, 20)
            self.chk_show_password.setText("Show Password")
            self.chk_show_password.setParent(self.pnl_password)
            self.chk_show_password.stateChanged.connect(self.on_click_show_password)
            self.chk_show_password.setStyleSheet("font: 12px Regular Inter;background-color:transparent"
                                                 )

            self.btn_password_ok = QPushButton()
            self.btn_password_ok.resize(72, 42)
            self.btn_password_ok.move(30, 130)
            self.btn_password_ok.clicked.connect(self.on_click_password_ok)
            self.btn_password_ok.setParent(self.pnl_password)
            self.btn_password_ok.setStyleSheet("QPushButton"
                                               "{"
                                               "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/Ok.png); "
                                                                                      "border : none "
                                                                                      "}"
                                                                                      "QPushButton::hover"
                                                                                      "{"
                                                                                      "background-image :url(" + ROOT_PATH + "Images/SettingScreenImages/OkHover.png); "
                                                                                                                             "}")

            self.btn_password_cancel = QPushButton()
            self.btn_password_cancel.resize(72, 42)
            self.btn_password_cancel.move(240, 130)
            self.btn_password_cancel.clicked.connect(self.on_click_password_cancel)
            self.btn_password_cancel.setParent(self.pnl_password)
            self.btn_password_cancel.setStyleSheet("QPushButton"
                                                   "{"
                                                   "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/Cancel.png); "
                                                                                          "border : none "
                                                                                          "}"
                                                                                          "QPushButton::hover"
                                                                                          "{"
                                                                                          "background-image :url(" + ROOT_PATH + "Images/VehicleEntryImages/CancelHover.png); "
                                                                                                                                 "}")

            self.hlyt_main.addWidget(self.frm_stamping_due)
            pass
        except Exception as e:
            print(e)
