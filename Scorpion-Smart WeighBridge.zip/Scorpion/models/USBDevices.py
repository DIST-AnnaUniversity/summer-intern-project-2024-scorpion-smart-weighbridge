import subprocess


class USBDevices:
    @staticmethod
    def get_usb_devices():
        # Run the shell command to get mount points
        output = subprocess.check_output(['mount']).decode('utf-8')

        # Split the output by lines
        lines = output.split('\n')

        # List to store device names and mount points
        devices = []

        # Iterate over each line
        for line in lines:
            # Check if the line contains '/dev/sd'
            if '/dev/sd' in line:
                # Split the line by spaces
                parts = line.split(' ')
                # Extract device name and mount point
                mount_point = parts[2]
                # Append to the devices list if mount point is not empty
                if mount_point:
                    devices.append({'mount_point': mount_point})

        # no devices are found
        if not devices:
            return []

        return devices

    @classmethod
    def fetch_usb_devices(cls):
        usb_devices = cls.get_usb_devices()
        lst_mount_device = []
        for device in usb_devices:
            mount_point = device['mount_point']
            lst_mount_device.append(mount_point)
        return lst_mount_device
