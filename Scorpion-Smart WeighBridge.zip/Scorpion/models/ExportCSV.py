import csv
import glob
import os
from datetime import datetime
from PyQt5.QtCore import QDateTime
from models.USBDevices import USBDevices


class ExportCSV:
    def __init__(self):
        self.row_count = None
        self.current_date_time = None

    def export_to_csv(self, widget_name, folder_name=None, sub_folder_name=None,sub_folder2_name = None,
                      application_name=None):
        try:
            """fetch the row count of table widget """
            self.row_count = widget_name.rowCount()
            if not self.row_count == 0:
                """fetch current date and time """
                self.current_date_time = QDateTime.currentDateTime()
                current_date = self.current_date_time.toString('dd-MM-yyyy')
                current_datetime = datetime.now().strftime("%Y-%m-%d %H-%M-%S")

                usb_device = USBDevices.fetch_usb_devices()

                if not len(usb_device) == 0:
                    for device in usb_device:
                        print(device)
                        for count, path_name in enumerate(glob.glob(device)):
                            """create folder path """
                            if sub_folder2_name:
                                folder_path = path_name + '/' + folder_name + '/' + sub_folder_name + '/' + sub_folder2_name + '/' + current_date + '/'
                            else:
                                folder_path = path_name + '/' + folder_name + '/' + sub_folder_name + '/' + current_date + '/'

                            """fetch the type of report cumulative or detailed """
                            if os.path.isdir(folder_path):
                                pass
                            else:
                                os.makedirs(folder_path, exist_ok=True)
                            """created file name """
                            file_name = f'ReportData {current_datetime}.csv'

                            with open(folder_path + file_name, 'w+') as stream:
                                writer = csv.writer(stream, lineterminator='\n')
                                headers = []

                                """ display headers for the excel """
                                lst_project_header = []
                                lst_project_header.extend(['', '', '', application_name, '\n', '\n'])
                                writer.writerow(lst_project_header)

                                for column in range(widget_name.columnCount()):
                                    header = widget_name.horizontalHeaderItem(column)
                                    headers.append(header.text() if header else f"Column {column}")
                                writer.writerow(headers)

                                for row in range(widget_name.rowCount()):
                                    row_data = [
                                        widget_name.item(row, column).text() if widget_name.item(row, column) else ''
                                        for column in range(widget_name.columnCount())]
                                    writer.writerow(row_data)

                            print("Exported Successfully!!!")
                            return "Exported Successfully!!!"
                else:
                    print("No Device Found!!!")
                    return "No Device Found!!!"
            else:
                print("No Data to download")
                return "No Data to download"

        except Exception as err:
            print("No Device Found!!!")
            print(err)
            return "No Device Found!!!"
