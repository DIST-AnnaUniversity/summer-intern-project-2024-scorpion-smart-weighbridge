import glob
import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image, Paragraph, Spacer

from models.USBDevices import USBDevices
from Presentation.Bundles.UiConfiguration import ROOT_PATH


class ExportPDF:

    def __init__(self):
        self.current_date_time = None

    def export_to_pdf(self, pdf_data, folder_name=None, sub_folder_name=None,sub_folder2_name = None,
                      header1=None, header2=None, header3=None, logo_image=None):
        try:
            """fetch current date and time """
            self.current_date_time = datetime.now()
            current_date = self.current_date_time.strftime("%d-%m-%y")
            current_datetime = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
            if len(pdf_data) > 0:
                inch = 55
                pg_size = (23 * inch, 10 * inch)
                dt = datetime.now()
                date = dt.strftime("%d-%m-%Y")
                time = dt.strftime("%H:%M:%S")
                usb_device = USBDevices.fetch_usb_devices()
                if not len(usb_device) == 0:
                    for device in usb_device:
                        print(device)
                        for count, path_name in enumerate(glob.glob(device)):
                            if sub_folder2_name:
                                folder_path = path_name + '/' + folder_name + '/' + sub_folder_name + '/' + sub_folder2_name + '/' + current_date + '/'
                            else:
                                folder_path = path_name + '/' + folder_name + '/' + sub_folder_name + '/' + current_date + '/'
                            file_name = f'ReportData {current_datetime}.pdf'
                            if not os.path.isdir(folder_path):
                                os.makedirs(folder_path, exist_ok=True)

                            pdfdata = SimpleDocTemplate(folder_path + file_name, pagesize=pg_size)
                            elements = []
                            tableobj = Table(pdf_data)
                            tableobj.setStyle(TableStyle(
                                [
                                    ('BACKGROUND', (0, 0), (-1, 0), colors.white),
                                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.blue),
                                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                    ('FONTNAME', (0, 0), (-1, 0), 'Courier-Bold'),

                                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                                    ('FONTSIZE', (0, 0), (-1, 0), 9),
                                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                    ('BOX', (0, 0), (-1, -1), 1, colors.lightgrey),
                                    ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey)
                                ]
                            ))
                            style = getSampleStyleSheet()
                            elements.append(Paragraph(f"{header1}", style=ParagraphStyle('abc',
                                                                                         fontName="Helvetica-Bold",
                                                                                         fontSize=15,
                                                                                         parent=style[
                                                                                             'Heading2'],
                                                                                         alignment=1,
                                                                                         spaceAfter=15
                                                                                         )))
                            elements.append(
                                Image(ROOT_PATH + 'Images/Logo/' + logo_image, 0.5 * inch, 0.5 * inch,
                                      hAlign='LEFT'))
                            elements.append(Spacer(0, -30))
                            elements.append(Paragraph(f"{header2}", style=ParagraphStyle('abc',
                                                                                         fontName="Helvetica-Bold",
                                                                                         fontSize=12,
                                                                                         parent=style[
                                                                                             'Heading2'],
                                                                                         alignment=1,
                                                                                         spaceAfter=15
                                                                                         )))
                            elements.append(Paragraph(f"{header3}", style=ParagraphStyle('abc',
                                                                                         fontName="Helvetica-Bold",
                                                                                         fontSize=12,
                                                                                         parent=style[
                                                                                             'Heading2'],
                                                                                         alignment=1,
                                                                                         spaceAfter=15
                                                                                         )))
                            elements.append(Spacer(0, -0))
                            elements.append(Paragraph(f"DateTime: {date} {' '} {time}",
                                                      style=ParagraphStyle('abc',
                                                                           fontName="Helvetica-Bold",
                                                                           fontSize=10,
                                                                           alignment=2
                                                                           )))
                            elements.append(Spacer(0, 15))
                            elements.append(tableobj)
                            pdfdata.build(elements)
                            print("Exported Successfully")
                            return "Exported Successfully!!!"
                else:
                    print("No Device Found")
                    return "No Device Found!!"
            else:
                print("No Data to Download")
                return "No Data to Download!!!"
        except Exception as err:
            print("No Device Found")
            print(err)
            return "No Device Found!!!"
