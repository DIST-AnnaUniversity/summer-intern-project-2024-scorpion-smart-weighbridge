
import firebase_admin
from firebase_admin import credentials, firestore
from Presentation.Bundles.UiConfiguration import FIREBASE_JSON

cred = credentials.Certificate(FIREBASE_JSON)
firebase_admin.initialize_app(credential=cred)
firestore_client = firestore.client()

"""A function for sending pop-up notification to mobile application """


class Mobile_Notifications:
    def __init__(self):
        super().__init__()

    def send_data_to_firestore_db(self, lst_parameters):
        try:
            update_data = firestore_client.collection('scorpionUser').document('lcs_scorpion_01')
            update_data.update(
                {
                    'deviceId': 'panther_scorpion_01',
                    'deviceInfo': {
                        'appId': 0,
                        'deviceName': 'Scorpion'
                    },
                    'vehicleEntry': {
                        'amount': int(lst_parameters[4]),
                        'transactions': int(lst_parameters[2])
                    },
                    'vehicleReentry': {
                        'amount': int(lst_parameters[5]),
                        'transactions': int(lst_parameters[3])
                    }

                }
            )
        except Exception as e:
            print(e)